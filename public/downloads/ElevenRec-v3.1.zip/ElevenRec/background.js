"use strict";

importScripts("lib/license-er.js");

const ALLOWED_HOST = /(^|\.)elevenreader\.io$/i;


async function injectPanel(tabId) {
  const result = await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    func: () => {
      if (window.ElevenRec && typeof window.ElevenRec.togglePanel === "function") {
        window.ElevenRec.togglePanel();
        return true;
      }
      return false;
    }
  });
  const alreadyLoaded = Boolean(result?.[0]?.result);
  if (!alreadyLoaded) {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["inject.js"],
      world: "MAIN"
    });
  }
  await chrome.action.setBadgeText({ text: "ON", tabId });
  await chrome.action.setBadgeBackgroundColor({ color: "#00C853", tabId });
}

async function injectGate(tabId) {
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["gate.js"]
  });
  await chrome.action.setBadgeText({ text: "LOCK", tabId });
  await chrome.action.setBadgeBackgroundColor({ color: "#FF9100", tabId });
}

/* License messages from the gate overlay */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || (msg.type !== "er-lic-status" && msg.type !== "er-lic-activate")) return;
  (async () => {
    if (msg.type === "er-lic-status") {
      sendResponse({ ok: true, status: await ER_LIC.status() });
      return;
    }
    const res = await ER_LIC.activate(String(msg.key || ""));
    if (res.ok && sender.tab && sender.tab.id) {
      try { await injectPanel(sender.tab.id); } catch (e) { console.error("[ElevenRec] post-activation inject failed:", e); }
    }
    sendResponse(res);
  })();
  return true;
});

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id || !tab.url) return;

  let hostname = "";
  try {
    hostname = new URL(tab.url).hostname;
  } catch {
    return;
  }

  if (!ALLOWED_HOST.test(hostname)) {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        alert("ElevenRec শুধু elevenreader.io তে কাজ করবে।");
      }
    });
    return;
  }

  /* License lock (v3.1): no valid ER1 key — activation gate, no panel. */
  const lic = await ER_LIC.status().catch(() => ({ licensed: false }));
  if (!lic.licensed) {
    try { await injectGate(tab.id); } catch (err) { console.error("[ElevenRec] Gate injection error:", err); }
    return;
  }

  try {
    const result = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: () => {
        if (window.ElevenRec && typeof window.ElevenRec.togglePanel === "function") {
          window.ElevenRec.togglePanel();
          return true;
        }
        return false;
      }
    });

    const alreadyLoaded = Boolean(result?.[0]?.result);

    if (!alreadyLoaded) {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["inject.js"],
        world: "MAIN"
      });
    }

    // Badge update
    await chrome.action.setBadgeText({ text: "ON", tabId: tab.id });
    await chrome.action.setBadgeBackgroundColor({ color: "#00C853", tabId: tab.id });

  } catch (err) {
    console.error("[ElevenRec] Injection error:", err);
    await chrome.action.setBadgeText({ text: "ERR", tabId: tab.id });
    await chrome.action.setBadgeBackgroundColor({ color: "#FF1744", tabId: tab.id });
  }
});

// Badge clear on navigation
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status === "complete") {
    const isTarget = ALLOWED_HOST.test((() => {
      try { return new URL(tab.url || "").hostname; } catch { return ""; }
    })());
    if (!isTarget) {
      chrome.action.setBadgeText({ text: "", tabId });
    }
  }
});
