/* ElevenRec — activation gate overlay (v3.1).
 * Injected by the service worker ONLY when no valid license is stored.
 * Talks to the worker (er-lic-status / er-lic-activate); on success the
 * worker injects the real recorder panel and this overlay removes itself. */
(() => {
  "use strict";
  if (window.__erGateShown) return;
  window.__erGateShown = true;

  const host = document.createElement("div");
  host.style.cssText = "position:fixed;top:18px;right:18px;z-index:2147483647;width:320px;";
  const shadow = host.attachShadow({ mode: "open" });
  shadow.innerHTML = `
    <style>
      .card{background:#0a0a0f;border:1px solid rgba(0,212,255,.25);border-radius:16px;padding:20px 18px;color:#e8f6ff;font-family:Inter,system-ui,sans-serif;box-shadow:0 18px 50px rgba(0,0,0,.6)}
      .lock{font-size:34px;text-align:center}
      h2{margin:8px 0 4px;font-size:17px;text-align:center}
      p{margin:0 0 10px;font-size:12.5px;line-height:1.55;color:#9db8c4;text-align:center}
      .lbl{display:block;font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:#7fa6b5;margin:12px 0 5px}
      .idrow{display:flex;gap:7px}
      .idrow code{flex:1;display:flex;align-items:center;justify-content:center;font-size:15.5px;font-weight:700;letter-spacing:.06em;background:rgba(255,255,255,.05);border:1px dashed rgba(255,255,255,.3);border-radius:9px;padding:8px 4px;user-select:all}
      button{cursor:pointer;border-radius:9px;border:1px solid rgba(255,255,255,.16);background:rgba(255,255,255,.06);color:#e8f6ff;font-weight:700;font-size:12.5px;padding:8px 12px}
      .order{display:flex;justify-content:center;width:100%;box-sizing:border-box;margin-top:11px;background:#22c55e;border-color:#22c55e;color:#06281a;font-weight:800;text-decoration:none;border-radius:9px;padding:10px;font-size:13px}
      textarea{width:100%;box-sizing:border-box;resize:vertical;font-family:monospace;font-size:12px;padding:8px;border-radius:9px;background:rgba(255,255,255,.05);color:#e8f6ff;border:1px solid rgba(255,255,255,.16)}
      .act{width:100%;margin-top:10px;background:linear-gradient(135deg,#00b8e6,#0090b8);border:none;color:#fff;font-size:13.5px;padding:11px}
      .err{color:#ff8585;font-size:12px;line-height:1.5;margin-top:8px;display:none}
      .x{position:absolute;top:8px;right:10px;background:none;border:none;color:#7fa6b5;font-size:16px;padding:2px 6px}
      .wrap{position:relative}
      .foot{margin-top:10px;font-size:10.5px;color:#5f7d89;text-align:center}
    </style>
    <div class="card wrap">
      <button class="x" id="g-close" title="Close">✕</button>
      <div class="lock">🔒</div>
      <h2>ElevenRec is locked</h2>
      <p>Send your Install ID to order a license key, then paste the key here.</p>
      <span class="lbl">Your Install ID</span>
      <div class="idrow"><code id="g-id">…………</code><button id="g-copy" type="button">Copy</button></div>
      <a class="order" id="g-order" href="https://wa.me/8801957566098" target="_blank" rel="noopener">🛒 Order key on WhatsApp</a>
      <span class="lbl">License key</span>
      <textarea id="g-key" rows="3" placeholder="ER1.…………" spellcheck="false"></textarea>
      <div class="err" id="g-err"></div>
      <button class="act" id="g-act" type="button">Activate</button>
      <div class="foot">One key per browser · ElevenRec by AMIN SHEIKH</div>
    </div>`;
  document.documentElement.appendChild(host);

  const $ = (id) => shadow.getElementById(id);
  const showErr = (msg) => { const e = $("g-err"); e.textContent = msg || ""; e.style.display = msg ? "block" : "none"; };

  chrome.runtime.sendMessage({ type: "er-lic-status" }, (res) => {
    if (res && res.status) {
      $("g-id").textContent = res.status.installId || "…………";
      $("g-order").href = "https://wa.me/8801957566098?text=" +
        encodeURIComponent("Hello, I want an ElevenRec license key.\nMy Install ID: " + (res.status.installId || ""));
      if (res.status.reason === "expired") showErr("Your previous license has expired — order a new key for this Install ID.");
      else if (res.status.reason === "other-id") showErr("The saved key belongs to a different Install ID — order a key for THIS ID.");
      else if (res.status.reason === "bad-key") showErr("The saved key is not valid anymore — paste a fresh key.");
    }
  });

  $("g-copy").addEventListener("click", async () => {
    try { await navigator.clipboard.writeText($("g-id").textContent.trim()); $("g-copy").textContent = "Copied ✓"; setTimeout(() => { $("g-copy").textContent = "Copy"; }, 1600); } catch (e) {}
  });
  $("g-close").addEventListener("click", () => { host.remove(); });
  $("g-act").addEventListener("click", () => {
    const key = $("g-key").value.trim();
    if (!key) { showErr("Paste your license key first."); return; }
    chrome.runtime.sendMessage({ type: "er-lic-activate", key }, (res) => {
      if (res && res.ok) { host.remove(); }
      else showErr((res && res.error) || "Activation failed — check the key and try again.");
    });
  });
})();
