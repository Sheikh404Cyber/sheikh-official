(() => {
  "use strict";

  if (window.ElevenRec?.loaded) {
    window.ElevenRec.togglePanel();
    return;
  }

  // ============================================================
  //  STATE
  // ============================================================
  const state = {
    loaded: true,
    panelVisible: true,
    minimized: false,
    sheikhMode: false,
    capturing: false,
    chunks: [],
    totalBytes: 0,
    startedAt: null,
    timerId: null,
    lastMessageAt: null,
    captureCount: 0,
    finalReceived: false
  };

  const processedEvents = new WeakSet();
  const wrappedListeners = new WeakMap();
  const wrappedOnMessage = new WeakMap();

  // ============================================================
  //  HELPERS
  // ============================================================
  const formatBytes = (bytes) => {
    if (!Number.isFinite(bytes) || bytes <= 0) return "0 B";
    const units = ["B", "KB", "MB", "GB"];
    const index = Math.min(Math.floor(Math.log(bytes) / Math.log(1024)), units.length - 1);
    return `${(bytes / Math.pow(1024, index)).toFixed(index === 0 ? 0 : 1)} ${units[index]}`;
  };

  const formatTime = (seconds) => {
    const s = Math.max(0, Math.floor(seconds || 0));
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    if (h > 0) return `${h}h ${m}m ${sec}s`;
    if (m > 0) return `${m}m ${sec}s`;
    return `${sec}s`;
  };

  const decodeBase64 = (input) => {
    if (typeof input !== "string") return null;
    let value = input.trim();
    const match = value.match(/^data:audio\/[^;]+;base64,(.+)$/i);
    if (match) value = match[1];
    value = value.replace(/\s+/g, "").replace(/-/g, "+").replace(/_/g, "/");
    if (value.length < 40 || !/^[A-Za-z0-9+/=]+$/.test(value)) return null;
    while (value.length % 4 !== 0) value += "=";
    try {
      const binary = atob(value);
      if (!binary.length) return null;
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      return bytes;
    } catch { return null; }
  };

  // ============================================================
  //  UI HELPERS
  // ============================================================
  const ui = { host: null, shadow: null };
  const $ = (id) => ui.shadow?.getElementById(id);

  const setStatus = (message, tone = "idle") => {
    const el = $("er-status");
    if (!el) return;
    el.textContent = message;
    el.dataset.tone = tone;
  };

  const updateCaptureBtn = () => {
    const btn = $("er-capture");
    if (!btn) return;
    if (state.capturing) {
      btn.className = "btn btn-stop";
      btn.innerHTML = `
        <svg viewBox="0 0 24 24" fill="currentColor">
          <rect x="5" y="5" width="14" height="14" rx="2"/>
        </svg>
        Capture Stop Korun`;
    } else {
      btn.className = "btn btn-start";
      btn.innerHTML = `
        <svg viewBox="0 0 24 24" fill="currentColor">
          <circle cx="12" cy="12" r="7"/>
          <circle cx="12" cy="12" r="3" fill="#000"/>
        </svg>
        Capture Shuru Korun`;
    }
  };

  const updateUi = () => {
    if (!ui.shadow) return;
    const size   = $("er-size");
    const chunks = $("er-chunks");
    const time   = $("er-time");
    const save   = $("er-save");
    const clear  = $("er-clear");
    const sheikh = $("er-sheikh");
    const bars   = $("er-bars");
    const panel  = $("er-panel");

    if (size)   size.textContent   = formatBytes(state.totalBytes);
    if (chunks) chunks.textContent = String(state.captureCount);
    if (time) {
      const elapsed = state.startedAt ? (Date.now() - state.startedAt) / 1000 : 0;
      time.textContent = formatTime(elapsed);
    }
    if (save)  save.disabled  = state.totalBytes === 0;
    if (clear) clear.disabled = state.totalBytes === 0;

    if (sheikh) {
      sheikh.className = "btn btn-sheikh" + (state.sheikhMode ? " active" : "");
      sheikh.innerHTML = state.sheikhMode
        ? `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>Sheikh Mode — ON`
        : `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>Sheikh Mode — OFF`;
    }

    if (bars) {
      const isActive = state.capturing && state.captureCount > 0;
      bars.classList.toggle("animating", isActive);
      bars.classList.toggle("recording", state.capturing);
    }

    if (panel) {
      panel.classList.toggle("capturing", state.capturing);
    }

    updateCaptureBtn();
  };

  const startTimer = () => {
    if (state.timerId) return;
    state.timerId = window.setInterval(updateUi, 500);
  };

  const stopTimer = () => {
    if (state.timerId) { clearInterval(state.timerId); state.timerId = null; }
  };

  // ============================================================
  //  CHUNK HANDLING
  // ============================================================
  const appendChunk = (bytes) => {
    if (!(bytes instanceof Uint8Array) || bytes.byteLength === 0) return;
    if (!state.capturing) return;
    if (!state.startedAt) { state.startedAt = Date.now(); startTimer(); }
    const copy = new Uint8Array(bytes.byteLength);
    copy.set(bytes);
    state.chunks.push(copy);
    state.totalBytes += copy.byteLength;
    state.captureCount += 1;
    state.lastMessageAt = Date.now();
    state.finalReceived = false;
    setStatus("Capture cholche...", "recording");
    updateUi();
  };

  const collectAudioValues = (value, found, depth = 0) => {
    if (depth > 5 || value == null) return;
    if (Array.isArray(value)) {
      for (const item of value) collectAudioValues(item, found, depth + 1);
      return;
    }
    if (typeof value !== "object") return;
    for (const [key, child] of Object.entries(value)) {
      const k = key.toLowerCase();
      if (typeof child === "string" &&
        ["audio","audio_base64","audiodata","audio_data","mp3"].includes(k)) {
        found.push(child);
      } else if (Array.isArray(child) &&
        ["audio","chunks","audio_chunks"].includes(k)) {
        for (const item of child) { if (typeof item === "string") found.push(item); }
      } else if (typeof child === "object" && child !== null) {
        collectAudioValues(child, found, depth + 1);
      }
    }
  };

  // ============================================================
  //  WEBSOCKET CAPTURE
  // ============================================================
  const handleSocketMessage = async (event) => {
    if (!event || typeof event !== "object") return;
    if (processedEvents.has(event)) return;
    processedEvents.add(event);
    try {
      if (typeof event.data === "string") {
        let payload;
        try { payload = JSON.parse(event.data); } catch { return; }
        const values = [];
        collectAudioValues(payload, values);
        for (const v of values) {
          const bytes = decodeBase64(v);
          if (bytes) appendChunk(bytes);
        }
        if (payload?.isFinal === true || payload?.is_final === true || payload?.final === true) {
          state.finalReceived = true;
          setStatus("Audio ready — Save korun!", "ready");
          updateUi();
        }
      } else if (event.data instanceof Blob && /^audio\//i.test(event.data.type || "")) {
        const bytes = new Uint8Array(await event.data.arrayBuffer());
        appendChunk(bytes);
      } else if (event.data instanceof ArrayBuffer) {
        appendChunk(new Uint8Array(event.data));
      }
    } catch (err) {
      console.debug("[ElevenRec] parse skip:", err);
    }
  };

  const installWebSocketCapture = () => {
    const NativeWS = window.WebSocket;
    if (!NativeWS || NativeWS.__erPatched) return;

    const nativeAdd    = NativeWS.prototype.addEventListener;
    const nativeRemove = NativeWS.prototype.removeEventListener;

    function ElevenRecWS(...args) {
      const socket = new NativeWS(...args);
      nativeAdd.call(socket, "message", handleSocketMessage);
      return socket;
    }

    Object.setPrototypeOf(ElevenRecWS, NativeWS);
    ElevenRecWS.prototype = NativeWS.prototype;
    for (const k of ["CONNECTING","OPEN","CLOSING","CLOSED"]) {
      Object.defineProperty(ElevenRecWS, k, { value: NativeWS[k], enumerable: true });
    }
    ElevenRecWS.__erPatched = true;
    ElevenRecWS.__native    = NativeWS;
    window.WebSocket = ElevenRecWS;

    NativeWS.prototype.addEventListener = function(type, listener, opts) {
      if (type !== "message" || !listener) return nativeAdd.call(this, type, listener, opts);
      let wrapped = wrappedListeners.get(listener);
      if (!wrapped) {
        if (typeof listener === "function") {
          wrapped = function(e) { handleSocketMessage(e); return listener.call(this, e); };
        } else if (typeof listener.handleEvent === "function") {
          wrapped = { handleEvent(e) { handleSocketMessage(e); listener.handleEvent.call(listener, e); } };
        } else { wrapped = listener; }
        wrappedListeners.set(listener, wrapped);
      }
      return nativeAdd.call(this, type, wrapped, opts);
    };

    NativeWS.prototype.removeEventListener = function(type, listener, opts) {
      return nativeRemove.call(this, type, wrappedListeners.get(listener) || listener, opts);
    };

    const desc = Object.getOwnPropertyDescriptor(NativeWS.prototype, "onmessage");
    if (desc?.get && desc?.set) {
      Object.defineProperty(NativeWS.prototype, "onmessage", {
        configurable: desc.configurable,
        enumerable  : desc.enumerable,
        get() { return wrappedOnMessage.get(this)?.original || desc.get.call(this); },
        set(listener) {
          if (typeof listener !== "function") {
            wrappedOnMessage.delete(this);
            return desc.set.call(this, listener);
          }
          const wrapped = (e) => { handleSocketMessage(e); return listener.call(this, e); };
          wrappedOnMessage.set(this, { original: listener, wrapped });
          return desc.set.call(this, wrapped);
        }
      });
    }
  };

  // ============================================================
  //  SHEIKH MODE (TURBO)
  // ============================================================
  const installSheikhMode = () => {
    const contexts = [window.AudioContext, window.webkitAudioContext].filter(Boolean);
    for (const Context of contexts) {
      const proto = Context.prototype;
      if (!proto || proto.__erTurboPatched) continue;
      const nativeCreateBufferSource = proto.createBufferSource;
      if (typeof nativeCreateBufferSource !== "function") continue;
      proto.createBufferSource = function(...args) {
        const source = nativeCreateBufferSource.apply(this, args);
        const nativeStart = source.start;
        source.start = function(...startArgs) {
          if (state.sheikhMode && source.playbackRate) {
            try { source.playbackRate.value = 200; }
            catch { try { source.playbackRate.setValueAtTime(200, this.context?.currentTime || 0); } catch {} }
          }
          return nativeStart.apply(this, startArgs);
        };
        return source;
      };
      Object.defineProperty(proto, "__erTurboPatched", { value: true, configurable: false });
    }
  };

  const updateMediaPlayback = () => {
    const rate = state.sheikhMode ? 16 : 1;
    for (const el of document.querySelectorAll("audio,video")) {
      try { el.playbackRate = rate; el.defaultPlaybackRate = rate; } catch {}
    }
  };

  const mediaObserver = new MutationObserver(() => {
    if (state.sheikhMode) updateMediaPlayback();
  });

  const toggleSheikhMode = () => {
    state.sheikhMode = !state.sheikhMode;
    updateMediaPlayback();
    setStatus(
      state.sheikhMode ? "Sheikh Mode ON — Akhon play korun!" : "Sheikh Mode OFF",
      state.sheikhMode ? "sheikh" : "idle"
    );
    updateUi();
  };

  // ============================================================
  //  CAPTURE START / STOP
  // ============================================================
  const startCapture = () => {
    if (state.capturing) return;
    state.capturing     = true;
    state.chunks        = [];
    state.totalBytes    = 0;
    state.captureCount  = 0;
    state.startedAt     = null;
    state.lastMessageAt = null;
    state.finalReceived = false;
    startTimer();
    setStatus("Capture shuru hoyeche — Play korun!", "recording");
    updateUi();
  };

  const stopCapture = () => {
    if (!state.capturing) return;
    state.capturing = false;
    stopTimer();
    if (state.totalBytes > 0) {
      setStatus("Capture complete — MP3 Save korun!", "ready");
    } else {
      setStatus("Kono audio pawa jay ni", "warning");
    }
    updateUi();
  };

  // ============================================================
  //  SAVE & CLEAR
  // ============================================================
  const saveAudio = () => {
    if (!state.chunks.length || state.totalBytes === 0) {
      setStatus("Kono audio capture hoyni!", "warning");
      return;
    }
    try {
      const blob   = new Blob(state.chunks, { type: "audio/mpeg" });
      const url    = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href     = url;
      anchor.download = `ElevenRec_${Date.now()}.mp3`;
      anchor.style.display = "none";
      document.documentElement.appendChild(anchor);
      anchor.click();
      anchor.remove();
      setTimeout(() => URL.revokeObjectURL(url), 15000);
      setStatus("MP3 download shuru hoyeche!", "ready");
    } catch (err) {
      console.error("[ElevenRec] save error:", err);
      setStatus("Save korা jacche na!", "warning");
    }
  };

  const clearAudio = () => {
    state.chunks        = [];
    state.totalBytes    = 0;
    state.startedAt     = null;
    state.lastMessageAt = null;
    state.captureCount  = 0;
    state.finalReceived = false;
    stopTimer();
    setStatus("Data clear hoyeche", "idle");
    updateUi();
  };

  // ============================================================
  //  CREATE UI
  // ============================================================
  const createUi = () => {
    const old = document.getElementById("eleven-rec-root");
    if (old) old.remove();

    const host = document.createElement("div");
    host.id = "eleven-rec-root";
    host.style.cssText = "all:initial;position:fixed;z-index:2147483647;right:24px;top:24px;";

    const shadow = host.attachShadow({ mode: "open" });

    shadow.innerHTML = `
    <style>
      :host { all: initial; }
      *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

      .panel {
        width: 310px;
        min-width: 260px;
        min-height: 200px;
        font-family: 'Segoe UI', Inter, Arial, sans-serif;
        background: #080808;
        border: 1px solid rgba(0,212,255,0.18);
        border-radius: 18px;
        overflow: hidden;
        box-shadow:
          0 0 0 1px rgba(0,212,255,0.04) inset,
          0 24px 60px rgba(0,0,0,0.9),
          0 0 50px rgba(0,212,255,0.05);
        transition: border-color 0.4s ease, box-shadow 0.4s ease;
        position: relative;
        resize: both;
      }

      .panel.capturing {
        border-color: rgba(255,23,68,0.35);
        box-shadow:
          0 0 0 1px rgba(255,23,68,0.05) inset,
          0 24px 60px rgba(0,0,0,0.9),
          0 0 50px rgba(255,23,68,0.08);
      }

      .panel.minimized .body { display: none; }

      /* SCAN LINE on capture */
      .panel.capturing::after {
        content: '';
        position: absolute;
        left: 0; right: 0; top: 0;
        height: 1px;
        background: linear-gradient(90deg, transparent 0%, rgba(255,23,68,0.6) 50%, transparent 100%);
        animation: scanline 2s linear infinite;
        pointer-events: none;
        z-index: 10;
      }
      @keyframes scanline {
        0%   { top: 0%; opacity: 1; }
        90%  { opacity: 1; }
        100% { top: 100%; opacity: 0; }
      }

      /* TOP ACCENT */
      .topline {
        height: 2px;
        background: linear-gradient(90deg, transparent 0%, #00D4FF 40%, #0077FF 60%, transparent 100%);
        transition: background 0.4s;
      }
      .panel.capturing .topline {
        background: linear-gradient(90deg, transparent 0%, #FF1744 40%, #FF4466 60%, transparent 100%);
        animation: topglow 1.5s ease-in-out infinite alternate;
      }
      @keyframes topglow {
        from { opacity: 0.7; }
        to   { opacity: 1; }
      }

      /* HEADER */
      .header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 12px 14px 10px;
        background: linear-gradient(135deg, #0a0a0a 0%, #0c1418 100%);
        border-bottom: 1px solid rgba(0,212,255,0.08);
        cursor: move;
      }

      .brand { display: flex; align-items: center; gap: 10px; }

      /* WAVE BARS */
      #er-bars {
        display: flex;
        align-items: center;
        gap: 2.5px;
        height: 26px;
        padding: 0 2px;
      }
      #er-bars .b {
        width: 3px;
        border-radius: 3px;
        background: #00D4FF;
        box-shadow: 0 0 5px rgba(0,212,255,0.5);
        transition: background 0.3s, box-shadow 0.3s;
      }
      #er-bars .b:nth-child(1) { height: 5px;  }
      #er-bars .b:nth-child(2) { height: 10px; }
      #er-bars .b:nth-child(3) { height: 17px; }
      #er-bars .b:nth-child(4) { height: 22px; }
      #er-bars .b:nth-child(5) { height: 17px; }
      #er-bars .b:nth-child(6) { height: 10px; }
      #er-bars .b:nth-child(7) { height: 5px;  }

      #er-bars.animating .b {
        animation: wavebar 0.6s ease-in-out infinite;
      }
      #er-bars.animating .b:nth-child(1) { animation-delay: 0.00s; }
      #er-bars.animating .b:nth-child(2) { animation-delay: 0.08s; }
      #er-bars.animating .b:nth-child(3) { animation-delay: 0.16s; }
      #er-bars.animating .b:nth-child(4) { animation-delay: 0.24s; }
      #er-bars.animating .b:nth-child(5) { animation-delay: 0.16s; }
      #er-bars.animating .b:nth-child(6) { animation-delay: 0.08s; }
      #er-bars.animating .b:nth-child(7) { animation-delay: 0.00s; }

      #er-bars.recording .b {
        background: #FF4466;
        box-shadow: 0 0 6px rgba(255,68,102,0.7);
      }

      @keyframes wavebar {
        0%, 100% { transform: scaleY(1);    opacity: 0.9; }
        50%       { transform: scaleY(0.2); opacity: 0.4; }
      }

      .title-wrap { display: flex; flex-direction: column; }
      .title-name {
        font-size: 14px;
        font-weight: 800;
        color: #fff;
        letter-spacing: 0.3px;
      }
      .title-sub {
        font-size: 8.5px;
        color: rgba(0,212,255,0.7);
        letter-spacing: 1.6px;
        text-transform: uppercase;
        margin-top: 1.5px;
      }

      .hbtns { display: flex; gap: 5px; }
      .hbtn {
        width: 26px; height: 26px;
        border: 1px solid rgba(255,255,255,0.07);
        border-radius: 7px;
        background: rgba(255,255,255,0.03);
        color: #666;
        cursor: pointer;
        display: flex; align-items: center; justify-content: center;
        transition: all 0.18s ease;
      }
      .hbtn svg { width: 12px; height: 12px; }
      .hbtn:hover { background: rgba(0,212,255,0.1); color: #00D4FF; border-color: rgba(0,212,255,0.25); }
      .hbtn.close:hover { background: rgba(255,23,68,0.12); color: #FF1744; border-color: rgba(255,23,68,0.25); }

      /* BODY */
      .body { padding: 12px 13px 13px; }

      /* STATUS */
      .status-row {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 8px 11px;
        background: rgba(255,255,255,0.025);
        border: 1px solid rgba(255,255,255,0.055);
        border-radius: 9px;
        margin-bottom: 10px;
        transition: border-color 0.3s;
      }
      .sdot {
        width: 7px; height: 7px;
        border-radius: 50%;
        background: #2a2a2a;
        flex-shrink: 0;
        transition: background 0.3s, box-shadow 0.3s;
      }
      #er-status[data-tone="recording"] ~ .sdot,
      .has-recording .sdot {
        background: #FF1744;
        box-shadow: 0 0 7px rgba(255,23,68,0.8);
        animation: pulsedot 0.9s ease-in-out infinite;
      }
      @keyframes pulsedot {
        0%,100% { transform: scale(1); }
        50%      { transform: scale(1.5); }
      }
      #er-status[data-tone="ready"]   { color: #00E676; }
      #er-status[data-tone="sheikh"]  { color: #00C853; }
      #er-status[data-tone="warning"] { color: #FF9100; }
      #er-status[data-tone="recording"] { color: #FF5252; }

      #er-status {
        font-size: 11px;
        color: #666;
        flex: 1;
        transition: color 0.25s;
      }

      /* METRICS */
      .metrics {
        display: grid;
        grid-template-columns: repeat(3,1fr);
        gap: 7px;
        margin-bottom: 10px;
      }
      .metric {
        background: #0c0c0c;
        border: 1px solid rgba(255,255,255,0.055);
        border-radius: 10px;
        padding: 8px 6px;
        text-align: center;
        transition: border-color 0.3s;
      }
      .panel.capturing .metric {
        border-color: rgba(255,23,68,0.15);
      }
      .mv {
        display: block;
        font-size: 13.5px;
        font-weight: 700;
        color: #00D4FF;
        transition: color 0.3s;
      }
      .panel.capturing .mv { color: #FF6680; }
      .ml {
        display: block;
        font-size: 8px;
        color: #383838;
        text-transform: uppercase;
        letter-spacing: 0.8px;
        margin-top: 3px;
      }

      /* CAPTURE BUTTON */
      .btn-start {
        width: 100%;
        padding: 11px 12px;
        border: none;
        border-radius: 10px;
        font-size: 12.5px;
        font-weight: 700;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 7px;
        letter-spacing: 0.3px;
        background: linear-gradient(135deg, #00C853 0%, #00E676 100%);
        color: #000;
        box-shadow: 0 4px 18px rgba(0,200,83,0.3);
        transition: all 0.2s ease;
        margin-bottom: 8px;
      }
      .btn-start:hover { transform: translateY(-2px); box-shadow: 0 6px 22px rgba(0,200,83,0.45); }
      .btn-start:active { transform: scale(0.97); }
      .btn-start svg { width: 14px; height: 14px; }

      .btn-stop {
        width: 100%;
        padding: 11px 12px;
        border: none;
        border-radius: 10px;
        font-size: 12.5px;
        font-weight: 700;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 7px;
        letter-spacing: 0.3px;
        background: linear-gradient(135deg, #FF1744 0%, #FF4466 100%);
        color: #fff;
        box-shadow: 0 4px 18px rgba(255,23,68,0.35);
        transition: all 0.2s ease;
        margin-bottom: 8px;
        animation: stopglow 1.5s ease-in-out infinite alternate;
      }
      @keyframes stopglow {
        from { box-shadow: 0 4px 18px rgba(255,23,68,0.3); }
        to   { box-shadow: 0 4px 28px rgba(255,23,68,0.6); }
      }
      .btn-stop:hover { transform: translateY(-2px); }
      .btn-stop:active { transform: scale(0.97); }
      .btn-stop svg { width: 14px; height: 14px; }

      /* OTHER BUTTONS */
      .btn {
        padding: 9px 12px;
        border: none;
        border-radius: 9px;
        font-size: 11.5px;
        font-weight: 700;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        transition: all 0.18s ease;
        letter-spacing: 0.2px;
      }
      .btn svg { width: 13px; height: 13px; flex-shrink: 0; }
      .btn:hover:not(:disabled) { transform: translateY(-1px); filter: brightness(1.12); }
      .btn:active:not(:disabled) { transform: scale(0.97); }
      .btn:disabled { opacity: 0.3; cursor: not-allowed; transform: none !important; filter: none !important; }

      .save-row {
        display: flex;
        gap: 7px;
        margin-bottom: 7px;
      }

      .btn-save {
        background: linear-gradient(135deg, #0088AA, #00B8D9);
        color: #000;
        box-shadow: 0 3px 14px rgba(0,184,217,0.25);
        flex: 1;
      }

      .btn-clear {
        background: rgba(255,255,255,0.04);
        color: #555;
        border: 1px solid rgba(255,255,255,0.07);
        padding: 9px 13px;
        flex-shrink: 0;
      }
      .btn-clear:hover:not(:disabled) {
        background: rgba(255,68,68,0.1);
        color: #FF5252;
        border-color: rgba(255,68,68,0.2);
      }

      .btn-sheikh {
        width: 100%;
        background: rgba(255,255,255,0.03);
        color: #444;
        border: 1px solid rgba(255,255,255,0.06);
        font-size: 11.5px;
      }
      .btn-sheikh.active {
        background: linear-gradient(135deg, rgba(0,200,83,0.15), rgba(0,200,83,0.06));
        color: #00E676;
        border-color: rgba(0,200,83,0.3);
        box-shadow: 0 0 14px rgba(0,200,83,0.12);
      }

      /* FOOTER */
      .footer {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-top: 10px;
        padding-top: 9px;
        border-top: 1px solid rgba(255,255,255,0.04);
      }
      .footer-brand {
        font-size: 8.5px;
        color: #222;
        letter-spacing: 1px;
        text-transform: uppercase;
      }
      .footer-brand span { color: rgba(0,212,255,0.35); }
      .footer-v { font-size: 8.5px; color: #1c1c1c; }
    </style>

    <div class="panel" id="er-panel">
      <div class="topline"></div>

      <div class="header" id="er-header">
        <div class="brand">
          <div id="er-bars">
            <div class="b"></div>
            <div class="b"></div>
            <div class="b"></div>
            <div class="b"></div>
            <div class="b"></div>
            <div class="b"></div>
            <div class="b"></div>
          </div>
          <div class="title-wrap">
            <span class="title-name">ElevenRec</span>
            <span class="title-sub">by Amin Sheikh</span>
          </div>
        </div>
        <div class="hbtns">
          <button class="hbtn" id="er-min">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
              <line x1="5" y1="12" x2="19" y2="12"/>
            </svg>
          </button>
          <button class="hbtn close" id="er-close">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
              <line x1="18" y1="6" x2="6" y2="18"/>
              <line x1="6" y1="6" x2="18" y2="18"/>
            </svg>
          </button>
        </div>
      </div>

      <div class="body">
        <div class="status-row" id="er-status-row">
          <span class="sdot" id="er-sdot"></span>
          <span id="er-status" data-tone="idle">Ready — ElevenReader e play dın</span>
        </div>

        <div class="metrics">
          <div class="metric">
            <span class="mv" id="er-size">0 B</span>
            <span class="ml">Captured</span>
          </div>
          <div class="metric">
            <span class="mv" id="er-chunks">0</span>
            <span class="ml">Chunks</span>
          </div>
          <div class="metric">
            <span class="mv" id="er-time">0s</span>
            <span class="ml">Duration</span>
          </div>
        </div>

        <button class="btn-start" id="er-capture">
          <svg viewBox="0 0 24 24" fill="currentColor">
            <circle cx="12" cy="12" r="7"/>
            <circle cx="12" cy="12" r="3" fill="#000"/>
          </svg>
          Capture Shuru Korun
        </button>

        <div class="save-row">
          <button class="btn btn-save" id="er-save" disabled>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/>
              <polyline points="7 10 12 15 17 10"/>
              <line x1="12" y1="15" x2="12" y2="3"/>
            </svg>
            MP3 Save Korun
          </button>
          <button class="btn btn-clear" id="er-clear" disabled>
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="3 6 5 6 21 6"/>
              <path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/>
            </svg>
          </button>
        </div>

        <button class="btn btn-sheikh" id="er-sheikh">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>
          </svg>
          Sheikh Mode — OFF
        </button>

        <div class="footer">
          <span class="footer-brand">ElevenRec <span>by AMIN SHEIKH</span></span>
          <span class="footer-v">v3.1</span>
        </div>
      </div>
    </div>
    `;

    document.documentElement.appendChild(host);
    ui.host   = host;
    ui.shadow = shadow;

    // ---- DRAG ----
    const header = shadow.getElementById("er-header");
    let dragging = false, offX = 0, offY = 0;

    header.addEventListener("mousedown", (e) => {
      if (e.target.closest("button")) return;
      dragging = true;
      const rect = host.getBoundingClientRect();
      offX = e.clientX - rect.left;
      offY = e.clientY - rect.top;
      host.style.right  = "auto";
      host.style.bottom = "auto";
      e.preventDefault();
    });
    window.addEventListener("mousemove", (e) => {
      if (!dragging) return;
      const maxX = Math.max(0, window.innerWidth  - host.offsetWidth);
      const maxY = Math.max(0, window.innerHeight - host.offsetHeight);
      host.style.left = Math.min(maxX, Math.max(0, e.clientX - offX)) + "px";
      host.style.top  = Math.min(maxY, Math.max(0, e.clientY - offY)) + "px";
    });
    window.addEventListener("mouseup", () => { dragging = false; });

    // ---- STATUS DOT SYNC ----
    const syncDot = () => {
      const sdot   = shadow.getElementById("er-sdot");
      const status = shadow.getElementById("er-status");
      if (!sdot || !status) return;
      const tone = status.dataset.tone;
      sdot.style.animation = "";
      sdot.style.background = "#2a2a2a";
      sdot.style.boxShadow  = "none";
      if (tone === "recording") {
        sdot.style.background = "#FF1744";
        sdot.style.boxShadow  = "0 0 8px rgba(255,23,68,0.8)";
        sdot.style.animation  = "pulsedot 0.9s ease-in-out infinite";
      } else if (tone === "ready") {
        sdot.style.background = "#00C853";
        sdot.style.boxShadow  = "0 0 7px rgba(0,200,83,0.7)";
      } else if (tone === "sheikh") {
        sdot.style.background = "#00C853";
        sdot.style.boxShadow  = "0 0 10px rgba(0,200,83,0.8)";
        sdot.style.animation  = "pulsedot 0.5s ease-in-out infinite";
      } else if (tone === "warning") {
        sdot.style.background = "#FF9100";
        sdot.style.boxShadow  = "0 0 7px rgba(255,145,0,0.6)";
      } else if (tone === "idle") {
        sdot.style.background = "#00D4FF";
        sdot.style.boxShadow  = "0 0 5px rgba(0,212,255,0.4)";
      }
    };

    // Override setStatus to also sync dot
    const origSetStatus = setStatus;
    window.__erSetStatus = (msg, tone) => {
      origSetStatus(msg, tone);
      setTimeout(syncDot, 10);
    };

    // ---- MINIMIZE ----
    shadow.getElementById("er-min").addEventListener("click", () => {
      state.minimized = !state.minimized;
      shadow.getElementById("er-panel").classList.toggle("minimized", state.minimized);
    });

    // ---- CLOSE ----
    shadow.getElementById("er-close").addEventListener("click", () => {
      state.panelVisible = false;
      host.style.display = "none";
    });

    // ---- CAPTURE ----
    shadow.getElementById("er-capture").addEventListener("click", () => {
      if (!state.capturing) startCapture();
      else stopCapture();
    });

    // ---- OTHER BUTTONS ----
    shadow.getElementById("er-save").addEventListener("click",   saveAudio);
    shadow.getElementById("er-clear").addEventListener("click",  clearAudio);
    shadow.getElementById("er-sheikh").addEventListener("click", toggleSheikhMode);

    syncDot();
    updateUi();
  };

  // ============================================================
  //  PANEL CONTROLS
  // ============================================================
  const showPanel = () => {
    if (!ui.host || !ui.host.isConnected) createUi();
    ui.host.style.display = "block";
    state.panelVisible = true;
  };

  const hidePanel = () => {
    if (ui.host) ui.host.style.display = "none";
    state.panelVisible = false;
  };

  const togglePanel = () => {
    if (state.panelVisible) hidePanel();
    else showPanel();
  };

  // ============================================================
  //  CHUNK COUNTER SYNC
  // ============================================================
  window.setInterval(() => {
    const el = $("er-chunks");
    if (el) el.textContent = String(state.captureCount);
  }, 500);

  // ============================================================
  //  INIT
  // ============================================================
  installWebSocketCapture();
  installSheikhMode();
  mediaObserver.observe(document.documentElement, { childList: true, subtree: true });
  createUi();

  window.ElevenRec = {
    loaded     : true,
    version    : "3.1.0",
    state,
    showPanel,
    hidePanel,
    togglePanel,
    clear      : clearAudio,
    save       : saveAudio
  };

  console.info("%cElevenRec v3.1 by AMIN SHEIKH",
    "background:#080808;color:#00D4FF;padding:4px 10px;border-radius:4px;font-weight:bold");
})();
