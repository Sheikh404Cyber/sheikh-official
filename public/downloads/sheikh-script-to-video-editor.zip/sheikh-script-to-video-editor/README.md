# Sheikh Script to Video Editor

Script + voiceover + timestamp-naam-wala image dilei **automatic video** baniye dey.
Sob kaj **tomar nijer computer ei** hoy — internet lage na, kono file cloud e jay na, kono paid API lage na.

---

## Chalate ja ja lagbe (ekbar install)

1. **Node.js** (LTS) — https://nodejs.org
2. **FFmpeg** — sohoj upay: PowerShell khule chalao
   ```
   winget install Gyan.FFmpeg
   ```
   Othoba https://www.gyan.dev/ffmpeg/builds/ theke namiye `bin` folder ta PATH e jog koro.
   Check korte: PowerShell/CMD te `ffmpeg -version` likhle version dekhabe.
3. **Google Chrome**

**npm install lagbe NA** — app ta zero-dependency, Node er built-in diyei chole.

## Prottekbar chalu kora

1. `start.bat` file e **double-click** koro.
2. Se Node.js ar FFmpeg ache kina check korbe, server chalu korbe, Chrome nijei khule jabe.
3. Chrome na khulle nije kholo: **http://127.0.0.1:3847**
4. Bondho korte start.bat er window ta bondho kore dao.

## Prothom video banano (step by step)

1. **Script file** (.txt) upload koro (na dileo video hobe, script sudhu dekhar jonno).
2. **Voiceover** upload koro (MP3/WAV/M4A). Etar doirghoi hobe video r doirgho.
3. **Image gula** upload koro. Prottektar naam hote hobe tar **start time**:
   `00-00-00.jpg`, `00-00-08.jpg`, `00-00-16.jpg` ... (erokom o cholbe: `00_00_18.png`, `00.00.36.webp`, `00:00:54.jpg`)
4. **Check Report** dekho — bhul thakle (duplicate time, ultapalta naam) ekhane laal kore dekhabe; thik kore abar dao. Prottek image protteker **porer image er time porjonto** thakbe, **sesh image voiceover sesh howa porjonto**.
5. **Timeline Preview** te prottek image er start/sesh/duration dekhte paba, chaile prottektar motion alada bodlate parba.
6. **Motion/Transition/Effect** pochondo moto sajao. Prothom bar: Motion = Automatic, Transition = Crossfade 0.5s rakho.
7. Music thakle upload koro — volume kom rakho, **Ducking on** rakho (kothar somoy music nijei aste hobe). Music chhoto hole nijei loop hobe.
8. Shape **16:9**, Resolution **1080p**, file er naam diye **Generate Video** chap dao.
9. Progress bar dekhabe; sesh hole **Video Download** button asbe. File ta app er `data` folder eo thake (server er job folder e).

**Project Save:** "Project Save Koro" chap dile ekta `.sheikh-project.json` file nambe — sob setting + file er naam thake (media file thake na). Pore "Project Kholo" diye seta khulle setting fire asbe; file gula ek e naam e abar upload korlei mile jabe (relink).

## v1.1 Update (2026-10-30) — Kapakapi (jitter) fix

Prothom version e zoom/pan er somoy chhobi halka **kapto** (FFmpeg zoompan er pixel-rounding somossa). Notun version e motion banano hoy **supersampling** diye: chhobi 4x boro kore, 2x size e motion baniye, sesh e namiye ana hoy. Frame-diff diye mepe dekha geche notun poddhoti **~1.4x beshi mosrin**. Tobu zoompan er sima onujayi khub halka kapuni thakte pare — beshi mone hole Motion Mode **Subtle** bebohar koro.
Update nite: notun ZIP ta **ager folder er uporei extract** kore overwrite koro — tomar upload kora file (data folder) kichu hobe na. Tarpor start.bat diye abar chalu kore render dao. Render e ektu beshi somoy lagte pare (boro size e kaj hoy bole).

## Ki ki TEST kore verified (2026-10-30, Linux test machine e)

- ✅ Timestamp parser + timeline: **19 ta unit test pass** (`node tests/parser-timeline.test.js`) — sort, start/end hisab, sesh image voiceover porjonto, duplicate/invalid dhora.
- ✅ **Asol render test pass** (`node tests/e2e.sample.js`): 5 image + 40s voiceover + music + ducking + grain + vignette + crossfade → output **thik 40.000s, 1280×720, 30fps, audio ache** (ffprobe diye check kora). Crossfade thakleo **duration drift hoy ni**.
- ✅ Cut transition + static motion + 9:16 portrait render pass (720×1280, 12.000s).
- ✅ Puro server flow test pass: upload → validate → render → download (10.000s er video, HTTP diye).

## Ekono test hoy ni / limitation

- ⚠️ **Windows e chaliye test kora hoy ni** — code Windows-compatible kore lekha (path, .bat launcher), kintu prothom bar Windows e chaliye dekhte hobe.
- ⚠️ **Caption video te purano (burn)** — code ache, kintu test render e burn diye verify kora hoy ni (sidecar SRT verified). FFmpeg e libass thakle kaj korbe (gyan.dev er full build e thake).
- ⚠️ **Automatic caption (voice sune nije lekha / STT)** — ei version e **nai**. SRT file dilei caption hobe. Bhitore mithya button rakha hoy ni.
- ⚠️ Boro project (200+ image) render e somoy lagbe — prottek image alada render hoy. Progress bar cholte thakbe, bondho koiro na.
- ⚠️ Zoom/pan e khub halka jitter thakte pare (v1.1 supersampling e onek komano hoyeche) — beshi mone hole Subtle mode bebohar koro.
- ⚠️ Glow effect code ache, kintu test render e use kore verify kora hoy ni.

## File structure (soja rakha hoyeche)

```
sheikh-script-to-video-editor/
  start.bat          <- double-click kore chalu
  server.js          <- local backend (127.0.0.1:3847)
  lib/timestamp.js   <- timestamp parser + timeline hisab
  lib/render.js      <- FFmpeg render engine
  public/            <- Chrome er interface (Banglish)
  tests/             <- unit + e2e test
  presets.json       <- default setting er reference
  data/              <- upload + render file (auto toiri hoy)
```

Original upload file kokhono delete hoy na — `data/<session>/inputs` e theke jay. `data` folder majhe majhe porishkar kore dio, jayga bachbe.
