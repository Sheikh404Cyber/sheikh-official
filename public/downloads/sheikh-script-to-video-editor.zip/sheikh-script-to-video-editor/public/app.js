'use strict';
// Sheikh Script to Video Editor — frontend logic (shob text Banglish)
const $ = (id) => document.getElementById(id);
const state = { sessionId: null, jobId: null, poll: null, neededFiles: null, validated: false };

function fmt(sec) {
  if (!isFinite(sec)) return '-';
  sec = Math.round(sec);
  const h = String(Math.floor(sec / 3600)).padStart(2, '0');
  const m = String(Math.floor((sec % 3600) / 60)).padStart(2, '0');
  const s = String(sec % 60).padStart(2, '0');
  return `${h}:${m}:${s}`;
}
function setStatus(t) { $('renderStatus').textContent = 'Status: ' + t; }

async function uploadFiles(field, files) {
  if (!files || !files.length) return;
  const fd = new FormData();
  if (state.sessionId) fd.append('sessionId', state.sessionId);
  for (const f of files) fd.append(field, f, f.name);
  setStatus('File upload hochche...');
  const r = await fetch('/api/upload', { method: 'POST', body: fd });
  const j = await r.json();
  if (!r.ok) { alert('Upload fail: ' + (j.error || 'jana jay ni')); return; }
  state.sessionId = j.sessionId;
  if (j.scriptText) $('scriptText').textContent = j.scriptText;
  setStatus('File upload hoye geche');
  checkRelink(j);
  validate();
}

function checkRelink(info) {
  if (!state.neededFiles) { $('relinkBox').classList.add('hidden'); return; }
  const need = state.neededFiles;
  const have = new Set(info.images || []);
  const missing = [];
  if (need.voiceover && info.voiceover !== need.voiceover) missing.push('Voiceover: ' + need.voiceover);
  for (const n of need.images || []) if (!have.has(n)) missing.push('Image: ' + n);
  if (missing.length) {
    $('relinkBox').textContent = 'Project khulecho — ei file gula ekhono deya hoy ni, ager naam ei abar upload koro:\n' + missing.join('\n');
    $('relinkBox').classList.remove('hidden');
  } else {
    $('relinkBox').textContent = 'Sob file mile geche — project ready.';
    $('relinkBox').classList.remove('hidden');
    state.neededFiles = null;
  }
}

const MOTIONS = ['zoom-in', 'zoom-out', 'pan-left', 'pan-right', 'pan-up', 'pan-down', 'ken-burns', 'static'];
const MOTION_BN = { 'zoom-in': 'Aste Aste Zoom In', 'zoom-out': 'Aste Aste Zoom Out', 'pan-left': 'Bame Sorbe', 'pan-right': 'Dane Sorbe', 'pan-up': 'Upore Sorbe', 'pan-down': 'Niche Sorbe', 'ken-burns': 'Ken Burns', 'static': 'Static (norbe na)' };

async function validate() {
  if (!state.sessionId) return;
  const r = await fetch('/api/validate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sessionId: state.sessionId }) });
  const j = await r.json();
  if (!r.ok) { $('errBox').textContent = j.error || 'Check fail'; return; }
  $('stImages').textContent = j.imageCount;
  $('stVoice').textContent = isFinite(j.voiceoverDuration) ? fmt(j.voiceoverDuration) : '-';
  $('stCover').textContent = j.items.length ? `0:00 theke ${fmt(j.voiceoverDuration)} porjonto` : '-';
  $('errBox').textContent = j.errors.length ? 'SOMOSSA:\n' + j.errors.join('\n') : '';
  $('warnBox').textContent = j.warnings.length ? 'Sotorko:\n' + j.warnings.join('\n') : '';
  state.validated = j.errors.length === 0 && j.items.length > 0;

  const tl = $('timeline');
  tl.innerHTML = '';
  if (!j.items.length) { tl.innerHTML = '<p class="hint">Ekhono timeline nai — image ar voiceover dao.</p>'; return; }
  j.items.forEach((it, i) => {
    const card = document.createElement('div');
    card.className = 'tcard' + (i === j.items.length - 1 ? ' last' : '');
    const sel = MOTIONS.map((mo) => `<option value="${mo}" ${mo === it.motion ? 'selected' : ''}>${MOTION_BN[mo]}</option>`).join('');
    card.innerHTML = `<img src="/api/thumb/${state.sessionId}/${encodeURIComponent(it.name)}" alt="">
      <div class="nm">${it.name}</div>
      <div>Shuru: ${fmt(it.start)} · Sesh: ${fmt(it.end)} · Somoy: ${it.duration}s${i === j.items.length - 1 ? ' (sesh image)' : ''}</div>
      <select data-motion="${it.name}">${sel}</select>`;
    tl.appendChild(card);
  });
}

function gatherSettings() {
  return {
    motionMode: $('motionMode').value,
    zoomIntensity: $('zoomIntensity').value / 100,
    transition: $('transition').value,
    transitionDuration: parseFloat($('transitionDuration').value),
    grain: $('fxGrain').checked, grainIntensity: $('fxGrainI').value / 100,
    shake: $('fxShake').checked, shakeIntensity: $('fxShakeI').value / 100,
    glow: $('fxGlow').checked, glowIntensity: $('fxGlowI').value / 100,
    vignette: $('fxVignette').checked, vignetteIntensity: $('fxVignetteI').value / 100,
    voiceVolume: $('voiceVolume').value / 100,
    musicVolume: $('musicVolume').value / 100,
    ducking: $('ducking').checked, duckingAmount: $('duckingAmount').value / 100,
    fadeIn: parseFloat($('fadeIn').value) || 0, fadeOut: parseFloat($('fadeOut').value) || 0,
    aspect: $('aspect').value, resolution: $('resolution').value,
    captions: $('captions').value, outputName: $('outputName').value.trim() || 'sheikh-video',
  };
}

function applySettings(s) {
  if (!s) return;
  const set = (id, v) => { if (v != null && $(id)) $(id).value = v; };
  const chk = (id, v) => { if (v != null && $(id)) $(id).checked = !!v; };
  set('motionMode', s.motionMode); set('zoomIntensity', Math.round((s.zoomIntensity || 1) * 100));
  set('transition', s.transition); set('transitionDuration', s.transitionDuration);
  chk('fxGrain', s.grain); set('fxGrainI', Math.round((s.grainIntensity || 0) * 100));
  chk('fxShake', s.shake); set('fxShakeI', Math.round((s.shakeIntensity || 0) * 100));
  chk('fxGlow', s.glow); set('fxGlowI', Math.round((s.glowIntensity || 0) * 100));
  chk('fxVignette', s.vignette); set('fxVignetteI', Math.round((s.vignetteIntensity || 0) * 100));
  set('voiceVolume', Math.round((s.voiceVolume || 1) * 100)); set('musicVolume', Math.round((s.musicVolume || 0) * 100));
  chk('ducking', s.ducking); set('duckingAmount', Math.round((s.duckingAmount || 0) * 100));
  set('fadeIn', s.fadeIn); set('fadeOut', s.fadeOut);
  set('aspect', s.aspect); set('resolution', s.resolution); set('captions', s.captions);
  set('outputName', s.outputName);
  refreshLabels();
}

function refreshLabels() {
  $('zoomVal').textContent = $('zoomIntensity').value + '%';
  $('transVal').textContent = $('transitionDuration').value + 's';
  $('voiceVolVal').textContent = $('voiceVolume').value + '%';
  $('musicVolVal').textContent = $('musicVolume').value + '%';
}

async function startRender() {
  if (!state.sessionId) { alert('Age file upload koro'); return; }
  if (!state.validated) { alert('Check Report e somossa ache — age thik koro, tarpor render dao'); return; }
  const overrides = {};
  document.querySelectorAll('[data-motion]').forEach((sel) => { overrides[sel.getAttribute('data-motion')] = sel.value; });
  $('renderError').classList.add('hidden');
  $('btnDownload').classList.add('hidden'); $('btnDownloadSrt').classList.add('hidden');
  $('btnCancel').classList.remove('hidden'); $('btnRender').disabled = true;
  setStatus('Render cholche...');
  const r = await fetch('/api/render', { method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ sessionId: state.sessionId, settings: gatherSettings(), motionOverrides: overrides }) });
  const j = await r.json();
  if (!r.ok) { $('btnRender').disabled = false; $('btnCancel').classList.add('hidden'); alert('Render shuru hoy ni: ' + (j.error || '')); return; }
  state.jobId = j.jobId;
  clearInterval(state.poll);
  state.poll = setInterval(pollJob, 1200);
  pollJob();
}

async function pollJob() {
  const r = await fetch('/api/jobs/' + state.jobId);
  const j = await r.json();
  $('progressBar').style.width = (j.progress || 0) + '%';
  $('progressText').textContent = j.stage + (j.state === 'running' ? ` (${j.progress || 0}%)` : '');
  if (j.state === 'done') {
    clearInterval(state.poll);
    $('btnCancel').classList.add('hidden'); $('btnRender').disabled = false;
    setStatus('Render sesh — video ready');
    const dl = $('btnDownload');
    dl.href = '/api/download/' + state.jobId;
    dl.classList.remove('hidden');
    if ($('captions').value === 'sidecar') {
      const ds = $('btnDownloadSrt');
      ds.href = '/api/download/' + state.jobId + '?file=srt';
      ds.classList.remove('hidden');
    }
  } else if (j.state === 'error' || j.state === 'cancelled') {
    clearInterval(state.poll);
    $('btnCancel').classList.add('hidden'); $('btnRender').disabled = false;
    setStatus(j.state === 'cancelled' ? 'Render bondho kora hoyeche' : 'Render fail koreche');
    const box = $('renderError');
    box.textContent = (j.error || 'Render fail') + (j.logTail ? '\n\n--- FFmpeg log (sesh ongsho) ---\n' + j.logTail : '');
    box.classList.remove('hidden');
  }
}

// ---- wiring ----
$('inScript').addEventListener('change', (e) => { $('fnScript').textContent = e.target.files[0]?.name || ''; uploadFiles('script', e.target.files); });
$('inVoice').addEventListener('change', (e) => { $('fnVoice').textContent = e.target.files[0]?.name || ''; uploadFiles('voiceover', e.target.files); });
$('inMusic').addEventListener('change', (e) => { $('fnMusic').textContent = e.target.files[0]?.name || ''; uploadFiles('music', e.target.files); });
$('inSrt').addEventListener('change', (e) => { $('fnSrt').textContent = e.target.files[0]?.name || ''; uploadFiles('srt', e.target.files); });
$('inImages').addEventListener('change', (e) => { $('fnImages').textContent = e.target.files.length + ' ta image'; uploadFiles('images', e.target.files); });
$('inFolder').addEventListener('change', (e) => {
  const imgs = [...e.target.files].filter((f) => /\.(jpe?g|png|webp)$/i.test(f.name));
  $('fnFolder').textContent = imgs.length + ' ta image (folder theke)';
  uploadFiles('images', imgs);
});
$('btnValidate').addEventListener('click', validate);
$('btnRender').addEventListener('click', startRender);
$('btnCancel').addEventListener('click', async () => { if (state.jobId) await fetch(`/api/jobs/${state.jobId}/cancel`, { method: 'POST' }); });
$('btnNew').addEventListener('click', () => { if (confirm('Notun project shuru korba? Ekhonkar sob file/setting muche jabe.')) location.reload(); });
for (const id of ['zoomIntensity', 'transitionDuration', 'voiceVolume', 'musicVolume']) $(id).addEventListener('input', refreshLabels);

$('btnSave').addEventListener('click', async () => {
  const data = { app: 'Sheikh Script to Video Editor', version: 1, name: $('projectName').value, settings: gatherSettings(), files: state.fileNames || {} };
  if (state.sessionId) {
    const r = await fetch('/api/validate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ sessionId: state.sessionId }) });
    const j = await r.json();
    data.files = { voiceover: $('fnVoice').textContent, images: (j.items || []).map((i) => i.name), music: $('fnMusic').textContent, srt: $('fnSrt').textContent, script: $('fnScript').textContent };
  }
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = ($('projectName').value || 'project').replace(/[^\w\- ]/g, '') + '.sheikh-project.json';
  a.click();
});

$('openProject').addEventListener('change', async (e) => {
  const f = e.target.files[0];
  if (!f) return;
  const data = JSON.parse(await f.text());
  $('projectName').value = data.name || 'Project';
  applySettings(data.settings);
  state.neededFiles = data.files || null;
  $('relinkBox').textContent = 'Project khulecho — ekhon file gula abar upload koro (ek e naam hole nijei mile jabe). Voiceover ar image gula age dao.';
  $('relinkBox').classList.remove('hidden');
});

refreshLabels();
