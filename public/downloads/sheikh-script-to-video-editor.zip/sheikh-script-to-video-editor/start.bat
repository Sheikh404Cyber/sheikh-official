@echo off
chcp 65001 >nul
title Sheikh Script to Video Editor
cd /d "%~dp0"

echo ============================================
echo   Sheikh Script to Video Editor
echo ============================================
echo.

where node >nul 2>nul
if errorlevel 1 (
  echo [SOMossa] Node.js pawa jay ni!
  echo Age Node.js install koro: https://nodejs.org  - LTS version ta nao.
  echo Install kore abar start.bat chalao.
  pause
  exit /b 1
)

where ffmpeg >nul 2>nul
if errorlevel 1 (
  echo [SOMossa] FFmpeg pawa jay ni!
  echo FFmpeg install na hole video render hobe na.
  echo Sohoj upay: PowerShell e ei command chalao:
  echo     winget install Gyan.FFmpeg
  echo Othoba https://www.gyan.dev/ffmpeg/builds/ theke download kore
  echo ffmpeg er bin folder ta Windows PATH e jog koro.
  echo Install kore abar start.bat chalao.
  pause
  exit /b 1
)

echo Node.js ar FFmpeg duitai ache. Server chalu hochche...
echo.
echo Chrome e ei address kholo:  http://127.0.0.1:3847
echo (Server bondho korte ei window ta bondho kore dao ba Ctrl+C chap dao)
echo.
start "" "http://127.0.0.1:3847"
node server.js
pause
