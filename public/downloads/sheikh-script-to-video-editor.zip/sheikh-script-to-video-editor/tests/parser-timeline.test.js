'use strict';
// Timestamp parser + timeline builder unit tests (spec section 15, case 1-6)
const assert = require('assert');
const { parseTimestamp, buildTimeline, assignMotion } = require('../lib/timestamp');

let pass = 0;
function t(name, fn) { fn(); pass++; console.log('PASS', name); }

// --- parser variants ---
t('HH-MM-SS', () => assert.strictEqual(parseTimestamp('00-01-05.jpg').seconds, 65));
t('HH_MM_SS', () => assert.strictEqual(parseTimestamp('00_00_18.png').seconds, 18));
t('HH.MM.SS', () => assert.strictEqual(parseTimestamp('00.00.36.webp').seconds, 36));
t('HH:MM:SS', () => assert.strictEqual(parseTimestamp('00:00:54.jpg').seconds, 54));
t('prefix/suffix', () => assert.strictEqual(parseTimestamp('img-00-02-00-final.jpeg').seconds, 120));
t('MM-SS', () => assert.strictEqual(parseTimestamp('01-30.jpg').seconds, 90));
t('ghonta', () => assert.strictEqual(parseTimestamp('01-00-00.jpg').seconds, 3600));
t('invalid name -> error', () => assert.ok(parseTimestamp('amar-photo.jpg').error));
t('invalid minute -> error', () => assert.ok(parseTimestamp('00-75-10.jpg').error));

// --- timeline (voiceover 90s, 4 images) ---
const files = ['00-01-05.jpg', '00-00-00.jpg', '00-00-36.jpg', '00-00-18.jpg'].map((name) => ({ name }));
const tl = buildTimeline(files, 90);
t('case1: numeric sort', () => assert.deepStrictEqual(tl.items.map((i) => i.start), [0, 18, 36, 65]));
t('case2: start times thik', () => assert.deepStrictEqual(tl.items.map((i) => i.name),
  ['00-00-00.jpg', '00-00-18.jpg', '00-00-36.jpg', '00-01-05.jpg']));
t('case3: prottekta porer tay sesh', () => {
  assert.strictEqual(tl.items[0].end, 18); assert.strictEqual(tl.items[0].duration, 18);
  assert.strictEqual(tl.items[1].end, 36); assert.strictEqual(tl.items[1].duration, 18);
  assert.strictEqual(tl.items[2].end, 65); assert.strictEqual(tl.items[2].duration, 29);
  assert.strictEqual(tl.items[3].end, 90); assert.strictEqual(tl.items[3].duration, 25);
});
t('case4: sesh image voiceover sesh porjonto (65s file nijei sesh start)', () => {
  const tl2 = buildTimeline([{ name: '00-00-00.jpg' }, { name: '00-00-30.jpg' }], 50);
  assert.strictEqual(tl2.items[1].end, 50);
  assert.strictEqual(tl2.items[1].duration, 20);
});

// --- errors ---
t('case5: duplicate timestamp dhora pore', () => {
  const d = buildTimeline([{ name: '00-00-10.jpg' }, { name: 'img_00_00_10.png' }], 60);
  assert.ok(d.errors.some((e) => /Duplicate/.test(e)));
});
t('case6: invalid filename report hoy', () => {
  const d = buildTimeline([{ name: 'photo.jpg' }], 60);
  assert.ok(d.errors.length > 0);
});
t('unsupported format report hoy', () => {
  const d = buildTimeline([{ name: '00-00-00.bmp' }], 60);
  assert.ok(d.errors.some((e) => /Unsupported/.test(e)));
});
t('voiceover er pore shuru hole error', () => {
  const d = buildTimeline([{ name: '00-00-00.jpg' }, { name: '00-02-00.jpg' }], 60);
  assert.ok(d.errors.some((e) => /voiceover sesh/.test(e)));
});

// --- motion assign ---
t('motion porpor ek hoy na (auto)', () => {
  const items = assignMotion(tl.items.concat([{ name: 'x', start: 0, end: 1, duration: 1 }, { name: 'y', start: 1, end: 2, duration: 1 }, { name: 'z', start: 2, end: 3, duration: 1 }]), 'auto');
  for (let i = 1; i < items.length; i++) assert.notStrictEqual(items[i].motion, items[i - 1].motion);
});
t('static mode', () => {
  const items = assignMotion(tl.items, 'static');
  assert.ok(items.every((i) => i.motion === 'static'));
});

console.log(`\nSob pass: ${pass} ta test`);
