'use strict';
// A/B smoothness test: purono chain (2x, direct) vs notun chain (4x -> 2x -> lanczos downscale)
// Zoom-in segment e por por frame er difference er spike maplei jitter bojha jay.
const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { motionFilter } = require('../lib/render');

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'sheikh-smooth-'));
const img = path.join(dir, 'detail.png');
// detail-wala image (flat color e jitter bojha jay na)
execFileSync('ffmpeg', ['-y', '-v', 'error', '-f', 'lavfi', '-i', 'mandelbrot=s=1280x720', '-frames:v', '1', img]);

const W = 1280, H = 720, FPS = 30, LEN = 6, F = LEN * FPS;
const oldChain = `scale=${W * 2}:${H * 2}:force_original_aspect_ratio=increase,crop=${W * 2}:${H * 2},zoompan=z='1+(1.0800-1)*on/${F - 1}':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=${F}:s=${W}x${H}:fps=${FPS}`;
const newChain = motionFilter('zoom-in', LEN, W, H, FPS, 0.08);

function renderSeg(chain, out) {
  execFileSync('ffmpeg', ['-y', '-v', 'error', '-i', img, '-vf', chain, '-frames:v', String(F),
    '-c:v', 'libx264', '-preset', 'veryfast', '-pix_fmt', 'yuv420p', out]);
}
function frameDiffs(video) {
  const { spawnSync } = require('child_process');
  const r = spawnSync('ffmpeg', ['-i', video, '-vf',
    'tblend=all_mode=difference,signalstats,metadata=print:key=lavfi.signalstats.YAVG',
    '-f', 'null', '-'], { maxBuffer: 64 * 1024 * 1024 });
  const out = (r.stderr || Buffer.alloc(0)).toString();
  return [...out.matchAll(/YAVG=([\d.]+)/g)].map((m) => parseFloat(m[1]));
}
function stats(name, diffs) {
  const d = diffs.slice(5, 60); // majhkhaner ongsho
  const mean = d.reduce((a, b) => a + b, 0) / d.length;
  const max = Math.max(...d);
  const sd = Math.sqrt(d.reduce((a, b) => a + (b - mean) ** 2, 0) / d.length);
  console.log(`${name}: mean-diff=${mean.toFixed(3)} max=${max.toFixed(3)} spike-ratio=${(max / mean).toFixed(2)} jabrabhab(CV)=${(sd / mean).toFixed(2)}`);
  return { mean, max, cv: sd / mean };
}

renderSeg(oldChain, path.join(dir, 'old.mp4'));
renderSeg(newChain, path.join(dir, 'new.mp4'));
const a = stats('PURONO (2x direct)', frameDiffs(path.join(dir, 'old.mp4')));
const b = stats('NOTUN (supersample)', frameDiffs(path.join(dir, 'new.mp4')));
if (b.cv < a.cv) console.log(`\nRESULT: notun chain mosrin beshi — jabrabhab ${(a.cv / b.cv).toFixed(1)}x kom`);
else console.log('\nRESULT: unnoti pawa jay ni');
console.log('dir:', dir);
