'use strict';
/**
 * E2E sample test (spec section 15, case 7-12):
 * 5 ta timestamp image + 40s voiceover + music diye asol render,
 * tarpor ffprobe diye check: duration, size, fps, audio ache kina.
 * Aro ekta chhoto render: cut transition + 9:16 portrait + static motion.
 */
const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { buildTimeline, assignMotion } = require('../lib/timestamp');
const { render, probe } = require('../lib/render');

function sh(cmd, args) { execFileSync(cmd, args, { stdio: 'pipe' }); }

async function main() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'sheikh-e2e-'));
  const imgDir = path.join(dir, 'inputs');
  fs.mkdirSync(imgDir, { recursive: true });
  const colors = ['0x3a6ea5', '0x7cb350', '0xc0653a', '0x6a4a8c', '0x3aa58c'];
  const names = ['00-00-00.jpg', '00-00-08.jpg', '00-00-16.jpg', '00-00-24.jpg', '00-00-32.jpg'];
  const images = {};
  names.forEach((n, i) => {
    const p = path.join(imgDir, n);
    sh('ffmpeg', ['-y', '-f', 'lavfi', '-i', `color=c=${colors[i]}:s=1280x720`, '-frames:v', '1', p]);
    images[n] = p;
  });
  const voice = path.join(imgDir, 'voice.mp3');
  sh('ffmpeg', ['-y', '-f', 'lavfi', '-i', 'sine=frequency=440:duration=40', '-c:a', 'libmp3lame', voice]);
  const music = path.join(imgDir, 'music.mp3');
  sh('ffmpeg', ['-y', '-f', 'lavfi', '-i', 'sine=frequency=220:duration=10', '-c:a', 'libmp3lame', music]);
  const srt = path.join(imgDir, 'cap.srt');
  fs.writeFileSync(srt, '1\n00:00:01,000 --> 00:00:05,000\nProthom caption\n\n2\n00:00:20,000 --> 00:00:25,000\nDitiyo caption\n');

  // --- Render 1: fade transition, auto motion, music+ducking, grain+vignette, sidecar srt, 720p ---
  const tl = buildTimeline(names.map((name) => ({ name })), 40);
  if (tl.errors.length) throw new Error('timeline error: ' + tl.errors.join('; '));
  const items = assignMotion(tl.items, 'auto');
  const settings = { width: 1280, height: 720, fps: 30, motionMode: 'auto', zoomIntensity: 1,
    transition: 'fade', transitionDuration: 0.5, grain: true, grainIntensity: 0.4,
    shake: false, glow: false, vignette: true, vignetteIntensity: 0.5,
    voiceVolume: 1, musicVolume: 0.3, ducking: true, duckingAmount: 0.7,
    fadeIn: 1, fadeOut: 2, captions: 'sidecar', outputName: 'sample-fade' };
  const r1 = await render({ dir: path.join(dir, 'job1'), images, voiceover: voice, music, srt, items, settings },
    (p, s2) => process.stdout.write(`\r[render1] ${p}% ${s2}        `));
  console.log('\nrender1 done:', r1);
  if (Math.abs(r1.duration - 40) > 0.75) throw new Error('case8 fail: duration drift ' + r1.duration);
  if (r1.width !== 1280 || r1.height !== 720) throw new Error('case11 fail: size ' + r1.width + 'x' + r1.height);
  if (r1.fps !== 30) throw new Error('case11 fail: fps ' + r1.fps);
  const pj = await probe(r1.outputPath);
  if (!(pj.streams || []).some((x) => x.codec_type === 'audio')) throw new Error('case9 fail: audio nai');
  if (!fs.existsSync(r1.outputPath.replace(/\.mp4$/, '.srt'))) throw new Error('sidecar srt hoy ni');
  console.log('PASS render1 (fade, music+ducking, grain+vignette, sidecar srt, case 7/8/9/10/11)');

  // --- Render 2: cut + static + portrait 9:16, voiceover only ---
  const names2 = ['00-00-00.jpg', '00-00-05.jpg'];
  const images2 = { '00-00-00.jpg': images['00-00-00.jpg'], '00-00-05.jpg': images['00-00-08.jpg'] };
  const voice2 = path.join(imgDir, 'voice2.mp3');
  sh('ffmpeg', ['-y', '-f', 'lavfi', '-i', 'sine=frequency=330:duration=12', '-c:a', 'libmp3lame', voice2]);
  const tl2 = buildTimeline(names2.map((name) => ({ name })), 12);
  const items2 = assignMotion(tl2.items, 'static');
  const settings2 = { ...settings, width: 720, height: 1280, transition: 'cut', captions: 'none', outputName: 'sample-cut', grain: false, vignette: false };
  const r2 = await render({ dir: path.join(dir, 'job2'), images: images2, voiceover: voice2, music: null, srt: null, items: items2, settings: settings2 },
    (p, s2) => process.stdout.write(`\r[render2] ${p}% ${s2}        `));
  console.log('\nrender2 done:', r2);
  if (r2.width !== 720 || r2.height !== 1280) throw new Error('portrait size fail');
  console.log('PASS render2 (cut, static, 9:16 portrait, voiceover only)');
  console.log('\nE2E SOB PASS. Sample dir:', dir);
}

main().catch((e) => { console.error('\nE2E FAIL:', e.message); process.exit(1); });
