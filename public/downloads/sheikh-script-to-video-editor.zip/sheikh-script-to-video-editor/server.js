'use strict';
/**
 * Sheikh Script to Video Editor — local backend server.
 * Sudhu 127.0.0.1 e bind hoy (bahir theke access na).
 * Zero npm dependency — Node.js built-in diye chole.
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { buildTimeline, assignMotion, fmtTime } = require('./lib/timestamp');
const renderLib = require('./lib/render');

const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const DATA = path.join(ROOT, 'data');
fs.mkdirSync(DATA, { recursive: true });

const PORT = process.env.PORT || 3847;
const sessions = new Map(); // id -> { dir, voiceover, music, srt, script, images: Map name->path }
const jobs = new Map();     // id -> { state, progress, stage, error, result, job }

const MIME = { '.html': 'text/html; charset=utf-8', '.css': 'text/css', '.js': 'text/javascript',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp',
  '.mp4': 'video/mp4', '.json': 'application/json', '.srt': 'text/plain; charset=utf-8' };

function send(res, code, body, type = 'application/json; charset=utf-8') {
  const data = typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body);
  res.writeHead(code, { 'Content-Type': type, 'Content-Length': Buffer.byteLength(data) });
  res.end(data);
}

function safeName(name) {
  const base = path.basename(String(name || '')).replace(/[<>:"|?*]/g, '_');
  return base || 'file';
}

function readBody(req, limit = 800 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (c) => { size += c.length; if (size > limit) { reject(new Error('File onek boro')); req.destroy(); } chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

// Khub simple multipart parser (local tool er jonno jothesto)
function parseMultipart(body, boundary) {
  const parts = [];
  const bBuf = Buffer.from('--' + boundary);
  let idx = body.indexOf(bBuf);
  while (idx !== -1) {
    let start = idx + bBuf.length;
    if (body[start] === 13 && body[start + 1] === 10) start += 2;
    if (body[start] === 45 && body[start + 1] === 45) break; // -- = sesh
    const headerEnd = body.indexOf('\r\n\r\n', start);
    if (headerEnd === -1) break;
    const headers = body.slice(start, headerEnd).toString('utf8');
    const next = body.indexOf(bBuf, headerEnd + 4);
    if (next === -1) break;
    let dataEnd = next - 2; // \r\n before boundary
    if (dataEnd < headerEnd + 4) dataEnd = headerEnd + 4;
    const data = body.slice(headerEnd + 4, dataEnd);
    const nameM = /name="([^"]+)"/.exec(headers);
    const fileM = /filename="([^"]*)"/.exec(headers);
    parts.push({ field: nameM && nameM[1], filename: fileM && fileM[1], data });
    idx = next;
  }
  return parts;
}

async function handleUpload(req, res) {
  const ct = req.headers['content-type'] || '';
  const bm = /boundary=(.+)$/.exec(ct);
  if (!bm) return send(res, 400, { error: 'Multipart boundary pawa jay ni' });
  const body = await readBody(req);
  const parts = parseMultipart(body, bm[1].trim());

  let sessionId = null;
  const sidPart = parts.find((p) => p.field === 'sessionId' && !p.filename);
  if (sidPart) sessionId = sidPart.data.toString('utf8').trim();
  if (!sessionId || !sessions.has(sessionId)) {
    sessionId = crypto.randomBytes(8).toString('hex');
    const dir = path.join(DATA, sessionId);
    fs.mkdirSync(path.join(dir, 'inputs'), { recursive: true });
    sessions.set(sessionId, { dir, voiceover: null, music: null, srt: null, script: null, images: new Map() });
  }
  const sess = sessions.get(sessionId);
  const inDir = path.join(sess.dir, 'inputs');

  for (const p of parts) {
    if (!p.filename) continue;
    const fname = safeName(p.filename);
    const dest = path.join(inDir, fname);
    fs.writeFileSync(dest, p.data);
    if (p.field === 'voiceover') sess.voiceover = dest;
    else if (p.field === 'music') sess.music = dest;
    else if (p.field === 'srt') sess.srt = dest;
    else if (p.field === 'script') sess.script = dest;
    else if (p.field === 'images') sess.images.set(fname, dest);
  }

  const info = { sessionId, images: [...sess.images.keys()],
    voiceover: sess.voiceover ? path.basename(sess.voiceover) : null,
    music: sess.music ? path.basename(sess.music) : null,
    srt: sess.srt ? path.basename(sess.srt) : null,
    script: sess.script ? path.basename(sess.script) : null };
  if (sess.voiceover) {
    try { info.voiceoverDuration = await renderLib.probeDuration(sess.voiceover); } catch { info.voiceoverDuration = NaN; }
  }
  if (sess.script) {
    try { info.scriptText = fs.readFileSync(sess.script, 'utf8').slice(0, 200000); } catch {}
  }
  return send(res, 200, info);
}

async function handleValidate(req, res) {
  const { sessionId } = JSON.parse((await readBody(req)).toString('utf8') || '{}');
  const sess = sessions.get(sessionId);
  if (!sess) return send(res, 404, { error: 'Session pawa jay ni — abar file upload koro' });

  let duration = NaN;
  const errors = [], warnings = [];
  if (!sess.voiceover) errors.push('Voiceover file deya hoy ni.');
  else {
    try { duration = await renderLib.probeDuration(sess.voiceover); if (!(duration > 0)) throw new Error('bad'); }
    catch { errors.push('Voiceover duration pora jachche na — file ta nosto hote pare.'); }
  }

  // image decode check
  const fileList = [];
  for (const [name, p] of sess.images) {
    try { await renderLib.probeImage(p); fileList.push({ name }); }
    catch { errors.push(`Image decode kora jay ni: ${name}`); }
  }

  const tl = buildTimeline(fileList, duration);
  errors.push(...tl.errors);
  warnings.push(...tl.warnings);
  const items = assignMotion(tl.items, 'auto');
  return send(res, 200, { items, errors, warnings, voiceoverDuration: duration,
    totalText: fmtTime(duration || 0), imageCount: fileList.length });
}

async function handleRender(req, res) {
  const body = JSON.parse((await readBody(req)).toString('utf8') || '{}');
  const sess = sessions.get(body.sessionId);
  if (!sess) return send(res, 404, { error: 'Session pawa jay ni' });
  const s = body.settings || {};
  // resolution map
  const resMap = { '16:9-1080': [1920, 1080], '16:9-720': [1280, 720], '9:16-1080': [1080, 1920], '9:16-720': [720, 1280] };
  const [W, H] = resMap[`${s.aspect || '16:9'}-${s.resolution || '1080'}`] || [1920, 1080];

  const duration = await renderLib.probeDuration(sess.voiceover);
  const tl = buildTimeline([...sess.images.keys()].map((name) => ({ name })), duration);
  if (tl.errors.length) return send(res, 400, { error: 'Timeline e somossa ache: ' + tl.errors[0] });
  let items = assignMotion(tl.items, s.motionMode || 'auto');
  if (body.motionOverrides) {
    items = items.map((it) => body.motionOverrides[it.name] ? { ...it, motion: body.motionOverrides[it.name] } : it);
  }

  const jobId = crypto.randomBytes(8).toString('hex');
  const jobDir = path.join(sess.dir, 'job-' + jobId);
  fs.mkdirSync(jobDir, { recursive: true });
  const job = { state: 'running', progress: 0, stage: 'Render shuru hochche', error: null, result: null };
  jobs.set(jobId, job);

  const renderJob = { dir: jobDir, images: Object.fromEntries(sess.images), voiceover: sess.voiceover,
    music: sess.music, srt: sess.srt, items,
    settings: { ...s, width: W, height: H, fps: 30 } };
  job._job = renderJob;

  renderLib.render(renderJob, (pct, stage) => { job.progress = pct; job.stage = stage; })
    .then((result) => {
      job.state = 'done'; job.progress = 100; job.stage = 'Render sesh — video ready';
      job.result = { ...result, outputName: path.basename(result.outputPath), jobId };
    })
    .catch((err) => {
      job.state = job._cancelled ? 'cancelled' : 'error';
      job.error = job._cancelled ? 'Tumi render bondho korecho' : (err.message || 'Render fail koreche');
      job.logTail = (() => { try { return fs.readFileSync(path.join(jobDir, 'render.log'), 'utf8').slice(-3000); } catch { return ''; } })();
    });

  return send(res, 200, { jobId });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://127.0.0.1');
    const p = url.pathname;

    if (req.method === 'POST' && p === '/api/upload') return await handleUpload(req, res);
    if (req.method === 'POST' && p === '/api/validate') return await handleValidate(req, res);
    if (req.method === 'POST' && p === '/api/render') return await handleRender(req, res);

    let m;
    if (req.method === 'GET' && (m = /^\/api\/jobs\/(\w+)$/.exec(p))) {
      const job = jobs.get(m[1]);
      if (!job) return send(res, 404, { error: 'Job pawa jay ni' });
      return send(res, 200, { state: job.state, progress: job.progress, stage: job.stage, error: job.error, result: job.result, logTail: job.logTail || null });
    }
    if (req.method === 'POST' && (m = /^\/api\/jobs\/(\w+)\/cancel$/.exec(p))) {
      const job = jobs.get(m[1]);
      if (job && job._job) { job._cancelled = true; job._job._kill && job._job._kill(); }
      return send(res, 200, { ok: true });
    }
    if (req.method === 'GET' && (m = /^\/api\/download\/(\w+)$/.exec(p))) {
      const job = jobs.get(m[1]);
      if (!job || !job.result) return send(res, 404, { error: 'File ready na' });
      const wantSrt = url.searchParams.get('file') === 'srt';
      const file = wantSrt ? job.result.outputPath.replace(/\.mp4$/, '.srt') : job.result.outputPath;
      if (!fs.existsSync(file)) return send(res, 404, { error: 'File pawa jay ni' });
      res.writeHead(200, { 'Content-Type': wantSrt ? MIME['.srt'] : MIME['.mp4'],
        'Content-Disposition': `attachment; filename="${path.basename(file)}"`, 'Content-Length': fs.statSync(file).size });
      return fs.createReadStream(file).pipe(res);
    }
    if (req.method === 'GET' && (m = /^\/api\/thumb\/(\w+)\/(.+)$/.exec(p))) {
      const sess = sessions.get(m[1]);
      const name = decodeURIComponent(m[2]);
      if (!sess || !sess.images.has(name)) return send(res, 404, { error: 'na' });
      const file = sess.images.get(name);
      res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream' });
      return fs.createReadStream(file).pipe(res);
    }
    if (req.method === 'GET' && (m = /^\/api\/script\/(\w+)$/.exec(p))) {
      const sess = sessions.get(m[1]);
      if (!sess || !sess.script) return send(res, 404, { error: 'na' });
      return send(res, 200, fs.readFileSync(sess.script, 'utf8'), 'text/plain; charset=utf-8');
    }

    // static files
    let filePath = path.join(PUBLIC, p === '/' ? 'index.html' : decodeURIComponent(p));
    if (!filePath.startsWith(PUBLIC) || !fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
      return send(res, 404, 'Pawa jay ni', 'text/plain; charset=utf-8');
    }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(filePath).toLowerCase()] || 'application/octet-stream' });
    fs.createReadStream(filePath).pipe(res);
  } catch (e) {
    send(res, 500, { error: e.message || 'Server error' });
  }
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`Sheikh Script to Video Editor cholche: http://127.0.0.1:${PORT}`);
});
