/*
 * SHEIKH Flow Auto — side panel logic (v2.4.1).
 * The panel loads/imports prompts and renders state; the background
 * owns the run and the saved state (chrome.storage.local "sfa_state").
 * Panel polls getState every 1s.
 *
 * i18n: STRINGS below is the single source for every panel UI string.
 * English is the source of truth; the completeness test
 * (tests/test-v22.js) fails if any language misses a key. The engine's
 * background log lines are diagnostics and are NOT translated.
 */
'use strict';

/* eslint-disable */
const STRINGS = {
en: {
  done: "Done", failed: "Failed", pending: "Pending", generated: "Generated",
  project: "Project", timeLeft: "Time left", nowGenerating: "Now generating",
  setup: "Setup",
  fileLabel: "Storyboard (.md) or prompt list (.txt) file:",
  pasteLabel: "Or paste prompts here (one prompt per line):",
  pastePlaceholder: "Paste prompts here, one per line...",
  loadPasted: "Load pasted prompts",
  projectLabel: "Project name (download folder):",
  projectPlaceholder: "e.g. BanksVideo",
  startNumberLabel: "Start number (text / paste only):",
  reference: "Reference image",
  refFileLabel: "Reference image (optional):",
  refModeLabel: "Use reference on:",
  refModeMarked: "Only prompts marked for reference (storyboard)",
  refModeAll: "Every prompt",
  refModeNone: "No reference",
  refTxtHint: "Text lists have no auto-marks — choose \"Every prompt\" if the character is needed on all prompts.",
  refStatusPrefix: "Reference status",
  refStChecking: "Checking…", refStUploading: "Uploading…", refStReady: "Ready in the project", refStFailed: "Failed", refStNone: "—",
  refConfirmText: "Reference image is set in the Flow project ({n} prompts need it)",
  refNoneInfo: "No reference image selected — pick one and it uploads once at Start.",
  refReadyInfo: "Reference ready: {name} (PNG, {kb} KB). Uploads once at run start — do not copy anything else until it is done.",
  refConvertFail: "Reference image could not be read: {msg}",
  download: "Download",
  autoDownload: "Auto download",
  qualityLabel: "Image quality:",
  datedFolder: "New dated folder for every run",
  retryAtEnd: "Retry failed at the end (3 rounds)",
  intervalLabel: "Seconds between generations:",
  downloadGenerated: "Download generated",
  generatedReady: "{n} image(s) generated — not downloaded yet.",
  flowCheck: "Flow tab check", checkBtn: "Check Flow Tab", checkingNow: "Checking...",
  checkFail: "Check failed: {msg}",
  pfFlowOk: "✓ Flow project page is open",
  pfFlowBad: "✗ No Flow page found — {reason}",
  pfInputOk: "✓ Prompt input found ({how})",
  pfInputBad: "✗ Prompt input not found",
  pfSendOk: "✓ Generate/Send button found ({how})",
  pfSendBad: "✗ Generate button not found",
  pfPlusOk: "✓ Reference add (+) button found — picker attach will work",
  pfPlusWarn: "! Reference add (+) button not found — the picker cannot open if a reference is needed",
  pfAgentBad: "✗ Agent mode is ON — turn it off (Agent error tiles have no Retry button, and the agent may ask for confirmation)",
  pfAgentOk: "✓ Agent mode is off",
  pfVideoBad: "✗ Looks like VIDEO mode — the run is BLOCKED (image-only lock). Select Image / Nano Banana in Flow.",
  pfImageOk: "✓ Image mode looks selected",
  pfModeUnknown: "? Mode is not certain — please make sure Image mode is selected",
  pfDurationWarn: "! A duration selector (5s/8s) is visible — that can be a video-mode sign, keep an eye on it",
  pfSharedRefWarn: "! {n} prompt(s) need a character reference — set a Shared Ref in the Flow project and tick the checkbox, or pick a reference image below",
  run: "Run", start: "Start", pause: "Pause", resume: "Resume", stop: "Stop",
  retryFailed: "Retry failed only", skipDownloaded: "Skip already downloaded", clearRun: "Clear saved run",
  detachCanceled: "Last detach: the yellow bar's Cancel was pressed — never press Cancel during a run",
  detachReason: "Last detach reason: {r}",
  bannerResume: "A previous run is half done — Resume continues the rest.",
  bannerStale: "The engine looks stopped — the saved run is unfinished. Resume restarts it from the saved state.",
  tabItems: "Items", tabLog: "Log", tabReport: "Report",
  stPending: "pending", stActive: "active", stDone: "done", stFailed: "failed", stGenerated: "generated",
  matchTitle: "QuickVid match report",
  matchIdle: "Press \"Check downloads\" to verify the files on disk.",
  checkDownloads: "Check downloads", copyMissing: "Copy missing list", downloadReport: "Download report",
  copied: "Copied!", copyFail: "Copy failed",
  rExpected: "Expected files", rVerified: "Downloaded & verified", rMissing: "Missing",
  rFailed: "Failed", rGenerated: "Generated (not downloaded)", rFlowNamed: "Saved with Flow names", rNone: "None",
  reportEmpty: "No run yet — finish a run first.",
  help: "Help",
  noPrompts: "No prompts loaded yet.",
  loadedInfo: "{n} prompt(s) loaded ({kind})",
  kindStoryboard: "storyboard", kindTxt: "text list",
  refNeededInfo: " — {n} need a character reference",
  logLoadedLine: "{n} prompt(s) loaded. First: {first}, last: {last}",
  logParseWarn: "Parse warning: {w}",
  logNoPromptsFound: "WARNING: no prompts found — check the file / format",
  logFileReadFail: "Could not read the file",
  logRefSelected: "Reference image selected: {name}",
  logClipboardOk: "Reference image is on the clipboard — it uploads once at run start; later prompts add it from the picker",
  logClipboardFail: "WARNING: could not write the reference to the clipboard ({msg}) — the run will go WITHOUT a reference",
  logLoadFirst: "Load prompts first",
  logBlockedVideo: "START BLOCKED: Flow looks like VIDEO mode. Select Image mode and Check again.",
  logBlockedRef: "START BLOCKED: {n} prompt(s) need a reference — set a Shared Ref in the Flow project and tick the checkbox, or pick a reference image below",
  logStartSent: "Run start sent — project: {project}, ref mode: {mode}",
  logStartSentRef: " (clipboard ref: {state})",
  refStateReady: "ready", refStateFail: "FAILED — will run without ref",
  logStartFail: "Start failed: {msg}",
  logResumeFail: "Resume failed: {msg}",
  logStopReq: "Stop requested",
  logRetryFail: "Retry failed: {msg}",
  logRetryCount: "Failed items will be retried: {n} item(s)",
  logSkipFail: "Skip check failed: {msg}",
  logSkipMarked: "Skip-downloaded: {n} item(s) marked done",
  logClearDone: "Saved run cleared",
  logClearFail: "Clear failed: {msg}",
  logReportEmpty: "No report yet — run something first",
  logDlDone: "Download generated finished: {n} image(s)",
  logDlFail: "Download generated failed: {msg}",
  logVerifying: "Checking downloads…",
  logVerifyFail: "Check failed: {msg}",
  checkAllGood: "All good",
  checkShortFlow: "Flow page", checkShortInput: "No prompt input", checkShortSend: "No Generate button",
  checkShortPlus: "No + button", checkShortAgent: "Agent mode ON", checkShortMode: "Video mode",
  endsAt: "Ends ~",
  dropToImport: "Drop to import",
  chooseFile: "Choose file", noFileChosen: "No file chosen",
  retryOne: "Retry",
  toastRunDone: "Run finished — Done {done}, Failed {failed}",
  toastDlDone: "Download finished — {n} image(s)",
  toastRetryOk: "Retry {id}: done",
  toastRetryFail: "Retry {id}: failed — {msg}",
  toastRetryBusy: "A run is going — retry after it ends",
  toastImportOk: "{n} prompt(s) loaded",
  toastImportFail: "Could not import that file",
  toastCheckFail: "Flow Tab Check found a problem"
},
bn: {
  done: "হয়েছে", failed: "ব্যর্থ", pending: "বাকি", generated: "তৈরি",
  project: "প্রজেক্ট", timeLeft: "বাকি সময়", nowGenerating: "এখন তৈরি হচ্ছে",
  setup: "সেটআপ",
  fileLabel: "স্টোরিবোর্ড (.md) বা প্রম্পট লিস্ট (.txt) ফাইল:",
  pasteLabel: "অথবা এখানে প্রম্পট পেস্ট করো (এক লাইনে একটা):",
  pastePlaceholder: "এখানে প্রম্পট পেস্ট করো, এক লাইনে একটা...",
  loadPasted: "পেস্ট করা প্রম্পট লোড করো",
  projectLabel: "প্রজেক্টের নাম (ডাউনলোড ফোল্ডার):",
  projectPlaceholder: "যেমন BanksVideo",
  startNumberLabel: "শুরুর নম্বর (শুধু টেক্সট / পেস্ট):",
  reference: "রেফারেন্স ছবি",
  refFileLabel: "রেফারেন্স ছবি (ঐচ্ছিক):",
  refModeLabel: "রেফারেন্স ব্যবহার হবে:",
  refModeMarked: "শুধু যেসব প্রম্পটে রেফারেন্স চিহ্নিত (স্টোরিবোর্ড)",
  refModeAll: "সব প্রম্পটে",
  refModeNone: "রেফারেন্স লাগবে না",
  refTxtHint: "টেক্সট লিস্টে অটো-চিহ্ন থাকে না — সব প্রম্পটে চরিত্র লাগলে \"সব প্রম্পটে\" বেছে নাও।",
  refStatusPrefix: "রেফারেন্সের অবস্থা",
  refStChecking: "দেখা হচ্ছে…", refStUploading: "আপলোড হচ্ছে…", refStReady: "প্রজেক্টে তৈরি আছে", refStFailed: "ব্যর্থ", refStNone: "—",
  refConfirmText: "রেফারেন্স ছবি Flow প্রজেক্টে সেট করা আছে ({n}টা প্রম্পটে লাগবে)",
  refNoneInfo: "কোনো রেফারেন্স ছবি বেছে নেওয়া হয়নি — একটা বেছে নিলে Start-এর সময় একবার আপলোড হবে।",
  refReadyInfo: "রেফারেন্স তৈরি: {name} (PNG, {kb} KB)। রান শুরুতে একবার আপলোড হবে — শেষ না হওয়া পর্যন্ত অন্য কিছু কপি করো না।",
  refConvertFail: "রেফারেন্স ছবি পড়া যায়নি: {msg}",
  download: "ডাউনলোড",
  autoDownload: "অটো ডাউনলোড",
  qualityLabel: "ছবির মান:",
  datedFolder: "প্রতিটা রানের জন্য তারিখসহ নতুন ফোল্ডার",
  retryAtEnd: "শেষে ব্যর্থগুলো আবার চেষ্টা (৩ রাউন্ড)",
  intervalLabel: "দুই তৈরির মাঝে কত সেকেন্ড:",
  downloadGenerated: "তৈরি হওয়াগুলো ডাউনলোড করো",
  generatedReady: "{n}টা ছবি তৈরি — এখনো ডাউনলোড হয়নি।",
  flowCheck: "Flow ট্যাব যাচাই", checkBtn: "Flow ট্যাব দেখো", checkingNow: "দেখা হচ্ছে...",
  checkFail: "যাচাই ব্যর্থ: {msg}",
  pfFlowOk: "✓ Flow প্রজেক্ট পেজ খোলা আছে",
  pfFlowBad: "✗ Flow পেজ পাওয়া যায়নি — {reason}",
  pfInputOk: "✓ প্রম্পট ইনপুট পাওয়া গেছে ({how})",
  pfInputBad: "✗ প্রম্পট ইনপুট পাওয়া যায়নি",
  pfSendOk: "✓ Generate/Send বোতাম পাওয়া গেছে ({how})",
  pfSendBad: "✗ Generate বোতাম পাওয়া যায়নি",
  pfPlusOk: "✓ রেফারেন্স যোগের (+) বোতাম আছে — পিকার দিয়ে যোগ করা যাবে",
  pfPlusWarn: "! রেফারেন্স যোগের (+) বোতাম পাওয়া যায়নি — রেফারেন্স লাগলে পিকার খুলবে না",
  pfAgentBad: "✗ Agent মোড চালু আছে — বন্ধ করো (Agent মোডে এরর টাইলে Retry বোতাম থাকে না, আর agent মাঝে মাঝে অনুমতি চায়)",
  pfAgentOk: "✓ Agent মোড বন্ধ আছে",
  pfVideoBad: "✗ VIDEO মোড মনে হচ্ছে — রান বন্ধ রাখা হলো (শুধু ছবির লক)। Flow-তে Image / Nano Banana বেছে নাও।",
  pfImageOk: "✓ Image মোড বেছে নেওয়া মনে হচ্ছে",
  pfModeUnknown: "? মোড নিশ্চিত হওয়া যায়নি — Image মোড আছে কিনা দেখে নাও",
  pfDurationWarn: "! সময় বেছে নেওয়ার অপশন (5s/8s) দেখা যাচ্ছে — এটা ভিডিও মোডের লক্ষণ হতে পারে, খেয়াল রেখো",
  pfSharedRefWarn: "! {n}টা প্রম্পটে চরিত্রের রেফারেন্স লাগবে — Flow প্রজেক্টে Shared Ref সেট করে নিচের বাক্সে টিক দাও, অথবা নিচে রেফারেন্স ছবি বেছে নাও",
  run: "রান", start: "শুরু", pause: "থামাও", resume: "আবার শুরু", stop: "বন্ধ",
  retryFailed: "শুধু ব্যর্থগুলো আবার", skipDownloaded: "ডাউনলোড হওয়াগুলো বাদ দাও", clearRun: "সেভ করা রান মুছো",
  detachCanceled: "শেষ বিচ্ছিন্ন: হলুদ বারের Cancel চাপা হয়েছিল — রান চলার সময় Cancel চাপবে না",
  detachReason: "শেষ বিচ্ছিন্নের কারণ: {r}",
  bannerResume: "আগের রান অর্ধেক বাকি আছে — Resume দিলে বাকিগুলো হবে।",
  bannerStale: "ইঞ্জিন থেমে গেছে মনে হচ্ছে — সেভ করা রান শেষ হয়নি। Resume দিলে সেভ করা অবস্থা থেকে আবার শুরু হবে।",
  tabItems: "আইটেম", tabLog: "লগ", tabReport: "রিপোর্ট",
  stPending: "বাকি", stActive: "চলছে", stDone: "হয়েছে", stFailed: "ব্যর্থ", stGenerated: "তৈরি",
  matchTitle: "QuickVid মিল রিপোর্ট",
  matchIdle: "ডিস্কের ফাইল যাচাই করতে \"ডাউনলোড যাচাই\" চাপ দাও।",
  checkDownloads: "ডাউনলোড যাচাই", copyMissing: "বাদ পড়া তালিকা কপি", downloadReport: "রিপোর্ট ডাউনলোড",
  copied: "কপি হয়েছে!", copyFail: "কপি ব্যর্থ",
  rExpected: "থাকার কথা এমন ফাইল", rVerified: "ডাউনলোড ও যাচাই হয়েছে", rMissing: "বাদ পড়েছে",
  rFailed: "ব্যর্থ", rGenerated: "তৈরি (ডাউনলোড হয়নি)", rFlowNamed: "Flow-এর নামে সেভ হয়েছে", rNone: "নেই",
  reportEmpty: "এখনো কোনো রান হয়নি — আগে একটা রান শেষ করো।",
  help: "সাহায্য",
  noPrompts: "এখনো কোনো প্রম্পট লোড হয়নি।",
  loadedInfo: "{n}টা প্রম্পট লোড হয়েছে ({kind})",
  kindStoryboard: "স্টোরিবোর্ড", kindTxt: "টেক্সট লিস্ট",
  refNeededInfo: " — {n}টায় চরিত্রের রেফারেন্স লাগবে",
  logLoadedLine: "{n}টা প্রম্পট লোড হয়েছে। প্রথম: {first}, শেষ: {last}",
  logParseWarn: "পার্স সতর্কতা: {w}",
  logNoPromptsFound: "সাবধান: কোনো প্রম্পট পাওয়া যায়নি — ফাইল / ফরম্যাট দেখো",
  logFileReadFail: "ফাইল পড়া যায়নি",
  logRefSelected: "রেফারেন্স ছবি বেছে নেওয়া হয়েছে: {name}",
  logClipboardOk: "রেফারেন্স ছবি ক্লিপবোর্ডে আছে — রান শুরুতে একবার আপলোড হবে; পরের প্রম্পটে পিকার দিয়ে যোগ হবে",
  logClipboardFail: "সাবধান: রেফারেন্স ক্লিপবোর্ডে লেখা যায়নি ({msg}) — রান রেফারেন্স ছাড়াই চলবে",
  logLoadFirst: "আগে প্রম্পট লোড করো",
  logBlockedVideo: "শুরু বন্ধ: Flow-তে VIDEO মোড মনে হচ্ছে। Image মোড বেছে আবার যাচাই করো।",
  logBlockedRef: "শুরু বন্ধ: {n}টা প্রম্পটে রেফারেন্স লাগবে — হয় Flow প্রজেক্টে Shared Ref সেট করে বাক্সে টিক দাও, নয়তো নিচে রেফারেন্স ছবি বেছে নাও",
  logStartSent: "রান শুরু পাঠানো হয়েছে — প্রজেক্ট: {project}, রেফ মোড: {mode}",
  logStartSentRef: " (ক্লিপবোর্ড রেফ: {state})",
  refStateReady: "তৈরি", refStateFail: "ব্যর্থ — রেফ ছাড়া চলবে",
  logStartFail: "শুরু ব্যর্থ: {msg}",
  logResumeFail: "Resume ব্যর্থ: {msg}",
  logStopReq: "বন্ধ চাওয়া হয়েছে",
  logRetryFail: "আবার চেষ্টা ব্যর্থ: {msg}",
  logRetryCount: "ব্যর্থ আইটেম আবার চেষ্টা হবে: {n}টা",
  logSkipFail: "বাদ-দেওয়া যাচাই ব্যর্থ: {msg}",
  logSkipMarked: "বাদ-দেওয়া: {n}টা আইটেম হয়েছে বলে চিহ্নিত হলো",
  logClearDone: "সেভ করা রান মোছা হলো",
  logClearFail: "মোছা ব্যর্থ: {msg}",
  logReportEmpty: "এখনো রিপোর্ট নেই — আগে কিছু চালাও",
  logDlDone: "তৈরি হওয়া ডাউনলোড শেষ: {n}টা ছবি",
  logDlFail: "তৈরি হওয়া ডাউনলোড ব্যর্থ: {msg}",
  logVerifying: "ডাউনলোড যাচাই হচ্ছে…",
  logVerifyFail: "যাচাই ব্যর্থ: {msg}",
  checkAllGood: "সব ঠিক আছে",
  checkShortFlow: "Flow পেজ", checkShortInput: "প্রম্পট ইনপুট নেই", checkShortSend: "Generate বোতাম নেই",
  checkShortPlus: "+ বোতাম নেই", checkShortAgent: "Agent মোড চালু", checkShortMode: "Video মোড",
  endsAt: "শেষ হবে ~",
  dropToImport: "আনতে এখানে ছাড়ো",
  chooseFile: "ফাইল বাছো", noFileChosen: "কোনো ফাইল বাছা হয়নি",
  retryOne: "আবার",
  toastRunDone: "রান শেষ — হয়েছে {done}, ব্যর্থ {failed}",
  toastDlDone: "ডাউনলোড শেষ — {n}টা ছবি",
  toastRetryOk: "আবার {id}: হয়েছে",
  toastRetryFail: "আবার {id}: ব্যর্থ — {msg}",
  toastRetryBusy: "রান চলছে — শেষ হলে আবার চেষ্টা করো",
  toastImportOk: "{n}টা প্রম্পট লোড হয়েছে",
  toastImportFail: "ফাইলটা আনা যায়নি",
  toastCheckFail: "Flow ট্যাব যাচাইয়ে সমস্যা পাওয়া গেছে"
},
hi: {
  done: "हो गया", failed: "विफल", pending: "बाकी", generated: "बन गया",
  project: "प्रोजेक्ट", timeLeft: "बचा समय", nowGenerating: "अभी बन रहा है",
  setup: "सेटअप",
  fileLabel: "स्टोरीबोर्ड (.md) या प्रॉम्प्ट सूची (.txt) फ़ाइल:",
  pasteLabel: "या यहाँ प्रॉम्प्ट चिपकाएँ (एक लाइन में एक):",
  pastePlaceholder: "यहाँ प्रॉम्प्ट चिपकाएँ, एक लाइन में एक...",
  loadPasted: "चिपकाए प्रॉम्प्ट लोड करें",
  projectLabel: "प्रोजेक्ट का नाम (डाउनलोड फ़ोल्डर):",
  projectPlaceholder: "जैसे BanksVideo",
  startNumberLabel: "शुरुआती नंबर (सिर्फ़ टेक्स्ट / पेस्ट):",
  reference: "संदर्भ छवि",
  refFileLabel: "संदर्भ छवि (वैकल्पिक):",
  refModeLabel: "संदर्भ इन पर लगे:",
  refModeMarked: "सिर्फ़ चिह्नित प्रॉम्प्ट पर (स्टोरीबोर्ड)",
  refModeAll: "हर प्रॉम्प्ट पर",
  refModeNone: "कोई संदर्भ नहीं",
  refTxtHint: "टेक्स्ट सूचियों में ऑटो-चिह्न नहीं होते — हर प्रॉम्प्ट पर किरदार चाहिए तो \"हर प्रॉम्प्ट पर\" चुनें।",
  refStatusPrefix: "संदर्भ स्थिति",
  refStChecking: "जाँच हो रही है…", refStUploading: "अपलोड हो रहा है…", refStReady: "प्रोजेक्ट में तैयार", refStFailed: "विफल", refStNone: "—",
  refConfirmText: "संदर्भ छवि Flow प्रोजेक्ट में सेट है ({n} प्रॉम्प्ट को चाहिए)",
  refNoneInfo: "कोई संदर्भ छवि नहीं चुनी गई — एक चुनें, वह Start पर एक बार अपलोड होगी।",
  refReadyInfo: "संदर्भ तैयार: {name} (PNG, {kb} KB)। रन शुरू होते ही एक बार अपलोड होगा — पूरा होने तक कुछ और कॉपी न करें।",
  refConvertFail: "संदर्भ छवि पढ़ी नहीं गई: {msg}",
  download: "डाउनलोड",
  autoDownload: "ऑटो डाउनलोड",
  qualityLabel: "छवि गुणवत्ता:",
  datedFolder: "हर रन के लिए तारीख़ वाला नया फ़ोल्डर",
  retryAtEnd: "अंत में विफल फिर से प्रयास (3 राउंड)",
  intervalLabel: "दो निर्माणों के बीच सेकंड:",
  downloadGenerated: "बनी हुई डाउनलोड करें",
  generatedReady: "{n} छवि(याँ) बन गईं — अभी डाउनलोड नहीं हुईं।",
  flowCheck: "Flow टैब जाँच", checkBtn: "Flow टैब जाँचें", checkingNow: "जाँच हो रही है...",
  checkFail: "जाँच विफल: {msg}",
  pfFlowOk: "✓ Flow प्रोजेक्ट पेज खुला है",
  pfFlowBad: "✗ Flow पेज नहीं मिला — {reason}",
  pfInputOk: "✓ प्रॉम्प्ट इनपुट मिला ({how})",
  pfInputBad: "✗ प्रॉम्प्ट इनपुट नहीं मिला",
  pfSendOk: "✓ Generate/Send बटन मिला ({how})",
  pfSendBad: "✗ Generate बटन नहीं मिला",
  pfPlusOk: "✓ संदर्भ जोड़ने का (+) बटन मिला — पिकर से जोड़ना चलेगा",
  pfPlusWarn: "! संदर्भ जोड़ने का (+) बटन नहीं मिला — संदर्भ चाहिए तो पिकर नहीं खुलेगा",
  pfAgentBad: "✗ Agent मोड चालू है — बंद करें (Agent मोड की एरर टाइल पर Retry बटन नहीं होता और agent पुष्टि माँग सकता है)",
  pfAgentOk: "✓ Agent मोड बंद है",
  pfVideoBad: "✗ VIDEO मोड लगता है — रन रोका गया (सिर्फ़-छवि लॉक)। Flow में Image / Nano Banana चुनें।",
  pfImageOk: "✓ Image मोड चुना हुआ लगता है",
  pfModeUnknown: "? मोड निश्चित नहीं — कृपया Image मोड चुना हो यह सुनिश्चित करें",
  pfDurationWarn: "! अवधि चुनने वाला (5s/8s) दिख रहा है — यह वीडियो मोड का संकेत हो सकता है, ध्यान रखें",
  pfSharedRefWarn: "! {n} प्रॉम्प्ट को किरदार संदर्भ चाहिए — Flow प्रोजेक्ट में Shared Ref सेट करके नीचे बॉक्स टिक करें, या नीचे संदर्भ छवि चुनें",
  run: "रन", start: "शुरू", pause: "रोकें", resume: "फिर शुरू", stop: "बंद",
  retryFailed: "सिर्फ़ विफल फिर से", skipDownloaded: "डाउनलोड हुए छोड़ें", clearRun: "सहेजा रन मिटाएँ",
  detachCanceled: "आख़िरी अलगाव: पीली पट्टी का Cancel दबा था — रन के दौरान Cancel कभी न दबाएँ",
  detachReason: "आख़िरी अलगाव का कारण: {r}",
  bannerResume: "पिछला रन आधा बाकी है — Resume बाकी पूरा करेगा।",
  bannerStale: "इंजन रुका लगता है — सहेजा रन अधूरा है। Resume सहेजी स्थिति से फिर शुरू करेगा।",
  tabItems: "आइटम", tabLog: "लॉग", tabReport: "रिपोर्ट",
  stPending: "बाकी", stActive: "चल रहा", stDone: "हो गया", stFailed: "विफल", stGenerated: "बन गया",
  matchTitle: "QuickVid मिलान रिपोर्ट",
  matchIdle: "डिस्क की फ़ाइलें जाँचने के लिए \"डाउनलोड जाँचें\" दबाएँ।",
  checkDownloads: "डाउनलोड जाँचें", copyMissing: "छूटी सूची कॉपी करें", downloadReport: "रिपोर्ट डाउनलोड",
  copied: "कॉपी हुआ!", copyFail: "कॉपी विफल",
  rExpected: "होनी चाहिए फ़ाइलें", rVerified: "डाउनलोड और जाँच हुईं", rMissing: "छूटी हुईं",
  rFailed: "विफल", rGenerated: "बनी हुईं (डाउनलोड नहीं)", rFlowNamed: "Flow के नाम से सहेजीं", rNone: "कोई नहीं",
  reportEmpty: "अभी कोई रन नहीं — पहले एक रन खत्म करें।",
  help: "मदद",
  noPrompts: "अभी कोई प्रॉम्प्ट लोड नहीं हुआ।",
  loadedInfo: "{n} प्रॉम्प्ट लोड हुए ({kind})",
  kindStoryboard: "स्टोरीबोर्ड", kindTxt: "टेक्स्ट सूची",
  refNeededInfo: " — {n} को किरदार संदर्भ चाहिए",
  logLoadedLine: "{n} प्रॉम्प्ट लोड हुए। पहला: {first}, आख़िरी: {last}",
  logParseWarn: "पार्स चेतावनी: {w}",
  logNoPromptsFound: "चेतावनी: कोई प्रॉम्प्ट नहीं मिला — फ़ाइल / फ़ॉर्मैट देखें",
  logFileReadFail: "फ़ाइल पढ़ी नहीं गई",
  logRefSelected: "संदर्भ छवि चुनी गई: {name}",
  logClipboardOk: "संदर्भ छवि क्लिपबोर्ड पर है — रन शुरू में एक बार अपलोड होगी; बाद के प्रॉम्प्ट पिकर से जोड़ेंगे",
  logClipboardFail: "चेतावनी: संदर्भ क्लिपबोर्ड पर लिखा नहीं गया ({msg}) — रन बिना संदर्भ चलेगा",
  logLoadFirst: "पहले प्रॉम्प्ट लोड करें",
  logBlockedVideo: "शुरू रोका: Flow में VIDEO मोड लगता है। Image मोड चुनकर फिर जाँचें।",
  logBlockedRef: "शुरू रोका: {n} प्रॉम्प्ट को संदर्भ चाहिए — Flow प्रोजेक्ट में Shared Ref सेट करके बॉक्स टिक करें, या नीचे संदर्भ छवि चुनें",
  logStartSent: "रन शुरू भेजा गया — प्रोजेक्ट: {project}, रेफ़ मोड: {mode}",
  logStartSentRef: " (क्लिपबोर्ड रेफ़: {state})",
  refStateReady: "तैयार", refStateFail: "विफल — बिना रेफ़ चलेगा",
  logStartFail: "शुरू विफल: {msg}",
  logResumeFail: "Resume विफल: {msg}",
  logStopReq: "बंद माँगा गया",
  logRetryFail: "फिर प्रयास विफल: {msg}",
  logRetryCount: "विफल आइटम फिर से चलेंगे: {n} आइटम",
  logSkipFail: "छोड़ने की जाँच विफल: {msg}",
  logSkipMarked: "छोड़ना: {n} आइटम हो गए चिह्नित हुए",
  logClearDone: "सहेजा रन मिट गया",
  logClearFail: "मिटाना विफल: {msg}",
  logReportEmpty: "अभी रिपोर्ट नहीं — पहले कुछ चलाएँ",
  logDlDone: "बनी हुई डाउनलोड खत्म: {n} छवि(याँ)",
  logDlFail: "बनी हुई डाउनलोड विफल: {msg}",
  logVerifying: "डाउनलोड जाँच हो रही है…",
  logVerifyFail: "जाँच विफल: {msg}",
  checkAllGood: "सब ठीक है",
  checkShortFlow: "Flow पेज", checkShortInput: "प्रॉम्प्ट इनपुट नहीं", checkShortSend: "Generate बटन नहीं",
  checkShortPlus: "+ बटन नहीं", checkShortAgent: "Agent मोड चालू", checkShortMode: "वीडियो मोड",
  endsAt: "खत्म ~",
  dropToImport: "इंपोर्ट करने के लिए छोड़ें",
  chooseFile: "फ़ाइल चुनें", noFileChosen: "कोई फ़ाइल नहीं चुनी",
  retryOne: "फिर से",
  toastRunDone: "रन खत्म — हो गया {done}, विफल {failed}",
  toastDlDone: "डाउनलोड खत्म — {n} छवि(याँ)",
  toastRetryOk: "फिर से {id}: हो गया",
  toastRetryFail: "फिर से {id}: विफल — {msg}",
  toastRetryBusy: "रन चल रहा है — खत्म होने पर फिर प्रयास करें",
  toastImportOk: "{n} प्रॉम्प्ट लोड हुए",
  toastImportFail: "वह फ़ाइल इंपोर्ट नहीं हुई",
  toastCheckFail: "Flow टैब जाँच में समस्या मिली"
},
tr: {
  done: "Bitti", failed: "Başarısız", pending: "Bekliyor", generated: "Üretildi",
  project: "Proje", timeLeft: "Kalan süre", nowGenerating: "Şimdi üretiliyor",
  setup: "Kurulum",
  fileLabel: "Storyboard (.md) veya komut listesi (.txt) dosyası:",
  pasteLabel: "Ya da komutları buraya yapıştır (her satıra bir tane):",
  pastePlaceholder: "Komutları buraya yapıştır, her satıra bir tane...",
  loadPasted: "Yapıştırılanları yükle",
  projectLabel: "Proje adı (indirme klasörü):",
  projectPlaceholder: "örn. BanksVideo",
  startNumberLabel: "Başlangıç numarası (sadece metin / yapıştır):",
  reference: "Referans görsel",
  refFileLabel: "Referans görsel (isteğe bağlı):",
  refModeLabel: "Referans şunlarda kullanılsın:",
  refModeMarked: "Sadece referans işaretli komutlarda (storyboard)",
  refModeAll: "Her komutta",
  refModeNone: "Referans yok",
  refTxtHint: "Metin listelerinde otomatik işaret yok — karakter hepsinde gerekliyse \"Her komutta\" seç.",
  refStatusPrefix: "Referans durumu",
  refStChecking: "Kontrol ediliyor…", refStUploading: "Yükleniyor…", refStReady: "Projede hazır", refStFailed: "Başarısız", refStNone: "—",
  refConfirmText: "Referans görsel Flow projesinde ayarlı ({n} komutun ihtiyacı var)",
  refNoneInfo: "Referans görsel seçilmedi — bir tane seç, Başlat'ta bir kez yüklensin.",
  refReadyInfo: "Referans hazır: {name} (PNG, {kb} KB). Çalışma başında bir kez yüklenecek — bitene kadar başka bir şey kopyalama.",
  refConvertFail: "Referans görsel okunamadı: {msg}",
  download: "İndirme",
  autoDownload: "Otomatik indir",
  qualityLabel: "Görsel kalitesi:",
  datedFolder: "Her çalışma için tarihli yeni klasör",
  retryAtEnd: "Başarısızları sonda tekrar dene (3 tur)",
  intervalLabel: "Üretimler arası saniye:",
  downloadGenerated: "Üretilenleri indir",
  generatedReady: "{n} görsel üretildi — henüz indirilmedi.",
  flowCheck: "Flow sekme kontrolü", checkBtn: "Flow Sekmesini Kontrol Et", checkingNow: "Kontrol ediliyor...",
  checkFail: "Kontrol başarısız: {msg}",
  pfFlowOk: "✓ Flow proje sayfası açık",
  pfFlowBad: "✗ Flow sayfası bulunamadı — {reason}",
  pfInputOk: "✓ Komut girişi bulundu ({how})",
  pfInputBad: "✗ Komut girişi bulunamadı",
  pfSendOk: "✓ Generate/Send düğmesi bulundu ({how})",
  pfSendBad: "✗ Generate düğmesi bulunamadı",
  pfPlusOk: "✓ Referans ekleme (+) düğmesi bulundu — seçiciyle ekleme çalışacak",
  pfPlusWarn: "! Referans ekleme (+) düğmesi bulunamadı — referans gerekirse seçici açılmaz",
  pfAgentBad: "✗ Agent modu AÇIK — kapat (Agent modunda hata kutularında Retry düğmesi olmaz ve agent onay isteyebilir)",
  pfAgentOk: "✓ Agent modu kapalı",
  pfVideoBad: "✗ VIDEO modu gibi görünüyor — çalışma ENGELLENDİ (sadece görsel kilidi). Flow'da Image / Nano Banana seç.",
  pfImageOk: "✓ Image modu seçili görünüyor",
  pfModeUnknown: "? Mod kesin değil — Image modunun seçili olduğundan emin ol",
  pfDurationWarn: "! Süre seçici (5s/8s) görünüyor — video modu işareti olabilir, dikkat et",
  pfSharedRefWarn: "! {n} komutun karakter referansına ihtiyacı var — Flow projesinde Shared Ref ayarlayıp aşağıdaki kutuyu işaretle ya da aşağıdan referans görsel seç",
  run: "Çalıştır", start: "Başlat", pause: "Duraklat", resume: "Sürdür", stop: "Durdur",
  retryFailed: "Sadece başarısızları dene", skipDownloaded: "İndirilenleri atla", clearRun: "Kayıtlı çalışmayı temizle",
  detachCanceled: "Son ayrılma: sarı çubuğun Cancel'ına basıldı — çalışma sırasında asla Cancel'a basma",
  detachReason: "Son ayrılma nedeni: {r}",
  bannerResume: "Önceki çalışma yarım kaldı — Sürdür kalanını tamamlar.",
  bannerStale: "Motor durmuş görünüyor — kayıtlı çalışma bitmedi. Sürdür, kayıtlı durumdan yeniden başlatır.",
  tabItems: "Öğeler", tabLog: "Kayıt", tabReport: "Rapor",
  stPending: "bekliyor", stActive: "çalışıyor", stDone: "bitti", stFailed: "başarısız", stGenerated: "üretildi",
  matchTitle: "QuickVid eşleşme raporu",
  matchIdle: "Diskteki dosyaları doğrulamak için \"İndirmeleri kontrol et\"e bas.",
  checkDownloads: "İndirmeleri kontrol et", copyMissing: "Eksik listesini kopyala", downloadReport: "Raporu indir",
  copied: "Kopyalandı!", copyFail: "Kopyalama başarısız",
  rExpected: "Beklenen dosyalar", rVerified: "İndirildi ve doğrulandı", rMissing: "Eksik",
  rFailed: "Başarısız", rGenerated: "Üretildi (indirilmedi)", rFlowNamed: "Flow adlarıyla kaydedildi", rNone: "Yok",
  reportEmpty: "Henüz çalışma yok — önce bir çalışmayı bitir.",
  help: "Yardım",
  noPrompts: "Henüz komut yüklenmedi.",
  loadedInfo: "{n} komut yüklendi ({kind})",
  kindStoryboard: "storyboard", kindTxt: "metin listesi",
  refNeededInfo: " — {n} tanesinin karakter referansına ihtiyacı var",
  logLoadedLine: "{n} komut yüklendi. İlk: {first}, son: {last}",
  logParseWarn: "Ayrıştırma uyarısı: {w}",
  logNoPromptsFound: "UYARI: komut bulunamadı — dosya / biçimi kontrol et",
  logFileReadFail: "Dosya okunamadı",
  logRefSelected: "Referans görsel seçildi: {name}",
  logClipboardOk: "Referans görsel panoda — çalışma başında bir kez yüklenir; sonraki komutlar seçiciden ekler",
  logClipboardFail: "UYARI: referans panoya yazılamadı ({msg}) — çalışma referanssız gidecek",
  logLoadFirst: "Önce komutları yükle",
  logBlockedVideo: "BAŞLATMA ENGELLENDİ: Flow VIDEO modunda görünüyor. Image modunu seçip tekrar kontrol et.",
  logBlockedRef: "BAŞLATMA ENGELLENDİ: {n} komutun referansa ihtiyacı var — Flow projesinde Shared Ref ayarlayıp kutuyu işaretle, ya da aşağıdan referans görsel seç",
  logStartSent: "Çalışma başlatma gönderildi — proje: {project}, ref modu: {mode}",
  logStartSentRef: " (pano ref: {state})",
  refStateReady: "hazır", refStateFail: "BAŞARISIZ — ref olmadan gidecek",
  logStartFail: "Başlatma başarısız: {msg}",
  logResumeFail: "Sürdürme başarısız: {msg}",
  logStopReq: "Durdurma istendi",
  logRetryFail: "Tekrar deneme başarısız: {msg}",
  logRetryCount: "Başarısız öğeler tekrar denenecek: {n} öğe",
  logSkipFail: "Atlama kontrolü başarısız: {msg}",
  logSkipMarked: "Atlama: {n} öğe bitti işaretlendi",
  logClearDone: "Kayıtlı çalışma temizlendi",
  logClearFail: "Temizleme başarısız: {msg}",
  logReportEmpty: "Henüz rapor yok — önce bir şey çalıştır",
  logDlDone: "Üretilenlerin indirmesi bitti: {n} görsel",
  logDlFail: "Üretilenlerin indirmesi başarısız: {msg}",
  logVerifying: "İndirmeler kontrol ediliyor…",
  logVerifyFail: "Kontrol başarısız: {msg}",
  checkAllGood: "Her şey tamam",
  checkShortFlow: "Flow sayfası", checkShortInput: "Komut girişi yok", checkShortSend: "Generate düğmesi yok",
  checkShortPlus: "+ düğmesi yok", checkShortAgent: "Agent modu AÇIK", checkShortMode: "Video modu",
  endsAt: "Bitiş ~",
  dropToImport: "İçe aktarmak için bırak",
  chooseFile: "Dosya seç", noFileChosen: "Dosya seçilmedi",
  retryOne: "Tekrar",
  toastRunDone: "Çalışma bitti — Bitti {done}, Başarısız {failed}",
  toastDlDone: "İndirme bitti — {n} görsel",
  toastRetryOk: "Tekrar {id}: bitti",
  toastRetryFail: "Tekrar {id}: başarısız — {msg}",
  toastRetryBusy: "Bir çalışma sürüyor — bitince tekrar dene",
  toastImportOk: "{n} komut yüklendi",
  toastImportFail: "Bu dosya içe aktarılamadı",
  toastCheckFail: "Flow sekme kontrolü bir sorun buldu"
},
fr: {
  done: "Terminé", failed: "Échoué", pending: "En attente", generated: "Généré",
  project: "Projet", timeLeft: "Temps restant", nowGenerating: "Génération en cours",
  setup: "Configuration",
  fileLabel: "Fichier storyboard (.md) ou liste de prompts (.txt) :",
  pasteLabel: "Ou collez les prompts ici (un par ligne) :",
  pastePlaceholder: "Collez les prompts ici, un par ligne...",
  loadPasted: "Charger les prompts collés",
  projectLabel: "Nom du projet (dossier de téléchargement) :",
  projectPlaceholder: "ex. BanksVideo",
  startNumberLabel: "Numéro de départ (texte / coller uniquement) :",
  reference: "Image de référence",
  refFileLabel: "Image de référence (optionnel) :",
  refModeLabel: "Utiliser la référence sur :",
  refModeMarked: "Uniquement les prompts marqués (storyboard)",
  refModeAll: "Chaque prompt",
  refModeNone: "Aucune référence",
  refTxtHint: "Les listes texte n'ont pas de marques auto — choisis « Chaque prompt » si le personnage est nécessaire partout.",
  refStatusPrefix: "État de la référence",
  refStChecking: "Vérification…", refStUploading: "Envoi…", refStReady: "Prête dans le projet", refStFailed: "Échoué", refStNone: "—",
  refConfirmText: "L'image de référence est définie dans le projet Flow ({n} prompts en ont besoin)",
  refNoneInfo: "Aucune image de référence choisie — choisis-en une, elle sera envoyée une fois au démarrage.",
  refReadyInfo: "Référence prête : {name} (PNG, {kb} Ko). Envoyée une fois au début — ne copie rien d'autre tant que ce n'est pas fini.",
  refConvertFail: "Image de référence illisible : {msg}",
  download: "Téléchargement",
  autoDownload: "Téléchargement auto",
  qualityLabel: "Qualité d'image :",
  datedFolder: "Nouveau dossier daté pour chaque exécution",
  retryAtEnd: "Réessayer les échecs à la fin (3 tours)",
  intervalLabel: "Secondes entre les générations :",
  downloadGenerated: "Télécharger les générées",
  generatedReady: "{n} image(s) générée(s) — pas encore téléchargée(s).",
  flowCheck: "Vérification de l'onglet Flow", checkBtn: "Vérifier l'onglet Flow", checkingNow: "Vérification...",
  checkFail: "Vérification échouée : {msg}",
  pfFlowOk: "✓ La page du projet Flow est ouverte",
  pfFlowBad: "✗ Aucune page Flow trouvée — {reason}",
  pfInputOk: "✓ Champ de prompt trouvé ({how})",
  pfInputBad: "✗ Champ de prompt introuvable",
  pfSendOk: "✓ Bouton Generate/Send trouvé ({how})",
  pfSendBad: "✗ Bouton Generate introuvable",
  pfPlusOk: "✓ Bouton d'ajout de référence (+) trouvé — l'ajout par sélecteur marchera",
  pfPlusWarn: "! Bouton d'ajout de référence (+) introuvable — le sélecteur ne s'ouvrira pas si une référence est nécessaire",
  pfAgentBad: "✗ Le mode Agent est ACTIVÉ — désactive-le (les tuiles d'erreur Agent n'ont pas de bouton Retry, et l'agent peut demander une confirmation)",
  pfAgentOk: "✓ Le mode Agent est désactivé",
  pfVideoBad: "✗ On dirait le mode VIDÉO — l'exécution est BLOQUÉE (verrou images uniquement). Choisis Image / Nano Banana dans Flow.",
  pfImageOk: "✓ Le mode Image semble sélectionné",
  pfModeUnknown: "? Mode incertain — vérifie que le mode Image est bien sélectionné",
  pfDurationWarn: "! Un sélecteur de durée (5s/8s) est visible — signe possible du mode vidéo, reste attentif",
  pfSharedRefWarn: "! {n} prompt(s) ont besoin d'une référence de personnage — définis une Shared Ref dans le projet Flow et coche la case, ou choisis une image de référence ci-dessous",
  run: "Exécution", start: "Démarrer", pause: "Pause", resume: "Reprendre", stop: "Arrêter",
  retryFailed: "Réessayer les échecs", skipDownloaded: "Ignorer les déjà téléchargés", clearRun: "Effacer l'exécution sauvée",
  detachCanceled: "Dernier détachement : le bouton Cancel de la barre jaune a été pressé — ne presse jamais Cancel pendant une exécution",
  detachReason: "Raison du dernier détachement : {r}",
  bannerResume: "Une exécution précédente est à moitié faite — Reprendre continue le reste.",
  bannerStale: "Le moteur semble arrêté — l'exécution sauvée est inachevée. Reprendre la relance depuis l'état sauvé.",
  tabItems: "Éléments", tabLog: "Journal", tabReport: "Rapport",
  stPending: "en attente", stActive: "en cours", stDone: "terminé", stFailed: "échoué", stGenerated: "généré",
  matchTitle: "Rapport de correspondance QuickVid",
  matchIdle: "Appuie sur « Vérifier les téléchargements » pour contrôler les fichiers sur le disque.",
  checkDownloads: "Vérifier les téléchargements", copyMissing: "Copier la liste des manquants", downloadReport: "Télécharger le rapport",
  copied: "Copié !", copyFail: "Copie échouée",
  rExpected: "Fichiers attendus", rVerified: "Téléchargés et vérifiés", rMissing: "Manquants",
  rFailed: "Échoués", rGenerated: "Générés (non téléchargés)", rFlowNamed: "Enregistrés avec les noms Flow", rNone: "Aucun",
  reportEmpty: "Aucune exécution pour l'instant — termine d'abord une exécution.",
  help: "Aide",
  noPrompts: "Aucun prompt chargé pour l'instant.",
  loadedInfo: "{n} prompt(s) chargé(s) ({kind})",
  kindStoryboard: "storyboard", kindTxt: "liste texte",
  refNeededInfo: " — {n} ont besoin d'une référence de personnage",
  logLoadedLine: "{n} prompt(s) chargé(s). Premier : {first}, dernier : {last}",
  logParseWarn: "Avertissement d'analyse : {w}",
  logNoPromptsFound: "ATTENTION : aucun prompt trouvé — vérifie le fichier / format",
  logFileReadFail: "Fichier illisible",
  logRefSelected: "Image de référence choisie : {name}",
  logClipboardOk: "L'image de référence est dans le presse-papiers — elle s'envoie une fois au début ; les prompts suivants l'ajoutent depuis le sélecteur",
  logClipboardFail: "ATTENTION : impossible d'écrire la référence dans le presse-papiers ({msg}) — l'exécution se fera SANS référence",
  logLoadFirst: "Charge d'abord des prompts",
  logBlockedVideo: "DÉMARRAGE BLOQUÉ : Flow semble en mode VIDÉO. Choisis le mode Image et revérifie.",
  logBlockedRef: "DÉMARRAGE BLOQUÉ : {n} prompt(s) ont besoin d'une référence — définis une Shared Ref dans le projet Flow et coche la case, ou choisis une image de référence ci-dessous",
  logStartSent: "Démarrage envoyé — projet : {project}, mode réf : {mode}",
  logStartSentRef: " (réf presse-papiers : {state})",
  refStateReady: "prête", refStateFail: "ÉCHOUÉ — sans réf",
  logStartFail: "Démarrage échoué : {msg}",
  logResumeFail: "Reprise échouée : {msg}",
  logStopReq: "Arrêt demandé",
  logRetryFail: "Nouvel essai échoué : {msg}",
  logRetryCount: "Les éléments échoués seront réessayés : {n} élément(s)",
  logSkipFail: "Vérification d'ignorés échouée : {msg}",
  logSkipMarked: "Ignorés : {n} élément(s) marqués terminés",
  logClearDone: "Exécution sauvée effacée",
  logClearFail: "Effacement échoué : {msg}",
  logReportEmpty: "Pas encore de rapport — lance quelque chose d'abord",
  logDlDone: "Téléchargement des générées terminé : {n} image(s)",
  logDlFail: "Téléchargement des générées échoué : {msg}",
  logVerifying: "Vérification des téléchargements…",
  logVerifyFail: "Vérification échouée : {msg}",
  checkAllGood: "Tout est bon",
  checkShortFlow: "Page Flow", checkShortInput: "Aucun champ prompt", checkShortSend: "Aucun bouton Generate",
  checkShortPlus: "Aucun bouton +", checkShortAgent: "Mode Agent ACTIVÉ", checkShortMode: "Mode vidéo",
  endsAt: "Fin ~",
  dropToImport: "Dépose pour importer",
  chooseFile: "Choisir un fichier", noFileChosen: "Aucun fichier choisi",
  retryOne: "Réessayer",
  toastRunDone: "Exécution terminée — Terminé {done}, Échoué {failed}",
  toastDlDone: "Téléchargement terminé — {n} image(s)",
  toastRetryOk: "Nouvel essai {id} : terminé",
  toastRetryFail: "Nouvel essai {id} : échoué — {msg}",
  toastRetryBusy: "Une exécution est en cours — réessaie après",
  toastImportOk: "{n} prompt(s) chargé(s)",
  toastImportFail: "Impossible d'importer ce fichier",
  toastCheckFail: "La vérification Flow a trouvé un problème"
},
de: {
  done: "Fertig", failed: "Fehlgeschlagen", pending: "Offen", generated: "Erstellt",
  project: "Projekt", timeLeft: "Restzeit", nowGenerating: "Wird jetzt erstellt",
  setup: "Einrichtung",
  fileLabel: "Storyboard- (.md) oder Promptlisten-Datei (.txt):",
  pasteLabel: "Oder Prompts hier einfügen (einer pro Zeile):",
  pastePlaceholder: "Prompts hier einfügen, einer pro Zeile...",
  loadPasted: "Eingefügte laden",
  projectLabel: "Projektname (Download-Ordner):",
  projectPlaceholder: "z. B. BanksVideo",
  startNumberLabel: "Startnummer (nur Text / Einfügen):",
  reference: "Referenzbild",
  refFileLabel: "Referenzbild (optional):",
  refModeLabel: "Referenz verwenden bei:",
  refModeMarked: "Nur markierten Prompts (Storyboard)",
  refModeAll: "Jedem Prompt",
  refModeNone: "Keine Referenz",
  refTxtHint: "Textlisten haben keine Auto-Markierungen — wähle \"Jeder Prompt\", wenn die Figur überall gebraucht wird.",
  refStatusPrefix: "Referenzstatus",
  refStChecking: "Prüfe…", refStUploading: "Lade hoch…", refStReady: "Im Projekt bereit", refStFailed: "Fehlgeschlagen", refStNone: "—",
  refConfirmText: "Referenzbild ist im Flow-Projekt gesetzt ({n} Prompts brauchen es)",
  refNoneInfo: "Kein Referenzbild gewählt — wähle eins, es wird beim Start einmal hochgeladen.",
  refReadyInfo: "Referenz bereit: {name} (PNG, {kb} KB). Wird beim Start einmal hochgeladen — bis es fertig ist, nichts anderes kopieren.",
  refConvertFail: "Referenzbild konnte nicht gelesen werden: {msg}",
  download: "Download",
  autoDownload: "Auto-Download",
  qualityLabel: "Bildqualität:",
  datedFolder: "Für jeden Lauf ein neuer datierter Ordner",
  retryAtEnd: "Fehler am Ende erneut versuchen (3 Runden)",
  intervalLabel: "Sekunden zwischen den Erstellungen:",
  downloadGenerated: "Erstellte herunterladen",
  generatedReady: "{n} Bild(er) erstellt — noch nicht heruntergeladen.",
  flowCheck: "Flow-Tab prüfen", checkBtn: "Flow-Tab prüfen", checkingNow: "Prüfe...",
  checkFail: "Prüfung fehlgeschlagen: {msg}",
  pfFlowOk: "✓ Flow-Projektseite ist offen",
  pfFlowBad: "✗ Keine Flow-Seite gefunden — {reason}",
  pfInputOk: "✓ Prompt-Eingabe gefunden ({how})",
  pfInputBad: "✗ Prompt-Eingabe nicht gefunden",
  pfSendOk: "✓ Generate/Send-Button gefunden ({how})",
  pfSendBad: "✗ Generate-Button nicht gefunden",
  pfPlusOk: "✓ Referenz-Hinzufügen-Button (+) gefunden — Anhängen per Auswahl klappt",
  pfPlusWarn: "! Referenz-Hinzufügen-Button (+) nicht gefunden — die Auswahl öffnet sich nicht, falls eine Referenz nötig ist",
  pfAgentBad: "✗ Agent-Modus ist AN — schalte ihn aus (Agent-Fehlerkacheln haben keinen Retry-Button, und der Agent fragt evtl. nach Bestätigung)",
  pfAgentOk: "✓ Agent-Modus ist aus",
  pfVideoBad: "✗ Sieht nach VIDEO-Modus aus — Lauf ist BLOCKIERT (Nur-Bild-Sperre). Wähle in Flow Image / Nano Banana.",
  pfImageOk: "✓ Image-Modus scheint gewählt",
  pfModeUnknown: "? Modus unsicher — bitte prüfe, ob der Image-Modus gewählt ist",
  pfDurationWarn: "! Eine Dauer-Auswahl (5s/8s) ist sichtbar — das kann ein Video-Modus-Zeichen sein, behalte es im Blick",
  pfSharedRefWarn: "! {n} Prompt(s) brauchen eine Figuren-Referenz — setze im Flow-Projekt eine Shared Ref und hake das Kästchen an, oder wähle unten ein Referenzbild",
  run: "Lauf", start: "Start", pause: "Pause", resume: "Weiter", stop: "Stopp",
  retryFailed: "Nur Fehler erneut", skipDownloaded: "Heruntergeladene überspringen", clearRun: "Gespeicherten Lauf löschen",
  detachCanceled: "Letzte Trennung: Cancel der gelben Leiste wurde gedrückt — während eines Laufs nie Cancel drücken",
  detachReason: "Grund der letzten Trennung: {r}",
  bannerResume: "Ein früherer Lauf ist halb fertig — Weiter macht den Rest.",
  bannerStale: "Die Engine scheint gestoppt — der gespeicherte Lauf ist unfertig. Weiter startet ihn aus dem gespeicherten Stand neu.",
  tabItems: "Elemente", tabLog: "Protokoll", tabReport: "Bericht",
  stPending: "offen", stActive: "läuft", stDone: "fertig", stFailed: "fehlgeschlagen", stGenerated: "erstellt",
  matchTitle: "QuickVid-Abgleichbericht",
  matchIdle: "Drücke \"Downloads prüfen\", um die Dateien auf der Platte zu kontrollieren.",
  checkDownloads: "Downloads prüfen", copyMissing: "Fehlende Liste kopieren", downloadReport: "Bericht herunterladen",
  copied: "Kopiert!", copyFail: "Kopieren fehlgeschlagen",
  rExpected: "Erwartete Dateien", rVerified: "Heruntergeladen & geprüft", rMissing: "Fehlend",
  rFailed: "Fehlgeschlagen", rGenerated: "Erstellt (nicht geladen)", rFlowNamed: "Mit Flow-Namen gespeichert", rNone: "Keine",
  reportEmpty: "Noch kein Lauf — beende zuerst einen Lauf.",
  help: "Hilfe",
  noPrompts: "Noch keine Prompts geladen.",
  loadedInfo: "{n} Prompt(s) geladen ({kind})",
  kindStoryboard: "Storyboard", kindTxt: "Textliste",
  refNeededInfo: " — {n} brauchen eine Figuren-Referenz",
  logLoadedLine: "{n} Prompt(s) geladen. Erster: {first}, letzter: {last}",
  logParseWarn: "Parse-Warnung: {w}",
  logNoPromptsFound: "WARNUNG: keine Prompts gefunden — Datei / Format prüfen",
  logFileReadFail: "Datei konnte nicht gelesen werden",
  logRefSelected: "Referenzbild gewählt: {name}",
  logClipboardOk: "Referenzbild ist in der Zwischenablage — es lädt beim Start einmal hoch; spätere Prompts fügen es über die Auswahl hinzu",
  logClipboardFail: "WARNUNG: Referenz konnte nicht in die Zwischenablage ({msg}) — der Lauf geht OHNE Referenz",
  logLoadFirst: "Zuerst Prompts laden",
  logBlockedVideo: "START BLOCKIERT: Flow sieht nach VIDEO-Modus aus. Image-Modus wählen und erneut prüfen.",
  logBlockedRef: "START BLOCKIERT: {n} Prompt(s) brauchen eine Referenz — setze im Flow-Projekt eine Shared Ref und hake das Kästchen an, oder wähle unten ein Referenzbild",
  logStartSent: "Laufstart gesendet — Projekt: {project}, Ref-Modus: {mode}",
  logStartSentRef: " (Zwischenablage-Ref: {state})",
  refStateReady: "bereit", refStateFail: "FEHLGESCHLAGEN — läuft ohne Ref",
  logStartFail: "Start fehlgeschlagen: {msg}",
  logResumeFail: "Weiter fehlgeschlagen: {msg}",
  logStopReq: "Stopp angefordert",
  logRetryFail: "Erneut fehlgeschlagen: {msg}",
  logRetryCount: "Fehlerhafte Elemente werden erneut versucht: {n} Element(e)",
  logSkipFail: "Überspring-Prüfung fehlgeschlagen: {msg}",
  logSkipMarked: "Überspringen: {n} Element(e) als fertig markiert",
  logClearDone: "Gespeicherter Lauf gelöscht",
  logClearFail: "Löschen fehlgeschlagen: {msg}",
  logReportEmpty: "Noch kein Bericht — starte zuerst etwas",
  logDlDone: "Download der Erstellten fertig: {n} Bild(er)",
  logDlFail: "Download der Erstellten fehlgeschlagen: {msg}",
  logVerifying: "Prüfe Downloads…",
  logVerifyFail: "Prüfung fehlgeschlagen: {msg}",
  checkAllGood: "Alles gut",
  checkShortFlow: "Flow-Seite", checkShortInput: "Keine Prompt-Eingabe", checkShortSend: "Kein Generate-Button",
  checkShortPlus: "Kein +-Button", checkShortAgent: "Agent-Modus AN", checkShortMode: "Video-Modus",
  endsAt: "Ende ~",
  dropToImport: "Zum Importieren loslassen",
  chooseFile: "Datei wählen", noFileChosen: "Keine Datei gewählt",
  retryOne: "Erneut",
  toastRunDone: "Lauf fertig — Fertig {done}, Fehlgeschlagen {failed}",
  toastDlDone: "Download fertig — {n} Bild(er)",
  toastRetryOk: "Erneut {id}: fertig",
  toastRetryFail: "Erneut {id}: fehlgeschlagen — {msg}",
  toastRetryBusy: "Ein Lauf läuft — danach erneut versuchen",
  toastImportOk: "{n} Prompt(s) geladen",
  toastImportFail: "Diese Datei konnte nicht importiert werden",
  toastCheckFail: "Flow-Tab-Prüfung hat ein Problem gefunden"
},
it: {
  done: "Fatto", failed: "Falliti", pending: "In attesa", generated: "Generati",
  project: "Progetto", timeLeft: "Tempo rimasto", nowGenerating: "Generazione in corso",
  setup: "Impostazione",
  fileLabel: "File storyboard (.md) o lista prompt (.txt):",
  pasteLabel: "Oppure incolla i prompt qui (uno per riga):",
  pastePlaceholder: "Incolla i prompt qui, uno per riga...",
  loadPasted: "Carica i prompt incollati",
  projectLabel: "Nome progetto (cartella download):",
  projectPlaceholder: "es. BanksVideo",
  startNumberLabel: "Numero iniziale (solo testo / incolla):",
  reference: "Immagine di riferimento",
  refFileLabel: "Immagine di riferimento (facoltativa):",
  refModeLabel: "Usa il riferimento su:",
  refModeMarked: "Solo prompt marcati per riferimento (storyboard)",
  refModeAll: "Ogni prompt",
  refModeNone: "Nessun riferimento",
  refTxtHint: "Le liste testo non hanno segni automatici — scegli \"Ogni prompt\" se il personaggio serve ovunque.",
  refStatusPrefix: "Stato riferimento",
  refStChecking: "Controllo…", refStUploading: "Caricamento…", refStReady: "Pronto nel progetto", refStFailed: "Fallito", refStNone: "—",
  refConfirmText: "L'immagine di riferimento è impostata nel progetto Flow (serve a {n} prompt)",
  refNoneInfo: "Nessuna immagine di riferimento scelta — scegline una, verrà caricata una volta all'avvio.",
  refReadyInfo: "Riferimento pronto: {name} (PNG, {kb} KB). Caricato una volta all'avvio — non copiare altro finché non è finito.",
  refConvertFail: "Immagine di riferimento non leggibile: {msg}",
  download: "Download",
  autoDownload: "Download automatico",
  qualityLabel: "Qualità immagine:",
  datedFolder: "Nuova cartella con data per ogni sessione",
  retryAtEnd: "Riprova i falliti alla fine (3 giri)",
  intervalLabel: "Secondi tra le generazioni:",
  downloadGenerated: "Scarica i generati",
  generatedReady: "{n} immagine/i generata/e — non ancora scaricata/e.",
  flowCheck: "Controllo scheda Flow", checkBtn: "Controlla scheda Flow", checkingNow: "Controllo...",
  checkFail: "Controllo fallito: {msg}",
  pfFlowOk: "✓ La pagina del progetto Flow è aperta",
  pfFlowBad: "✗ Nessuna pagina Flow trovata — {reason}",
  pfInputOk: "✓ Campo prompt trovato ({how})",
  pfInputBad: "✗ Campo prompt non trovato",
  pfSendOk: "✓ Pulsante Generate/Send trovato ({how})",
  pfSendBad: "✗ Pulsante Generate non trovato",
  pfPlusOk: "✓ Pulsante aggiungi riferimento (+) trovato — l'aggiunta da selettore funzionerà",
  pfPlusWarn: "! Pulsante aggiungi riferimento (+) non trovato — il selettore non si aprirà se serve un riferimento",
  pfAgentBad: "✗ La modalità Agent è ATTIVA — disattivala (le tile di errore Agent non hanno il pulsante Retry e l'agente può chiedere conferme)",
  pfAgentOk: "✓ La modalità Agent è disattivata",
  pfVideoBad: "✗ Sembra modalità VIDEO — sessione BLOCCATA (blocco solo immagini). Seleziona Image / Nano Banana in Flow.",
  pfImageOk: "✓ La modalità Image sembra selezionata",
  pfModeUnknown: "? Modalità non certa — assicurati che sia selezionata la modalità Image",
  pfDurationWarn: "! È visibile un selettore di durata (5s/8s) — può essere un segno di modalità video, fai attenzione",
  pfSharedRefWarn: "! {n} prompt hanno bisogno di un riferimento personaggio — imposta uno Shared Ref nel progetto Flow e spunta la casella, oppure scegli un'immagine di riferimento sotto",
  run: "Sessione", start: "Avvia", pause: "Pausa", resume: "Riprendi", stop: "Ferma",
  retryFailed: "Riprova solo i falliti", skipDownloaded: "Salta già scaricati", clearRun: "Cancella sessione salvata",
  detachCanceled: "Ultimo distacco: è stato premuto Cancel della barra gialla — non premere mai Cancel durante una sessione",
  detachReason: "Motivo ultimo distacco: {r}",
  bannerResume: "Una sessione precedente è a metà — Riprendi continua il resto.",
  bannerStale: "Il motore sembra fermo — la sessione salvata è incompleta. Riprendi la rilancia dallo stato salvato.",
  tabItems: "Elementi", tabLog: "Registro", tabReport: "Rapporto",
  stPending: "in attesa", stActive: "in corso", stDone: "fatto", stFailed: "fallito", stGenerated: "generato",
  matchTitle: "Rapporto di corrispondenza QuickVid",
  matchIdle: "Premi \"Controlla download\" per verificare i file sul disco.",
  checkDownloads: "Controlla download", copyMissing: "Copia elenco mancanti", downloadReport: "Scarica rapporto",
  copied: "Copiato!", copyFail: "Copia fallita",
  rExpected: "File attesi", rVerified: "Scaricati e verificati", rMissing: "Mancanti",
  rFailed: "Falliti", rGenerated: "Generati (non scaricati)", rFlowNamed: "Salvati con nomi Flow", rNone: "Nessuno",
  reportEmpty: "Ancora nessuna sessione — prima finiscine una.",
  help: "Aiuto",
  noPrompts: "Nessun prompt caricato finora.",
  loadedInfo: "{n} prompt caricati ({kind})",
  kindStoryboard: "storyboard", kindTxt: "lista testo",
  refNeededInfo: " — {n} hanno bisogno di un riferimento personaggio",
  logLoadedLine: "{n} prompt caricati. Primo: {first}, ultimo: {last}",
  logParseWarn: "Avviso di analisi: {w}",
  logNoPromptsFound: "ATTENZIONE: nessun prompt trovato — controlla file / formato",
  logFileReadFail: "File non leggibile",
  logRefSelected: "Immagine di riferimento scelta: {name}",
  logClipboardOk: "L'immagine di riferimento è negli appunti — si carica una volta all'avvio; i prompt successivi la aggiungono dal selettore",
  logClipboardFail: "ATTENZIONE: impossibile scrivere il riferimento negli appunti ({msg}) — la sessione andrà SENZA riferimento",
  logLoadFirst: "Prima carica i prompt",
  logBlockedVideo: "AVVIO BLOCCATO: Flow sembra in modalità VIDEO. Seleziona la modalità Image e ricontrolla.",
  logBlockedRef: "AVVIO BLOCCATO: {n} prompt hanno bisogno di un riferimento — imposta uno Shared Ref nel progetto Flow e spunta la casella, oppure scegli un'immagine sotto",
  logStartSent: "Avvio inviato — progetto: {project}, modo rif: {mode}",
  logStartSentRef: " (rif appunti: {state})",
  refStateReady: "pronto", refStateFail: "FALLITO — andrà senza rif",
  logStartFail: "Avvio fallito: {msg}",
  logResumeFail: "Ripresa fallita: {msg}",
  logStopReq: "Fermata richiesta",
  logRetryFail: "Nuovo tentativo fallito: {msg}",
  logRetryCount: "Gli elementi falliti saranno riprovati: {n} elemento/i",
  logSkipFail: "Controllo salta fallito: {msg}",
  logSkipMarked: "Salta: {n} elemento/i marcati fatti",
  logClearDone: "Sessione salvata cancellata",
  logClearFail: "Cancellazione fallita: {msg}",
  logReportEmpty: "Ancora nessun rapporto — prima avvia qualcosa",
  logDlDone: "Download dei generati finito: {n} immagine/i",
  logDlFail: "Download dei generati fallito: {msg}",
  logVerifying: "Controllo download…",
  logVerifyFail: "Controllo fallito: {msg}",
  checkAllGood: "Tutto a posto",
  checkShortFlow: "Pagina Flow", checkShortInput: "Nessun campo prompt", checkShortSend: "Nessun pulsante Generate",
  checkShortPlus: "Nessun pulsante +", checkShortAgent: "Modalità Agent ATTIVA", checkShortMode: "Modalità video",
  endsAt: "Fine ~",
  dropToImport: "Rilascia per importare",
  chooseFile: "Scegli file", noFileChosen: "Nessun file scelto",
  retryOne: "Riprova",
  toastRunDone: "Sessione finita — Fatti {done}, Falliti {failed}",
  toastDlDone: "Download finito — {n} immagine/i",
  toastRetryOk: "Riprova {id}: fatto",
  toastRetryFail: "Riprova {id}: fallito — {msg}",
  toastRetryBusy: "C'è una sessione in corso — riprova alla fine",
  toastImportOk: "{n} prompt caricati",
  toastImportFail: "Impossibile importare quel file",
  toastCheckFail: "Il controllo Flow ha trovato un problema"
},
es: {
  done: "Hecho", failed: "Fallido", pending: "Pendiente", generated: "Generado",
  project: "Proyecto", timeLeft: "Tiempo restante", nowGenerating: "Generando ahora",
  setup: "Configuración",
  fileLabel: "Archivo storyboard (.md) o lista de prompts (.txt):",
  pasteLabel: "O pega los prompts aquí (uno por línea):",
  pastePlaceholder: "Pega los prompts aquí, uno por línea...",
  loadPasted: "Cargar los pegados",
  projectLabel: "Nombre del proyecto (carpeta de descarga):",
  projectPlaceholder: "ej. BanksVideo",
  startNumberLabel: "Número inicial (solo texto / pegar):",
  reference: "Imagen de referencia",
  refFileLabel: "Imagen de referencia (opcional):",
  refModeLabel: "Usar referencia en:",
  refModeMarked: "Solo prompts marcados para referencia (storyboard)",
  refModeAll: "Cada prompt",
  refModeNone: "Sin referencia",
  refTxtHint: "Las listas de texto no tienen marcas automáticas — elige \"Cada prompt\" si el personaje se necesita en todos.",
  refStatusPrefix: "Estado de la referencia",
  refStChecking: "Comprobando…", refStUploading: "Subiendo…", refStReady: "Lista en el proyecto", refStFailed: "Fallido", refStNone: "—",
  refConfirmText: "La imagen de referencia está puesta en el proyecto Flow ({n} prompts la necesitan)",
  refNoneInfo: "No se eligió imagen de referencia — elige una y se subirá una vez al iniciar.",
  refReadyInfo: "Referencia lista: {name} (PNG, {kb} KB). Se subirá una vez al iniciar — no copies nada más hasta que termine.",
  refConvertFail: "No se pudo leer la imagen de referencia: {msg}",
  download: "Descarga",
  autoDownload: "Descarga automática",
  qualityLabel: "Calidad de imagen:",
  datedFolder: "Carpeta nueva con fecha para cada sesión",
  retryAtEnd: "Reintentar los fallidos al final (3 rondas)",
  intervalLabel: "Segundos entre generaciones:",
  downloadGenerated: "Descargar los generados",
  generatedReady: "{n} imagen(es) generada(s) — aún no descargada(s).",
  flowCheck: "Comprobación de la pestaña Flow", checkBtn: "Comprobar pestaña Flow", checkingNow: "Comprobando...",
  checkFail: "Comprobación fallida: {msg}",
  pfFlowOk: "✓ La página del proyecto Flow está abierta",
  pfFlowBad: "✗ No se encontró página Flow — {reason}",
  pfInputOk: "✓ Campo de prompt encontrado ({how})",
  pfInputBad: "✗ Campo de prompt no encontrado",
  pfSendOk: "✓ Botón Generate/Send encontrado ({how})",
  pfSendBad: "✗ Botón Generate no encontrado",
  pfPlusOk: "✓ Botón de añadir referencia (+) encontrado — la adición por selector funcionará",
  pfPlusWarn: "! Botón de añadir referencia (+) no encontrado — el selector no se abrirá si se necesita referencia",
  pfAgentBad: "✗ El modo Agent está ACTIVADO — desactívalo (las tarjetas de error Agent no tienen botón Retry y el agente puede pedir confirmación)",
  pfAgentOk: "✓ El modo Agent está desactivado",
  pfVideoBad: "✗ Parece modo VIDEO — la sesión está BLOQUEADA (bloqueo solo imágenes). Selecciona Image / Nano Banana en Flow.",
  pfImageOk: "✓ El modo Image parece seleccionado",
  pfModeUnknown: "? Modo no seguro — asegúrate de que el modo Image esté seleccionado",
  pfDurationWarn: "! Se ve un selector de duración (5s/8s) — puede ser señal de modo video, tenlo en cuenta",
  pfSharedRefWarn: "! {n} prompt(s) necesitan referencia de personaje — pon un Shared Ref en el proyecto Flow y marca la casilla, o elige una imagen de referencia abajo",
  run: "Sesión", start: "Iniciar", pause: "Pausar", resume: "Continuar", stop: "Detener",
  retryFailed: "Reintentar solo fallidos", skipDownloaded: "Saltar ya descargados", clearRun: "Borrar sesión guardada",
  detachCanceled: "Última desconexión: se pulsó Cancel de la barra amarilla — nunca pulses Cancel durante una sesión",
  detachReason: "Motivo de la última desconexión: {r}",
  bannerResume: "Una sesión anterior está a medias — Continuar hace el resto.",
  bannerStale: "El motor parece detenido — la sesión guardada está incompleta. Continuar la reinicia desde el estado guardado.",
  tabItems: "Elementos", tabLog: "Registro", tabReport: "Informe",
  stPending: "pendiente", stActive: "en curso", stDone: "hecho", stFailed: "fallido", stGenerated: "generado",
  matchTitle: "Informe de coincidencia QuickVid",
  matchIdle: "Pulsa \"Comprobar descargas\" para verificar los archivos en disco.",
  checkDownloads: "Comprobar descargas", copyMissing: "Copiar lista de faltantes", downloadReport: "Descargar informe",
  copied: "¡Copiado!", copyFail: "Copia fallida",
  rExpected: "Archivos esperados", rVerified: "Descargados y verificados", rMissing: "Faltantes",
  rFailed: "Fallidos", rGenerated: "Generados (sin descargar)", rFlowNamed: "Guardados con nombres Flow", rNone: "Ninguno",
  reportEmpty: "Aún no hay sesión — termina una primero.",
  help: "Ayuda",
  noPrompts: "Aún no se cargó ningún prompt.",
  loadedInfo: "{n} prompt(s) cargado(s) ({kind})",
  kindStoryboard: "storyboard", kindTxt: "lista de texto",
  refNeededInfo: " — {n} necesitan referencia de personaje",
  logLoadedLine: "{n} prompt(s) cargado(s). Primero: {first}, último: {last}",
  logParseWarn: "Aviso de análisis: {w}",
  logNoPromptsFound: "AVISO: no se encontró ningún prompt — revisa el archivo / formato",
  logFileReadFail: "No se pudo leer el archivo",
  logRefSelected: "Imagen de referencia elegida: {name}",
  logClipboardOk: "La imagen de referencia está en el portapapeles — se sube una vez al iniciar; los prompts siguientes la añaden desde el selector",
  logClipboardFail: "AVISO: no se pudo escribir la referencia en el portapapeles ({msg}) — la sesión irá SIN referencia",
  logLoadFirst: "Primero carga los prompts",
  logBlockedVideo: "INICIO BLOQUEADO: Flow parece en modo VIDEO. Selecciona el modo Image y vuelve a comprobar.",
  logBlockedRef: "INICIO BLOQUEADO: {n} prompt(s) necesitan referencia — pon un Shared Ref en el proyecto Flow y marca la casilla, o elige una imagen abajo",
  logStartSent: "Inicio enviado — proyecto: {project}, modo ref: {mode}",
  logStartSentRef: " (ref portapapeles: {state})",
  refStateReady: "lista", refStateFail: "FALLIDA — irá sin ref",
  logStartFail: "Inicio fallido: {msg}",
  logResumeFail: "Continuación fallida: {msg}",
  logStopReq: "Detención pedida",
  logRetryFail: "Reintento fallido: {msg}",
  logRetryCount: "Los elementos fallidos se reintentarán: {n} elemento(s)",
  logSkipFail: "Comprobación de salto fallida: {msg}",
  logSkipMarked: "Salto: {n} elemento(s) marcados como hechos",
  logClearDone: "Sesión guardada borrada",
  logClearFail: "Borrado fallido: {msg}",
  logReportEmpty: "Aún no hay informe — ejecuta algo primero",
  logDlDone: "Descarga de generados terminada: {n} imagen(es)",
  logDlFail: "Descarga de generados fallida: {msg}",
  logVerifying: "Comprobando descargas…",
  logVerifyFail: "Comprobación fallida: {msg}",
  checkAllGood: "Todo bien",
  checkShortFlow: "Página Flow", checkShortInput: "Sin campo de prompt", checkShortSend: "Sin botón Generate",
  checkShortPlus: "Sin botón +", checkShortAgent: "Modo Agent ACTIVADO", checkShortMode: "Modo vídeo",
  endsAt: "Termina ~",
  dropToImport: "Suelta para importar",
  chooseFile: "Elegir archivo", noFileChosen: "Ningún archivo elegido",
  retryOne: "Reintentar",
  toastRunDone: "Sesión terminada — Hecho {done}, Fallido {failed}",
  toastDlDone: "Descarga terminada — {n} imagen(es)",
  toastRetryOk: "Reintento {id}: hecho",
  toastRetryFail: "Reintento {id}: fallido — {msg}",
  toastRetryBusy: "Hay una sesión en curso — reintenta al terminar",
  toastImportOk: "{n} prompt(s) cargado(s)",
  toastImportFail: "No se pudo importar ese archivo",
  toastCheckFail: "La comprobación Flow encontró un problema"
}
};

/* ---------------- i18n ---------------- */
/* v2.4: real flag IMAGES (assets/flags/*.svg) — Windows Chrome does
 * not render flag emoji (it shows "GB"/"BD" letters), so emoji flags
 * are not used anywhere in the picker. */
const LANGS = [
  { code: 'en', flagFile: 'gb', name: 'English' },
  { code: 'bn', flagFile: 'bd', name: 'বাংলা' },
  { code: 'hi', flagFile: 'in', name: 'हिन्दी' },
  { code: 'tr', flagFile: 'tr', name: 'Türkçe' },
  { code: 'fr', flagFile: 'fr', name: 'Français' },
  { code: 'de', flagFile: 'de', name: 'Deutsch' },
  { code: 'it', flagFile: 'it', name: 'Italiano' },
  { code: 'es', flagFile: 'es', name: 'Español' }
];
const FLAG_SRC = (L) => 'assets/flags/' + L.flagFile + '.svg';
let curLang = 'en';
function t(key, params) {
  const dict = STRINGS[curLang] || STRINGS.en;
  let s = dict[key] !== undefined ? dict[key] : (STRINGS.en[key] !== undefined ? STRINGS.en[key] : key);
  if (params) {
    for (const k of Object.keys(params)) s = s.split('{' + k + '}').join(String(params[k]));
  }
  return s;
}
function panelFormatClock(ts) {
  const d = new Date(ts);
  let h = d.getHours();
  const ap = h >= 12 ? 'PM' : 'AM';
  h = h % 12; if (h === 0) h = 12;
  return h + ':' + String(d.getMinutes()).padStart(2, '0') + ' ' + ap;
}
function panelFormatEta(sec) {
  if (sec === null || sec === undefined || !isFinite(sec) || sec < 0) return '—';
  sec = Math.round(sec);
  if (sec < 60) return sec + 's';
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  if (m < 60) return m + 'm ' + s + 's';
  return Math.floor(m / 60) + 'h ' + (m % 60) + 'm';
}

/* ---------------- panel state ---------------- */
const P = window.SFAParse;
const $ = (id) => document.getElementById(id);

let displayItems = [];
let sourceKind = null;
let lastImportAt = 0;
let lastPreflight = null;
let bgState = null;
let bgLoopActive = false;
let adoptNext = false;
let lastItemSig = '';
let lastLogSig = '';
const localLog = [];
let refBlob = null;
let refFileName = '';
let engineStale = false;
let lastParse = null;        // {n, kind, ref} — for re-render on language change
let refInfo = { kind: 'none' }; // {kind:'none'|'ready'|'fail', name, kb, msg}
let settingsHydrated = false;
let qualitySel = '1K';
let muted = false;
/* v2.4: Flow Tab Check verdict lives ON the button itself.
 * checkVerdict: null (not run yet) | { state:'pass' } |
 * { state:'fail', labelKey } | { state:'failText', text } */
let checkVerdict = null;
let dlToastAt = 0;
let prevDlPass = false;
let prevGenCount = 0;
let lastFinishAt = null;
let activeSeen = { id: '', at: 0 };
let ringShown = -1;
let ringTarget = 0;
let ringAnim = false;
const thumbLocal = new Map();
const thumbAsked = new Set();
let matchData = null;

function plog(msg) {
  localLog.push(new Date().toTimeString().slice(0, 8) + '  ' + msg);
  renderLog();
}
function send(msg) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(msg, (res) => {
      const err = chrome.runtime.lastError;
      resolve(err ? { ok: false, error: err.message } : (res || { ok: false, error: 'No response' }));
    });
  });
}
function needsRefCount() { return P.countNeedsRef(displayItems); }
function itemCounts() {
  const c = { done: 0, failed: 0, pending: 0, active: 0, generated: 0, total: displayItems.length };
  for (const it of displayItems) c[it.status] = (c[it.status] || 0) + 1;
  return c;
}

/* ---------------- toasts (v2.4) ---------------- */
function toast(msg, type) {
  const box = $('toasts');
  if (!box || !msg) return;
  const d = document.createElement('div');
  d.className = 'toast ' + (type || 'info');
  d.textContent = msg;
  box.appendChild(d);
  requestAnimationFrame(() => d.classList.add('in'));
  setTimeout(() => {
    d.classList.add('out');
    setTimeout(() => d.remove(), 320);
  }, 4000);
  while (box.children.length > 3) box.firstChild.remove();
}

/* ---------------- language picker ---------------- */
function buildLangMenu() {
  const menu = $('langMenu');
  menu.innerHTML = '';
  for (const L of LANGS) {
    const b = document.createElement('button');
    b.className = 'langrow' + (L.code === curLang ? ' sel' : '');
    b.dataset.lang = L.code;
    const fl = document.createElement('img'); fl.className = 'flagimg'; fl.src = FLAG_SRC(L); fl.alt = '';
    const nm = document.createElement('span'); nm.textContent = L.name;
    b.appendChild(fl); b.appendChild(nm);
    b.addEventListener('click', () => { setLang(L.code); $('langMenu').classList.add('hidden'); });
    menu.appendChild(b);
  }
  const cur = LANGS.find((L) => L.code === curLang) || LANGS[0];
  $('langFlagImg').src = FLAG_SRC(cur);
}
function setLang(code) {
  if (!STRINGS[code]) code = 'en';
  curLang = code;
  try { chrome.storage.local.set({ sfa_lang: code }); } catch (e) { /* ignore */ }
  buildLangMenu();
  applyLang();
}
$('langBtn').addEventListener('click', (ev) => {
  ev.stopPropagation();
  $('langMenu').classList.toggle('hidden');
});
document.addEventListener('click', (ev) => {
  if (!$('langMenu').classList.contains('hidden') && !ev.target.closest('.langwrap')) {
    $('langMenu').classList.add('hidden');
  }
  if (!$('refModeMenu').classList.contains('hidden') && !ev.target.closest('#refModeDD')) {
    closeRefDD();
  }
});
function applyLang() {
  document.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.getAttribute('data-i18n')); });
  document.querySelectorAll('[data-i18n-ph]').forEach((el) => { el.setAttribute('placeholder', t(el.getAttribute('data-i18n-ph'))); });
  if (!($('fileInput').files && $('fileInput').files.length)) $('fileChosen').textContent = t('noFileChosen');
  if (!($('refImageInput').files && $('refImageInput').files.length)) $('refFileChosen').textContent = t('noFileChosen');
  syncRefDD();
  renderCheckBtn();
  lastItemSig = '';
  lastLogSig = '';
  renderParseInfo();
  renderRefInfo();
  renderRefStatus();
  renderItems();
  renderLog();
  renderStatus();
  renderLive();
  renderReportSummary();
  renderMatch();
  syncControls();
}

/* ---------------- import ---------------- */
function renderParseInfo() {
  if (!lastParse) { $('parseInfo').textContent = t('noPrompts'); return; }
  $('parseInfo').textContent = t('loadedInfo', { n: lastParse.n, kind: t(lastParse.kind === 'storyboard' ? 'kindStoryboard' : 'kindTxt') }) +
    (lastParse.ref ? t('refNeededInfo', { n: lastParse.ref }) : '');
}
function setItems(items, kind, warnings) {
  displayItems = items.map((i) => ({ id: i.id, prompt: i.prompt, needsRef: !!i.needsRef, status: 'pending', attempts: 0, note: '' }));
  sourceKind = kind;
  lastImportAt = Date.now();
  lastItemSig = '';
  lastParse = { n: items.length, kind, ref: needsRefCount() };
  renderParseInfo();
  (warnings || []).forEach((w) => plog(t('logParseWarn', { w })));
  if (items.length === 0) { plog(t('logNoPromptsFound')); toast(t('toastImportFail'), 'error'); }
  else {
    plog(t('logLoadedLine', { n: items.length, first: items[0].id, last: items[items.length - 1].id }));
    toast(t('toastImportOk', { n: items.length }), 'success');
  }
  syncRefRow();
  renderItems();
  renderStatus();
  syncControls();
}
function parseFileText(name, text) {
  const isMd = /\.md$/i.test(name) || /\.markdown$/i.test(name);
  if (isMd || text.indexOf('**Image assignment:**') !== -1) {
    const r = P.parseStoryboard(text);
    setItems(r.items, 'storyboard', r.warnings);
  } else {
    const r = P.parseTxt(text, parseInt($('startNumber').value, 10) || 1);
    setItems(r.items, 'txt', r.warnings);
  }
}
function importFile(f) {
  if (!f) return;
  const reader = new FileReader();
  reader.onload = () => parseFileText(f.name, String(reader.result || ''));
  reader.onerror = () => { plog(t('logFileReadFail')); toast(t('toastImportFail'), 'error'); };
  reader.readAsText(f);
}
$('fileInput').addEventListener('change', (ev) => {
  const f = ev.target.files && ev.target.files[0];
  $('fileChosen').textContent = f ? f.name : t('noFileChosen');
  importFile(f);
});
/* v2.4: drag & drop a .txt/.md file anywhere on the panel to import
 * it — same parse path and feedback as the file picker. */
let dragDepth = 0;
document.addEventListener('dragenter', (ev) => {
  if (!ev.dataTransfer || !Array.from(ev.dataTransfer.types || []).includes('Files')) return;
  ev.preventDefault();
  dragDepth++;
  $('dropOverlay').classList.remove('hidden');
});
document.addEventListener('dragover', (ev) => { ev.preventDefault(); });
document.addEventListener('dragleave', (ev) => {
  dragDepth = Math.max(0, dragDepth - 1);
  if (dragDepth === 0) $('dropOverlay').classList.add('hidden');
});
document.addEventListener('drop', (ev) => {
  ev.preventDefault();
  dragDepth = 0;
  $('dropOverlay').classList.add('hidden');
  const f = ev.dataTransfer && ev.dataTransfer.files && ev.dataTransfer.files[0];
  if (!f) return;
  if (!/\.(txt|md|markdown)$/i.test(f.name)) { toast(t('toastImportFail'), 'error'); return; }
  $('fileChosen').textContent = f.name;
  importFile(f);
});
$('loadPasteBtn').addEventListener('click', () => {
  const r = P.parseTxt($('pasteBox').value, parseInt($('startNumber').value, 10) || 1);
  setItems(r.items, 'txt', r.warnings);
});
$('startNumber').addEventListener('change', () => {
  if (sourceKind === 'txt' && $('pasteBox').value.trim()) {
    const r = P.parseTxt($('pasteBox').value, parseInt($('startNumber').value, 10) || 1);
    setItems(r.items, 'txt', r.warnings);
  }
});

/* ---------------- reference image (clipboard route) ---------------- */
function renderRefInfo() {
  const el = $('refImgInfo');
  if (refInfo.kind === 'ready') el.textContent = t('refReadyInfo', { name: refInfo.name, kb: refInfo.kb });
  else if (refInfo.kind === 'fail') el.textContent = t('refConvertFail', { msg: refInfo.msg });
  else el.textContent = t('refNoneInfo');
}
function toPngBlob(file) {
  return new Promise((resolve, reject) => {
    if (file.type === 'image/png') { resolve(file); return; }
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      try {
        const c = document.createElement('canvas');
        c.width = img.naturalWidth;
        c.height = img.naturalHeight;
        c.getContext('2d').drawImage(img, 0, 0);
        URL.revokeObjectURL(url);
        c.toBlob((b) => (b ? resolve(b) : reject(new Error('PNG convert fail'))), 'image/png');
      } catch (err) { reject(err); }
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('Image read fail')); };
    img.src = url;
  });
}
$('refImageInput').addEventListener('change', async (ev) => {
  const f = ev.target.files && ev.target.files[0];
  $('refFileChosen').textContent = f ? f.name : t('noFileChosen');
  refBlob = null;
  refFileName = '';
  if (!f) { refInfo = { kind: 'none' }; renderRefInfo(); return; }
  try {
    refBlob = await toPngBlob(f);
    refFileName = f.name;
    refInfo = { kind: 'ready', name: f.name, kb: Math.round(refBlob.size / 1024) };
    plog(t('logRefSelected', { name: f.name }));
  } catch (e) {
    refInfo = { kind: 'fail', msg: e.message };
  }
  renderRefInfo();
  syncControls();
});
async function writeRefToClipboard() {
  if (!refBlob) return false;
  try {
    await navigator.clipboard.write([new ClipboardItem({ 'image/png': refBlob })]);
    plog(t('logClipboardOk'));
    return true;
  } catch (e) {
    plog(t('logClipboardFail', { msg: e.message }));
    return false;
  }
}
function refImageChosen() { return !!refBlob && $('refMode').value !== 'none'; }
$('refMode').addEventListener('change', () => { syncRefDD(); syncControls(); });

/* ---------------- refMode custom dropdown (v2.4) ----------------
 * The native <select id="refMode"> stays in the DOM (hidden) as the
 * single source of the value — every existing reader keeps working.
 * The visible control is a styled button + popup; picking a row sets
 * the select's value and fires its change event. */
const REF_MODE_KEYS = { marked: 'refModeMarked', all: 'refModeAll', none: 'refModeNone' };
function syncRefDD() {
  const v = $('refMode').value;
  $('refModeLabel').textContent = t(REF_MODE_KEYS[v] || 'refModeMarked');
  document.querySelectorAll('#refModeMenu .ddrow').forEach((row) => {
    const sel = row.dataset.val === v;
    row.classList.toggle('sel', sel);
    row.setAttribute('aria-selected', sel ? 'true' : 'false');
    row.querySelector('.tick').textContent = sel ? '✓' : '';
  });
}
function closeRefDD() {
  $('refModeMenu').classList.add('hidden');
  $('refModeDD').classList.remove('open');
  $('refModeBtn').setAttribute('aria-expanded', 'false');
}
function openRefDD() {
  $('refModeMenu').classList.remove('hidden');
  $('refModeDD').classList.add('open');
  $('refModeBtn').setAttribute('aria-expanded', 'true');
  const sel = document.querySelector('#refModeMenu .ddrow.sel') || document.querySelector('#refModeMenu .ddrow');
  if (sel) sel.focus();
}
$('refModeBtn').addEventListener('click', (ev) => {
  ev.stopPropagation();
  if ($('refModeMenu').classList.contains('hidden')) openRefDD(); else closeRefDD();
});
document.querySelectorAll('#refModeMenu .ddrow').forEach((row) => {
  row.addEventListener('click', () => {
    $('refMode').value = row.dataset.val;
    $('refMode').dispatchEvent(new Event('change'));
    closeRefDD();
    $('refModeBtn').focus();
  });
});
$('refModeDD').addEventListener('keydown', (ev) => {
  const rows = Array.from(document.querySelectorAll('#refModeMenu .ddrow'));
  const cur = rows.indexOf(document.activeElement);
  if (ev.key === 'Escape') { closeRefDD(); $('refModeBtn').focus(); }
  else if (ev.key === 'ArrowDown' || ev.key === 'ArrowUp') {
    ev.preventDefault();
    if ($('refModeMenu').classList.contains('hidden')) { openRefDD(); return; }
    const next = ev.key === 'ArrowDown'
      ? rows[(cur + 1) % rows.length]
      : rows[(cur - 1 + rows.length) % rows.length];
    if (next) next.focus();
  }
});
function renderRefStatus() {
  const el = $('refStatus');
  const st = bgState && bgState.refStatus;
  if (!st) { el.textContent = ''; return; }
  const key = st === 'checking' ? 'refStChecking' : st === 'uploading' ? 'refStUploading' : st === 'ready' ? 'refStReady' : st === 'failed' ? 'refStFailed' : 'refStNone';
  el.textContent = t('refStatusPrefix') + ': ' + t(key);
}

/* ---------------- preflight (v2.4: verdict on the button) ----------
 * The per-check lines go to the panel Log; the button itself carries
 * the verdict: green "Flow Tab Check: ✓ All good" or red
 * "Flow Tab Check: ✗ <first failed check>". No results list. */
function preflightChecks(r) {
  // [{cls:'ok'|'bad'|'warn', text, shortKey?}] in display order.
  const out = [];
  if (!r) return out;
  out.push(r.flowPage
    ? { cls: 'ok', text: t('pfFlowOk') }
    : { cls: 'bad', text: t('pfFlowBad', { reason: r.blockReason || '' }), shortKey: 'checkShortFlow' });
  if (r.flowPage) {
    out.push(r.input
      ? { cls: 'ok', text: t('pfInputOk', { how: r.input.strategy }) }
      : { cls: 'bad', text: t('pfInputBad'), shortKey: 'checkShortInput' });
    out.push(r.send
      ? { cls: 'ok', text: t('pfSendOk', { how: r.send.strategy }) }
      : { cls: 'bad', text: t('pfSendBad'), shortKey: 'checkShortSend' });
    out.push(r.plusBtn
      ? { cls: 'ok', text: t('pfPlusOk') }
      : { cls: 'warn', text: t('pfPlusWarn'), shortKey: 'checkShortPlus' });
    if (r.agent && r.agent.present && r.agent.active) out.push({ cls: 'bad', text: t('pfAgentBad'), shortKey: 'checkShortAgent' });
    else if (r.agent && r.agent.present) out.push({ cls: 'ok', text: t('pfAgentOk') });
    if (r.mode === 'video') out.push({ cls: 'bad', text: t('pfVideoBad'), shortKey: 'checkShortMode' });
    else if (r.mode === 'image') out.push({ cls: 'ok', text: t('pfImageOk') });
    else out.push({ cls: 'warn', text: t('pfModeUnknown'), shortKey: 'checkShortMode' });
    if (r.modeSignals && r.modeSignals.durationSignal) out.push({ cls: 'warn', text: t('pfDurationWarn') });
  }
  const ref = needsRefCount();
  if (ref > 0) out.push({ cls: 'warn', text: t('pfSharedRefWarn', { n: ref }) });
  return out;
}
function checkLabel() {
  const s = t('flowCheck');
  return s.charAt(0).toUpperCase() + s.slice(1);
}
function renderCheckBtn() {
  const btn = $('checkBtn');
  btn.classList.remove('checking', 'pass', 'fail');
  if (!checkVerdict) { btn.textContent = checkLabel(); return; }
  if (checkVerdict.state === 'pass') {
    btn.classList.add('pass');
    btn.textContent = checkLabel() + ': ✓ ' + t('checkAllGood');
  } else {
    btn.classList.add('fail');
    btn.textContent = checkLabel() + ': ✗ ' + (checkVerdict.labelKey ? t(checkVerdict.labelKey) : (checkVerdict.text || ''));
  }
}
function renderPreflight(logIt) {
  const checks = preflightChecks(lastPreflight);
  if (logIt) checks.forEach((c) => plog(c.text));
  const firstBad = checks.find((c) => c.cls === 'bad');
  checkVerdict = firstBad
    ? { state: 'fail', labelKey: firstBad.shortKey || null, text: firstBad.text }
    : { state: 'pass' };
  renderCheckBtn();
}
$('checkBtn').addEventListener('click', async () => {
  const btn = $('checkBtn');
  btn.disabled = true;
  btn.classList.remove('pass', 'fail');
  btn.classList.add('checking');
  btn.textContent = checkLabel() + ': ' + t('checkingNow');
  const res = await send({ type: 'preflight' });
  btn.disabled = false;
  btn.classList.remove('checking');
  if (!res.ok) {
    plog(t('checkFail', { msg: res.error || '' }));
    checkVerdict = { state: 'fail', labelKey: null, text: res.error || '' };
    renderCheckBtn();
    toast(t('toastCheckFail'), 'error');
    return;
  }
  lastPreflight = res.result;
  renderPreflight(true);
  if (checkVerdict && checkVerdict.state === 'fail') toast(t('toastCheckFail'), 'error');
  syncControls();
});

/* ---------------- ref confirm row ---------------- */
function syncRefRow() {
  const ref = needsRefCount();
  $('refRow').classList.toggle('hidden', ref === 0);
  if (ref > 0) $('refText').textContent = t('refConfirmText', { n: ref });
}
$('refConfirm').addEventListener('change', syncControls);

/* ---------------- download settings ---------------- */
function collectDlSettings() {
  let iv = parseInt($('intervalSec').value, 10);
  if (!isFinite(iv)) iv = 10;
  iv = Math.min(120, Math.max(3, iv));
  return {
    autoDownload: $('autoDownload').checked,
    quality: qualitySel,
    datedFolder: $('datedFolder').checked,
    retryAtEnd: $('retryAtEnd').checked,
    intervalSec: iv
  };
}
async function pushSettings() {
  await send({ type: 'settings', settings: collectDlSettings() });
}
function hydrateSettings(s) {
  if (!s || settingsHydrated) return;
  settingsHydrated = true;
  $('autoDownload').checked = s.autoDownload !== false;
  $('datedFolder').checked = !!s.datedFolder;
  $('retryAtEnd').checked = !!s.retryAtEnd;
  $('intervalSec').value = s.intervalSec || 10;
  qualitySel = (s.quality === '2K' || s.quality === '4K') ? s.quality : '1K';
  document.querySelectorAll('#qualityPills .pill').forEach((p) => p.classList.toggle('sel', p.dataset.q === qualitySel));
}
$('autoDownload').addEventListener('change', pushSettings);
$('datedFolder').addEventListener('change', pushSettings);
$('retryAtEnd').addEventListener('change', pushSettings);
$('intervalSec').addEventListener('change', () => {
  const v = collectDlSettings();
  $('intervalSec').value = v.intervalSec;
  pushSettings();
});
document.querySelectorAll('#qualityPills .pill').forEach((p) => {
  p.addEventListener('click', () => {
    qualitySel = p.dataset.q;
    document.querySelectorAll('#qualityPills .pill').forEach((x) => x.classList.toggle('sel', x === p));
    pushSettings();
  });
});
$('downloadGeneratedBtn').addEventListener('click', async () => {
  $('downloadGeneratedBtn').disabled = true;
  const res = await send({ type: 'downloadGenerated' });
  if (!res.ok) plog(t('logDlFail', { msg: res.error || '' }));
  else {
    plog(t('logDlDone', { n: res.count || 0 }));
    if ((res.count || 0) > 0) { dlToastAt = Date.now(); toast(t('toastDlDone', { n: res.count }), 'success'); }
  }
  await pollState(true);
});

/* ---------------- run controls ---------------- */
$('startBtn').addEventListener('click', async () => {
  if (!displayItems.length) { plog(t('logLoadFirst')); return; }
  if (lastPreflight && lastPreflight.blocked) { plog(t('logBlockedVideo')); return; }
  const ref = needsRefCount();
  if (ref > 0 && !$('refConfirm').checked && !refImageChosen()) {
    plog(t('logBlockedRef', { n: ref }));
    return;
  }
  // Clipboard write must happen inside this user gesture (Start click).
  const refMode = refImageChosen() ? $('refMode').value : 'none';
  let refReady = false;
  if (refMode !== 'none') refReady = await writeRefToClipboard();
  const project = P.sanitizeProject($('projectName').value || 'Project');
  const res = await send({
    type: 'start',
    items: displayItems.map((i) => ({ id: i.id, prompt: i.prompt, needsRef: i.needsRef })),
    project,
    settings: Object.assign({ refMode, refReady, refFileName }, collectDlSettings()),
    tabId: lastPreflight ? lastPreflight.tabId : undefined
  });
  if (!res.ok) plog(t('logStartFail', { msg: res.error || '' }));
  else plog(t('logStartSent', { project, mode: refMode }) + (refMode !== 'none' ? t('logStartSentRef', { state: refReady ? t('refStateReady') : t('refStateFail') }) : ''));
});
$('pauseBtn').addEventListener('click', async () => { await send({ type: 'pause' }); });
$('resumeBtn').addEventListener('click', async () => {
  const res = await send({ type: 'resume' });
  if (!res.ok) plog(t('logResumeFail', { msg: res.error || '' }));
});
$('stopBtn').addEventListener('click', async () => { await send({ type: 'stop' }); plog(t('logStopReq')); });
$('retryBtn').addEventListener('click', async () => {
  const res = await send({ type: 'retryFailed' });
  if (!res.ok) plog(t('logRetryFail', { msg: res.error || '' }));
  else plog(t('logRetryCount', { n: res.count || 0 }));
});
$('skipBtn').addEventListener('click', async () => {
  const res = await send({
    type: 'skipDownloaded',
    items: displayItems.map((i) => ({ id: i.id, prompt: i.prompt, needsRef: i.needsRef, status: i.status, attempts: i.attempts || 0, note: i.note || '' })),
    project: $('projectName').value
  });
  if (!res.ok) plog(t('logSkipFail', { msg: res.error || '' }));
  else { plog(t('logSkipMarked', { n: res.marked })); adoptNext = true; await pollState(true); }
});
$('clearBtn').addEventListener('click', async () => {
  const res = await send({ type: 'clearState' });
  if (res.ok) {
    displayItems = []; lastItemSig = ''; lastParse = null; matchData = null;
    renderItems(); renderStatus(); renderParseInfo(); renderMatch(); renderReportSummary();
    plog(t('logClearDone')); syncControls();
  } else plog(t('logClearFail', { msg: res.error || '' }));
});
$('reportBtn').addEventListener('click', async () => {
  const res = await send({ type: 'buildReport' });
  const text = (res && res.report) || (bgState && bgState.lastReport) || '';
  if (!text) { plog(t('logReportEmpty')); return; }
  const blob = new Blob([text], { type: 'text/plain' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'run-report.txt';
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
});
$('verifyBtn').addEventListener('click', async () => {
  plog(t('logVerifying'));
  const res = await send({ type: 'matchReport' });
  if (!res.ok) { plog(t('logVerifyFail', { msg: res.error || '' })); return; }
  matchData = res.report;
  renderMatch();
});
$('copyMissingBtn').addEventListener('click', async () => {
  const missing = (matchData && matchData.missing) || [];
  try {
    await navigator.clipboard.writeText(missing.join(', '));
    $('copyMissingBtn').textContent = t('copied');
    setTimeout(() => { $('copyMissingBtn').textContent = t('copyMissing'); }, 1500);
  } catch (e) { plog(t('copyFail')); }
});
/* ---------------- tabs ---------------- */
document.querySelectorAll('.tab').forEach((tab) => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((x) => x.classList.toggle('sel', x === tab));
    for (const name of ['items', 'log', 'report']) {
      $('tab-' + name).classList.toggle('hidden', name !== tab.dataset.tab);
    }
    if (tab.dataset.tab === 'report') { renderReportSummary(); renderMatch(); }
    if (tab.dataset.tab === 'log') renderLog(true);
  });
});

/* ---------------- sound + completion celebration ---------------- */
let audioCtx = null;
function playChime() {
  if (muted) return;
  try {
    audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
    if (audioCtx.state === 'suspended') audioCtx.resume();
    const t0 = audioCtx.currentTime;
    [[880, 0], [1318.5, 0.13]].forEach((pair) => {
      const o = audioCtx.createOscillator();
      const g = audioCtx.createGain();
      o.type = 'sine';
      o.frequency.value = pair[0];
      const at = t0 + pair[1];
      g.gain.setValueAtTime(0.0001, at);
      g.gain.exponentialRampToValueAtTime(0.14, at + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, at + 0.12);
      o.connect(g); g.connect(audioCtx.destination);
      o.start(at); o.stop(at + 0.14);
    });
  } catch (e) { /* sound is best-effort */ }
}
function burstConfetti() {
  const box = $('confetti');
  if (!box) return;
  box.innerHTML = '';
  const colors = ['#19b8a6', '#57d977', '#ffc857', '#4fc3f7', '#ff8a80', '#ffffff'];
  for (let i = 0; i < 42; i++) {
    const d = document.createElement('div');
    d.className = 'confetto';
    const size = 5 + Math.random() * 5;
    d.style.left = (Math.random() * 100) + '%';
    d.style.width = size + 'px';
    d.style.height = (size * (0.5 + Math.random())) + 'px';
    d.style.background = colors[i % colors.length];
    d.style.borderRadius = Math.random() > 0.5 ? '50%' : '2px';
    d.style.animationDuration = (1.1 + Math.random() * 0.5) + 's';
    d.style.animationDelay = (Math.random() * 0.2) + 's';
    box.appendChild(d);
  }
  setTimeout(() => { box.innerHTML = ''; }, 2100);
}
$('soundBtn').addEventListener('click', () => {
  muted = !muted;
  $('soundBtn').textContent = muted ? '🔇' : '🔊';
  try { chrome.storage.local.set({ sfa_muted: muted }); } catch (e) { /* ignore */ }
  if (!muted) playChime();
});

/* ---------------- rendering: status card / ring / ETA ---------------- */
function setRing(pct) {
  ringTarget = Math.max(0, Math.min(100, pct));
  if (ringShown < 0) ringShown = 0;
  if (ringAnim) return;
  ringAnim = true;
  const step = () => {
    const diff = ringTarget - ringShown;
    if (Math.abs(diff) < 0.6) { ringShown = ringTarget; }
    else ringShown += diff * 0.25;
    const C = 188.5;
    $('ringFg').style.strokeDashoffset = String(C * (1 - ringShown / 100));
    $('ringPct').textContent = Math.round(ringShown) + '%';
    if (ringShown !== ringTarget) requestAnimationFrame(step);
    else ringAnim = false;
  };
  requestAnimationFrame(step);
}
function renderStatus() {
  const c = itemCounts();
  $('statDone').textContent = c.done;
  $('statFailed').textContent = c.failed;
  $('statPending').textContent = c.pending + c.active;
  $('statGenerated').textContent = c.generated;
  const proj = (bgState && (bgState.runFolder || bgState.project)) || $('projectName').value || '';
  $('statProject').textContent = proj || '—';
  const finished = c.done + c.generated;
  setRing(c.total ? (100 * finished / c.total) : 0);
  let etaTxt = '—';
  let endsTxt = '—';
  if (bgState && bgState.running && bgState.runStartedAt && finished >= 3) {
    const remaining = c.pending + c.active;
    if (remaining > 0) {
      const avgMs = (Date.now() - bgState.runStartedAt) / finished;
      const etaMs = avgMs * remaining;
      etaTxt = panelFormatEta(etaMs / 1000);
      // v2.4: wall-clock finish time next to the time-left.
      endsTxt = panelFormatClock(Date.now() + etaMs);
    } else etaTxt = panelFormatEta(0);
  }
  $('statEta').textContent = etaTxt;
  $('endsLabel').textContent = t('endsAt');
  $('statEnds').textContent = endsTxt;
  const gen = c.generated;
  $('dlLaterInfo').classList.toggle('hidden', gen === 0);
  if (gen > 0) $('dlLaterInfo').textContent = t('generatedReady', { n: gen });
  $('downloadGeneratedBtn').classList.toggle('hidden', gen === 0);
  document.body.classList.toggle('running', !!(bgState && bgState.running));
  renderRefStatus();
}
function renderLive() {
  const active = displayItems.find((i) => i.status === 'active');
  const card = $('liveCard');
  if (!active || !(bgState && bgState.running)) {
    card.classList.add('hidden');
    activeSeen = { id: '', at: 0 };
    return;
  }
  card.classList.remove('hidden');
  if (activeSeen.id !== active.id) activeSeen = { id: active.id, at: Date.now() };
  $('liveId').textContent = active.id;
  $('liveStage').textContent = active.stage || t('stActive');
  $('liveElapsed').textContent = panelFormatEta((Date.now() - activeSeen.at) / 1000);
}

/* ---------------- rendering: items ---------------- */
function renderItems() {
  const thumbSig = Array.from(thumbLocal.keys()).sort().join(',');
  const sig = curLang + '|' + thumbSig + '|' + displayItems.map((i) => i.id + ':' + i.status + ':' + (i.stage || '') + ':' + (i.failReason ? 'F' : '')).join('|');
  if (sig === lastItemSig) return;
  lastItemSig = sig;
  const box = $('itemList');
  box.innerHTML = '';
  const frag = document.createDocumentFragment();
  const stKey = { pending: 'stPending', active: 'stActive', done: 'stDone', failed: 'stFailed', generated: 'stGenerated' };
  for (const it of displayItems) {
    const row = document.createElement('div');
    row.className = 'item';
    if (it.status === 'failed' && (it.failReason || it.note)) row.title = (it.failReason || it.note);
    const dot = document.createElement('span'); dot.className = 'dot ' + (it.status || 'pending');
    const id = document.createElement('span'); id.className = 'id'; id.textContent = it.id;
    row.appendChild(dot);
    row.appendChild(id);
    if (it.needsRef) { const b = document.createElement('span'); b.className = 'refbadge'; b.textContent = 'REF'; row.appendChild(b); }
    const pv = document.createElement('span'); pv.className = 'pv'; pv.textContent = it.prompt.slice(0, 90);
    if (it.status === 'failed' && (it.failReason || it.note)) pv.title = (it.failReason || it.note);
    row.appendChild(pv);
    const thumb = thumbLocal.get(it.id);
    if (thumb) { const im = document.createElement('img'); im.className = 'itemthumb'; im.src = thumb; im.alt = it.id; row.appendChild(im); }
    const st = document.createElement('span');
    st.className = 'st ' + (it.status || 'pending');
    st.textContent = (it.status === 'active' && it.stage) ? it.stage : t(stKey[it.status] || 'stPending');
    row.appendChild(st);
    if (it.status === 'failed') {
      // v2.4: single-item retry — regenerates ONLY this item; the
      // engine downloads it under this item's own ID (see retryOne).
      const rb = document.createElement('button');
      rb.className = 'btn small retryone';
      rb.textContent = t('retryOne');
      rb.addEventListener('click', async (ev) => {
        ev.stopPropagation();
        rb.disabled = true;
        const res = await send({ type: 'retryOne', itemId: it.id });
        if (res.ok) toast(t('toastRetryOk', { id: it.id }), 'success');
        else if (res.error === 'busy') toast(t('toastRetryBusy'), 'error');
        else toast(t('toastRetryFail', { id: it.id, msg: res.error || '' }), 'error');
        lastItemSig = '';
        await pollState(true);
      });
      row.appendChild(rb);
    }
    frag.appendChild(row);
  }
  box.appendChild(frag);
  requestThumbs();
}
async function requestThumbs() {
  const want = displayItems
    .filter((i) => (i.status === 'done' || i.status === 'generated') && !thumbLocal.has(i.id) && !thumbAsked.has(i.id))
    .map((i) => i.id);
  if (!want.length) return;
  want.forEach((id) => thumbAsked.add(id));
  const res = await send({ type: 'thumbs', ids: want });
  if (res.ok && res.thumbs) {
    let got = false;
    for (const id of Object.keys(res.thumbs)) { thumbLocal.set(id, res.thumbs[id]); got = true; }
    // Items the background has no thumbnail for: allow one later retry
    // (the fetch may still be in flight right after completion).
    setTimeout(() => { want.forEach((id) => { if (!thumbLocal.has(id)) thumbAsked.delete(id); }); }, 8000);
    if (got) { lastItemSig = ''; renderItems(); }
  }
}

/* ---------------- rendering: log / report ---------------- */
function renderLog(force) {
  const stateLog = (bgState && bgState.log) || [];
  const all = stateLog.concat(localLog.map((l) => '[panel] ' + l));
  const sig = all.length + ':' + all.reduce((a, l) => a + l.length, 0) + ':' + (all[all.length - 1] || '');
  if (!force && sig === lastLogSig) return;
  lastLogSig = sig;
  const box = $('logBox');
  box.textContent = all.join('\n');
  box.scrollTop = box.scrollHeight;
}
function reportRow(label, val) {
  const d = document.createElement('div'); d.className = 'rrow';
  const a = document.createElement('span'); a.textContent = label;
  const b = document.createElement('b'); b.textContent = val;
  d.appendChild(a); d.appendChild(b);
  return d;
}
function idsLine(ids, cls) {
  const d = document.createElement('div'); d.className = 'ids' + (cls ? ' ' + cls : '');
  d.textContent = ids && ids.length ? ids.join(', ') : t('rNone');
  return d;
}
function renderReportSummary() {
  const box = $('reportSummary');
  if (!box) return;
  box.innerHTML = '';
  if (!displayItems.length) { box.textContent = t('reportEmpty'); return; }
  const c = itemCounts();
  box.appendChild(reportRow(t('rExpected'), String(c.total)));
  box.appendChild(reportRow(t('done'), String(c.done)));
  box.appendChild(reportRow(t('failed'), String(c.failed)));
  box.appendChild(reportRow(t('generated'), String(c.generated)));
  box.appendChild(reportRow(t('pending'), String(c.pending + c.active)));
}
function renderMatch() {
  const box = $('matchReport');
  if (!box) return;
  box.innerHTML = '';
  if (!matchData) return;
  const r = matchData;
  box.appendChild(reportRow(t('rExpected'), String(r.total)));
  box.appendChild(reportRow(t('rVerified'), String(r.verified.length)));
  box.appendChild(reportRow(t('rMissing'), String(r.missing.length)));
  if (r.missing.length) box.appendChild(idsLine(r.missing, 'miss'));
  box.appendChild(reportRow(t('rFailed'), String(r.failed.length)));
  if (r.failed.length) box.appendChild(idsLine(r.failed, 'miss'));
  box.appendChild(reportRow(t('rGenerated'), String(r.generated.length)));
  if (r.generated.length) box.appendChild(idsLine(r.generated, ''));
  box.appendChild(reportRow(t('rFlowNamed'), String(r.flowNamed.length)));
  if (r.flowNamed.length) {
    const d = document.createElement('div'); d.className = 'ids flow';
    d.textContent = r.flowNamed.map((f) => f.id + ' → ' + f.name).join(', ');
    box.appendChild(d);
  }
  $('copyMissingBtn').disabled = !r.missing.length;
}

/* ---------------- controls state ---------------- */
function syncControls() {
  const running = (!!(bgState && bgState.running) || bgLoopActive) && !engineStale;
  const paused = !!(bgState && bgState.paused);
  const hasItems = displayItems.length > 0;
  const hasFailed = displayItems.some((i) => i.status === 'failed');
  const incomplete = displayItems.some((i) => i.status === 'pending' || i.status === 'active');
  const refBlock = needsRefCount() > 0 && !$('refConfirm').checked && !refImageChosen();
  const videoBlock = !!(lastPreflight && lastPreflight.blocked);
  const resumable = (running && paused) || (!bgLoopActive && incomplete && bgState && bgState.runStartedAt) || (engineStale && incomplete);
  $('startBtn').disabled = !hasItems || running || refBlock || videoBlock;
  $('pauseBtn').disabled = !running || paused;
  $('resumeBtn').disabled = !resumable;
  $('stopBtn').disabled = !running;
  $('retryBtn').disabled = !hasFailed || running;
  $('skipBtn').disabled = !hasItems || running;
  $('fileInput').disabled = running;
  $('loadPasteBtn').disabled = running;
  $('downloadGeneratedBtn').disabled = running || !!(bgState && bgState.dlPass) ||
    !displayItems.some((i) => i.status === 'generated');
  const showBanner = (!bgLoopActive && incomplete && bgState && bgState.runStartedAt) || (engineStale && incomplete);
  $('resumeBanner').classList.toggle('hidden', !showBanner);
  $('resumeBanner').textContent = engineStale ? t('bannerStale') : t('bannerResume');
}
/* v2.4.1: the bottom bar no longer repeats status text (Done/Total,
 * engine state, current item — all of that lives in the top zone now).
 * Only the detach warning remains, rendered under the live card. */
function renderEngineStatus() {
  const dEl = $('detachStatus');
  if (!dEl) return;
  const dr = bgState ? (bgState.lastDetachReason || '') : '';
  if (dr) {
    dEl.textContent = dr === 'canceled_by_user' ? t('detachCanceled') : t('detachReason', { r: dr });
    dEl.classList.remove('hidden');
  } else {
    dEl.classList.add('hidden');
    dEl.textContent = '';
  }
}

/* ---------------- state polling ---------------- */
let wasRunning = false;
async function pollState(force) {
  const res = await send({ type: 'getState' });
  if (!res.ok) return;
  bgState = res.state;
  bgLoopActive = !!res.loopActive;
  const st = bgState;
  hydrateSettings(st.settings);
  engineStale = !!(st.running && !bgLoopActive && (!st.engineHeartbeat || Date.now() - st.engineHeartbeat > 30000));
  const idsMatch = st.items && st.items.length === displayItems.length &&
    st.items.every((it, k) => displayItems[k] && it.id === displayItems[k].id);
  if (adoptNext && idsMatch) { displayItems = st.items; adoptNext = false; syncRefRow(); }
  if (st.items && st.items.length && st.runStartedAt && st.runStartedAt >= lastImportAt) {
    displayItems = st.items;
    if (st.project && !$('projectName').value) $('projectName').value = st.project;
    sourceKind = sourceKind || 'storyboard';
    syncRefRow();
  }
  // Setup section: open while idle, closed while a run is going.
  const runningNow = !!st.running;
  if (runningNow !== wasRunning) {
    wasRunning = runningNow;
    $('setupSec').open = !runningNow;
  }
  // Natural finish → celebration + toast (once per run finish).
  const finAt = st.runFinishedAt || 0;
  if (lastFinishAt === null) lastFinishAt = finAt;
  else if (finAt !== lastFinishAt) {
    lastFinishAt = finAt;
    const doneN = (st.items || []).filter((i) => i.status === 'done').length;
    const failN = (st.items || []).filter((i) => i.status === 'failed').length;
    if (finAt > 0) {
      if (doneN > 0) { burstConfetti(); playChime(); }
      toast(t('toastRunDone', { done: doneN, failed: failN }), failN > 0 ? 'info' : 'success');
    }
  }
  // v2.4: Download-Later pass (panel button or the engine's automatic
  // end-of-run pass) finished → toast once, unless the button handler
  // just toasted it. "n" = generated items that left that status
  // during the pass.
  const dlNow = !!st.dlPass;
  const genNow = (st.items || []).filter((i) => i.status === 'generated').length;
  if (prevDlPass && !dlNow && Date.now() - dlToastAt > 3000) {
    const n = Math.max(0, prevGenCount - genNow);
    if (n > 0) { dlToastAt = Date.now(); toast(t('toastDlDone', { n }), 'success'); }
  }
  prevDlPass = dlNow;
  prevGenCount = genNow;
  renderItems();
  renderStatus();
  renderLive();
  renderLog();
  renderEngineStatus();
  syncControls();
}

/* ---------------- init ---------------- */
buildLangMenu();
renderParseInfo();
renderRefInfo();
renderCheckBtn();
syncControls();
try {
  chrome.storage.local.get(['sfa_lang', 'sfa_muted'], (got) => {
    if (got) {
      if (got.sfa_muted) { muted = true; $('soundBtn').textContent = '🔇'; }
      if (got.sfa_lang && STRINGS[got.sfa_lang]) setLang(got.sfa_lang);
    }
    applyLang();
  });
} catch (e) { applyLang(); }
setInterval(() => pollState(false), 1000);
pollState(true);
