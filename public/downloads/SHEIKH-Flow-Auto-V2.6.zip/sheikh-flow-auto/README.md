# SHEIKH Flow Auto

Nijer Google Flow image production er batch extension. Prompt list dile ekta ekta kore Flow te generate kore, thik storyboard er naam e download kore dey (jemon `052B.png`). ViralDNA Auto Flow er motoi poddhoti — kintu amader nijer pipeline er jonno sajano: storyboard .md direct import, A/B number shoho exact naam, reference (Maya) count check.

## Install (ek bar)

1. Chrome e jao: `chrome://extensions`
2. Upar-right e **Developer mode** on koro
3. **Load unpacked** click kore ei `sheikh-flow-auto` folder ta select koro
4. Toolbar e SHEIKH Flow Auto icon asbe — click korle side panel khulbe (icon na dekhale puzzle-piece menu theke pin kore nao)

Update pele: oi eki page e extension er **reload** (circular arrow) button chaplei hobe.

## Prothom test protocol (oboshshoi evabe)

1. Flow te **notun ekdom khali project** kholo (labs.google → Flow)
2. Settings: **Nano Banana**, **16:9**, **x1**, ar oboshshoi **Image mode** (Video mode hole credit noshto hoy — extension nijeo video mode bujhle run block kore dibe)
3. Maya-r reference lagle project e **Shared Ref** hishebe Maya-r chhobi agei set kore rakho
4. Panel e file load koro — prothome **sudhu 10 ta prompt** diye test. Serial thik ache kina, naam thik ache kina, Maya thik asche kina dekho
5. 10 ta pass hole tobei full list (215/166) chalao

## Feature gula kivabe kaj kore

- **Storyboard import:** amader storyboard .md file dile extension nije prompt + image ID (001A, 052B...) ber kore ney. Jekhane prompt e character reference er kotha ache, sekhane REF badge dekhabe ar mot count bole dibe
- **TXT / Paste:** ek line = ek prompt. Start number ja diba sekhan theke serial ID hobe (1 dile 001A, 002A...)
- **Project name:** download hobe `Downloads/SHEIKH Flow Auto/<ProjectName>/<ID>.png` folder e
- **Check Flow Tab:** run er age check kore — Flow page khola ache kina, prompt box ar Generate button paoa jacche kina, ar Image na Video mode select ache. Video mode mone hole **Start block** hoye jabe
- **Run:** ekta ekta kore — prompt bosay, **age Enter chap diye send kore** (Flow er box chat-style, Enter = send). Enter e generation shuru na hole tokhoni **asli mouse click** e Generate chay (Flow nakol click ney na, tai debugger diye real click hoy — cholar somoy Chrome er **holud debugging bar** asbe, eta normal, bar ta bondho koro na). Send button er jayga prompt **lekhar agei** (khali box er layout e) dhore rakha hoy, ar click er age sei point ta verify kore ney — tai text thaka obosthay pashe asha clear/close (×) button e click porar voy nai. Generation sesh howa porjonto opekkha kore, tarpor image ta amader naam e download kore. Proti generation shuru howar majhe **ontoto 10 second gap** (v2 theke fixed niyom)
- **Fail hole:** oi item 2 bar porjonto abar try hoy. Tao fail hole number ta **gap** theke jay (serial sore na), ar sei obosthar screenshot `ERROR-<ID>.png` naam e save hoy. **Retry failed only** dile sudhu fail gula abar hobe
- **Skip already downloaded:** age theke download thakle segula check kore done mark kore dey — gap-fill er jonno
- **Pause / Resume:** Pause dile cholti item sesh kore theme jabe. Chrome bondho hoye geleo queue save thake — panel khulle Resume offer pabe
- **Report:** run sesh hole `run-report.txt` download folder ei project er bhitore save hoy; panel thekeo jekono somoy Download report kora jay. Report e fail item gulor **karon (failReason)** ar seshe **engine log er sesh 40 line** thake — somossa hole sudhu report file ta pathiye dilei diagnosis hobe

## v1.2: Reference image (clipboard diye) + engine log

- **Reference image panel thekei deya jay:** Settings e "Reference image" theke chhobi (jemon Maya) select koro, ar "Reference lagbe" theke mode bachai koro:
  - **Sudhu je prompt e reference lekha ache (storyboard auto):** storyboard jekhane REF badge dekhay, sudhu sei prompt gulor age image paste hobe
  - **SOB prompt ei reference bosbe:** prottektar agei paste hobe (TXT list er jonno eta beche naw — TXT te kono auto-mark nai)
  - **Reference lagbe na:** reference use hobe na
  Start chaple panel image ta **clipboard e PNG hishebe rekhe dey**, engine prottek dorkari item er age Flow er prompt box e **Ctrl+V paste** kore ingredient hishebe bosay, tarpor prompt type kore. Paste hoyeche kina chip bereche kina diye check kore log e likhe dey.
  **⚠️ SABDHAN: reference run cholar somoy computer e onno kichu copy korba na.** Clipboard ei chhobi tai thakte hobe — onno kichu copy korle porer item gulote vul image paste hoye jabe.
  Flow project er **Shared Ref** poddhoti-o chaile ager motoi use korte paro (checkbox) — duto theke ekta beche nilei hobe.
- **Engine log:** ekhon engine er prottek step panel er Log box ei `[engine]` likha shoho ashe — debugger attach holo kina, prompt type verify holo kina, kon button strategy te click holo, generation shuru howar signal pelo kina, waiting e koto second geche, download koto byte holo — sob dekha jay. Item er chip e **stage** (typed / waiting 30s / downloading...) dekhabe, ar fail item er upor mouse rakhle **fail er karon** dekhabe.
- **Generation shuru na hole fail fast:** send er por 12 sec er moddhe generation shurur signal na pele extension porer poddhoti (Enter er por click) try kore; tao na hole item ta 4 minute boshe na theke **shathe shathe fail** hoye jay karon shoho (v1.3 theke: "send hoy ni — Enter o click duitai miss (button khuje pete somossa)").
- **Engine heartbeat:** Run section e "Engine: cholche (last activity Xs age)" dekhabe. Engine theme gele (service worker bondho hoye gele) panel sorkari kore debe ar Resume banner ashbe — saved state theke abar shuru kora jay.

## v1.3: send er bug fix (Enter age, click pore)

- **v1.2 er asol bug:** prompt thikmoto type hoto, kintu send button khujto lekhar **pore** — text thakle composer er pashe ekta clear/close (×) control ashe, ar finder seta tei click kore prompt ta **kete** dito. Generation kono dino shuru hoto na. Upor se "box khali hoyeche" ke generation shurur signal dhore nito, tai engine vul kore 4 minute opekkha korto.
- **Ekhon send hoy Enter diye age:** debugger diye asli Enter chap jay — vul button e porar sujog-i nai. Enter kaj na korle tobei click, tao **lekhar age dhore rakha jayga** te, age sei point ta verify kore (button kina, close/clear kina) — ar close/clear/remove/cancel/delete/dismiss/backspace naam er kono button ke finder ekhon **kokhonoi** beche ney na.
- **Signal er niyom-o bodle geche:** ekhon sudhu **image count barle** ba **generating indicator dekhale** generation shuru hoyeche dhora hoy. Box khali howa ar signal **na** — log e sudhu note hishebe thakbe.
- **Reference mode er naam poriskar:** option gulay ekhon thik ja hobe tai lekha — "Sudhu je prompt e reference lekha ache (storyboard auto)", "SOB prompt ei reference bosbe", "Reference lagbe na". TXT list e kono auto-mark thake na, tai sob prompt e character lagle **'SOB prompt ei'** beche nao.

## v1.4: debugger chere geleo run theme na

- **v1.2 run er report e prove howa bug:** run er majhe Chrome er debugger session ekbar chere gele ("Debugger is not attached to the tab...") engine ar kokhono nije theke attach korto na — baki **prottek** item songe songe ek-i error e fail hoye jeto, puropuri run tai noshto. Session chere jay holud bar er **Cancel** chaple, ba Chrome er service worker restart hole.
- **Ekhon nijei sere jay:** prottek item shurur age ar prottek debugger command e session jachaai hoy; chere giye thakle engine **nijei abar attach** kore command ta retry kore. Generation er opekkhar (wait) majhe detach holeo item more na — opekkha timeout porjonto chaltei thake.
- **Panel e karon dekhabe:** unexpected detach hole Engine line er niche karon ta asbe ("canceled_by_user" hole Cancel er warning shoho), ar log eo line thakbe. Session abar attach hole warning ta chole jay.
- **SABDhan — holud bar er Cancel chapba na:** run cholar somoy debugging bar er **Cancel** chaple session chere jabe. v1.4 nije sere geleo, generation er thik majhe detach hole sei item er somoy noshto hote pare — tai run chola obosthai Cancel e hat debe na.

## v1.5: reference paste ekbar-i, upload sesh na hole send na

- **v1.4 run er report e prove howa tin ta somossa:** (1) prottek attempt e notun kore reference paste hocchilo — ingredient jome jachhilo (chip 2 → 7 → 9), ar prottek copy project grid eo arekta kore sheet upload kore dicchilo. (2) 2.9 MB sheet tar upload cholte thaka obosthai ~1 second porei send hoye jaway Flow nije generation fail kore dey ("Sorry, this image failed to generate"). (3) Paste er por composer sore jaway ager coordinate e type pore box faka theke jeto (box length 0).
- **Paste ekbar-i:** item/attempt shurutei composer e ingredient ache kina dekha hoy; thakle **abar paste hobe na** — log e asbe "reference age thekei ache". Flow successful send er por nijei ingredient khali kore dey, tai porer item abar 0 theke shuru hoy.
- **Upload sesh howa porjonto opekkha:** paste er por engine upload indicator bondho howa + ingredient songkhya por por 2 bar eki thaka porjonto opekkha kore (beshi hole 30 second). **Sei opekkha sesh na hole type-o hobe na, send-o hobe na.**
- **Paste er por composer notun kore khuje type kore:** upload sesh hole composer abar khuje niye notun coordinate e click kore type hoy. Type tao fail hole eki attempt er vitorei aro ekbar — composer notun kore khuje, 600ms opekkha kore — type hoy; dubar-i fail hole tobei attempt fail.
- Ingredient gonona ekhon asol thumbnail ar "image.png" label diye hoy — UI icon ar chip-count er vul gonona ar hobe na.

## v1.6: completion ekhon dui bhabei dhora pore

- **v1.5 run er report e prove howa bug:** generation sesh hoye chhobi project grid e bose chilo, kintu engine 211+ second dhore "image count 0" dekhiye opekkha koreche — karon Flow chhobi majhe majhe sadharon `<img>` hishebe na sajiye **CSS background-image** hishebe sajay, ar ager gonona sudhu `<img>`-i gunto.
- **Ekhon dui bhabei gone:** image gonona ekhon `<img>` ar background-image — **duitai** mile hoy. Download er URL-o sei gonona thekei ashe (background tile er alada download path dorkar hoy na).
- **Busy-cycle niyom (notun backup):** gononay dhora na porleo, generation er "busy" chinno ekbar dekhale ar tarpor por por shanto hoye gele (send er por kompokkhe 15 second) completion dhora pore — log e asbe "completion — busy-cycle rule", gononay mille "completion — count rule".
- **Log e DOM sample:** 60 second periye gele-o notun chhobi gononay na ashle, log e page er image-DOM er sample (koita img ache, segular src ki rokom) ekbar likhe deowa hoy — porer jekono mismatch sudhu report dekhei bojha jabe.

## v2.0 — Final: reference ekbar upload, picker diye re-add, tile diye completion

- **Reference ekbar-i upload hoy, ar full upload na hole kichui shuru hoy na:** run er shurute engine age project e khunje dekhe reference asset ta age thekei ache kina (upload project onujayi theke jay). Na thakle **ekbar** clipboard paste diye upload hoy, tarpor engine tile tar `data-media-id` asha ar "%" chinno chole jawa porjonto opekkha kore (beshi hole 90 second) — **sei gate par na hole generation ekta-o shuru hoy na**, run theme jay karon shoho. Upload hoye gele composer "Clear prompt" diye faka hoy; asset project ei theke jay.
- **Pore kokhono re-upload na — picker diye re-add:** prottek dorkari prompt er age engine composer er **"+" (Add ingredients)** chap diye picker khole, **All** tab theke upload hoye thaka asset ta (age media-id diye, na mille naam diye) beche **"Add to prompt"** chap dey. Chip bosheche kina ingredient gone verify kore. Paste sudhu sei ekbar-i — majhe ar clipboard er dorkar nai, tai run er majhe onno kichu copy korleo somossa nai.
- **Completion ekhon tile dhore:** Flow er notun chhobi googleusercontent diye ashe na — grid er tile (`flow-grid-tile-container`, `data-media-id` shoho `flow.google.com/asb/...` chhobi) dhorei engine bojhe generation sesh. Reference upload ta ke result bole vul kore na.
- **Flow fail korle Retry button:** generation fail hole grid e "Failed" tile ashe — engine sei tile er **Retry** button chap diye abar chalay (item proti 2 bar porjonto). Purono fail tile project e theke geleo segula ke notun fail bole dhore na. **Agent mode OFF rakhba** — Agent mode e error tile e Retry thake na.
- **10 second gap:** proti generation shuru howar majhe ontoto 10 second biroti — panel er purono min/max biroti setting ar nai, eta v2 er fixed niyom.
- **Proti step log e:** upload gate, picker khola, tab, asset select, Add to prompt, chip verify, Retry, completion — prottek dhap log e karon shoho thake. Kothao atkale report file tai bole dibe thik kon dhap e atkechhe.

## v2.1: picker ebar search diye select kore

- **Picker er asol roop dhore probe notun:** Flow er picker ta sadharon listbox na — custom panel ("Search assets" box, category row, thumbnail + naam shoho asset row, preview, "Add to prompt" button). v2.0 probe role/data-media-id khuje 1 ta option peyeo match korte parchilo na, tai sob item "picker e reference khuje pai ni" te fail hochhilo. v2.1 probe search box + "Add to prompt" button shoho panel ta chine vitore thekei tab ar option ber kore.
- **Search diye select:** picker khulle age **"Search assets" box e asset er naam likhe** filter kore (gate er somoy tile er label theke picker-naam record thake; paste kora asset er khetre "image"). Search e 0 option ele search muchhe unfiltered list thekei khunje.
- **Match er order:** media-id → naam → **picker e ekmatro option thakle setai** (log e "picker e ekmatro option tai select holo" ashbe) → kom option thakle filename-pattern. Tao na mille **ja ja option chilo naam shoho log e** theke jay, tai porer diagnosis report thekei hobe.
- **Picker fail ekbare more na:** "picker khule ni / khuje pai ni / add hoy ni" — ei karon gula ekhn **2 attempt porjonto** try pay (age attempts=1 ei item more jeto).

## Honest limits (jene rakho)

- Flow majhe majhe tader page er design bodlay (UI update). Tokhon button/input khunjar selector nao milte pare — run atkale **ERROR screenshot ta pathiye dile** ami selector fix kore notun version diye dibo. Ek-duita fix round lagtei pare, eta ei dhoroner sob extension er i hoy (ViralDNA-r o hoy)
- Run er somoy **Flow tab ta khola ar visible** rakhte hobe; onno tab e chole gele Chrome generation slow/paused kore dite pare
- Holud **debugging bar** asbei — ota bondho korle extension click korte parbe na
- Flow project e DevTools (F12) khola thakle debugger attach fail hote pare — run er somoy DevTools bondho rakho
- Eta sudhu tomar nijer account e, nijer kaj er jonno, safe speed e chalano hoy — khub druto por por chalale Google captcha chaite pare

## Somossa hole

Project folder er `run-report.txt` file tai Bby ke pathiye daw — ete fail er karon ar engine log er sesh ongsho thake, konta te, kon ID te, ki hoyeche bojha jabe. Dorkar hole panel er Log box er screenshot ar `ERROR-*.png` screenshot-o pathate paro.

## v2.2 — Pro Dashboard + new download options (simple English)

This update changes the panel look and adds new download features. The
generation engine is the same proven one from v2.1 — nothing changed in how
images are made.

- **Pro Dashboard panel:** a bigger logo, a status card with an animated
  progress ring, Done / Failed / Pending counts, time-remaining text, a live
  "now generating" card, and Items / Log / Report tabs. Setup, Reference,
  Download and Preflight are clean sections. **Compact mode** shrinks the
  panel to just the ring, counts and Pause/Stop.
- **All panel text is in simple English.** A **language picker** in the
  header (flag button) switches every panel label instantly: English,
  বাংলা, हिन्दी, Türkçe, Français, Deutsch, Italiano, Español. Your choice
  is saved and used next time. Engine log lines stay as they are (they are
  diagnostics).
- **Item thumbnails:** finished items show a small preview image in the
  Items tab.
- **Download quality — 1K / 2K / 4K:** 1K downloads the image directly (the
  old way). 2K and 4K use Flow's own download menu on the finished image,
  so the file keeps Flow's file name — the Report tab lists which items
  have Flow names. If the menu way fails, the tool falls back to 1K
  automatically and writes it in the log.
- **Download Later mode:** turn off "Auto Download" and images are only
  generated, not downloaded. Press **Download generated** to download them
  all afterwards, in order.
- **New dated folder for every run:** downloads go to
  `SHEIKH Flow Auto/<Project>-<YYYYMMDD-HHmm>/` so runs never mix.
- **Retry failed at the end:** failed items are automatically tried again
  when the run finishes (up to 3 extra rounds), unless you press Stop.
- **Seconds between generations:** you can set the gap yourself
  (default 10 seconds, minimum 3, maximum 120).
- **QuickVid match report (Report tab):** press "Check downloads" to see
  how many files are on disk, which IDs are missing, which failed, and
  which were saved with Flow names. "Copy missing list" copies the missing
  IDs for QuickVid gap-filling.
- **Finish alert:** when a run finishes by itself, Chrome shows a
  notification and the panel plays a short sound and a small celebration
  animation. The speaker button in the header turns the sound off.
- **Help link:** the footer has a Help button with the Facebook logo. It
  opens the developer's Facebook profile in a new tab.

Note: the 2K/4K menu download and the thumbnails depend on how Flow's page
behaves live — they are built carefully with safe fallbacks, but test them
on a small run (10 prompts) first, like always.

## v2.3 — Stop/Start fix + Download Later auto-finish

- **Stop er por Start atke thaka fix:** age kokhono kokhono Stop er por
  Start chapleo kichui hoto na (holud bar er Cancel chaple debugger
  session atke giye run loop theme thakto, ar Start silently bad
  pore jeto). Ekhon prottek debugger call er 8 second timeout ache,
  Stop dile sob wait sathe sathe venge jay, ar loop atke thakle
  (heartbeat 20s purono) Start nijei reset kore notun run shuru kore.
  Start kokhono silent na — log e karon lekha thake.
- **Download Later ekhon nijei sesh hoy:** Auto Download off thakle
  age image "generated" hoye bose thakto — panel er button chapa
  lagto. Ekhon run sesh hole generated sob image nije thekei por por
  download hoye jay (Stop chaple hobe na). Majher advance o ek jayga
  theke hoy — done hok ba generated, loop porer prompt e jabei.

## v2.4 — Final

- **Sticky layout:** the header + status card never move (top), the
  middle scrolls, and all Run buttons sit in a fixed bottom bar. The
  Help (Facebook) button lives in that bottom bar too. The live
  generating card is one compact row (ID · stage · time) under the
  status card. Compact mode is gone — one full layout.
- **Flow Tab Check:** one button. Click it and the button itself shows
  the result — green "✓ All good" or red "✗ <what failed>". The detail
  lines go to the Log tab.
- **One design system:** custom dropdown for "Use reference on",
  switch toggles for the download options, a segmented 1K/2K/4K
  control, themed file pickers and inputs, Inter font (with Bengali
  fallback), smooth animations everywhere, and 4 accent colors
  (turquoise, blue, purple, orange) in the header.
- **Real flags:** the language picker uses bundled flag images
  (Windows does not show flag emoji).
- **Toolbar badge:** during a run the extension icon shows the
  done-percent (e.g. 42%).
- **Single-item retry:** every failed item has its own Retry button.
  It regenerates ONLY that item and downloads it under that item's
  own number — no other image is touched or renumbered. (While a run
  is going, retry waits: press it after the run ends.)
- **Ends ~ time:** next to "Time left", the panel shows the clock
  time the run should finish (e.g. "Ends ~5:42 PM").
- **Drag & drop:** drop a .txt/.md file anywhere on the panel to
  import it.
- **Toasts:** small pop-up messages confirm finishes, downloads,
  retries and imports.

## v2.4.1 — Calmer panel (fix round)

- **One fixed colour theme:** the accent colour picker is gone. The
  panel always uses the calm dark + turquoise theme.
- **Calmer buttons:** Start is a soft turquoise fill, Stop is a dark
  button with a red border and red text (no loud solid red), and the
  small buttons in the bottom bar are quiet ghost buttons.
- **Cleaner bottom bar:** it now holds ONLY the run buttons and Help.
  The repeated "Done / Total", version and "Engine: running" lines
  were removed — that info lives in the top status card. (The detach
  warning still appears, under the live card in the top zone.)
- **Less text:** the long reference explanations were shortened in all
  8 languages; labels stay short and to the point.
- **Visible animation:** the logo has a soft pulsing glow, the
  progress ring gets a rotating light sweep while a run is going, the
  Start button breathes gently when idle, and the sections fade in
  one after another when the panel opens.

## v2.6 — Text diet, neutral cinematic theme, real ETA, generation options

- **Text diet:** the Reference section's three explanatory lines are
  gone — one short status chip (✓ filename / status word) is all that
  remains, and every UI string in all 8 languages is now at most one
  short line.
- **Neutral cinematic theme:** near-black base (#0a0a0f) and card
  surfaces (#131318) with quiet neutral borders — no colour washes.
  Violet appears only on selections/buttons and the progress ring,
  cyan only on section headers, green only on Download-generated.
- **Smoother motion:** one easing curve (cubic-bezier(.22,.8,.28,1)),
  200–350ms, transform/opacity only — accordion, tabs, menus, pills,
  buttons, the ring sweep and a gentle live-card pulse.
- **Accurate ETA:** "Time left" and "Ends ~" are computed by the
  engine from this run's real measured pace (rolling average of the
  last up to 8 send→finish cycles; paced mode also weighs the sends
  still to go against the interval). A dash shows until the first
  item completes.
- **Reference thumbnail:** picking a reference file shows a small
  46px preview next to the file chip (session-only, never stored).
- **GENERATION card (ViralDNA parity):** Type (Image | Video), Model
  (Nano Banana 2.1 / Nano Banana Pro / Imagen 4, or Veo 3.1 Fast /
  Veo 3.1 Quality), Aspect ratio (16:9, 9:16, 1:1, 4:3, 3:4) and
  Count (x1–x4). At run start the engine applies the choices to
  Flow's own composer menu and reads the chip back to verify — one
  short log line per setting, and a setting that cannot be applied
  never blocks the run. With Count > 1 each prompt consumes up to
  that many tiles in send order: the first downloads under the
  item's name, the rest are skipped as extras (noted once). Video
  items complete through the same tile machinery and save as .mp4
  (best effort; an uncapturable video fails just that item with an
  honest reason).

## v2.5 — Violet Pro style + Paced mode

- **New look:** deep dark-violet cinematic theme in the ViralDNA
  style — sections as separate rounded cards with soft glows,
  violet segmented pills for every choice, pale-cyan small-caps
  section headers, styled file picker (no native controls), and a
  single green reserved for the Download-generated button.
- **Status-card log:** preflight checks and log lines now render as
  styled rows with ✓ / ✗ / ! / i chips instead of raw text lines.
- **Interval control:** a − value + stepper with preset chips
  (10s, 30s, 1m, 90s, 2m) and a one-line explanation.
- **Two run modes (segmented control):**
  - *One by one* — the classic serial engine, unchanged.
  - *Paced* — after the one-time reference upload, prompts are SENT
    one by one at the set interval without waiting for each image.
    A watcher assigns every finished tile to the OLDEST sent item
    (FIFO), so downloads keep the exact prompt order even when Flow
    finishes out of order. A new error tile (or a 240s silence)
    counts as a failed attempt for the oldest pending item: it is
    re-sent next, up to 3 sends, then marked failed. Pause / Stop /
    Resume work as before; Download Later is honoured (the pass
    downloads in list order).
