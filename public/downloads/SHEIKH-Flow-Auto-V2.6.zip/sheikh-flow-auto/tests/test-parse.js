/* SHEIKH Flow Auto — parser tests against the real pipeline files. */
'use strict';
const fs = require('fs');
const path = require('path');
const P = require(path.join(__dirname, '..', 'lib', 'parse.js'));

const YOUR = '/home/hatch/workspace/your_files';
let failures = 0;
function check(name, cond, detail) {
  console.log((cond ? 'PASS' : 'FAIL') + '  ' + name + (detail ? '  (' + detail + ')' : ''));
  if (!cond) failures++;
}

// --- Banks storyboard: 215 items, 001A..207A, 47 needsRef ---
const banks = P.parseStoryboard(fs.readFileSync(path.join(YOUR, 'how-banks-create-money-storyboard.md'), 'utf8'));
check('banks: 215 items', banks.items.length === 215, 'got ' + banks.items.length);
check('banks: first id 001A', banks.items[0] && banks.items[0].id === '001A', banks.items[0] && banks.items[0].id);
check('banks: last id 207A', banks.items[banks.items.length - 1].id === '207A', banks.items[banks.items.length - 1].id);
check('banks: 47 needsRef', P.countNeedsRef(banks.items) === 47, 'got ' + P.countNeedsRef(banks.items));
check('banks: no empty prompts', banks.items.every(i => i.prompt.length > 30));
check('banks: unique ids', new Set(banks.items.map(i => i.id)).size === banks.items.length);
const bSet = new Set(banks.items.map(i => i.id));
check('banks: has 052B', bSet.has('052B') && bSet.has('052A'));

// --- Printing Money storyboard: 166 items, 0 needsRef ---
const pm = P.parseStoryboard(fs.readFileSync(path.join(YOUR, 'why-printing-money-storyboard.md'), 'utf8'));
check('printing: 166 items', pm.items.length === 166, 'got ' + pm.items.length);
check('printing: first id 001A', pm.items[0] && pm.items[0].id === '001A');
check('printing: last id 156A', pm.items[pm.items.length - 1].id === '156A', pm.items[pm.items.length - 1].id);
check('printing: 0 needsRef', P.countNeedsRef(pm.items) === 0, 'got ' + P.countNeedsRef(pm.items));
check('printing: unique ids', new Set(pm.items.map(i => i.id)).size === pm.items.length);
const pmSet = new Set(pm.items.map(i => i.id));
check('printing: B splits present (019B, 148B)', pmSet.has('019B') && pmSet.has('148B'));
check('printing: no empty prompts', pm.items.every(i => i.prompt.length > 30));

// --- TXT mode: 215 items, ids 001A..215A ---
const txt = P.parseTxt(fs.readFileSync(path.join(YOUR, 'autoflow-FULL-001-207.txt'), 'utf8'), 1);
check('txt: 215 items', txt.items.length === 215, 'got ' + txt.items.length);
check('txt: first id 001A', txt.items[0] && txt.items[0].id === '001A');
check('txt: last id 215A', txt.items[txt.items.length - 1].id === '215A', txt.items[txt.items.length - 1].id);
check('txt: serial ids', txt.items.every((it, k) => it.id === P.pad3(k + 1) + 'A'));

// --- helpers ---
check('pad3', P.pad3(7) === '007' && P.pad3(52) === '052' && P.pad3(215) === '215');
check('targetPath', P.targetPath('Banks Video', '052B') === 'SHEIKH Flow Auto/Banks Video/052B.png', P.targetPath('Banks Video', '052B'));
check('sanitizeProject strips slashes', P.sanitizeProject('a/b:c*d') === 'a b c d', P.sanitizeProject('a/b:c*d'));
check('parseTxt start offset', P.parseTxt('one\n\ntwo\n', 61).items.map(i => i.id).join(',') === '061A,062A');

console.log(failures === 0 ? '\nALL TESTS PASSED' : '\n' + failures + ' TEST(S) FAILED');
process.exit(failures === 0 ? 0 : 1);
