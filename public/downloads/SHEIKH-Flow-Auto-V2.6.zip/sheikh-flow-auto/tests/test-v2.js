/* SHEIKH Flow Auto — v2.0 tests.
 * 1) Self-containment: every page-side probe must survive extraction ->
 *    toString() -> reparse with no references to background-scope names
 *    (that is exactly how evalFn injects them into the Flow tab). The
 *    two pure helpers (sfaMatchOption, sfaPickResultTile) must also
 *    revive standalone.
 * 2) Fake-DOM functional tests: sfaTiles classification (image done /
 *    image with % / error tile with Retry coords / upload tile),
 *    sfaPickResultTile decisions, sfaMatchOption by mediaId then name,
 *    sfaPicker extraction, sfaFindAsset, sfaTileUrl, sfaComposerBar. */
'use strict';
const fs = require('fs');
const path = require('path');
const src = fs.readFileSync(path.join(__dirname, '..', 'background.js'), 'utf8');

let failures = 0;
function check(name, cond, detail) {
  console.log((cond ? 'PASS' : 'FAIL') + '  ' + name + (detail ? '  (' + detail + ')' : ''));
  if (!cond) failures++;
}

/* ---- extraction (brace matching, same shape as evalFn's toString) ---- */
function extract(name) {
  const start = src.indexOf('function ' + name + '(');
  if (start < 0) return null;
  let i = src.indexOf('{', start), depth = 0, j = i;
  for (; j < src.length; j++) {
    if (src[j] === '{') depth++;
    else if (src[j] === '}') { depth--; if (depth === 0) break; }
  }
  return src.slice(start, j + 1);
}

/* ---- 1) self-containment ---- */
const probes = ['sfaFindComposer', 'sfaVerifyPoint', 'sfaProbe', 'sfaMediaScan', 'sfaLastImg',
  'sfaFindDownloadBtn', 'sfaModeProbe', 'sfaComposerText', 'sfaComposerChips', 'sfaIngredients',
  'sfaTiles', 'sfaFindAsset', 'sfaPicker', 'sfaPickerScroll', 'sfaTileUrl', 'sfaComposerBar', 'sfaFindTextBtn'];
const helpers = ['sfaMatchOption', 'sfaPickResultTile', 'sfaSearchTerm', 'sfaPickerNameFromLabel'];
const forbidden = ['evalFn', 'scriptFn', 'cdp(', 'elog(', 'realClick', 'save(', 'beat(', 'sleep(',
  'chrome.', 'targetPath', 'upgradeUrl', 'attachedTabId', 'stopRequested', 'ABORT'];
for (const name of probes.concat(helpers)) {
  const code = extract(name);
  if (!code) { check('exists: ' + name, false, 'not found'); continue; }
  let revived = null;
  try { revived = new Function('return (' + code + ')')(); } catch (e) { /* handled below */ }
  const bad = forbidden.filter((f) => code.includes(f));
  const sRef = /\bS\./.test(code);
  check('self-contained: ' + name, typeof revived === 'function' && bad.length === 0 && !sRef,
    bad.length ? 'outer refs: ' + bad.join(',') : (sRef ? 'outer ref: S.' : code.length + ' chars'));
}

/* ---- 2) fake DOM ---- */
let ALL = [];
function matchSimple(el, part) {
  part = part.trim();
  if (!part) return false;
  const m = part.match(/^([a-zA-Z*][\w-]*)?(.*)$/);
  const tag = m[1];
  let rest = m[2] || '';
  if (tag && tag !== '*' && el.tagName !== tag.toUpperCase()) return false;
  const cls = rest.match(/\.([\w-]+)/);
  if (cls) {
    if (el.className.split(/\s+/).indexOf(cls[1]) === -1) return false;
    rest = rest.replace(cls[0], '');
  }
  const attrParts = rest.match(/\[[^\]]+\]/g) || [];
  for (const a of attrParts) {
    const am = a.match(/^\[([\w-]+)(?:([*^$]?=)"([^"]*)")?\]$/);
    if (!am) return false;
    const name = am[1], op = am[2], val = am[3];
    if (name === 'class') {
      if (op === '*=') { if (el.className.toLowerCase().indexOf(String(val).toLowerCase()) === -1) return false; }
      else if (!el.className) return false;
    } else {
      const v = el.getAttribute(name);
      if (op === '=') { if (v !== val) return false; }
      else if (op === '*=') { if (!v || v.indexOf(val) === -1) return false; }
      else if (v === null || v === undefined) return false;
    }
  }
  return true;
}
function matches(el, sel) { return sel.split(',').some((p) => matchSimple(el, p)); }
class El {
  constructor(tag, opts = {}) {
    this.tagName = tag.toUpperCase();
    this.children = [];
    this.parentElement = null;
    this.text = opts.text || '';
    this.attrs = opts.attrs || {};
    this.className = opts.classes || '';
    this.src = opts.src || '';
    this.currentSrc = opts.src || '';
    this.alt = opts.alt || '';
    this.bgImage = opts.bg || 'none';
    this.w = opts.w === undefined ? 300 : opts.w;
    this.h = opts.h === undefined ? 200 : opts.h;
    this.scrollHeight = opts.scrollHeight || 0;
    this.clientHeight = opts.clientHeight || 0;
    this.scrollTop = 0;
    ALL.push(this);
  }
  add(child) { child.parentElement = this; this.children.push(child); return child; }
  get textContent() { return this.text + this.children.map((c) => c.textContent).join(''); }
  getAttribute(n) {
    if (n === 'class') return this.className || null;
    if (n === 'alt') return this.alt || null;
    return Object.prototype.hasOwnProperty.call(this.attrs, n) ? this.attrs[n] : null;
  }
  getBoundingClientRect() { return { width: this.w, height: this.h, top: 100, left: 50, right: 50 + this.w, bottom: 100 + this.h }; }
  querySelectorAll(sel) {
    const out = [];
    const walk = (e) => { e.children.forEach((c) => { if (matches(c, sel)) out.push(c); walk(c); }); };
    walk(this);
    return out;
  }
  querySelector(sel) { const r = this.querySelectorAll(sel); return r.length ? r[0] : null; }
  closest(sel) { let e = this; while (e) { if (matches(e, sel)) return e; e = e.parentElement; } return null; }
  contains(o) { let e = o; while (e) { if (e === this) return true; e = e.parentElement; } return false; }
}
function buildWorld(build) {
  ALL = [];
  const body = new El('body');
  build(body);
  global.document = {
    body,
    querySelectorAll: (sel) => body.querySelectorAll(sel),
    querySelector: (sel) => body.querySelector(sel),
    get images() { return ALL.filter((e) => e.tagName === 'IMG'); }
  };
  global.window = { innerHeight: 900, innerWidth: 1400 };
  global.getComputedStyle = (el) => ({
    display: 'block', visibility: 'visible', opacity: '1',
    backgroundImage: el.bgImage || 'none'
  });
  return body;
}
const revive = (name) => new Function('return (' + extract(name) + ')')();
const ASB = 'https://flow.google.com/asb/';

/* ---- sfaTiles classification ---- */
const sfaTiles = revive('sfaTiles');
buildWorld((body) => {
  const grid = body.add(new El('div'));
  // done image tile
  const t1 = grid.add(new El('div', { classes: 'flow-grid-tile-container' }));
  const it1 = t1.add(new El('div', { classes: 'flow-image-tile' }));
  it1.add(new El('img', { attrs: { 'data-media-id': 'm1' }, src: ASB + 'aaa' }));
  // in-progress image tile (45%)
  const t2 = grid.add(new El('div', { classes: 'flow-grid-tile-container' }));
  const it2 = t2.add(new El('div', { classes: 'flow-image-tile' }));
  it2.add(new El('img', { attrs: { 'data-media-id': 'm2' }, src: ASB + 'bbb' }));
  t2.add(new El('span', { text: '45%' }));
  // error tile with Retry
  const t3 = grid.add(new El('div', { classes: 'flow-grid-tile-container' }));
  const et = t3.add(new El('div', { classes: 'flow-error-tile' }));
  et.add(new El('div', { classes: 'error-title', text: 'Failed' }));
  et.add(new El('div', { text: 'Sorry, this image failed to generate.' }));
  et.add(new El('button', { text: 'Retry' }));
  et.add(new El('button', { text: 'Delete' }));
  // upload tile still processing (12%), img carries the media id, no flow-image-tile class
  const t4 = grid.add(new El('div', { classes: 'flow-grid-tile-container', attrs: { 'aria-label': 'Maya.png' } }));
  t4.add(new El('img', { attrs: { 'data-media-id': 'u1' }, src: ASB + 'ccc' }));
  t4.add(new El('span', { text: '12%' }));
});
const tiles = sfaTiles();
check('sfaTiles: 4 tiles', tiles.length === 4, 'got ' + tiles.length);
check('sfaTiles: done image classified', tiles[0].kind === 'image' && tiles[0].mediaId === 'm1' && tiles[0].hasThumb === true && tiles[0].hasPct === false && tiles[0].key === 'mid:m1', JSON.stringify(tiles[0]));
check('sfaTiles: progress tile has %', tiles[1].hasPct === true && tiles[1].pct === 45 && tiles[1].mediaId === 'm2', JSON.stringify(tiles[1]));
check('sfaTiles: error tile + Retry coords', tiles[2].kind === 'error' && !!tiles[2].retryBtn && typeof tiles[2].retryBtn.x === 'number', JSON.stringify(tiles[2]));
check('sfaTiles: upload tile', tiles[3].mediaId === 'u1' && tiles[3].hasPct === true && tiles[3].kind === 'image', JSON.stringify(tiles[3]));

/* ---- sfaPickResultTile decisions ---- */
const pick = revive('sfaPickResultTile');
check('pick: first new done tile', pick(tiles, [], null) === tiles[0]);
check('pick: snapshot excludes m1, % tiles never picked', pick(tiles, ['m1'], null) === null);
const tiles2 = tiles.concat([{ mediaId: 'ref1', kind: 'image', hasPct: false, hasThumb: true, label: '', retryBtn: null, key: 'mid:ref1' },
  { mediaId: 'm9', kind: 'image', hasPct: false, hasThumb: true, label: '', retryBtn: null, key: 'mid:m9' }]);
check('pick: reference tile never mistaken for a result', pick(tiles2, ['m1'], 'ref1').mediaId === 'm9');
check('pick: null on empty', pick(null, [], null) === null && pick([], [], null) === null);

/* ---- sfaMatchOption ---- */
const matchOpt = revive('sfaMatchOption');
const opts = [
  { mediaId: 'a1', name: 'street scene.png', x: 1, y: 2 },
  { mediaId: 'b2', name: 'Maya.png', x: 3, y: 4 },
  { mediaId: 'c3', name: 'Maya final version.png', x: 5, y: 6 }
];
check('match: by mediaId wins over name', matchOpt(opts, 'b2', 'zzz') === opts[1]);
check('match: by name (case-insensitive)', matchOpt(opts, null, 'maya.png') === opts[1]);
check('match: by base name substring', matchOpt(opts, 'missing-id', 'Maya final') === opts[2]);
/* v2.1: with >3 options there is no filename fallback, so an unknown
 * name still yields null. (With <=3 options the filename rule below
 * intentionally picks the first image-looking name.) */
const opts4 = opts.concat([{ mediaId: 'd4', name: 'extra.png', x: 7, y: 8 }]);
check('match: nothing found -> null', matchOpt(opts4, null, 'nope') === null && matchOpt([], 'b2', 'Maya') === null);
/* v2.1 matching order: mediaId > name > single-option > filename. */
const oneOpt = [{ mediaId: 'zz', name: 'image.png', x: 1, y: 1 }];
check('match v2.1: single-option shortcut', matchOpt(oneOpt.map((o) => ({ ...o })), 'other-id', 'Economics Explainer Character Sheet.png', 'Economics Explainer Character Sheet.png').via === 'single');
check('match v2.1: mediaId beats single shortcut', matchOpt(oneOpt.map((o) => ({ ...o })), 'zz', 'nope').via === 'mediaId');
const twoOpts = [{ mediaId: null, name: 'notes', x: 0, y: 0 }, { mediaId: null, name: 'image.png', x: 1, y: 1 }];
check('match v2.1: filename-pattern fallback (<=3)', matchOpt(twoOpts.map((o) => ({ ...o })), null, 'nope').via === 'filename');
const namedFirst = [{ mediaId: null, name: 'hero.png', x: 0, y: 0 }, { mediaId: null, name: 'image.png', x: 1, y: 1 }];
check('match v2.1: name match beats filename order', matchOpt(namedFirst.map((o) => ({ ...o })), null, '', 'image.png').via === 'name');

/* ---- v2.1 search-term + picker-name helpers ---- */
const searchTerm = revive('sfaSearchTerm');
check('searchTerm: refPickerName wins', searchTerm('image.png', 'whatever.png', 'Other File.png') === 'image.png');
check('searchTerm: asset filename next', searchTerm('', 'image.png', 'Other File.png') === 'image.png');
check('searchTerm: file base when asset name is a label', searchTerm('', 'some tile label', 'Economics Explainer Character Sheet.png') === 'Economics Explainer Character Sheet');
check('searchTerm: default image', searchTerm('', '', '') === 'image');
const pickerName = revive('sfaPickerNameFromLabel');
check('pickerName: filename from label', pickerName('Nov 01 image.png') === 'image.png');
check('pickerName: generic fallback', pickerName('a generated scene title') === 'image');

/* ---- sfaFindAsset / sfaTileUrl on the same world ---- */
const findAsset = revive('sfaFindAsset');
const fa = findAsset('Maya.png');
check('findAsset: labelled upload tile found', fa.found === true && fa.mediaId === 'u1' && fa.hasPct === true, JSON.stringify(fa));
check('findAsset: unknown name not found', findAsset('nope.png').found === false);
const tileUrl = revive('sfaTileUrl');
const tu = tileUrl('m1');
check('tileUrl: url + centre of the tile', !!tu && tu.url === ASB + 'aaa' && tu.x > 0 && tu.y > 0, JSON.stringify(tu));
check('tileUrl: unknown id -> null', tileUrl('nope') === null);

/* ---- sfaPicker extraction ---- */
const sfaPicker = revive('sfaPicker');
buildWorld((body) => {
  const dlg = body.add(new El('div', { attrs: { role: 'dialog' } }));
  const tablist = dlg.add(new El('div'));
  ['All', 'Images', 'Uploads'].forEach((t) => tablist.add(new El('button', { attrs: { role: 'tab' }, text: t })));
  const lb = dlg.add(new El('div', { attrs: { role: 'listbox', 'aria-label': 'Asset list' } }));
  const o1 = lb.add(new El('div', { attrs: { role: 'option', 'aria-label': 'Maya.png' } }));
  o1.add(new El('img', { attrs: { 'data-media-id': 'p1' }, src: ASB + 'p1' }));
  const o2 = lb.add(new El('div', { attrs: { role: 'option', 'aria-label': 'town.png' } }));
  o2.add(new El('img', { attrs: { 'data-media-id': 'p2' }, src: ASB + 'p2' }));
  dlg.add(new El('button', { text: 'Add to prompt' }));
  dlg.add(new El('button', { text: 'Upload image' }));
});
const pk = sfaPicker();
check('picker: open detected', pk.open === true, JSON.stringify({ open: pk.open, tabs: pk.tabs.length, options: pk.options.length }));
check('picker: tabs found', pk.tabs.map((t) => t.name).join(',') === 'All,Images,Uploads', JSON.stringify(pk.tabs));
check('picker: options carry mediaId + name', pk.options.length === 2 && pk.options[0].mediaId === 'p1' && pk.options[0].name === 'Maya.png', JSON.stringify(pk.options));
check('picker: Add to prompt coords', !!pk.addBtn && typeof pk.addBtn.x === 'number');
check('picker: upload button in scope', pk.uploadBtn === true);
check('picker: option match by mediaId', matchOpt(pk.options, 'p2', '') === pk.options[1]);
check('picker: option match by asset name', matchOpt(pk.options, null, 'Maya.png') === pk.options[0]);

/* ---- sfaPicker v2.1: the REAL custom panel (no ARIA roles at all) --
 * Mirrors the user's screenshot: "Search assets" input, category rows
 * as plain divs, ONE asset row (thumbnail WITHOUT data-media-id +
 * two-line text "image.png" / "Image"), a textless preview pane,
 * "Upload media" and "Add to prompt" buttons. This is the shape the
 * v2.0 role-based probe failed on (1 option seen, never matched). */
buildWorld((body) => {
  const panel = body.add(new El('div', { w: 640, h: 560 }));
  const head = panel.add(new El('div', { w: 640, h: 48 }));
  head.add(new El('input', { attrs: { placeholder: 'Search assets' }, w: 320, h: 36 }));
  const main = panel.add(new El('div', { w: 640, h: 440 }));
  const rail = main.add(new El('div', { w: 180, h: 440 }));
  ['All', 'Images', 'Videos', 'Voices', 'Characters', 'Avatars', 'Uploads'].forEach((t) => {
    const row = rail.add(new El('div', { w: 180, h: 40 }));
    row.add(new El('span', { text: t }));
  });
  const results = main.add(new El('div', { w: 440, h: 440 }));
  const arow = results.add(new El('div', { w: 300, h: 52 }));
  arow.add(new El('img', { src: ASB + 'ref1', w: 40, h: 40 }));
  const tw = arow.add(new El('div', { w: 200, h: 52 }));
  tw.add(new El('div', { text: 'image.png' }));
  tw.add(new El('div', { text: 'Image' }));
  const preview = results.add(new El('div', { w: 380, h: 260 }));
  preview.add(new El('img', { src: ASB + 'ref1big', w: 380, h: 260 }));
  const foot = panel.add(new El('div', { w: 640, h: 56 }));
  foot.add(new El('button', { text: 'Upload media' }));
  foot.add(new El('button', { text: 'Add to prompt' }));
});
const pk2 = sfaPicker();
check('picker v2.1: custom panel detected open', pk2.open === true, JSON.stringify({ tabs: pk2.tabs.length, options: pk2.options.length }));
check('picker v2.1: search input found', !!pk2.searchInput && typeof pk2.searchInput.x === 'number');
check('picker v2.1: category rows found as tabs', pk2.tabs.map((t) => t.name).join(',') === 'All,Images,Videos,Voices,Characters,Avatars,Uploads', JSON.stringify(pk2.tabs.map((t) => t.name)));
check('picker v2.1: exactly one option, filename extracted', pk2.options.length === 1 && pk2.options[0].name === 'image.png' && pk2.options[0].mediaId === null, JSON.stringify(pk2.options));
check('picker v2.1: addBtn + uploadBtn', !!pk2.addBtn && pk2.uploadBtn === true);
check('picker v2.1: the real failure now matches via single-option', matchOpt(pk2.options.map((o) => ({ ...o })), 'unknown-media-id', 'unrelated tile label', 'Economics Explainer Character Sheet.png').via === 'single');

/* ---- sfaComposerBar ---- */
const bar = revive('sfaComposerBar');
buildWorld((body) => {
  body.add(new El('button', { attrs: { 'aria-label': 'Add ingredients to the prompt box' }, text: '+' }));
  body.add(new El('button', { attrs: { 'aria-label': 'Clear prompt' } }));
  body.add(new El('button', { attrs: { 'aria-pressed': 'true' }, text: 'Agent' }));
  body.add(new El('button', { text: 'Start generation' }));
});
const cb = bar();
check('composerBar: plus found', !!cb.plus && cb.plus.label.indexOf('Add ingredients') !== -1, JSON.stringify(cb.plus));
check('composerBar: clear found', !!cb.clear);
check('composerBar: agent present + active', cb.agent.present === true && cb.agent.active === true, JSON.stringify(cb.agent));
buildWorld((body) => { body.add(new El('button', { text: 'Agent' })); });
const cb2 = bar();
check('composerBar: agent present but off', cb2.agent.present === true && cb2.agent.active === false && cb2.plus === null);

console.log(failures === 0 ? '\nALL TESTS PASSED' : '\n' + failures + ' TEST(S) FAILED');
process.exit(failures === 0 ? 0 : 1);
