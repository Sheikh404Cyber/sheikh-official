/* SHEIKH Flow Auto — v1.6 probe tests.
 * 1) Self-containment: every page-side probe must survive extraction ->
 *    toString() -> reparse with no references to background-scope names
 *    (that is exactly how evalFn injects them into the Flow tab).
 * 2) Fake-DOM functional tests for sfaMediaScan: background-image tiles,
 *    <img> tiles, both, and no media. */
'use strict';
const fs = require('fs');
const path = require('path');
const src = fs.readFileSync(path.join(__dirname, '..', 'background.js'), 'utf8');

let failures = 0;
function check(name, cond, detail) {
  console.log((cond ? 'PASS' : 'FAIL') + '  ' + name + (detail ? '  (' + detail + ')' : ''));
  if (!cond) failures++;
}

/* ---- extraction (brace matching, same as evalFn's toString shape) ---- */
function extract(name) {
  const start = src.indexOf('function ' + name + '(');
  if (start < 0) return null;
  let i = src.indexOf('{', start), depth = 0, j = i;
  for (; j < src.length; j++) {
    if (src[j] === '{') depth++;
    else if (src[j] === '}') { depth--; if (depth === 0) break; }
  }
  return src.slice(start, j + 1);
}

/* ---- 1) self-containment for all page probes ---- */
const probes = ['sfaFindComposer', 'sfaVerifyPoint', 'sfaProbe', 'sfaMediaScan', 'sfaLastImg',
  'sfaFindDownloadBtn', 'sfaModeProbe', 'sfaComposerText', 'sfaComposerChips', 'sfaIngredients'];
const forbidden = ['evalFn', 'scriptFn', 'cdp(', 'elog(', 'realClick', 'save(', 'beat(', 'sleep(',
  'chrome.', 'targetPath', 'upgradeUrl', 'attachedTabId', 'stopRequested', 'ABORT'];
for (const name of probes) {
  const code = extract(name);
  if (!code) { check('probe exists: ' + name, false, 'not found'); continue; }
  let revived = null;
  try { revived = new Function('return (' + code + ')')(); } catch (e) { /* handled below */ }
  const bad = forbidden.filter((f) => code.includes(f)) || [];
  const sRef = /\bS\./.test(code);
  check('self-contained: ' + name, typeof revived === 'function' && bad.length === 0 && !sRef,
    bad.length ? 'outer refs: ' + bad.join(',') : (sRef ? 'outer ref: S.' : code.length + ' chars'));
}

/* ---- 2) fake DOM ---- */
let ALL = [];
class El {
  constructor(tag, opts = {}) {
    this.tagName = tag.toUpperCase();
    this.children = [];
    this.parentElement = null;
    this.text = opts.text || '';
    this.attrs = opts.attrs || {};
    this.classes = opts.classes || '';
    this.role = opts.role || '';
    this.src = opts.src || '';
    this.currentSrc = opts.src || '';
    this.bgImage = opts.bg || 'none';
    this.w = opts.w === undefined ? 300 : opts.w;
    this.h = opts.h === undefined ? 200 : opts.h;
    ALL.push(this);
  }
  add(child) { child.parentElement = this; this.children.push(child); return child; }
  get textContent() { return this.text + this.children.map((c) => c.textContent).join(''); }
  getAttribute(n) { return this.attrs[n] || (n === 'role' ? (this.role || null) : null); }
  getBoundingClientRect() { return { width: this.w, height: this.h, top: 100, left: 0 }; }
  querySelectorAll(sel) {
    const out = [];
    const walk = (e) => { e.children.forEach((c) => { if (matchSel(c, sel)) out.push(c); walk(c); }); };
    walk(this);
    return out;
  }
}
function matchSel(el, sel) {
  return sel.split(',').some((part) => {
    part = part.trim();
    if (part === '*') return true;
    if (part === 'img') return el.tagName === 'IMG';
    if (part === '[role="progressbar"]') return el.role === 'progressbar';
    if (part === '[role="alert"]') return el.role === 'alert';
    if (part === '[aria-label]') return !!el.attrs['aria-label'];
    let m = part.match(/^\[class\*="([^"]+)" i\]$/);
    if (m) return el.classes.toLowerCase().includes(m[1].toLowerCase());
    return false;
  });
}
function buildWorld(build) {
  ALL = [];
  const body = new El('body');
  build(body);
  global.document = {
    body,
    querySelectorAll: (sel) => {
      const out = [];
      if (matchSel(body, sel)) out.push(body);
      return out.concat(body.querySelectorAll(sel));
    },
    get images() { return ALL.filter((e) => e.tagName === 'IMG'); }
  };
  global.window = { innerHeight: 900, innerWidth: 1400 };
  global.getComputedStyle = (el) => ({
    display: 'block', visibility: 'visible', opacity: '1',
    backgroundImage: el.bgImage || 'none'
  });
}

const scan = new Function('return (' + extract('sfaMediaScan') + ')')();
const GC = 'https://lh3.googleusercontent.com/';

/* (a) background-image tile only */
buildWorld((body) => {
  const grid = body.add(new El('div'));
  grid.add(new El('div', { bg: 'url("' + GC + 'aaa=w400-h300")' }));
});
let r = scan();
check('(a) bg tile only: total 1', r.total === 1 && r.imgCount === 0 && r.bgCount === 1, JSON.stringify({ t: r.total, i: r.imgCount, b: r.bgCount }));
check('(a) bg tile only: lastUrl is the bg URL', r.lastUrl === GC + 'aaa=w400-h300', String(r.lastUrl));

/* (b) <img> tile only */
buildWorld((body) => {
  const grid = body.add(new El('div'));
  grid.add(new El('img', { src: GC + 'bbb=w400-h300', w: 300, h: 200 }));
});
r = scan();
check('(b) img tile only: total 1', r.total === 1 && r.imgCount === 1 && r.bgCount === 0, JSON.stringify({ t: r.total, i: r.imgCount, b: r.bgCount }));
check('(b) img tile only: lastUrl is the img src', r.lastUrl === GC + 'bbb=w400-h300', String(r.lastUrl));

/* (c) both kinds — lastUrl is the LAST in document order */
buildWorld((body) => {
  const grid = body.add(new El('div'));
  grid.add(new El('img', { src: GC + 'ccc=w400-h300', w: 300, h: 200 }));
  grid.add(new El('div', { bg: 'url("' + GC + 'ddd=w400-h300")' }));
});
r = scan();
check('(c) both: total 2', r.total === 2 && r.imgCount === 1 && r.bgCount === 1, JSON.stringify({ t: r.total, i: r.imgCount, b: r.bgCount }));
check('(c) both: lastUrl is last in document order', r.lastUrl === GC + 'ddd=w400-h300', String(r.lastUrl));

/* (c2) googleusercontent preferred over a later blob: match */
buildWorld((body) => {
  const grid = body.add(new El('div'));
  grid.add(new El('img', { src: GC + 'eee=w400-h300', w: 300, h: 200 }));
  grid.add(new El('img', { src: 'blob:https://flow.google.com/1234', w: 300, h: 200 }));
});
r = scan();
check('(c2) both counted, lastUrl prefers googleusercontent', r.total === 2 && r.lastUrl === GC + 'eee=w400-h300', JSON.stringify({ t: r.total, last: r.lastUrl }));

/* (d) no media — plain elements, a foreign icon, and a too-small GC img */
buildWorld((body) => {
  const grid = body.add(new El('div'));
  grid.add(new El('img', { src: 'https://example.com/icon.png', w: 20, h: 20 }));
  grid.add(new El('img', { src: GC + 'tiny=w40-h30', w: 40, h: 30 }));
  grid.add(new El('div', { text: 'Start creating' }));
});
r = scan();
check('(d) no media: total 0', r.total === 0 && r.imgCount === 0 && r.bgCount === 0, JSON.stringify({ t: r.total, i: r.imgCount, b: r.bgCount }));
check('(d) no media: lastUrl null', r.lastUrl === null, String(r.lastUrl));
check('(d) no media: sampleSrcs falls back to any img srcs', Array.isArray(r.sampleSrcs) && r.sampleSrcs.length >= 1 && r.sampleSrcs[0] === 'https://example.com/icon.png', JSON.stringify(r.sampleSrcs));
check('(d) no media: totalImgs diagnostic', r.totalImgs === 2, 'got ' + r.totalImgs);

console.log(failures === 0 ? '\nALL TESTS PASSED' : '\n' + failures + ' TEST(S) FAILED');
process.exit(failures === 0 ? 0 : 1);
