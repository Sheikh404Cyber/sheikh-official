/*
 * SHEIKH Flow Auto — background service worker.
 * Owns the run engine and the CDP (chrome.debugger) layer.
 * Truth lives in chrome.storage.local under "sfa_state".
 */
'use strict';

/* Clicking the toolbar icon must open the side panel (MV3: not automatic). */
if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
}

/* ---------------- small utils ---------------- */
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const nowTime = () => new Date().toTimeString().slice(0, 8);
const FLOW_URL_RE = /(labs\.google\/.+\/flow|flow\.google\.com)/i;
/* Generation-start spacing: v2.0 fixed a 10s floor (user rule);
 * v2.2 makes it a user setting (settings.intervalSec, 3–120s,
 * default 10) enforced at every send by enforceSendGap. */

/* v2.2 pure helpers (unit-tested in tests/test-v22.js). */
function clampIntervalSec(v) {
  const n = parseInt(v, 10);
  if (!isFinite(n)) return 10;
  return Math.min(120, Math.max(3, n));
}
function formatEta(sec) {
  if (sec === null || sec === undefined || !isFinite(sec) || sec < 0) return '—';
  sec = Math.round(sec);
  if (sec < 60) return sec + 's';
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  if (m < 60) return m + 'm ' + s + 's';
  const h = Math.floor(m / 60);
  const mm = m % 60;
  return h + 'h ' + mm + 'm';
}
/* Dated run folder base: "Project-YYYYMMDD-HHmm" (local time). */
function datedFolderName(project, ts) {
  const d = new Date(ts || Date.now());
  const p2 = (n) => String(n).padStart(2, '0');
  return sanitizeProject(project) + '-' + d.getFullYear() + p2(d.getMonth() + 1) + p2(d.getDate()) + '-' + p2(d.getHours()) + p2(d.getMinutes());
}
/* QuickVid match report builder (pure): items + a verify map
 * (id -> {found, filename}) built by verifyDownloads(). A "done" item
 * whose file is not found on disk is MISSING; items downloaded through
 * Flow's own menu (2K/4K) carry dlName and are listed as flowNamed. */
function buildMatchReport(items, verifyMap) {
  const rep = { total: (items || []).length, verified: [], missing: [], failed: [], generated: [], pending: [], flowNamed: [] };
  for (const it of items || []) {
    const v = (verifyMap && verifyMap[it.id]) || { found: false, filename: '' };
    if (it.status === 'failed') rep.failed.push(it.id);
    else if (it.status === 'generated') rep.generated.push(it.id);
    else if (it.status === 'done') {
      if (v.found) rep.verified.push(it.id); else rep.missing.push(it.id);
      if (it.dlName) rep.flowNamed.push({ id: it.id, name: it.dlName });
    } else rep.pending.push(it.id);
  }
  return rep;
}

/* v2.3 pure helpers (unit-tested in tests/test-v23.js).
 * shouldForceResetLoop: the start/resume handlers may force-reset a
 * run whose loop flag is on but whose heartbeat has not moved for
 * over 20s — every live wait in the engine beats at least every 2s
 * and the heartbeat interval beats every 4s, so 20s of silence means
 * the loop is wedged (e.g. parked inside a CDP call that will never
 * settle) and can be safely invalidated.
 * terminalStatusFor: the single advance decision in the run loop —
 * an item outcome is either "generated" (Download Later: image made,
 * file comes down in the pass) or "done" (everything else). */
function shouldForceResetLoop(isLoopActive, heartbeatMs, nowMs) {
  if (!isLoopActive) return false;
  return (nowMs - (heartbeatMs || 0)) > 20000;
}
function terminalStatusFor(outcome) {
  return outcome && outcome.generatedOnly ? 'generated' : 'done';
}

/* ---------------- state ---------------- */
const DEFAULT_SETTINGS = () => ({
  refMode: 'marked', refReady: false,
  // v2.2 download settings (panel Download section)
  autoDownload: true,   // false = Download Later mode
  quality: '1K',        // '1K' | '2K' | '4K'
  datedFolder: false,   // run folder = <Project>-<YYYYMMDD-HHmm>
  retryAtEnd: false,    // auto-retry failed items when the queue drains (max 3 rounds)
  intervalSec: 10,      // seconds between generation starts (3–120)
  runMode: 'serial'     // v2.5: 'serial' (one by one) | 'paced' (send every interval, FIFO match)
});
const DEFAULT_STATE = () => ({
  version: 1,
  running: false,
  paused: false,
  project: '',
  runFolder: '',        // v2.2: effective download folder base for this run (set at start; resume keeps it)
  retryRoundsUsed: 0,   // v2.2: retry-at-end rounds already spent this run
  dlPass: false,        // v2.2: a Download-Later pass is running right now
  items: [],            // {id, prompt, needsRef, status, attempts, note, failReason, stage, tileMediaId, tileUrl, completedAt, dlName}
  settings: DEFAULT_SETTINGS(),
  // v2.0 reference lifecycle: the reference uploads FIRST and ONCE per
  // project; afterwards each item re-adds it from the project via the
  // ingredient picker. refStatus: '' | 'checking' | 'uploading' | 'ready' | 'failed'
  refFileName: '',      // file name the panel sent (asset name in Flow)
  refMediaId: null,     // data-media-id of the uploaded reference asset
  refAssetName: '',     // label Flow shows for that asset (may be generic)
  refPickerName: '',    // v2.1: name the picker shows/searches (from the tile label's filename, else 'image')
  refStatus: '',
  pacedBase: null,      // v2.5: {at, ids} tile baseline for paced matching (survives resume)
  lastSendAt: 0,        // ms timestamp of the last generation start (10s gap)
  log: [],
  engineHeartbeat: 0,   // ms timestamp, updated by the engine while the run loop lives
  lastDetachReason: '', // last unexpected chrome.debugger detach reason (v1.4)
  lastPreflight: null,
  lastReport: '',
  tabId: null,
  runStartedAt: null,
  runFinishedAt: null
});
let S = DEFAULT_STATE();
let loopActive = false;
let pauseRequested = false;
let stopRequested = false;
let stateLoaded = false;
/* v2.3 — run generation + abort epoch.
 * runGen increments on every runLoop entry and on a force-reset; a
 * loop whose generation is no longer current stops touching state
 * (its finally also skips cleanup, which the newer run owns).
 * abortEpoch is bumped by Stop and by force-reset: every long wait
 * captures the epoch at entry and aborts the moment it changes, and
 * sleepOrStop races its sleep against the epoch so a stop wakes the
 * wait immediately instead of at its next poll (up to 2s later, or —
 * for the 15s attempt backoff — 15s later). */
let runGen = 0;
let abortEpoch = 0;
const epochWaiters = new Set();
function bumpAbortEpoch() {
  abortEpoch++;
  const ws = Array.from(epochWaiters);
  epochWaiters.clear();
  ws.forEach((r) => { try { r(); } catch (e) { /* waiter already gone */ } });
}
function epochChangedPromise(from) {
  if (from !== abortEpoch) return Promise.resolve();
  return new Promise((r) => epochWaiters.add(r));
}
/* Sleep that throws ABORT the instant Stop (or a force-reset) lands.
 * `epoch` is the caller's captured abort epoch; default: current. */
async function sleepOrStop(ms, epoch) {
  const ep = (epoch === undefined ? abortEpoch : epoch);
  if (stopRequested || ep !== abortEpoch) throw ABORT;
  if (!(ms > 0)) return;
  const r = await Promise.race([
    sleep(ms).then(() => 'tick'),
    epochChangedPromise(ep).then(() => 'abort')
  ]);
  if (r === 'abort' || stopRequested || ep !== abortEpoch) throw ABORT;
}

async function loadState() {
  if (stateLoaded) return;
  try {
    const got = await chrome.storage.local.get('sfa_state');
    if (got && got.sfa_state) {
      S = Object.assign(DEFAULT_STATE(), got.sfa_state);
      // v2.2: older saved states lack the new settings — merge defaults.
      S.settings = Object.assign(DEFAULT_SETTINGS(), S.settings || {});
    }
  } catch (e) { /* fresh start */ }
  stateLoaded = true;
}
let saveTimer = null;
function save() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    updateBadge();
    chrome.storage.local.set({ sfa_state: S }).catch(() => {});
  }, 120);
}
function saveNow() {
  if (saveTimer) { clearTimeout(saveTimer); saveTimer = null; }
  updateBadge();
  return chrome.storage.local.set({ sfa_state: S }).catch(() => {});
}

/* v2.4 — toolbar icon badge: while a run is going, the action icon
 * shows the done-percent ("42%"); it clears when the run ends. Driven
 * from the save path (already throttled) and itself only touches
 * Chrome when the integer percent actually changes. */
let lastBadgePct = -1;
function badgePctFor(isRunning, doneCount, generatedCount, totalCount) {
  if (!isRunning || !totalCount) return -1;
  return Math.floor(100 * (doneCount + generatedCount) / totalCount);
}
function updateBadge() {
  try {
    if (!chrome.action || !chrome.action.setBadgeText) return;
    const c = counts();
    const pct = badgePctFor(S.running, c.done, c.generated, c.total);
    if (pct === lastBadgePct) return;
    lastBadgePct = pct;
    if (pct < 0) {
      chrome.action.setBadgeText({ text: '' }).catch(() => {});
    } else {
      chrome.action.setBadgeBackgroundColor({ color: '#7c3aed' }).catch(() => {});
      chrome.action.setBadgeText({ text: pct + '%' }).catch(() => {});
    }
  } catch (e) { /* badge is best-effort */ }
}
function beat() { S.engineHeartbeat = Date.now(); }
function elog(msg) {
  S.log.push('[engine] ' + nowTime() + '  ' + msg);
  if (S.log.length > 300) S.log = S.log.slice(-300);
  beat();
  save();
}
let hbTimer = null;
function startHeartbeat() {
  beat();
  if (hbTimer) return;
  hbTimer = setInterval(() => { beat(); save(); }, 4000);
}
function stopHeartbeat() {
  if (hbTimer) { clearInterval(hbTimer); hbTimer = null; }
}
function counts() {
  const c = { done: 0, failed: 0, pending: 0, active: 0, generated: 0, total: S.items.length };
  for (const it of S.items) c[it.status] = (c[it.status] || 0) + 1;
  return c;
}

/* ---------------- page-side functions (self-contained; run in Flow tab) --- */
function sfaFindComposer() {
  function vis(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
  }
  function center(el) {
    const r = el.getBoundingClientRect();
    return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2), w: Math.round(r.width), h: Math.round(r.height) };
  }
  const cands = [];
  document.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"]').forEach((el) => {
    if (!vis(el)) return;
    const kind = el.tagName.toLowerCase() === 'textarea' ? 'textarea'
      : (el.getAttribute('contenteditable') === 'true' ? 'contenteditable' : 'textbox');
    const hint = ((el.getAttribute('placeholder') || '') + ' ' + (el.getAttribute('aria-label') || '')).toLowerCase();
    const r = el.getBoundingClientRect();
    let score = (r.width * r.height) / 1000;
    if (/what do you want|describe|prompt|create|imagine/.test(hint)) score += 5000;
    if (r.top > window.innerHeight * 0.35) score += 2000;
    cands.push({ el, kind, score });
  });
  cands.sort((a, b) => b.score - a.score);
  if (!cands.length) return { input: null, send: null };
  const inputEl = cands[0].el;
  const ic = center(inputEl);
  let btns = [];
  let container = inputEl;
  for (let up = 0; up < 7 && container; up++) {
    container = container.parentElement;
    if (!container) break;
    const found = [];
    container.querySelectorAll('button, [role="button"]').forEach((b) => { if (vis(b)) found.push(b); });
    if (found.length) { btns = found; break; }
  }
  if (!btns.length) {
    document.querySelectorAll('button, [role="button"]').forEach((b) => {
      if (!vis(b)) return;
      const r = b.getBoundingClientRect();
      if (r.top > window.innerHeight * 0.5 && r.left > window.innerWidth * 0.45) btns.push(b);
    });
  }
  let send = null;
  btns.forEach((b) => {
    const label = ((b.getAttribute('aria-label') || '') + ' ' + (b.getAttribute('title') || '') + ' ' + (b.textContent || '')).toLowerCase();
    // BLACKLIST: a clear/close (x) control can appear in or near the composer
    // once text is present — clicking it ERASES the prompt instead of sending
    // (that is exactly the v1.2 bug). Never pick such a candidate, here or in
    // the preflight (which uses this same finder).
    if (/close|clear|remove|cancel|delete|dismiss|backspace/.test(label)) return;
    const c = center(b);
    let sc = c.x / 10; // prefer right side of the composer row
    if (/send|generate|create|submit|arrow/.test(label)) sc += 1000;
    if (!send || sc > send._sc) {
      const rawLabel = (b.getAttribute('aria-label') || b.getAttribute('title') || (b.textContent || '').trim());
      send = { x: c.x, y: c.y, w: c.w, h: c.h, label: String(rawLabel).slice(0, 60), strategy: /send|generate|create|submit/.test(label) ? 'label-match' : 'rightmost-in-composer', _sc: sc };
    }
  });
  if (send) delete send._sc;
  return { input: { x: ic.x, y: ic.y, w: ic.w, h: ic.h, strategy: cands[0].kind }, send };
}

/* Verify a stored click point: the element at (x, y) — or its closest
 * button ancestor — must be button-like and NOT a blacklisted control
 * (close/clear/remove/cancel/delete/dismiss/backspace). Used before the
 * fallback click so pre-typing coordinates are never trusted blindly. */
function sfaVerifyPoint(pos) {
  const x = pos && typeof pos.x === 'number' ? pos.x : -1;
  const y = pos && typeof pos.y === 'number' ? pos.y : -1;
  if (x < 0 || y < 0) return { ok: false, reason: 'bad coords' };
  const el = document.elementFromPoint(x, y);
  if (!el) return { ok: false, reason: 'point e kichu nai' };
  const btn = el.closest ? el.closest('button, [role="button"]') : null;
  if (!btn) return { ok: false, reason: 'button na', tag: el.tagName || '' };
  const label = ((btn.getAttribute('aria-label') || '') + ' ' + (btn.getAttribute('title') || '') + ' ' + (btn.textContent || '')).toLowerCase();
  if (/close|clear|remove|cancel|delete|dismiss|backspace/.test(label)) {
    return { ok: false, reason: 'blacklisted button', label: label.trim().slice(0, 60) };
  }
  const rawLabel = (btn.getAttribute('aria-label') || btn.getAttribute('title') || (btn.textContent || '').trim());
  return { ok: true, label: String(rawLabel).slice(0, 60), tag: btn.tagName || '' };
}

function sfaProbe() {
  let count = 0;
  document.querySelectorAll('img').forEach((im) => {
    const src = im.currentSrc || im.src || '';
    if (!/googleusercontent|blob:/.test(src)) return;
    const r = im.getBoundingClientRect();
    if (r.width > 100 && r.height > 60) count++;
  });
  let busy = false;
  document.querySelectorAll('[role="progressbar"]').forEach((e) => {
    const r = e.getBoundingClientRect();
    if (r.width > 0 && r.height > 0) busy = true;
  });
  if (!busy) document.querySelectorAll('[aria-label]').forEach((e) => {
    if (busy) return;
    const a = (e.getAttribute('aria-label') || '').toLowerCase();
    if (/generating|loading|working on/.test(a)) {
      const r = e.getBoundingClientRect();
      if (r.width > 0 && r.height > 0) busy = true;
    }
  });
  if (!busy) document.querySelectorAll('[class*="spinner" i], [class*="loading" i]').forEach((e) => {
    if (busy) return;
    const r = e.getBoundingClientRect();
    if (r.width > 4 && r.height > 4) {
      const s = getComputedStyle(e);
      if (s.display !== 'none' && s.visibility !== 'hidden') busy = true;
    }
  });
  let error = '';
  document.querySelectorAll('[role="alert"], [class*="toast" i], [class*="snackbar" i], [class*="error" i]').forEach((e) => {
    if (error) return;
    const t = (e.textContent || '').trim();
    if (t && /couldn'?t generate|can'?t generate|something went wrong|unable to generate|failed to generate|violates|policy/i.test(t)) {
      const r = e.getBoundingClientRect();
      if (r.width > 0 && r.height > 0) error = t.slice(0, 200);
    }
  });
  return { count, busy, error };
}

/* v1.6 — combined media scan. Proven by the user's v1.5 run report:
 * generation finished and the completed tile sat in the Flow project
 * grid, yet every wait poll for 211+ seconds logged "image count 0
 * (baseline 0, busy=false)". flow.google.com does NOT render generated
 * tiles as plain <img src=googleusercontent|blob:> elements that
 * sfaProbe counts — the tiles are CSS background-image elements (or
 * another DOM shape). This probe counts BOTH kinds in one document-order
 * walk (capped at ~5000 elements for perf): matching <img> elements and
 * elements whose computed background-image URL matches. lastUrl prefers
 * a googleusercontent URL (size-upgradeable) over blob:. Busy/error
 * detection is the same logic as sfaProbe. Diagnostics (totalImgs,
 * sampleSrcs) ride along so any future DOM mismatch is visible in the
 * run report alone. */
function sfaMediaScan() {
  const MEDIA = /googleusercontent|blob:/i;
  let imgCount = 0;
  let bgCount = 0;
  let lastAny = null;
  let lastGc = null;
  const matchSrcs = [];
  function noteMatch(url) {
    if (!url) return;
    lastAny = url;
    if (/googleusercontent/i.test(url)) lastGc = url;
  }
  let els = [];
  try {
    els = document.body ? Array.prototype.slice.call(document.body.querySelectorAll('*')) : [];
  } catch (e) { els = []; }
  const CAP = 5000;
  const n = Math.min(els.length, CAP);
  for (let i = 0; i < n; i++) {
    const el = els[i];
    let matched = false;
    if (el.tagName === 'IMG') {
      const src = el.currentSrc || el.src || '';
      if (src && MEDIA.test(src)) {
        const r = el.getBoundingClientRect();
        if (r.width >= 80 && r.height >= 50) {
          imgCount++;
          matched = true;
          noteMatch(src);
          if (matchSrcs.length < 3) matchSrcs.push(src.slice(0, 90));
        }
      }
    }
    if (!matched) {
      let bg = '';
      try { bg = getComputedStyle(el).backgroundImage || ''; } catch (e) { bg = ''; }
      if (bg && bg !== 'none' && MEDIA.test(bg)) {
        const parts = bg.match(/url\(["']?[^"')]+["']?\)/g) || [];
        for (let k = 0; k < parts.length; k++) {
          const inner = parts[k].replace(/^url\(["']?/, '').replace(/["']?\)$/, '');
          if (MEDIA.test(inner)) { bgCount++; noteMatch(inner); break; }
        }
      }
    }
  }
  const allImgs = document.images || [];
  const sampleSrcs = matchSrcs.slice(0, 3);
  if (!sampleSrcs.length) {
    for (let i = 0; i < allImgs.length && sampleSrcs.length < 2; i++) {
      const s = allImgs[i].currentSrc || allImgs[i].src || '';
      if (s) sampleSrcs.push(s.slice(0, 90));
    }
  }
  let busy = false;
  document.querySelectorAll('[role="progressbar"]').forEach((e) => {
    const r = e.getBoundingClientRect();
    if (r.width > 0 && r.height > 0) busy = true;
  });
  if (!busy) document.querySelectorAll('[aria-label]').forEach((e) => {
    if (busy) return;
    const a = (e.getAttribute('aria-label') || '').toLowerCase();
    if (/generating|loading|working on/.test(a)) {
      const r = e.getBoundingClientRect();
      if (r.width > 0 && r.height > 0) busy = true;
    }
  });
  if (!busy) document.querySelectorAll('[class*="spinner" i], [class*="loading" i]').forEach((e) => {
    if (busy) return;
    const r = e.getBoundingClientRect();
    if (r.width > 4 && r.height > 4) {
      const s = getComputedStyle(e);
      if (s.display !== 'none' && s.visibility !== 'hidden') busy = true;
    }
  });
  let error = '';
  document.querySelectorAll('[role="alert"], [class*="toast" i], [class*="snackbar" i], [class*="error" i]').forEach((e) => {
    if (error) return;
    const t = (e.textContent || '').trim();
    if (t && /couldn'?t generate|can'?t generate|something went wrong|unable to generate|failed to generate|violates|policy/i.test(t)) {
      const r = e.getBoundingClientRect();
      if (r.width > 0 && r.height > 0) error = t.slice(0, 200);
    }
  });
  return {
    imgCount, bgCount, total: imgCount + bgCount,
    lastUrl: lastGc || lastAny,
    totalImgs: allImgs.length,
    sampleSrcs, busy, error
  };
}

function sfaLastImg() {
  let best = null;
  document.querySelectorAll('img').forEach((im) => {
    const src = im.currentSrc || im.src || '';
    if (!/googleusercontent|blob:/.test(src)) return;
    const r = im.getBoundingClientRect();
    if (r.width <= 100 || r.height <= 60) return;
    best = { src, x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2), w: Math.round(r.width), h: Math.round(r.height) };
  });
  return best;
}

function sfaFindDownloadBtn() {
  let best = null;
  document.querySelectorAll('button, [role="button"], a').forEach((b) => {
    const label = ((b.getAttribute('aria-label') || '') + ' ' + (b.getAttribute('title') || '') + ' ' + (b.textContent || '')).toLowerCase();
    if (!/download/.test(label)) return;
    const r = b.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return;
    const s = getComputedStyle(b);
    if (s.display === 'none' || s.visibility === 'hidden') return;
    const c = { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2), top: r.top };
    if (!best || c.top < best.top) best = c; // prefer the topmost (viewer toolbar)
  });
  return best;
}

function sfaModeProbe() {
  const out = { modelText: '', selectedMode: '', hasVeo: false, hasImageModel: false, durationSignal: false };
  const bodyText = (document.body && document.body.innerText) || '';
  out.hasVeo = /\bveo\b/i.test(bodyText);
  out.hasImageModel = /nano banana|imagen/i.test(bodyText);
  document.querySelectorAll('button, [role="button"], [role="tab"], [aria-pressed], [aria-selected]').forEach((e) => {
    const t = (e.textContent || '').trim();
    const pressed = e.getAttribute('aria-pressed') === 'true' || e.getAttribute('aria-selected') === 'true';
    if (pressed && /^(image|images|video|videos)$/i.test(t)) out.selectedMode = t.toLowerCase();
    if (/veo|nano banana|imagen/i.test(t) && t.length > 0 && t.length < 60) out.modelText = t;
    if (/^\d+\s*s$/.test(t) || /^\d+:\d{2}$/.test(t)) out.durationSignal = true;
  });
  return out;
}

function sfaComposerText() {
  function vis(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
  }
  const cands = [];
  document.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"]').forEach((el) => {
    if (!vis(el)) return;
    const hint = ((el.getAttribute('placeholder') || '') + ' ' + (el.getAttribute('aria-label') || '')).toLowerCase();
    const r = el.getBoundingClientRect();
    let score = (r.width * r.height) / 1000;
    if (/what do you want|describe|prompt|create|imagine/.test(hint)) score += 5000;
    if (r.top > window.innerHeight * 0.35) score += 2000;
    cands.push({ el, score });
  });
  cands.sort((a, b) => b.score - a.score);
  if (!cands.length) return { text: '', found: false };
  const el = cands[0].el;
  const text = el.tagName.toLowerCase() === 'textarea' ? (el.value || '') : (el.innerText || el.textContent || '');
  return { text, found: true };
}

function sfaComposerChips() {
  function vis(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
  }
  const cands = [];
  document.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"]').forEach((el) => {
    if (!vis(el)) return;
    const hint = ((el.getAttribute('placeholder') || '') + ' ' + (el.getAttribute('aria-label') || '')).toLowerCase();
    const r = el.getBoundingClientRect();
    let score = (r.width * r.height) / 1000;
    if (/what do you want|describe|prompt|create|imagine/.test(hint)) score += 5000;
    if (r.top > window.innerHeight * 0.35) score += 2000;
    cands.push({ el, score });
  });
  cands.sort((a, b) => b.score - a.score);
  if (!cands.length) return { chips: -1 };
  // Walk up to the composer container (same strategy as the composer finder),
  // then count visible ingredient-like elements inside it.
  let container = cands[0].el;
  for (let up = 0; up < 7 && container; up++) {
    container = container.parentElement;
    if (!container) break;
    let hasBtn = false;
    container.querySelectorAll('button, [role="button"]').forEach((b) => { if (vis(b)) hasBtn = true; });
    if (hasBtn) break;
  }
  if (!container) container = cands[0].el.parentElement || document.body;
  let chips = 0;
  container.querySelectorAll('img, [class*="chip" i], [class*="ingredient" i], [class*="attachment" i], [class*="thumbnail" i]').forEach((e) => {
    if (e === cands[0].el) return;
    if (vis(e)) chips++;
  });
  return { chips };
}

/* v1.5 — count REAL reference ingredients inside the composer and detect
 * an in-progress upload. The old chip counter in sfaComposerChips matched
 * UI icons too (a paste read "chip 2 -> 7"), so it could not tell a real
 * uploaded thumbnail from composer chrome. An ingredient here is either
 * (a) an <img> that actually loaded pixels (naturalWidth >= 50) — UI
 * icons are smaller — or (b) a filename label: Flow labels a pasted
 * upload "image.png", so a leaf-ish element whose text names a .png/.jpg
 * counts, unless it wraps one of the counted thumbnails (no double count).
 * uploading = a progressbar / spinner / percent label inside the composer
 * container, or an <img> in the container that has not finished loading. */
function sfaIngredients() {
  function vis(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
  }
  const cands = [];
  document.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"]').forEach((el) => {
    if (!vis(el)) return;
    const hint = ((el.getAttribute('placeholder') || '') + ' ' + (el.getAttribute('aria-label') || '')).toLowerCase();
    const r = el.getBoundingClientRect();
    let score = (r.width * r.height) / 1000;
    if (/what do you want|describe|prompt|create|imagine/.test(hint)) score += 5000;
    if (r.top > window.innerHeight * 0.35) score += 2000;
    cands.push({ el, score });
  });
  cands.sort((a, b) => b.score - a.score);
  if (!cands.length) return { ingredients: -1, uploading: false };
  let container = cands[0].el;
  for (let up = 0; up < 7 && container; up++) {
    container = container.parentElement;
    if (!container) break;
    let hasBtn = false;
    container.querySelectorAll('button, [role="button"]').forEach((b) => { if (vis(b)) hasBtn = true; });
    if (hasBtn) break;
  }
  if (!container) container = cands[0].el.parentElement || document.body;

  const thumbs = [];
  let uploading = false;
  container.querySelectorAll('img').forEach((im) => {
    if (im === cands[0].el) return;
    if (!vis(im)) return;
    if (im.naturalWidth >= 50) thumbs.push(im);
    else if (!im.complete) uploading = true; // still loading inside the composer
  });
  let labels = 0;
  container.querySelectorAll('*').forEach((e) => {
    if (e === cands[0].el) return;
    if (!vis(e)) return;
    const t = (e.textContent || '').trim();
    if (!t || t.length > 60) return;
    if (!/\.(png|jpe?g)\b/i.test(t)) return;
    // Must be a leaf-ish label (the filename text itself), not an ancestor
    // whose textContent merely contains the filename deeper down.
    let own = '';
    e.childNodes.forEach((n) => { if (n.nodeType === 3) own += n.textContent; });
    if (!/\.(png|jpe?g)\b/i.test(own)) return;
    // Pair the label with a thumbnail when a small wrapper holds both:
    // walk up (max 3 levels) to the nearest ancestor containing counted
    // thumbnails — exactly 1 means this label belongs to that same
    // ingredient; more than 1 means a shared row, where the label is a
    // unit of its own. The walk stops at the composer level itself (the
    // ancestor that also holds the input): a thumbnail and a label that
    // only meet there are SEPARATE ingredients in the same row.
    let wrapsThumb = false;
    let anc = e;
    for (let up = 0; up < 3 && anc; up++) {
      if (up > 0 && anc.contains(cands[0].el)) break;
      let n = 0;
      thumbs.forEach((im) => { if (anc.contains(im)) n++; });
      if (n === 1) { wrapsThumb = true; break; }
      if (n > 1) break;
      anc = anc.parentElement;
    }
    if (!wrapsThumb) labels++;
  });
  container.querySelectorAll('[role="progressbar"], progress, [class*="spinner" i], [class*="progress" i], [aria-label*="upload" i]').forEach((e) => {
    if (vis(e)) uploading = true;
  });
  container.querySelectorAll('*').forEach((e) => {
    if (!vis(e)) return;
    const t = (e.textContent || '').trim();
    if (/^\d{1,3}\s*%$/.test(t) || /uploading/i.test(t)) uploading = true;
  });
  return { ingredients: thumbs.length + labels, uploading };
}

/* v2.0 — tile snapshot. Google Flow renders the project grid as
 * flow-grid-tile-container elements; generated thumbnails are <img>
 * with signed https://flow.google.com/asb/... URLs (NOT
 * googleusercontent — that is why the v1.6 counter was blind) and
 * carry data-media-id. Error tiles contain flow-error-tile with an
 * .error-title "Failed" and Retry / Reuse prompt / Delete buttons.
 * In-progress tiles show "NN%" text that vanishes at completion, but a
 * brand-new tile may show no % in its first seconds — so completion
 * also requires a thumbnail. One snapshot entry per tile, document
 * order (newest first in the grid), capped at 60. */
function sfaTiles() {
  function vis(el) {
    if (!el) return false;
    var r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    var s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
  }
  function center(el) {
    var r = el.getBoundingClientRect();
    return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) };
  }
  var containers = [];
  try {
    containers = Array.prototype.slice.call(document.querySelectorAll('.flow-grid-tile-container'));
  } catch (e) { containers = []; }
  if (!containers.length) {
    var seen = [];
    var markers = [];
    try {
      markers = document.querySelectorAll('[class*="flow-image-tile"], [class*="flow-error-tile"], [class*="flow-video-tile"], img[data-media-id]');
    } catch (e) { markers = []; }
    Array.prototype.forEach.call(markers, function (m) {
      var t = m;
      for (var up = 0; up < 4 && t; up++) {
        if (/tile/.test(t.className || '')) break;
        t = t.parentElement;
      }
      var wrap = t || m.parentElement || m;
      if (seen.indexOf(wrap) === -1) { seen.push(wrap); containers.push(wrap); }
    });
  }
  var out = [];
  for (var i = 0; i < containers.length && out.length < 60; i++) {
    var c = containers[i];
    if (!vis(c)) continue;
    var midEl = null;
    try { midEl = c.querySelector('[data-media-id]'); } catch (e) { midEl = null; }
    var mediaId = midEl ? midEl.getAttribute('data-media-id') : null;
    if (!mediaId && c.getAttribute) mediaId = c.getAttribute('data-media-id');
    var img = null;
    try { img = c.querySelector('img'); } catch (e) { img = null; }
    var text = (c.textContent || '').replace(/\s+/g, ' ').trim();
    var isError = false;
    var isImage = false;
    var isVideo = false;
    try {
      isError = !!c.querySelector('[class*="flow-error-tile"], .error-title');
      isImage = !!c.querySelector('[class*="flow-image-tile"]');
      isVideo = !!c.querySelector('[class*="flow-video-tile"], video');
    } catch (e) { /* partial info is fine */ }
    var kind = isError ? 'error' : (isImage ? 'image' : (isVideo ? 'video' : (img ? 'image' : 'other')));
    var pctM = text.match(/(\d{1,3})\s*%/);
    var retryBtn = null;
    if (isError) {
      var btns = [];
      try { btns = c.querySelectorAll('button, [role="button"]'); } catch (e) { btns = []; }
      for (var b = 0; b < btns.length; b++) {
        var bl = ((btns[b].getAttribute('aria-label') || '') + ' ' + (btns[b].textContent || '')).replace(/\s+/g, ' ').trim();
        if (/retry/i.test(bl) && vis(btns[b])) { retryBtn = center(btns[b]); break; }
      }
    }
    var label = (c.getAttribute && c.getAttribute('aria-label')) || (img && img.getAttribute('alt')) || text;
    out.push({
      mediaId: mediaId || null,
      kind: kind,
      hasPct: !!pctM,
      pct: pctM ? parseInt(pctM[1], 10) : null,
      hasThumb: !!(img && (img.currentSrc || img.src)),
      label: String(label || '').slice(0, 60),
      retryBtn: retryBtn,
      key: mediaId ? ('mid:' + mediaId) : ('pos:' + i)
    });
  }
  return out;
}

/* v2.0 — find a project asset (grid tile) whose shown name matches the
 * reference file name. Uploads persist per project and an uploaded
 * asset's name is its file name; a clipboard paste lands with a generic
 * name. Matching: case-insensitive, full name or extension-stripped
 * base name as substring of the tile label. */
function sfaFindAsset(name) {
  function vis(el) {
    if (!el) return false;
    var r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    var s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
  }
  function center(el) {
    var r = el.getBoundingClientRect();
    return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) };
  }
  var target = String(name || '').toLowerCase().trim();
  if (!target) return { found: false };
  var base = target.replace(/\.[a-z0-9]{1,5}$/, '');
  var containers = [];
  try {
    containers = Array.prototype.slice.call(document.querySelectorAll('.flow-grid-tile-container'));
  } catch (e) { containers = []; }
  if (!containers.length) {
    try {
      containers = Array.prototype.slice.call(document.querySelectorAll('[data-media-id]')).map(function (el) {
        return (el.closest && el.closest('[class*="tile"]')) || el.parentElement || el;
      });
    } catch (e) { containers = []; }
  }
  var uniq = [];
  containers.forEach(function (c) { if (c && uniq.indexOf(c) === -1) uniq.push(c); });
  for (var i = 0; i < uniq.length; i++) {
    var c = uniq[i];
    if (!vis(c)) continue;
    var midEl = null;
    try { midEl = c.querySelector('[data-media-id]'); } catch (e) { midEl = null; }
    var mediaId = midEl ? midEl.getAttribute('data-media-id') : (c.getAttribute ? c.getAttribute('data-media-id') : null);
    var img = null;
    try { img = c.querySelector('img'); } catch (e) { img = null; }
    var label = ((c.getAttribute && c.getAttribute('aria-label')) || (img && img.getAttribute('alt')) || (c.textContent || '')).replace(/\s+/g, ' ').trim();
    var low = label.toLowerCase();
    var match = low === target || low.indexOf(target) !== -1 || (base.length >= 3 && low.indexOf(base) !== -1);
    if (!match) continue;
    var ctr = center(c);
    return { found: true, mediaId: mediaId || null, label: label.slice(0, 60), hasPct: /\d+\s*%/.test(c.textContent || ''), x: ctr.x, y: ctr.y };
  }
  return { found: false };
}

/* v2.1 — ingredient picker state. The REAL Flow picker is a custom
 * panel (field-proven by the user's V2 run report + screenshot):
 * a "Search assets" input at the top, category rows (All / Images /
 * Videos / Voices / Characters / Avatars / Uploads) as icon+text rows,
 * asset rows with a thumbnail + two-line text ("image.png" / "Image"),
 * a large preview, an "Upload media" button and an "Add to prompt"
 * button. The v2.0 probe looked for role=listbox/option markup and
 * data-media-id thumbnails; on the real page it saw exactly 1 option
 * it could not match. v2.1 therefore identifies the picker container
 * as the smallest visible ancestor holding BOTH the search input and
 * the "Add to prompt" button, and extracts tabs/options generically
 * inside it. Fallback: the v2.0 listbox-based detection. */
function sfaPicker() {
  function vis(el) {
    if (!el) return false;
    var r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    var s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
  }
  function center(el) {
    var r = el.getBoundingClientRect();
    return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) };
  }
  function clean(s) { return String(s || '').replace(/\s+/g, ' ').trim(); }
  var TABNAMES = ['All', 'Images', 'Videos', 'Voices', 'Characters', 'Avatars', 'Uploads'];
  var FILERX = /\S+\.(png|jpe?g|webp)/i;

  // "Add to prompt" / "Upload media" buttons (document-wide).
  var addBtnEl = null;
  var uploadBtnEl = null;
  try {
    document.querySelectorAll('button, [role="button"]').forEach(function (b) {
      if (!vis(b)) return;
      var label = clean((b.getAttribute('aria-label') || '') + ' ' + (b.textContent || ''));
      if (!addBtnEl && /add to prompt/i.test(label)) addBtnEl = b;
      if (!uploadBtnEl && /upload media/i.test(label)) uploadBtnEl = b;
    });
  } catch (e) { /* partial info is fine */ }

  // "Search assets" input.
  var searchEl = null;
  try {
    document.querySelectorAll('input').forEach(function (inp) {
      if (searchEl || !vis(inp)) return;
      var hint = (inp.getAttribute('placeholder') || '') + ' ' + (inp.getAttribute('aria-label') || '');
      if (/search assets/i.test(hint)) searchEl = inp;
    });
  } catch (e) { searchEl = null; }

  var addBtn = addBtnEl ? center(addBtnEl) : null;
  var searchInput = searchEl ? center(searchEl) : null;

  // Picker container: smallest ancestor of the search input that also
  // holds the "Add to prompt" button.
  var container = null;
  if (searchEl && addBtnEl) {
    var up0 = searchEl.parentElement;
    while (up0 && up0 !== document.body) {
      if (up0.contains && up0.contains(addBtnEl)) { container = up0; break; }
      up0 = up0.parentElement;
    }
  }

  if (container) {
    // Tabs: any element whose whole trimmed text is exactly a category
    // name; keep the leaf-most element per name (a row wrapper and its
    // inner label can both match).
    var tabs = [];
    try {
      var tabCands = [];
      container.querySelectorAll('*').forEach(function (el) {
        if (!vis(el)) return;
        if (TABNAMES.indexOf(clean(el.textContent)) !== -1) tabCands.push(el);
      });
      tabCands.forEach(function (el) {
        var wrapped = false;
        for (var ti = 0; ti < tabCands.length; ti++) {
          if (tabCands[ti] !== el && el.contains && el.contains(tabCands[ti])) { wrapped = true; break; }
        }
        if (wrapped) return;
        var nm = clean(el.textContent);
        var dup = false;
        for (var tj = 0; tj < tabs.length; tj++) if (tabs[tj].name === nm) dup = true;
        if (dup) return;
        var tc = center(el);
        tabs.push({ name: nm, x: tc.x, y: tc.y });
      });
    } catch (e) { tabs = []; }

    // Options: elements inside the results area holding an img AND
    // short visible text. Smallest area first; an element wrapping an
    // already-taken row (or nested inside one) is skipped, so the
    // panel wrappers and the preview pane do not pollute the list.
    var options = [];
    try {
      var cands = [];
      container.querySelectorAll('*').forEach(function (el) {
        if (!vis(el)) return;
        var im = null;
        try { im = el.querySelector('img'); } catch (e2) { im = null; }
        if (!im) return;
        var tx = clean(el.textContent);
        if (!tx || tx.length > 80) return;
        if (TABNAMES.indexOf(tx) !== -1) return;
        if (searchEl && el.contains && el.contains(searchEl)) return;
        if (addBtnEl && el.contains && el.contains(addBtnEl)) return;
        if (uploadBtnEl && el.contains && el.contains(uploadBtnEl)) return;
        var rr = el.getBoundingClientRect();
        cands.push({ el: el, area: rr.width * rr.height });
      });
      cands.sort(function (a, b) { return a.area - b.area; });
      var taken = [];
      cands.forEach(function (cd) {
        if (options.length >= 40) return;
        var el = cd.el;
        var clash = false;
        for (var ki = 0; ki < taken.length; ki++) {
          if (taken[ki] === el || (taken[ki].contains && taken[ki].contains(el)) || (el.contains && el.contains(taken[ki]))) { clash = true; break; }
        }
        if (clash) return;
        taken.push(el);
        var midEl = null;
        try { midEl = (el.getAttribute && el.getAttribute('data-media-id')) ? el : el.querySelector('[data-media-id]'); } catch (e3) { midEl = null; }
        var mediaId = midEl ? midEl.getAttribute('data-media-id') : null;
        var raw = (typeof el.innerText === 'string' && el.innerText) ? el.innerText : (el.textContent || '');
        var lines = String(raw).split('\n').map(function (s) { return clean(s); }).filter(function (s) { return !!s; });
        var name = '';
        for (var li = 0; li < lines.length; li++) {
          var mm = lines[li].match(FILERX);
          if (mm) { name = mm[0]; break; }
        }
        if (!name) name = (lines[0] || clean(el.textContent)).slice(0, 60);
        var oc = center(el);
        options.push({ mediaId: mediaId || null, name: String(name).slice(0, 60), x: oc.x, y: oc.y });
      });
    } catch (e) { options = []; }
    return { open: true, tabs: tabs, options: options, addBtn: addBtn, uploadBtn: !!uploadBtnEl, searchInput: searchInput };
  }

  // ---- fallback: v2.0 listbox-based detection ----
  var listbox = null;
  try {
    document.querySelectorAll('[role="listbox"]').forEach(function (lb) {
      if (!listbox && vis(lb)) listbox = lb;
    });
  } catch (e) { listbox = null; }
  var scope = listbox || document;
  if (listbox) {
    var up = listbox;
    for (var i = 0; i < 5 && up; i++) {
      up = up.parentElement;
      if (!up) break;
      var hasTabs = false;
      try { hasTabs = !!up.querySelector('[role="tab"]'); } catch (e) { hasTabs = false; }
      if (hasTabs) { scope = up; break; }
    }
  }
  var tabs2 = [];
  try {
    scope.querySelectorAll('[role="tab"], button').forEach(function (t) {
      if (!vis(t)) return;
      var tx = (t.textContent || '').replace(/\s+/g, ' ').trim();
      if (TABNAMES.indexOf(tx) !== -1) {
        var ctr = center(t);
        tabs2.push({ name: tx, x: ctr.x, y: ctr.y });
      }
    });
  } catch (e) { tabs2 = []; }
  var options2 = [];
  var optEls = [];
  try {
    (listbox || scope).querySelectorAll('[role="option"]').forEach(function (o) { optEls.push(o); });
  } catch (e) { optEls = []; }
  if (!optEls.length && listbox) {
    try {
      listbox.querySelectorAll('img[data-media-id]').forEach(function (im) {
        var o = (im.closest && im.closest('[role="option"], li, button')) || im.parentElement || im;
        if (optEls.indexOf(o) === -1) optEls.push(o);
      });
    } catch (e) { /* options stay empty */ }
  }
  optEls.forEach(function (o) {
    if (!vis(o)) return;
    var midEl2 = null;
    try { midEl2 = o.getAttribute && o.getAttribute('data-media-id') ? o : o.querySelector('[data-media-id]'); } catch (e) { midEl2 = null; }
    var mediaId2 = midEl2 ? midEl2.getAttribute('data-media-id') : (o.getAttribute ? o.getAttribute('data-media-id') : null);
    var im2 = null;
    try { im2 = o.querySelector('img'); } catch (e) { im2 = null; }
    var nm2 = (o.getAttribute && o.getAttribute('aria-label')) || (im2 && im2.getAttribute('alt')) || (o.textContent || '');
    var ctr2 = center(o);
    options2.push({ mediaId: mediaId2 || null, name: String(nm2 || '').replace(/\s+/g, ' ').trim().slice(0, 60), x: ctr2.x, y: ctr2.y });
  });
  var uploadBtn2 = false;
  if (scope !== document) {
    try {
      document.querySelectorAll('button, [role="button"]').forEach(function (b) {
        if (!vis(b)) return;
        var label2 = ((b.getAttribute('aria-label') || '') + ' ' + (b.textContent || '')).replace(/\s+/g, ' ').trim();
        if (/upload/i.test(label2) && scope.contains && scope.contains(b)) uploadBtn2 = true;
      });
    } catch (e) { /* uploadBtn stays false */ }
  }
  return { open: !!listbox || (tabs2.length > 0 && options2.length > 0), tabs: tabs2, options: options2, addBtn: addBtn, uploadBtn: uploadBtn2, searchInput: searchInput };
}

/* v2.0 — scroll the picker asset list down one page (for option search). */
function sfaPickerScroll() {
  var lb = null;
  try {
    document.querySelectorAll('[role="listbox"]').forEach(function (e) {
      if (lb) return;
      var r = e.getBoundingClientRect();
      if (r.width > 2 && r.height > 2) lb = e;
    });
  } catch (e) { lb = null; }
  var el = lb;
  for (var up = 0; up < 5 && el; up++) {
    if (el.scrollHeight > el.clientHeight + 10) { el.scrollTop = el.scrollTop + 400; return true; }
    el = el.parentElement;
  }
  if (lb) { lb.scrollTop = lb.scrollTop + 400; return true; }
  return false;
}

/* v2.0 — download URL + click point for a finished tile, by media id.
 * Returns the tile's centre (for the viewer-opening click) and the
 * thumbnail img URL (the signed flow.google.com/asb/... URL). */
function sfaTileUrl(mediaId) {
  if (!mediaId) return null;
  var img = null;
  try { img = document.querySelector('img[data-media-id="' + mediaId + '"]'); } catch (e) { img = null; }
  if (!img) {
    var all = [];
    try { all = document.querySelectorAll('[data-media-id]'); } catch (e) { all = []; }
    for (var i = 0; i < all.length; i++) {
      if (all[i].getAttribute('data-media-id') === mediaId && all[i].tagName === 'IMG') { img = all[i]; break; }
    }
  }
  if (!img) return null;
  var tile = img;
  if (img.closest) tile = img.closest('.flow-grid-tile-container') || img.parentElement || img;
  var r = tile.getBoundingClientRect();
  return {
    url: img.currentSrc || img.src || '',
    x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2),
    w: Math.round(r.width), h: Math.round(r.height)
  };
}

/* v2.0 — composer bar buttons by accessible name: the "+" ("Add
 * ingredients to the prompt box"), "Clear prompt", and the "Agent"
 * toggle state. Agent mode must be OFF: in Agent mode error tiles have
 * no Retry button and the agent asks for confirmations. */
function sfaComposerBar() {
  function vis(el) {
    if (!el) return false;
    var r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    var s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
  }
  function center(el) {
    var r = el.getBoundingClientRect();
    return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) };
  }
  var plus = null;
  var clear = null;
  var agent = { present: false, active: false };
  try {
    document.querySelectorAll('button, [role="button"]').forEach(function (b) {
      if (!vis(b)) return;
      var al = (b.getAttribute('aria-label') || '').trim();
      var tx = (b.textContent || '').replace(/\s+/g, ' ').trim();
      if (!plus && /add ingredients/i.test(al)) { var c1 = center(b); plus = { x: c1.x, y: c1.y, label: al.slice(0, 60) }; }
      if (!clear && (/clear prompt/i.test(al) || tx === 'Clear prompt')) { var c2 = center(b); clear = { x: c2.x, y: c2.y, label: (al || tx).slice(0, 60) }; }
      if ((al === 'Agent' || tx === 'Agent') && !agent.present) {
        agent.present = true;
        agent.active = b.getAttribute('aria-pressed') === 'true' || b.getAttribute('aria-selected') === 'true' || b.getAttribute('aria-checked') === 'true';
      }
    });
  } catch (e) { /* partial info is fine */ }
  return { plus: plus, clear: clear, agent: agent };
}

/* v2.0 — find a visible button/menu item whose label contains the given
 * text (used for the "1K Original size" entry in the download menu). */
function sfaFindTextBtn(arg) {
  var want = String((arg && arg.text) || '').toLowerCase();
  if (!want) return null;
  var best = null;
  try {
    document.querySelectorAll('button, [role="button"], [role="menuitem"], a').forEach(function (b) {
      if (best) return;
      var label = ((b.getAttribute('aria-label') || '') + ' ' + (b.textContent || '')).replace(/\s+/g, ' ').trim();
      if (label.toLowerCase().indexOf(want) === -1) return;
      var r = b.getBoundingClientRect();
      if (r.width < 2 || r.height < 2) return;
      var s = getComputedStyle(b);
      if (s.display === 'none' || s.visibility === 'hidden') return;
      best = { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2), label: label.slice(0, 60) };
    });
  } catch (e) { best = null; }
  return best;
}

/* Pure helpers (background scope, unit-tested): picker option
 * matching and result-tile picking: the first image tile that is NEW
 * (mediaId not in the pre-send snapshot), is not the reference upload
 * itself, has a thumbnail and shows no progress %.
 * v2.1 matching order (the winner is tagged on the option as .via):
 * (a) exact data-media-id; (b) name — the option name contains the
 * recorded asset name or the original file name (full or extension-
 * stripped base, case-insensitive); (c) single-option shortcut: only
 * one asset is visible in the picker, so it IS the reference;
 * (d) filename-pattern: with at most 3 options, the first whose name
 * looks like an image file. */
function sfaMatchOption(options, refMediaId, refAssetName, refFileName) {
  if (!options || !options.length) return null;
  var i;
  if (refMediaId) {
    for (i = 0; i < options.length; i++) {
      if (options[i].mediaId && options[i].mediaId === refMediaId) { options[i].via = 'mediaId'; return options[i]; }
    }
  }
  var cands = [];
  [refAssetName, refFileName].forEach(function (v) {
    var s = String(v || '').toLowerCase().trim();
    if (!s) return;
    if (cands.indexOf(s) === -1) cands.push(s);
    var b = s.replace(/\.[a-z0-9]{1,5}$/, '');
    if (b.length >= 3 && cands.indexOf(b) === -1) cands.push(b);
  });
  if (cands.length) {
    for (i = 0; i < options.length; i++) {
      var n = String(options[i].name || '').toLowerCase();
      if (!n) continue;
      for (var ci = 0; ci < cands.length; ci++) {
        if (n.indexOf(cands[ci]) !== -1) { options[i].via = 'name'; return options[i]; }
      }
    }
  }
  if (options.length === 1) { options[0].via = 'single'; return options[0]; }
  if (options.length <= 3) {
    for (i = 0; i < options.length; i++) {
      if (/\.(png|jpe?g|webp)$/i.test(String(options[i].name || ''))) { options[i].via = 'filename'; return options[i]; }
    }
  }
  return null;
}
/* v2.1 pure helper: the name the picker displays for the uploaded
 * reference, taken from the completed upload tile's label — the first
 * filename-looking token in it; clipboard pastes land with a generic
 * name, so the fallback is 'image'. Recorded at gate time as
 * state.refPickerName and used as the picker search term. */
function sfaPickerNameFromLabel(label) {
  var m = String(label || '').match(/\S+\.(png|jpe?g|webp)/i);
  return m ? m[0] : 'image';
}
/* v2.1 pure helper: which term to type into the picker's "Search
 * assets" box. The recorded picker name wins; else the recorded asset
 * name when it is itself a filename; else the original file name's
 * base; else 'image'. */
function sfaSearchTerm(refPickerName, refAssetName, refFileName) {
  var pn = String(refPickerName || '').trim();
  if (pn) return pn;
  var an = String(refAssetName || '').trim();
  if (/\.(png|jpe?g|webp)$/i.test(an)) return an;
  var fn = String(refFileName || '').trim();
  if (fn) return fn.replace(/\.[a-z0-9]{1,5}$/i, '') || fn;
  return 'image';
}
function sfaPickResultTile(tiles, snapIds, refMediaId) {
  if (!tiles) return null;
  var ids = snapIds || [];
  for (var i = 0; i < tiles.length; i++) {
    var t = tiles[i];
    if (!t || t.kind !== 'image' || !t.mediaId) continue;
    if (ids.indexOf(t.mediaId) !== -1) continue;
    if (refMediaId && t.mediaId === refMediaId) continue;
    if (!t.hasThumb || t.hasPct) continue;
    return t;
  }
  return null;
}

/* v2.5 paced-mode pure helpers (unit-tested in tests/test-v25.js).
 * pacedCompletedNew: finished image tiles in a snapshot that the
 * watcher has not handled yet — kind 'image', has a mediaId, NOT in
 * handledIds, NOT the reference upload itself, has a thumbnail and
 * shows no %. Baseline media-ids captured at run start live in
 * handledIds, so pre-existing grid images are never matched.
 * pacedAssign: FIFO pairing — sfaTiles returns the grid newest-first,
 * so the new tiles are reversed (oldest finish first) and zipped with
 * the pending ids in SEND order: the oldest sent-but-unmatched item
 * gets the oldest newly finished tile. Downloads/naming therefore
 * stay locked to prompt order even when generations finish out of
 * order.
 * pacedErrorDelta: how many NEW error tiles appeared since the last
 * poll (error tiles persist forever, so only the count increase is a
 * signal; a decrease just re-syncs the baseline).
 * pacedIsTimedOut: a sent item with no tile after the limit is a
 * failed attempt (same 240s cap as the serial completion wait). */
function pacedCompletedNew(tiles, handledIds, refMediaId) {
  var handled = handledIds || [];
  var out = [];
  var list = tiles || [];
  for (var i = 0; i < list.length; i++) {
    var t = list[i];
    if (!t || t.kind !== 'image' || !t.mediaId) continue;
    if (handled.indexOf(t.mediaId) !== -1) continue;
    if (refMediaId && t.mediaId === refMediaId) continue;
    if (!t.hasThumb || t.hasPct) continue;
    out.push(t);
  }
  return out;
}
function pacedAssign(pendingIds, newTiles) {
  var ids = pendingIds || [];
  var rev = (newTiles || []).slice().reverse();
  var pairs = [];
  var n = Math.min(ids.length, rev.length);
  for (var i = 0; i < n; i++) pairs.push({ itemId: ids[i], tile: rev[i] });
  return pairs;
}
function pacedErrorDelta(prevCount, tiles) {
  var now = 0;
  var list = tiles || [];
  for (var i = 0; i < list.length; i++) if (list[i] && list[i].kind === 'error') now++;
  var prev = prevCount || 0;
  return { now: now, delta: Math.max(0, now - prev) };
}
function pacedIsTimedOut(sentAt, nowMs, limitMs) {
  if (!sentAt) return false;
  return (nowMs - sentAt) > (limitMs || 240000);
}

/* ---------------- CDP layer ---------------- */
/* v2.3 — no CDP call may hang forever. The proven v2.2 failure: the
 * user pressed the yellow bar's Cancel (canceled_by_user detach)
 * while a sendCommand was in flight; that promise never settled, the
 * run loop waited inside it forever, loopActive stayed true, and the
 * already-running guard then silently swallowed every later Start.
 * withTimeout races every debugger call; cdp() treats a timeout
 * exactly like a detach (heal the session, retry the command once);
 * a second failure surfaces as a normal error the item logic handles. */
const CDP_TIMEOUT_MS = 8000;
function withTimeout(promise, ms, label) {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => {
      const e = new Error('CDP timeout: ' + label + ' — ' + ms + 'ms e response ashe ni');
      e.cdpTimeout = true;
      reject(e);
    }, ms);
    Promise.resolve(promise).then(
      (v) => { clearTimeout(t); resolve(v); },
      (e) => { clearTimeout(t); reject(e); }
    );
  });
}
const attachedTabs = new Set();
/* v1.4 — self-healing debugger session. Proven by the user's v1.2 run
 * report: once the debugger session was lost mid-run (yellow-bar Cancel,
 * or an MV3 service-worker restart dropping it), the engine NEVER
 * re-attached — the first "Debugger is not attached to the tab with id"
 * error made every attempt of every later item fail instantly.
 * attachedOk/attachedTabId are the session truth; ensureAttached() heals
 * the session, and cdp() retries a command once after re-attaching. */
let attachedTabId = null;
let attachedOk = false;
const intentionalDetachTabs = new Set();

async function ensureAttached(tabId, force) {
  if (!force && attachedOk && attachedTabId === tabId) return true;
  try {
    await withTimeout(chrome.debugger.attach({ tabId }, '1.3'), CDP_TIMEOUT_MS, 'debugger.attach');
  } catch (e) {
    const m = (e && e.message) || String(e);
    if (/already attached/i.test(m)) {
      // Session actually survived (e.g. service-worker restart) — attached.
      attachedTabs.add(tabId);
      attachedTabId = tabId;
      attachedOk = true;
      return true;
    }
    attachedOk = false;
    elog('Debugger attach FAIL (tab ' + tabId + '): ' + m);
    throw new Error('Debugger attach fail: ' + m);
  }
  attachedTabs.add(tabId);
  attachedTabId = tabId;
  attachedOk = true;
  S.lastDetachReason = '';
  elog('Debugger attach holo (tab ' + tabId + ')');
  save();
  return true;
}

async function dbgAttach(tabId) { return ensureAttached(tabId); }

async function dbgDetach(tabId) {
  if (attachedTabId === tabId) { attachedOk = false; attachedTabId = null; }
  if (!attachedTabs.has(tabId)) return;
  attachedTabs.delete(tabId);
  intentionalDetachTabs.add(tabId);
  try { await withTimeout(chrome.debugger.detach({ tabId }), 3000, 'debugger.detach'); } catch (e) { /* already gone */ }
  setTimeout(() => intentionalDetachTabs.delete(tabId), 1000);
}

chrome.debugger.onDetach.addListener((src, reason) => {
  if (!src || !src.tabId) return;
  attachedTabs.delete(src.tabId);
  if (src.tabId === attachedTabId) { attachedOk = false; attachedTabId = null; }
  if (intentionalDetachTabs.has(src.tabId)) return; // our own detach (pause/stop/end) — no warning
  const r = reason || 'unknown';
  S.lastDetachReason = r;
  if (r === 'canceled_by_user') {
    elog('Debugger detach hoyeche (reason: canceled_by_user) — holud bar er Cancel chaple emon hoy; run cholar somoy Cancel chapba na');
  } else {
    elog('Debugger detach hoyeche (reason: ' + r + ')');
  }
  save();
});

async function cdp(tabId, method, params) {
  try {
    return await withTimeout(chrome.debugger.sendCommand({ tabId }, method, params || {}), CDP_TIMEOUT_MS, method);
  } catch (e) {
    const m = (e && e.message) || String(e);
    const timedOut = !!(e && e.cdpTimeout);
    if (!timedOut && !/not attached/i.test(m)) throw e;
    // A timeout is treated exactly like a detach: the session is in
    // an unknown state, so heal it and retry the command once. If the
    // retry also fails/times out, that error propagates as a normal
    // error — the item logic retries or fails the item, and the run
    // loop keeps moving instead of parking forever.
    if (timedOut) elog('CDP timeout (' + method + ') — session atke chilo, detach dhore abar attach kore retry hocche');
    else elog('Debugger chere giyechilo — abar attach kore retry hocche (' + method + ')');
    attachedOk = false;
    await ensureAttached(tabId, true);
    return withTimeout(chrome.debugger.sendCommand({ tabId }, method, params || {}), CDP_TIMEOUT_MS, method);
  }
}
async function evalFn(tabId, fn, arg) {
  const expr = '(' + fn.toString() + ')(' + JSON.stringify(arg === undefined ? null : arg) + ')';
  const res = await cdp(tabId, 'Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true });
  if (res && res.exceptionDetails) {
    throw new Error('Page evaluate failed: ' + (res.exceptionDetails.text || 'unknown'));
  }
  return res && res.result ? res.result.value : undefined;
}
async function scriptFn(tabId, fn, arg) {
  const out = await chrome.scripting.executeScript({ target: { tabId }, func: fn, args: [arg === undefined ? null : arg] });
  return out && out[0] ? out[0].result : undefined;
}
async function realClick(tabId, x, y) {
  await cdp(tabId, 'Input.dispatchMouseEvent', { type: 'mouseMoved', x, y, button: 'none' });
  await sleep(70);
  await cdp(tabId, 'Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', clickCount: 1 });
  await sleep(60);
  await cdp(tabId, 'Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', clickCount: 1 });
}
async function clearFocusedInput(tabId) {
  const opts = { modifiers: 2, windowsVirtualKeyCode: 65, nativeVirtualKeyCode: 65 };
  await cdp(tabId, 'Input.dispatchKeyEvent', Object.assign({ type: 'keyDown', key: 'a', code: 'KeyA' }, opts));
  await cdp(tabId, 'Input.dispatchKeyEvent', Object.assign({ type: 'keyUp', key: 'a', code: 'KeyA' }, opts));
  await cdp(tabId, 'Input.dispatchKeyEvent', { type: 'keyDown', key: 'Backspace', code: 'Backspace', windowsVirtualKeyCode: 8, nativeVirtualKeyCode: 8 });
  await cdp(tabId, 'Input.dispatchKeyEvent', { type: 'keyUp', key: 'Backspace', code: 'Backspace', windowsVirtualKeyCode: 8, nativeVirtualKeyCode: 8 });
}
/* Trusted Enter key via CDP — Flow's composer is a chat-style input where
 * Enter = send. This is the PRIMARY send method in v1.3: unlike a mouse
 * click it can never land on the wrong (clear/close) control. */
async function pressEnter(tabId) {
  const base = { key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13, nativeVirtualKeyCode: 13 };
  await cdp(tabId, 'Input.dispatchKeyEvent', Object.assign({ type: 'keyDown' }, base));
  await sleep(40);
  await cdp(tabId, 'Input.dispatchKeyEvent', Object.assign({ type: 'keyUp' }, base));
}
/* Trusted Escape via CDP — closes the ingredient picker between open
 * retries (the opener click occasionally produces no picker). */
async function pressEscape(tabId) {
  const base = { key: 'Escape', code: 'Escape', windowsVirtualKeyCode: 27, nativeVirtualKeyCode: 27 };
  await cdp(tabId, 'Input.dispatchKeyEvent', Object.assign({ type: 'keyDown' }, base));
  await sleep(30);
  await cdp(tabId, 'Input.dispatchKeyEvent', Object.assign({ type: 'keyUp' }, base));
}

/* ---------------- downloads ---------------- */
const dlWaiters = new Map();
chrome.downloads.onChanged.addListener((delta) => {
  const w = dlWaiters.get(delta.id);
  if (!w) return;
  if (delta.state && delta.state.current === 'complete') {
    dlWaiters.delete(delta.id);
    chrome.downloads.search({ id: delta.id }).then((items) => w.resolve(items && items[0] ? items[0] : null)).catch(() => w.resolve(null));
  } else if (delta.state && delta.state.current === 'interrupted') {
    dlWaiters.delete(delta.id);
    w.resolve(null);
  }
});
function downloadsDownload(opts) {
  return new Promise((resolve, reject) => {
    chrome.downloads.download(opts, (id) => {
      const err = chrome.runtime.lastError;
      if (err || id === undefined || id === null) reject(new Error('Download start fail: ' + (err ? err.message : 'no id')));
      else resolve(id);
    });
  });
}
function waitDownloadComplete(id, timeoutMs) {
  return new Promise((resolve) => {
    const timer = setTimeout(() => { dlWaiters.delete(id); resolve(null); }, timeoutMs || 90000);
    dlWaiters.set(id, { resolve: (item) => { clearTimeout(timer); resolve(item); } });
    chrome.downloads.search({ id }).then((items) => {
      const it = items && items[0];
      if (it && it.state === 'complete') { clearTimeout(timer); dlWaiters.delete(id); resolve(it); }
      else if (it && it.state === 'interrupted') { clearTimeout(timer); dlWaiters.delete(id); resolve(null); }
    }).catch(() => {});
  });
}
async function downloadAndVerify(url, filename) {
  const id = await downloadsDownload({ url, filename, saveAs: false });
  const item = await waitDownloadComplete(id, 90000);
  if (!item) throw new Error('Download interrupted ba timeout');
  const size = item.fileSize || item.totalBytes || 0;
  if (size <= 10000) throw new Error('Download size khub chhoto (' + size + ' bytes) — verify fail');
  return size;
}
function upgradeUrl(u) {
  if (!/googleusercontent/.test(u)) return u;
  if (/=w\d+/.test(u)) return u.replace(/=w\d+/, '=w2048');
  if (/=s\d+/.test(u)) return u.replace(/=s\d+/, '=s2048');
  return u;
}
async function screenshotError(tabId, project, itemId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
    await downloadsDownload({ url: dataUrl, filename: 'SHEIKH Flow Auto/' + runFolderName() + '/ERROR-' + itemId + '.png', saveAs: false });
  } catch (e) { /* best effort */ }
}

/* ---------------- v2.2 item thumbnails (session only) ----------------
 * After an item's image completes, fetch its tile URL, downscale to a
 * ≤120px-wide JPEG data URL and keep it in an in-memory Map keyed by
 * item ID. Never persisted. Any failure (CORS, decode) is silent apart
 * from one log line — the panel simply shows no thumbnail. */
const thumbCache = new Map();
let thumbFailLogged = false;
function bufferToDataUrl(buf, mime) {
  const bytes = new Uint8Array(buf);
  let bin = '';
  const CH = 0x8000;
  for (let i = 0; i < bytes.length; i += CH) {
    bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
  }
  return 'data:' + mime + ';base64,' + btoa(bin);
}
async function captureThumbnail(id, url) {
  try {
    if (!id || !url || url.indexOf('blob:') === 0 || thumbCache.has(id)) return;
    const resp = await fetch(url, { credentials: 'include' });
    if (!resp || !resp.ok) throw new Error('HTTP ' + (resp ? resp.status : '?'));
    const blob = await resp.blob();
    const bmp = await createImageBitmap(blob);
    const scale = Math.min(1, 120 / (bmp.width || 120));
    const w = Math.max(1, Math.round(bmp.width * scale));
    const h = Math.max(1, Math.round(bmp.height * scale));
    const canvas = new OffscreenCanvas(w, h);
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('no 2d context');
    ctx.drawImage(bmp, 0, 0, w, h);
    if (bmp.close) bmp.close();
    const out = await canvas.convertToBlob({ type: 'image/jpeg', quality: 0.7 });
    const buf = await out.arrayBuffer();
    thumbCache.set(id, bufferToDataUrl(buf, 'image/jpeg'));
  } catch (e) {
    if (!thumbFailLogged) {
      thumbFailLogged = true;
      elog('Thumbnail: kono image er preview ana jay ni (' + (e && e.message ? e.message : String(e)) + ') — preview charai cholbe');
    }
  }
}

/* ---------------- local copies of parse helpers (background is standalone) */
function sanitizeProject(name) {
  const s = String(name == null ? '' : name).replace(/[\\/:*?"<>|#]/g, ' ').replace(/\s+/g, ' ').trim().replace(/[. ]+$/g, '');
  return s || 'Project';
}
/* v2.2: the run's effective folder base — set at run start (dated when
 * the dated-folder setting is on) and kept across resumes. */
function runFolderName() {
  return S.runFolder || sanitizeProject(S.project);
}
function targetPath(project, id) {
  return 'SHEIKH Flow Auto/' + runFolderName() + '/' + String(id).toUpperCase() + '.png';
}
/* v2.2: merge the panel's Download-section settings into state
 * (validated field by field; refMode/refReady are handled separately
 * by the start flow and are never touched here). */
function applyDownloadSettings(obj) {
  if (!obj) return;
  if (typeof obj.autoDownload === 'boolean') S.settings.autoDownload = obj.autoDownload;
  if (obj.quality === '1K' || obj.quality === '2K' || obj.quality === '4K') S.settings.quality = obj.quality;
  if (typeof obj.datedFolder === 'boolean') S.settings.datedFolder = obj.datedFolder;
  if (typeof obj.retryAtEnd === 'boolean') S.settings.retryAtEnd = obj.retryAtEnd;
  if (obj.intervalSec !== undefined) S.settings.intervalSec = clampIntervalSec(obj.intervalSec);
  if (obj.runMode === 'serial' || obj.runMode === 'paced') S.settings.runMode = obj.runMode;
}

/* ---------------- flow tab ---------------- */
async function findFlowTab() {
  let tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  let t = tabs && tabs[0];
  if (t && t.url && FLOW_URL_RE.test(t.url)) return t;
  tabs = await chrome.tabs.query({});
  t = (tabs || []).find((x) => x.url && FLOW_URL_RE.test(x.url));
  return t || null;
}

/* ---------------- preflight ---------------- */
async function runPreflight() {
  await loadState();
  const tab = await findFlowTab();
  const result = { ok: false, tabId: null, url: '', flowPage: false, input: null, send: null, mode: 'unknown', modeSignals: null, blocked: false, blockReason: '', checkedAt: Date.now(), plusBtn: null, clearBtn: null, agent: { present: false, active: false } };
  if (!tab) { result.blockReason = 'Kono Flow tab khola nai — age Flow project tab khule rakho.'; return result; }
  result.tabId = tab.id;
  result.url = tab.url || '';
  result.flowPage = FLOW_URL_RE.test(result.url);
  try {
    const composer = await scriptFn(tab.id, sfaFindComposer);
    if (composer) { result.input = composer.input; result.send = composer.send; }
    // v2.0: ingredient "+" button + Agent toggle (picker attach needs the
    // "+"; Agent mode ON breaks error-tile Retry, so it is surfaced).
    const bar = await scriptFn(tab.id, sfaComposerBar).catch(() => null);
    if (bar) {
      result.plusBtn = bar.plus || null;
      result.clearBtn = bar.clear || null;
      result.agent = bar.agent || { present: false, active: false };
    }
    const mode = await scriptFn(tab.id, sfaModeProbe);
    result.modeSignals = mode;
    if (mode) {
      const selVideo = /^videos?$/.test(mode.selectedMode || '');
      const modelVeo = /veo/i.test(mode.modelText || '');
      const modelImage = /nano banana|imagen/i.test(mode.modelText || '');
      if (selVideo || (modelVeo && !modelImage)) { result.mode = 'video'; }
      else if (/^images?$/.test(mode.selectedMode || '') || modelImage) { result.mode = 'image'; }
      else if (mode.hasImageModel && !mode.hasVeo) { result.mode = 'image'; }
    }
  } catch (e) {
    result.blockReason = 'Page probe fail: ' + e.message;
  }
  if (result.mode === 'video') {
    result.blocked = true;
    result.blockReason = 'VIDEO mode select kora ache mone hocche — image-only lock er jonno run block kora holo. Flow te Image mode / Nano Banana select kore abar Check koro.';
  }
  result.ok = result.flowPage && !!result.input && !!result.send && !result.blocked;
  S.lastPreflight = result;
  S.tabId = result.tabId;
  save();
  return result;
}

/* ---------------- generation wait ---------------- */
const ABORT = Symbol('abort');
/* v2.0 completion wait — tile-based, replacing the count-based wait.
 * Everything is relative to the pre-send snapshot (snap.ids = mediaIds
 * present before the send, snap.errorCount = error tiles then).
 *
 * NEW error tile (error count grows past the handled baseline): Flow's
 * own failures are usually just busy servers — press the tile's Retry
 * button (max 2 per attempt), extend the deadline, keep waiting. With
 * no retries left the attempt fails with the tile's error text. OLD
 * error tiles persist forever, so only the count INCREASE is reacted
 * to, and the toast-style scan.error is only trusted when the page has
 * no error tiles at all (otherwise it is an old tile's text).
 *
 * COMPLETE when a tile exists that is kind 'image', has a mediaId NOT
 * in the snapshot, is not the reference upload itself, has a thumbnail
 * and shows no % — stable across 2 consecutive polls.
 *
 * Last-resort fallback (spec): no new tile and no error after 150s AND
 * busy was seen and has cleared for 3 polls → return viaBusy and let
 * the caller try the newest-tile / media-URL download path. */
async function waitForCompletion(tabId, snap, item, opts) {
  const epoch = abortEpoch; // v2.3: abort the moment Stop/force-reset bumps it
  const t0 = Date.now();
  let busySeen = !!(opts && opts.busySeen);
  let deadline = t0 + 240000;
  let errBase = snap.errorCount || 0;
  let retries = 0;
  let stableBusy = 0;
  let candId = null;
  let candStable = 0;
  let lastBeatLog = -1;
  let sampleLogged = false;
  let pollErrLogged = false;
  while (Date.now() < deadline) {
    if (stopRequested) throw ABORT;
    if (epoch !== abortEpoch) throw ABORT;
    beat();
    let tiles = null;
    let scan = null;
    try {
      tiles = await evalFn(tabId, sfaTiles);
      pollErrLogged = false;
    } catch (e) {
      if (!pollErrLogged) {
        elog(item.id + ': tile poll e badha (' + (e && e.message ? e.message : String(e)) + ') — opekkha cholche, abar try hobe');
        pollErrLogged = true;
      }
    }
    try { scan = await evalFn(tabId, sfaMediaScan); } catch (e) { scan = null; }
    const elapsed = Math.round((Date.now() - t0) / 1000);
    item.stage = 'waiting ' + elapsed + 's';
    if (elapsed - lastBeatLog >= 30) {
      lastBeatLog = elapsed;
      const newN = tiles ? tiles.filter((t) => t.mediaId && snap.ids.indexOf(t.mediaId) === -1).length : '?';
      const errN = tiles ? tiles.filter((t) => t.kind === 'error').length : '?';
      elog(item.id + ': opekkha cholche — ' + elapsed + 's geche, tile mot ' + (tiles ? tiles.length : '?') + ' (notun ' + newN + ', error ' + errN + ', busy=' + (scan ? !!scan.busy : '?') + ')');
    }
    if (!sampleLogged && scan && elapsed > 60) {
      sampleLogged = true;
      elog(item.id + ': DOM sample: totalImgs=' + scan.totalImgs + ', sampleSrcs=[' + (scan.sampleSrcs && scan.sampleSrcs.length ? scan.sampleSrcs.join(' | ') : 'none') + ']');
    }
    save();
    if (tiles) {
      const errTiles = tiles.filter((t) => t.kind === 'error');
      if (errTiles.length > errBase) {
        const et = errTiles[0];
        if (retries < 2 && et.retryBtn) {
          retries++;
          elog(item.id + ': Flow fail korechilo — Retry chap dilam (' + retries + '/2)');
          await realClick(tabId, et.retryBtn.x, et.retryBtn.y);
          errBase = errTiles.length - 1; // the retried tile should leave error state
          deadline = Math.max(deadline, Date.now() + 120000);
          candId = null;
          candStable = 0;
          await sleepOrStop(2000, epoch);
          continue;
        }
        const err = new Error('Flow error: ' + (et.label || 'generation failed'));
        err.finalReason = err.message;
        throw err;
      }
      const cand = sfaPickResultTile(tiles, snap.ids, S.refMediaId);
      if (cand) {
        if (cand.mediaId === candId) candStable++;
        else { candId = cand.mediaId; candStable = 1; }
        if (candStable >= 2) {
          elog(item.id + ': completion — notun tile (mediaId=' + cand.mediaId + ')');
          return { tile: cand, viaBusy: false };
        }
      } else {
        candId = null;
        candStable = 0;
      }
    }
    if (scan) {
      if (scan.busy) {
        busySeen = true;
        stableBusy = 0;
      } else if (busySeen) {
        stableBusy++;
        if (stableBusy >= 3 && Date.now() - t0 > 150000) {
          elog(item.id + ': completion — busy-cycle fallback (150s periye geche, notun tile dhora poreni)');
          return { tile: null, viaBusy: true };
        }
      }
      const errTileCount = tiles ? tiles.filter((t) => t.kind === 'error').length : 0;
      if (scan.error && errTileCount === 0) throw new Error('Flow error: ' + scan.error);
    }
    await sleepOrStop(2000, epoch);
  }
  throw new Error('Timeout 240s — generation sesh hoyni');
}

/* Verify generation ACTUALLY started after sending (fail fast).
 * Success signals (either one, within 15s): a busy / generating
 * indicator is visible, OR a new tile appears in the grid (any kind —
 * including an error tile, which the completion wait then handles via
 * its Retry button), OR the grid grew / a new mediaId showed up.
 * "Composer cleared" is NOT a signal — in v1.2 the post-typing finder
 * clicked a clear/close (x) control that erased the prompt, and the
 * cleared box then falsely read as "generation started". A cleared box
 * is still logged ONCE per wait, as diagnostic info only.
 * Returns {name, busySeen}, or null after ~15s. */
async function waitForStartSignal(tabId, snap, typedLen) {
  const epoch = abortEpoch; // v2.3: abort the moment Stop/force-reset bumps it
  const t0 = Date.now();
  let clearedLogged = false;
  let pollErrLogged = false;
  let busySeen = false;
  while (Date.now() - t0 < 15000) {
    if (stopRequested) throw ABORT;
    if (epoch !== abortEpoch) throw ABORT;
    beat();
    let scan = null;
    let tiles = null;
    try {
      scan = await evalFn(tabId, sfaMediaScan);
      pollErrLogged = false;
    } catch (e) {
      if (!pollErrLogged) {
        elog('Start-signal poll e badha (' + (e && e.message ? e.message : String(e)) + ') — opekkha cholche');
        pollErrLogged = true;
      }
    }
    try { tiles = await evalFn(tabId, sfaTiles); } catch (e) { tiles = null; }
    if (scan && scan.busy) return { name: 'generating indicator dekha geche', busySeen: true };
    if (tiles) {
      const fresh = tiles.find((t) => t.mediaId && snap.ids.indexOf(t.mediaId) === -1);
      if (fresh) return { name: 'notun tile esheche (' + fresh.kind + ')', busySeen };
      if (tiles.length > snap.count) return { name: 'grid e notun tile esheche', busySeen };
      if (tiles.filter((t) => t.kind === 'error').length > snap.errorCount) return { name: 'error tile esheche (Retry diye handle hobe)', busySeen };
      if (scan && scan.error && tiles.filter((t) => t.kind === 'error').length === 0) {
        throw new Error('Flow error: ' + scan.error);
      }
    } else if (scan && scan.error) {
      throw new Error('Flow error: ' + scan.error);
    }
    if (!clearedLogged && typedLen > 20) {
      const ct = await evalFn(tabId, sfaComposerText).catch(() => null);
      const cur = ct && typeof ct.text === 'string' ? ct.text.replace(/\s+/g, ' ').trim() : '';
      if (cur.length < typedLen * 0.2) {
        clearedLogged = true;
        elog('Note: box khali hoyeche, kintu eta signal na — tile/busy signal er opekkhai achi');
      }
    }
    await sleepOrStop(1000, epoch);
  }
  return null;
}

/* Read back the composer text and verify our prompt really landed there. */
async function verifyTyped(tabId, promptText) {
  const ct = await evalFn(tabId, sfaComposerText);
  const norm = (s) => String(s || '').replace(/\s+/g, ' ').trim();
  const boxText = norm(ct && ct.text);
  const probe = norm(promptText).slice(0, 30);
  return { ok: probe.length > 0 && boxText.indexOf(probe) !== -1, len: boxText.length };
}

function itemNeedsRef(item) {
  const st = S.settings || {};
  if (!st.refReady) return false;
  if (st.refMode === 'all') return true;
  if (st.refMode === 'marked') return !!item.needsRef;
  return false;
}

/* Read the composer's real ingredient state (v1.5 probe). ingredients
 * is -1 when the probe could not read the composer at all. */
async function getIngredients(tabId) {
  const info = await evalFn(tabId, sfaIngredients).catch(() => null);
  if (!info || typeof info.ingredients !== 'number') return { ingredients: -1, uploading: false };
  return { ingredients: info.ingredients, uploading: !!info.uploading };
}

/* Generation-start gap (user rule): v2.0 fixed it at 10s; v2.2 reads
 * settings.intervalSec (3–120s, default 10). Enforced immediately
 * before every Enter send; lastSendAt persists in state so the gap
 * holds across items and resumes. */
async function enforceSendGap(item) {
  const gapSec = clampIntervalSec(S.settings && S.settings.intervalSec);
  const last = S.lastSendAt || 0;
  const waitMs = last ? (last + gapSec * 1000 - Date.now()) : 0;
  if (waitMs > 0) {
    elog((item ? item.id : 'send') + ': ' + gapSec + 's gap rakha hocche (aro ' + Math.ceil(waitMs / 1000) + 's)');
    await sleepOrStop(waitMs); // v2.3: Stop wakes the gap instantly (heartbeat interval keeps beat() alive)
  }
  S.lastSendAt = Date.now();
  save();
}

/* v2.0 — upload gate: after the one-time paste, poll the tiles until
 * the new upload tile (a mediaId that was NOT in the pre-upload
 * snapshot) exists AND shows no % — i.e. its processing has fully
 * ended and it has gained data-media-id. Max 90s. Progress % is logged
 * whenever it changes. NOTHING else in the run proceeds before this
 * resolves — that is the user's rule 1. */
async function waitRefUploadGate(tabId, preTiles, name) {
  const preIds = new Set((preTiles || []).map((t) => t.mediaId).filter(Boolean));
  // A tile that was already visible but still processing at snapshot
  // time (the "found but hasPct" path in ensureReference) is also a
  // valid gate success once its % clears.
  const prePctIds = new Set((preTiles || []).filter((t) => t.hasPct).map((t) => t.mediaId).filter(Boolean));
  const epoch = abortEpoch; // v2.3: abort the moment Stop/force-reset bumps it
  const t0 = Date.now();
  let lastPct = -1;
  while (Date.now() - t0 < 90000) {
    if (stopRequested) throw ABORT;
    if (epoch !== abortEpoch) throw ABORT;
    beat();
    const tiles = await evalFn(tabId, sfaTiles).catch(() => null);
    if (tiles) {
      for (const t of tiles) {
        if (t.mediaId && !t.hasPct && (!preIds.has(t.mediaId) || prePctIds.has(t.mediaId))) {
          return { mediaId: t.mediaId, label: t.label || '', secs: Math.round((Date.now() - t0) / 1000) };
        }
      }
      const prog = tiles.find((t) => t.hasPct && (!t.mediaId || !preIds.has(t.mediaId)));
      if (prog && prog.pct !== null && prog.pct !== lastPct) {
        lastPct = prog.pct;
        elog('reference upload cholche… ' + prog.pct + '%');
      }
    }
    await sleepOrStop(2000, epoch);
  }
  return null;
}

/* After the one-time upload, empty the composer with "Clear prompt"
 * (the upload itself stays in the project). Falls back to Ctrl+A +
 * Backspace. Logs the resulting composer state; if the reference chip
 * itself survives the clear, the first item simply uses it (its attach
 * step sees ingredients >= 1 and skips the picker). */
async function clearComposerAfterUpload(tabId) {
  const bar = await evalFn(tabId, sfaComposerBar).catch(() => null);
  if (bar && bar.clear) {
    await realClick(tabId, bar.clear.x, bar.clear.y);
    elog('Composer "Clear prompt" diye porishkar kora holo');
  } else {
    const composer = await evalFn(tabId, sfaFindComposer).catch(() => null);
    if (composer && composer.input) {
      await realClick(tabId, composer.input.x, composer.input.y);
      await sleep(150);
      await clearFocusedInput(tabId);
      elog('Composer Ctrl+A diye porishkar kora holo (Clear prompt button paoa jay ni)');
    }
  }
  await sleep(500);
  const ct = await evalFn(tabId, sfaComposerText).catch(() => null);
  const ing = await getIngredients(tabId);
  elog('Composer obostha: text ' + (ct && typeof ct.text === 'string' ? ct.text.trim().length : '?') + ' chars, ingredients ' + ing.ingredients + ' — upload project ei theke geche');
}

/* v2.0 reference lifecycle (run start, replaces paste-per-attempt):
 * 1) If the reference asset is already in this project (uploads persist
 *    per project) → ready, no upload at all.
 * 2) Otherwise ONE-TIME upload: clipboard paste into the composer, then
 *    the upload gate (tile has data-media-id AND no %) — max 90s.
 *    Timeout aborts the run start: nothing is generated.
 * 3) Clear the composer; the asset stays in the project and every item
 *    re-adds it via the picker (attachRefFromProject). */
async function ensureReference(tabId) {
  const anyNeed = S.items.some((it) => (it.status === 'pending' || it.status === 'active') && itemNeedsRef(it));
  if (!anyNeed) return true;
  const name = S.refFileName || 'image.png';
  S.refStatus = 'checking';
  save();
  elog('Reference check: project e "' + name + '" khujchi');
  const tiles = await evalFn(tabId, sfaTiles).catch(() => null) || [];
  if (S.refMediaId) {
    const byId = tiles.find((t) => t.mediaId === S.refMediaId);
    if (byId && !byId.hasPct) {
      S.refStatus = 'ready';
      S.refAssetName = byId.label || S.refAssetName || name;
      S.refPickerName = sfaPickerNameFromLabel(byId.label || S.refAssetName);
      elog('reference project ei paoa geche — notun upload lagbe na (mediaId=' + S.refMediaId + ', picker naam="' + S.refPickerName + '")');
      save();
      return true;
    }
  }
  const found = await evalFn(tabId, sfaFindAsset, name).catch(() => null);
  if (found && found.found && found.mediaId && !found.hasPct) {
    S.refMediaId = found.mediaId;
    S.refAssetName = found.label || name;
    S.refPickerName = sfaPickerNameFromLabel(found.label);
    S.refStatus = 'ready';
    elog('reference project ei paoa geche — notun upload lagbe na (mediaId=' + found.mediaId + ', naam="' + (found.label || '') + '", picker naam="' + S.refPickerName + '")');
    save();
    return true;
  }
  if (!(found && found.found)) {
    elog('Reference prothom bar upload hocche — EKbar-i hobe, pore ar kokhono upload hobe na');
    const composer = await evalFn(tabId, sfaFindComposer);
    if (!composer || !composer.input) {
      S.refStatus = 'failed';
      save();
      elog('ERROR: reference upload er jonno prompt input paoa jay ni — run shuru holona');
      return false;
    }
    await realClick(tabId, composer.input.x, composer.input.y);
    await sleep(250);
    const keyOpts = { key: 'v', code: 'KeyV', modifiers: 2, windowsVirtualKeyCode: 86, nativeVirtualKeyCode: 86 };
    await cdp(tabId, 'Input.dispatchKeyEvent', Object.assign({ type: 'keyDown' }, keyOpts));
    await cdp(tabId, 'Input.dispatchKeyEvent', Object.assign({ type: 'keyUp' }, keyOpts));
    await sleep(1000);
  } else {
    elog('Reference tile project e ache kintu ekhono process hocche — upload gate e opekkha hocche');
  }
  S.refStatus = 'uploading';
  save();
  const gate = await waitRefUploadGate(tabId, tiles, name);
  if (!gate) {
    S.refStatus = 'failed';
    save();
    elog('ERROR: reference upload sesh hoyni — run shuru holona');
    return false;
  }
  S.refMediaId = gate.mediaId;
  S.refAssetName = gate.label || name;
  S.refPickerName = sfaPickerNameFromLabel(gate.label);
  S.refStatus = 'ready';
  elog('reference upload COMPLETE (mediaId=' + gate.mediaId + ', ' + gate.secs + 's)');
  elog('picker e khonjar naam record holo: "' + S.refPickerName + '"');
  await clearComposerAfterUpload(tabId);
  save();
  return true;
}

/* v2.0/v2.1 — re-ADD the already-uploaded reference from the project
 * via the ingredient picker (never a re-upload). Steps, each logged:
 * "+" ("Add ingredients to the prompt box") → picker (retry open 3×
 * with Escape between) → "All" tab row (else "Uploads") → v2.1:
 * "Search assets" box e asset er naam likhe filter (search e 0 option
 * ele search muchhe unfiltered list) → option match: mediaId → naam →
 * ekmatro-option shortcut → filename-pattern (na mille scroll ×2,
 * tarpor ja ja option chilo log e likhe fail) → click option
 * (preview) → "Add to prompt" (absent = option click attached)
 * → verify the composer ingredient count grew. One full retry inside,
 * and processItem gives picker failures a 2nd attempt overall. */
async function attachRefFromProject(tabId, item) {
  const fail = (reason) => { const e = new Error(reason); e.finalReason = reason; return e; };
  const before = await getIngredients(tabId);
  if (before.ingredients >= 1) {
    elog(item.id + ': reference age thekei composer e ache (ingredients=' + before.ingredients + ') — picker lagbe na');
    return;
  }
  for (let attachTry = 1; attachTry <= 2; attachTry++) {
    if (stopRequested) throw ABORT;
    let picker = null;
    for (let openTry = 1; openTry <= 3 && !picker; openTry++) {
      const bar = await evalFn(tabId, sfaComposerBar).catch(() => null);
      if (!bar || !bar.plus) throw fail('picker khola jay ni — "Add ingredients" (+) button paoa jay ni');
      await realClick(tabId, bar.plus.x, bar.plus.y);
      elog(item.id + ': picker kholar chesta (' + openTry + '/3) — "+" button e click holo');
      const t0 = Date.now();
      while (Date.now() - t0 < 2500) {
        if (stopRequested) throw ABORT;
        const pk = await evalFn(tabId, sfaPicker).catch(() => null);
        if (pk && pk.open) { picker = pk; break; }
        await sleepOrStop(400);
      }
      if (!picker) {
        elog(item.id + ': picker khule ni — Escape diye abar try hobe');
        await pressEscape(tabId).catch(() => {});
        await sleep(400);
      }
    }
    if (!picker) throw fail('picker khule ni (3 bar try korechi)');
    elog(item.id + ': picker khuleche (' + (picker.options || []).length + ' option dekha jacche)');
    const tabWanted = (picker.tabs || []).find((t) => /^all$/i.test(t.name)) || (picker.tabs || []).find((t) => /^uploads$/i.test(t.name));
    if (tabWanted) {
      await realClick(tabId, tabWanted.x, tabWanted.y);
      elog(item.id + ': picker tab "' + tabWanted.name + '" select holo');
      await sleep(700);
      picker = await evalFn(tabId, sfaPicker).catch(() => picker) || picker;
    } else {
      elog(item.id + ': tab row paoa jay ni — current tab diyei cholche');
    }
    // v2.1 search-first: the real picker has a "Search assets" box —
    // typing the asset name filters the list down to the reference
    // instead of depending on row order or roles.
    if (picker.searchInput) {
      const term = sfaSearchTerm(S.refPickerName, S.refAssetName, S.refFileName);
      const preSearchCount = (picker.options || []).length;
      await realClick(tabId, picker.searchInput.x, picker.searchInput.y);
      await sleep(200);
      await cdp(tabId, 'Input.insertText', { text: term });
      await sleep(900);
      picker = await evalFn(tabId, sfaPicker).catch(() => picker) || picker;
      elog(item.id + ": picker e search dilam: '" + term + "' — " + (picker.options || []).length + ' option');
      if ((picker.options || []).length === 0 && preSearchCount > 0 && picker.searchInput) {
        // The search filtered everything out (the asset may carry a
        // different display name) — clear it and use the unfiltered
        // list rather than failing the item.
        elog(item.id + ': search e 0 option — search muchhe unfiltered list e khujchi');
        await realClick(tabId, picker.searchInput.x, picker.searchInput.y);
        await sleep(150);
        await clearFocusedInput(tabId);
        await sleep(700);
        picker = await evalFn(tabId, sfaPicker).catch(() => picker) || picker;
        elog(item.id + ': search muchhar por ' + (picker.options || []).length + ' option dekha jacche');
      }
    }
    let opt = sfaMatchOption(picker.options, S.refMediaId, S.refAssetName, S.refFileName);
    let scrolls = 0;
    while (!opt && scrolls < 2) {
      const scrolled = await evalFn(tabId, sfaPickerScroll).catch(() => false);
      if (!scrolled) break;
      scrolls++;
      await sleep(600);
      picker = await evalFn(tabId, sfaPicker).catch(() => picker) || picker;
      opt = sfaMatchOption(picker.options, S.refMediaId, S.refAssetName, S.refFileName);
      elog(item.id + ': picker scroll ' + scrolls + ' — option ' + (opt ? 'paichi' : 'ekhono pai ni') + ' (mot ' + (picker.options || []).length + ' option dekha jacche)');
    }
    if (!opt) {
      // v2.1: name what WAS seen, so a future miss is self-diagnosing.
      const seen = (picker.options || []).slice(0, 5).map((o) => "[name='" + (o.name || '') + "' mediaId=" + (o.mediaId || 'null') + ']').join(', ');
      elog(item.id + ': picker options chilo: ' + (seen || '(kono option dekha jay ni)'));
      await pressEscape(tabId).catch(() => {});
      throw fail('picker e reference khuje pai ni');
    }
    if (opt.via === 'single') {
      elog(item.id + ": picker e ekmatro option tai select holo (name='" + (opt.name || '') + "')");
    } else if (opt.via === 'filename') {
      elog(item.id + ": filename-pattern diye option select holo (name='" + (opt.name || '') + "')");
    } else {
      elog(item.id + ': asset select holo — "' + (opt.name || '') + '"' + (opt.mediaId ? ' (mediaId=' + opt.mediaId + ')' : ''));
    }
    await realClick(tabId, opt.x, opt.y);
    await sleep(600);
    const pk2 = await evalFn(tabId, sfaPicker).catch(() => null);
    if (pk2 && pk2.addBtn) {
      await realClick(tabId, pk2.addBtn.x, pk2.addBtn.y);
      elog(item.id + ': "Add to prompt" click holo');
      await sleep(600);
    } else {
      elog(item.id + ': "Add to prompt" button nai — option click ei attach dhora holo');
    }
    const after = await getIngredients(tabId);
    const grew = (before.ingredients >= 0 && after.ingredients > before.ingredients) ||
      (before.ingredients < 0 && after.ingredients >= 1);
    if (grew) {
      elog(item.id + ': reference add hoyeche — chip ache ekhon ' + after.ingredients);
      return;
    }
    elog(item.id + ': reference add verify fail (ingredients ' + before.ingredients + ' -> ' + after.ingredients + ') — attach try ' + attachTry + '/2');
    await pressEscape(tabId).catch(() => {});
    await sleep(400);
  }
  throw fail('reference add hoy ni');
}

/* ---------------- download ---------------- */
/* v2.2 quality route: for 2K/4K the download goes through Flow's own
 * tile menu (the direct URL is only the original size). Flow's menu
 * offers "1K Original size" / "2K Upscaled" — for 4K we pick the
 * highest option the menu actually shows. A menu download lands with
 * Flow's own file name (the downloads API cannot rename a download
 * the page started), so the item records dlName and the match report
 * lists it under Flow names. Any menu failure falls back to the 1K
 * direct download below. */
async function downloadViaMenu(tabId, item, tile, quality) {
  const before = new Set();
  const existing = await chrome.downloads.search({});
  (existing || []).forEach((d) => before.add(d.id));
  const tu = tile && tile.mediaId ? await evalFn(tabId, sfaTileUrl, tile.mediaId).catch(() => null) : null;
  if (!tu) throw new Error('tile paoa jay ni');
  elog(item.id + ': ' + quality + ' menu download — tile e click hocche (viewer khulbe)');
  await realClick(tabId, tu.x, tu.y);
  await sleep(1500);
  const btn = await evalFn(tabId, sfaFindDownloadBtn);
  if (!btn) throw new Error('Viewer e Download button paoa jay ni');
  elog(item.id + ': menu download — Download button e click hocche');
  await realClick(tabId, btn.x, btn.y);
  await sleep(900);
  const want = quality === '4K' ? ['4K', '2K', 'Upscaled', 'Original size'] : ['2K', 'Upscaled', 'Original size'];
  let picked = null;
  for (const t of want) {
    picked = await evalFn(tabId, sfaFindTextBtn, { text: t }).catch(() => null);
    if (picked) break;
  }
  let pickedLabel = 'Download';
  if (picked) {
    pickedLabel = picked.label || pickedLabel;
    if (quality === '4K' && !/4\s*k/i.test(pickedLabel)) {
      elog(item.id + ': 4K nai — highest available nilam ("' + pickedLabel + '")');
    } else {
      elog(item.id + ': menu theke "' + pickedLabel + '" select holo');
    }
    await realClick(tabId, picked.x, picked.y);
  } else {
    elog(item.id + ': size submenu paoa jay ni — Download click ei ja ashe tai hobe');
  }
  const t0 = Date.now();
  while (Date.now() - t0 < 30000) {
    const news = await chrome.downloads.search({ startedAfter: new Date(t0 - 5000).toISOString() });
    const fresh = (news || []).find((d) => !before.has(d.id));
    if (fresh) {
      const done = await waitDownloadComplete(fresh.id, 60000);
      if (!done) throw new Error('Menu download interrupted');
      const base = String(done.filename || '').replace(/\\/g, '/').split('/').pop();
      elog(item.id + ': menu download done — file: ' + base + ' (' + (done.fileSize || done.totalBytes || 0) + ' bytes)');
      return { flowName: base, label: pickedLabel };
    }
    await sleep(1000);
  }
  throw new Error('Menu download shuru hoyni');
}

/* v2.0: primary path is the completed tile's own URL (sfaTileUrl —
 * the signed flow.google.com/asb/... thumbnail URL), saved under our
 * exact filename and byte-verified as before. Blob URLs and missing
 * URLs fall back to the viewer route. v2.2: 2K/4K try Flow's own
 * download menu first (see downloadViaMenu). */
async function downloadFromTile(tabId, item, tile) {
  const q = (S.settings && S.settings.quality) || '1K';
  if ((q === '2K' || q === '4K') && tile && tile.mediaId) {
    try {
      const r = await downloadViaMenu(tabId, item, tile, q);
      item.dlName = r.flowName || '';
      item.stage = 'done';
      return 'via menu — ' + r.label + ' (flow name: ' + r.flowName + ')';
    } catch (e) {
      elog(item.id + ': ' + q + ' menu fail (' + e.message + ') — 1K direct download holo');
      item.dlName = '';
    }
  }
  const fname = targetPath(S.project, item.id);
  const tu = tile && tile.mediaId ? await evalFn(tabId, sfaTileUrl, tile.mediaId).catch(() => null) : null;
  const url = tu && tu.url ? tu.url : '';
  if (url && url.indexOf('blob:') !== 0) {
    elog(item.id + ': download shuru — ' + fname + ' (tile mediaId=' + tile.mediaId + ')');
    const size = await downloadAndVerify(upgradeUrl(url), fname);
    elog(item.id + ': download done (' + size + ' bytes)');
    item.stage = 'done';
    return '';
  }
  if (url) elog(item.id + ': blob URL — tile click fallback hocche');
  else elog(item.id + ': tile URL paoa jay ni — tile click fallback hocche');
  try {
    const note = await fallbackDownload(tabId, tile);
    elog(item.id + ': fallback download done');
    item.stage = 'done';
    return note;
  } catch (fbErr) {
    const err = new Error('download hoy ni — report pathao');
    err.finalReason = 'download hoy ni — report pathao';
    throw err;
  }
}

/* Viewer fallback: click the finished tile (realClick moves the mouse
 * first — hover toolbars need real pointer movement), press the
 * viewer's Download button, then "1K Original size" when the download
 * opens a size submenu. The file lands with Flow's own name, so a
 * successful fallback returns the 'fallback-name' note. */
async function fallbackDownload(tabId, tileHint) {
  const before = new Set();
  const existing = await chrome.downloads.search({});
  (existing || []).forEach((d) => before.add(d.id));
  let cx = null;
  let cy = null;
  if (tileHint && tileHint.mediaId) {
    const tu = await evalFn(tabId, sfaTileUrl, tileHint.mediaId).catch(() => null);
    if (tu) { cx = tu.x; cy = tu.y; }
  }
  if (cx === null) {
    const tiles = await evalFn(tabId, sfaTiles).catch(() => null);
    const cand = (tiles || []).find((t) => t.kind === 'image' && t.mediaId);
    if (cand) {
      const tu2 = await evalFn(tabId, sfaTileUrl, cand.mediaId).catch(() => null);
      if (tu2) { cx = tu2.x; cy = tu2.y; }
    }
  }
  if (cx === null) {
    const img = await evalFn(tabId, sfaLastImg).catch(() => null);
    if (img) { cx = img.x; cy = img.y; }
  }
  if (cx === null) throw new Error('Result image tile paoa jay ni');
  elog('Fallback: tile e click hocche (' + cx + ',' + cy + ') — viewer khulbe');
  await realClick(tabId, cx, cy);
  await sleep(1500);
  const btn = await evalFn(tabId, sfaFindDownloadBtn);
  if (!btn) throw new Error('Viewer e Download button paoa jay ni');
  elog('Fallback: Download button e click hocche');
  await realClick(tabId, btn.x, btn.y);
  await sleep(900);
  const sizeBtn = await evalFn(tabId, sfaFindTextBtn, { text: 'Original size' }).catch(() => null);
  if (sizeBtn) {
    elog('Fallback: size menu te "' + sizeBtn.label + '" pelam — click hocche');
    await realClick(tabId, sizeBtn.x, sizeBtn.y);
  }
  const t0 = Date.now();
  while (Date.now() - t0 < 30000) {
    const news = await chrome.downloads.search({ startedAfter: new Date(t0 - 5000).toISOString() });
    const fresh = (news || []).find((d) => !before.has(d.id));
    if (fresh) {
      const done = await waitDownloadComplete(fresh.id, 60000);
      if (done) return 'fallback-name';
      throw new Error('Fallback download interrupted');
    }
    await sleep(1000);
  }
  throw new Error('Fallback download shuru hoyni');
}

/* v2.2 — one completed generation, two outcomes. Records the tile
 * identity + URL on the item and kicks off its thumbnail, then:
 * - Download Later mode (settings.autoDownload === false): returns
 *   { generatedOnly: true } — the caller marks the item "generated"
 *   and NO download happens now.
 * - Auto mode: downloads immediately (tile route, direct URL, or the
 *   viewer fallback) and returns { note }.
 * With neither a tile nor a usable URL there is nothing to defer, so
 * the viewer fallback runs at once even in Download Later mode. */
async function completeItem(tabId, item, tile, knownUrl) {
  let url = knownUrl || '';
  if (tile && tile.mediaId) {
    item.tileMediaId = tile.mediaId;
    if (!url) {
      const tu = await evalFn(tabId, sfaTileUrl, tile.mediaId).catch(() => null);
      if (tu && tu.url) url = tu.url;
    }
  }
  if (url) item.tileUrl = url;
  if (tile || url) item.completedAt = Date.now();
  if (url && url.indexOf('blob:') !== 0) captureThumbnail(item.id, upgradeUrl(url));
  if (S.settings && S.settings.autoDownload === false && (tile || (url && url.indexOf('blob:') !== 0))) {
    elog(item.id + ': generated — download pore hobe (Download Later mode, tile mone rakha holo)');
    item.stage = 'generated';
    save();
    return { generatedOnly: true };
  }
  if (tile) {
    const note = await downloadFromTile(tabId, item, tile);
    return { note: note || '' };
  }
  if (url && url.indexOf('blob:') !== 0) {
    const fname = targetPath(S.project, item.id);
    elog(item.id + ': download shuru — ' + fname);
    const size = await downloadAndVerify(upgradeUrl(url), fname);
    elog(item.id + ': download done (' + size + ' bytes)');
    item.stage = 'done';
    return { note: '' };
  }
  const note = await fallbackDownload(tabId, tile || null);
  elog(item.id + ': fallback download done');
  item.stage = 'done';
  return { note: note || '' };
}

/* Decide where the fallback send-click goes. First choice: the coords
 * captured BEFORE typing (empty-composer layout, known-good) — but only if
 * the element at that point still verifies via sfaVerifyPoint as a
 * non-blacklisted button. If verification fails, re-run the (now
 * blacklist-aware) composer finder and verify its pick the same way. */
async function resolveClickTarget(tabId, item, storedSend) {
  if (storedSend) {
    const v = await evalFn(tabId, sfaVerifyPoint, { x: storedSend.x, y: storedSend.y }).catch(() => null);
    if (v && v.ok) return { x: storedSend.x, y: storedSend.y, label: v.label || storedSend.label || '', strategy: 'age-dhora coords (verified)' };
    elog(item.id + ': click fallback — age-dhora coords verify fail (' + (v ? (v.reason || '?') + (v.label ? ', label="' + v.label + '"' : '') : 'probe fail') + '), notun kore button khujchi');
  }
  const fresh = await evalFn(tabId, sfaFindComposer).catch(() => null);
  if (fresh && fresh.send) {
    const v2 = await evalFn(tabId, sfaVerifyPoint, { x: fresh.send.x, y: fresh.send.y }).catch(() => null);
    if (v2 && v2.ok) return { x: fresh.send.x, y: fresh.send.y, label: v2.label || fresh.send.label || '', strategy: fresh.send.strategy + ' (notun, verified)' };
    elog(item.id + ': click fallback — notun button er point-verify fail (' + (v2 ? (v2.reason || '?') : 'probe fail') + '), finder er pick tai use hocche');
    return { x: fresh.send.x, y: fresh.send.y, label: fresh.send.label || '', strategy: fresh.send.strategy + ' (notun)' };
  }
  return null;
}

/* ---------------- one item ---------------- */
/* v2.5 — ONE send attempt, factored out of processItem so the paced
 * loop can reuse the exact same machinery (snapshot -> clear -> picker
 * attach -> type+verify -> gap -> Enter -> start-signal wait with the
 * hardened click fallback). ctx carries the cross-attempt type-fail
 * counter ({ typeFails }); opts.enforceGap === false skips the send
 * gap (paced mode paces sends itself) but still stamps lastSendAt.
 * Resolves { snap, busySeen, sentAt } once generation has verifiably
 * started; throws (with finalReason where the serial rules make it
 * final) otherwise. */
async function sendPromptOnce(tabId, item, ctx, opts) {
  ctx = ctx || { typeFails: 0 };
  opts = opts || {};
  const wantRef = itemNeedsRef(item);
  // Pre-send snapshot: completion + error detection are relative to
  // this. snap.ids = mediaIds already in the grid; snap.errorCount =
  // error tiles already there (old error tiles persist forever).
  const snapTiles = await evalFn(tabId, sfaTiles).catch(() => []);
  const snap = {
    ids: (snapTiles || []).map((t) => t.mediaId).filter(Boolean),
    count: (snapTiles || []).length,
    errorCount: (snapTiles || []).filter((t) => t.kind === 'error').length
  };
  let composer = await evalFn(tabId, sfaFindComposer);
  if (!composer || !composer.input) throw new Error('Prompt input paoa jay ni');
  // Send-button coords are captured NOW, in the empty-composer layout
  // where the arrow's position is known-good. In v1.2 the button was
  // re-located AFTER typing — and once text is present a clear/close (x)
  // control sits near the composer, which the finder mistook for the
  // send button: the click erased the prompt and nothing generated.
  const storedSend = composer.send || null;
  if (storedSend) {
    elog(item.id + ': send button age theke dhora ache (' + storedSend.x + ',' + storedSend.y + '), strategy=' + storedSend.strategy + ', label="' + (storedSend.label || '') + '"');
  } else {
    elog(item.id + ': SABDHAN: khali box e send button paoa jay ni — click fallback thakbe na, sudhu Enter diye try hobe');
  }

  // Focus + clear the box first (clearing after an attach could
  // remove the ingredient, so the order is: clear -> attach -> type).
  item.stage = 'typing';
  await realClick(tabId, composer.input.x, composer.input.y);
  await sleep(150);
  await clearFocusedInput(tabId);

  if (wantRef) {
    item.stage = 'ref bosano hocche';
    save();
    await attachRefFromProject(tabId, item);
    // Attaching re-renders/shifts the composer, so re-find it and
    // type with the fresh layout (v1.4 typed into nowhere exactly
    // because pre-attach coordinates went stale).
    const freshComposer = await evalFn(tabId, sfaFindComposer).catch(() => null);
    if (freshComposer && freshComposer.input) {
      composer = freshComposer;
      elog(item.id + ': reference add er por composer notun kore khuje neowa holo');
    } else {
      elog(item.id + ': reference add er por composer notun kore paoa jay ni — ager coords diyei type hobe');
    }
  }

  // Type, with ONE in-attempt retry: a failed verify re-finds the
  // composer, refocuses, waits 600ms and types again before the
  // attempt is allowed to fail on typing.
  let vt = null;
  for (let t = 1; t <= 2; t++) {
    await realClick(tabId, composer.input.x, composer.input.y);
    await sleep(t === 1 ? 150 : 600);
    await cdp(tabId, 'Input.insertText', { text: item.prompt });
    await sleep(500);
    vt = await verifyTyped(tabId, item.prompt);
    if (vt.ok) break;
    if (t === 1) {
      elog(item.id + ': TYPE FAIL (in-attempt 1/2, box length ' + vt.len + ') — composer notun kore khuje abar type hocche');
      const reComposer = await evalFn(tabId, sfaFindComposer).catch(() => null);
      if (reComposer && reComposer.input) composer = reComposer;
    }
  }
  if (!vt.ok) {
    ctx.typeFails++;
    elog(item.id + ': TYPE FAIL: box e lekha nai (fail ' + typeFails + '/2, box length ' + vt.len + ')');
    if (ctx.typeFails >= 2) {
      const err = new Error('prompt type hoy ni');
      err.finalReason = 'prompt type hoy ni';
      throw err;
    }
    throw new Error('prompt type hoy ni — abar try hobe');
  }
  item.stage = 'typed';
  elog(item.id + ': typed OK, ' + vt.len + ' chars box e ache');
  save();

  // Pacing rule: generation starts are spaced by the configured
  // interval (settings.intervalSec; v2.0's fixed 10s is the default).
  if (opts.enforceGap === false) { S.lastSendAt = Date.now(); save(); }
    else await enforceSendGap(item);

  // ---- SEND: Enter FIRST. Flow's composer is a chat-style input
  // where Enter = send, and a trusted CDP Enter can never land on
  // a wrong (clear/close) control the way a blind click could.
  item.stage = 'send: Enter';
  elog(item.id + ': Enter diye send er chesta');
  save();
  let sentAt = Date.now();
  await pressEnter(tabId);

  // Fail fast if generation never actually starts: 15s signal wait
  // after Enter, then ONE hardened click fallback + another 15s.
  item.stage = 'gen shuru check';
  save();
  let signal = await waitForStartSignal(tabId, snap, vt.len);
  if (!signal) {
    elog(item.id + ': Enter e start signal pai ni (15s) — click fallback hocche');
    const target = await resolveClickTarget(tabId, item, storedSend);
    if (target) {
      item.stage = 'send: click';
      elog(item.id + ': click fallback — button "' + (target.label || '') + '" (' + target.x + ',' + target.y + '), strategy=' + target.strategy);
      save();
      await realClick(tabId, target.x, target.y);
      S.lastSendAt = Date.now();
      save();
      sentAt = Date.now();
      signal = await waitForStartSignal(tabId, snap, vt.len);
    } else {
      elog(item.id + ': click fallback er jonno nirbhorjoggo button paoa jay ni');
    }
  }
  if (!signal) {
    const err = new Error('send hoy ni — Enter o click duitai miss (button khuje pete somossa)');
    err.finalReason = err.message;
    throw err;
  }
  elog(item.id + ': generation shuru hoyeche — signal: ' + signal.name);
  item.stage = 'waiting';
  save();

  return { snap: snap, busySeen: signal.busySeen, sentAt: sentAt };
}

async function processItem(tabId, item, gen) {
  let lastError = null;
  const sendCtx = { typeFails: 0 };
  for (let attempt = 1; attempt <= 3; attempt++) {
    if (stopRequested) throw ABORT;
    if (gen !== undefined && gen !== runGen) throw ABORT; // v2.3: superseded by a newer run
    item.attempts = (item.attempts || 0) + 1;
    elog(item.id + ': attempt ' + attempt + ' shuru');
    save();
    try {
      await ensureAttached(tabId); // never start an attempt on a dead session
      const sent = await sendPromptOnce(tabId, item, sendCtx);
      // Tile-based completion wait (240s cap; error tiles handled via
      // their Retry button inside the wait).
      const comp = await waitForCompletion(tabId, sent.snap, item, { busySeen: sent.busySeen, sentAt: sent.sentAt });
      item.stage = 'downloading';
      save();
      if (comp.tile) {
        return await completeItem(tabId, item, comp.tile, '');
      }
      // Busy-cycle fallback: try the newest result tile (even one still
      // showing % — it settled while we watched busy), then a media URL
      // from the combined scan, then the viewer fallback.
      elog(item.id + ': notun tile sarasari pai ni — sesh chesta: notun tile ba media URL diye download');
      const tilesNow = await evalFn(tabId, sfaTiles).catch(() => null);
      const cand = sfaPickResultTile(tilesNow, sent.snap.ids, S.refMediaId) ||
        (tilesNow || []).filter((t) => t.kind === 'image' && t.mediaId && sent.snap.ids.indexOf(t.mediaId) === -1 && t.mediaId !== S.refMediaId)[0] || null;
      if (cand) return await completeItem(tabId, item, cand, '');
      const scanNow = await evalFn(tabId, sfaMediaScan).catch(() => null);
      const lastUrl = scanNow && scanNow.lastUrl ? scanNow.lastUrl : null;
      if (lastUrl && lastUrl.indexOf('blob:') !== 0) {
        return await completeItem(tabId, item, null, lastUrl);
      }
      try {
        const note = await fallbackDownload(tabId, null);
        elog(item.id + ': fallback download done');
        item.stage = 'done';
        return { note: note || '' };
      } catch (fbErr) {
        const err = new Error('image khuje pai ni — report pathao');
        err.finalReason = 'image khuje pai ni — report pathao';
        throw err;
      }
    } catch (e) {
      if (e === ABORT) throw e;
      lastError = e;
      elog(item.id + ': attempt ' + attempt + ' fail — ' + e.message);
      if (e.finalReason) {
        // v2.1: picker attach failures are usually transient (picker
        // timing/render) — they may consume up to 2 attempts with the
        // standard backoff before the item is marked FAILED. They used
        // to die at attempts=1 because attach marks them final.
        const PICKER_FAIL_PREFIXES = ['picker e reference khuje pai ni', 'picker khule ni', 'picker khola jay ni', 'reference add hoy ni'];
        const isPickerFail = PICKER_FAIL_PREFIXES.some((p) => e.finalReason.indexOf(p) === 0);
        if (!isPickerFail || attempt >= 2) throw e; // fail fast: reason is final for this item
        elog(item.id + ': picker attach fail — 2 attempt porjonto try hobe (ekhon ' + attempt + '/2), 15s por abar try hobe');
      }
      if (attempt < 3) {
        elog(item.id + ': 15s por abar try hobe');
        await sleepOrStop(15000); // v2.3: Stop cuts the backoff short instantly
      }
    }
  }
  throw lastError || new Error('Unknown failure');
}

/* ---------------- report ---------------- */
function buildReport() {
  const c = counts();
  const lines = [];
  lines.push('SHEIKH Flow Auto — Run Report');
  lines.push('Project: ' + (S.project || '(unnamed)'));
  lines.push('Date: ' + new Date().toLocaleString());
  lines.push('Started: ' + (S.runStartedAt ? new Date(S.runStartedAt).toLocaleString() : '-'));
  lines.push('Finished: ' + (S.runFinishedAt ? new Date(S.runFinishedAt).toLocaleString() : '-'));
  lines.push('Total: ' + c.total + ' | Done: ' + c.done + ' | Failed: ' + c.failed + ' | Pending: ' + c.pending + (c.generated ? ' | Generated (not downloaded): ' + c.generated : ''));
  lines.push('Download settings: quality ' + ((S.settings && S.settings.quality) || '1K') + ', auto-download ' + (S.settings && S.settings.autoDownload === false ? 'OFF (Download Later)' : 'ON') + ', folder ' + runFolderName() + ', run mode ' + ((S.settings && S.settings.runMode) || 'serial'));
  const failedIds = S.items.filter((i) => i.status === 'failed').map((i) => i.id);
  lines.push('Failed IDs: ' + (failedIds.length ? failedIds.join(', ') : 'none'));
  lines.push('');
  const failedItems = S.items.filter((i) => i.status === 'failed');
  if (failedItems.length) {
    lines.push('Failed items (reason shoho):');
    for (const it of failedItems) lines.push(it.id + ' — ' + (it.failReason || it.note || 'reason jana nai'));
    lines.push('');
  }
  lines.push('Per-item status:');
  for (const it of S.items) {
    lines.push(it.id + '  ' + it.status + (it.attempts ? '  attempts=' + it.attempts : '') + (it.stage ? '  stage=' + it.stage : '') + (it.failReason ? '  failReason=' + it.failReason : '') + (it.note ? '  note=' + it.note : ''));
  }
  lines.push('');
  lines.push('--- Engine log (last 40) — diagnosis er jonno Bby ke pathiye dilei hobe ---');
  const engineLines = S.log.filter((l) => l.indexOf('[engine]') === 0);
  const tail = (engineLines.length ? engineLines : S.log).slice(-40);
  for (const l of tail) lines.push(l);
  return lines.join('\n');
}
async function downloadReportFile() {
  try {
    const url = 'data:text/plain;charset=utf-8,' + encodeURIComponent(S.lastReport || buildReport());
    await downloadsDownload({ url, filename: 'SHEIKH Flow Auto/' + runFolderName() + '/run-report.txt', saveAs: false });
  } catch (e) { /* panel button is the reliable path */ }
}

/* ---------------- run loop ---------------- */
async function parkWhilePaused(tabId) {
  if (!pauseRequested) return false; // returns true if we parked
  S.paused = true;
  elog('Engine: pause dhora hoyeche — debugger detach kore opekkha korchi');
  await dbgDetach(tabId);
  saveNow();
  while (pauseRequested && !stopRequested) {
    beat();
    try { await sleepOrStop(500); } catch (e) { if (e !== ABORT) throw e; break; }
  }
  S.paused = false;
  save();
  if (stopRequested) return true;
  await dbgAttach(tabId);
  elog('Engine: resume — debugger abar attach OK');
  return true;
}

/* v2.3 — force-reset a wedged run (start/resume handlers call this
 * when the loop flag is on but the heartbeat is >20s stale). The old
 * loop is invalidated by generation and woken by the epoch bump, so
 * its waits throw ABORT and its finally skips cleanup; every page
 * call it might be parked inside now carries the 8s CDP timeout, so
 * it unwinds fast and never touches the new run's items. */
function forceResetRun() {
  runGen++;
  bumpAbortEpoch();
  loopActive = false;
  pauseRequested = false;
  stopRequested = false;
  S.running = false;
  S.paused = false;
  for (const it of S.items) if (it.status === 'active') { it.status = 'pending'; it.stage = ''; }
}

/* ---------------- v2.5 paced loop ----------------
 * Sends go out one by one at the configured interval (minimum gap
 * between SENDS, stamped via S.lastSendAt) WITHOUT waiting for each
 * generation to finish. A watcher polls the grid every ~1.5s:
 *  - each NEW finished image tile is assigned FIFO to the OLDEST
 *    sent-but-unmatched item (pacedCompletedNew + pacedAssign), so
 *    downloads/naming stay locked to prompt order even if Flow
 *    finishes generations out of order. Matched items complete via
 *    completeItem (download now, or "generated" in Download Later
 *    mode — the later pass walks the list in order).
 *  - a NEW error tile consumes the OLDEST pending item as a failed
 *    attempt: it is re-sent next, ahead of unsent items, until the
 *    item has used its 3 sends; then it is marked failed.
 *  - a pending item with no tile after 240s is a failed attempt on
 *    the same path.
 * Baseline media-ids (grid contents + the reference at loop entry)
 * are never matched; S.pacedBase persists the baseline across
 * resumes. Pause parks like the serial loop; Stop unwinds via the
 * abort epoch and returns still-pending items to "pending" so a
 * Resume re-sends them. */
async function runPacedLoop(tabId, gen) {
  const epoch = abortEpoch;
  const TIMEOUT_MS = 240000;
  const baseTiles = await evalFn(tabId, sfaTiles).catch(() => null) || [];
  if (!(S.pacedBase && S.pacedBase.at === S.runStartedAt && Array.isArray(S.pacedBase.ids))) {
    S.pacedBase = { at: S.runStartedAt, ids: baseTiles.map((t) => t.mediaId).filter(Boolean) };
    save();
  }
  const handled = new Set(S.pacedBase.ids);
  for (const it of S.items) if (it.tileMediaId) handled.add(it.tileMediaId);
  if (S.refMediaId) handled.add(S.refMediaId);
  let errBaseline = baseTiles.filter((t) => t.kind === 'error').length;
  const sendQueue = S.items.filter((i) => i.status === 'pending');
  const retryQueue = [];
  const pending = S.items.filter((i) => i.status === 'active' && !i.tileMediaId);
  let inFlight = null; // item inside sendPromptOnce right now (in no queue)
  for (const p of pending) if (!p.sentAt) p.sentAt = Date.now();
  elog('Paced mode shuru — interval ' + clampIntervalSec(S.settings && S.settings.intervalSec) + 's, pathano baki ' + sendQueue.length + ', age theke opekkha ' + pending.length);

  const markFailed = async (item, reason) => {
    item.status = 'failed';
    item.stage = 'failed';
    item.note = reason;
    item.failReason = reason;
    elog(item.id + ': FAILED — ' + reason);
    await screenshotError(tabId, sanitizeProject(S.project), item.id).catch(() => {});
    saveNow();
  };
  const failAttempt = async (item, reason) => {
    const ix = pending.indexOf(item);
    if (ix >= 0) pending.splice(ix, 1);
    if ((item.attempts || 0) < 3) {
      item.tileMediaId = null;
      item.tileUrl = '';
      item.sentAt = 0;
      item.status = 'active';
      item.stage = 'resend hobe';
      retryQueue.unshift(item);
      elog(item.id + ': attempt fail (' + reason + ') — resend queue r age jabe (send ' + (item.attempts || 0) + '/3)');
      saveNow();
    } else {
      await markFailed(item, reason);
    }
  };

  try {
    while (true) {
      if (stopRequested || gen !== runGen || epoch !== abortEpoch) break;
      if (await parkWhilePaused(tabId)) {
        if (stopRequested) break;
        await ensureAttached(tabId).catch(() => {});
      }
      if (stopRequested || gen !== runGen || epoch !== abortEpoch) break;
      beat();

      // ---- SEND: next item once the send gap has elapsed ----
      const nextItem = retryQueue[0] || sendQueue[0];
      if (nextItem) {
        const gapMs = clampIntervalSec(S.settings && S.settings.intervalSec) * 1000;
        const last = S.lastSendAt || 0;
        if (!last || Date.now() - last >= gapMs) {
          const item = retryQueue.length ? retryQueue.shift() : sendQueue.shift();
          item.status = 'active';
          item.stage = 'shuru hocche';
          item.failReason = '';
          item.attempts = (item.attempts || 0) + 1;
          saveNow();
          elog(item.id + ': paced send hocche (send ' + item.attempts + '/3)');
          inFlight = item;
          try {
            await ensureAttached(tabId);
            const sent = await sendPromptOnce(tabId, item, { typeFails: 0 }, { enforceGap: false });
            item.sentAt = sent.sentAt || Date.now();
            item.stage = 'waiting';
            pending.push(item);
            saveNow();
          } catch (e) {
            if (e === ABORT) throw e;
            await failAttempt(item, (e && (e.finalReason || e.message)) || String(e));
          } finally {
            inFlight = null;
          }
        }
      }

      // ---- WATCH: match finished tiles, consume errors, timeouts ----
      let tiles = null;
      try { tiles = await evalFn(tabId, sfaTiles); } catch (e) { tiles = null; }
      if (tiles) {
        const ed = pacedErrorDelta(errBaseline, tiles);
        errBaseline = ed.now;
        for (let k = 0; k < ed.delta; k++) {
          if (pending.length) {
            elog('Paced: notun error tile — sobcheye ager pending item (' + pending[0].id + ') er attempt fail dhora holo');
            await failAttempt(pending[0], 'Flow error: generation failed (error tile)');
          } else {
            elog('Paced: notun error tile esheche kintu pending item nai — ignore kora holo');
          }
        }
        const fresh = pacedCompletedNew(tiles, Array.from(handled), S.refMediaId);
        if (fresh.length && pending.length) {
          const pairs = pacedAssign(pending.map((p) => p.id), fresh);
          for (const pr of pairs) {
            const item = pending.find((p) => p.id === pr.itemId);
            if (!item) continue;
            handled.add(pr.tile.mediaId);
            pending.splice(pending.indexOf(item), 1);
            item.stage = 'downloading';
            save();
            try {
              const outcome = await completeItem(tabId, item, pr.tile, '');
              const term = terminalStatusFor(outcome);
              item.status = term;
              item.stage = term;
              item.failReason = '';
              if (term === 'generated') {
                elog(item.id + ': generated — image ready, download baki (Download Later)');
              } else {
                item.note = (outcome && outcome.note) || '';
                elog(item.id + ': done' + (item.note ? ' (' + item.note + ')' : ''));
              }
            } catch (e) {
              await failAttempt(item, (e && (e.finalReason || e.message)) || String(e));
            }
            saveNow();
          }
        }
        const nowMs = Date.now();
        for (const item of pending.slice()) {
          if (pacedIsTimedOut(item.sentAt, nowMs, TIMEOUT_MS)) {
            elog(item.id + ': paced timeout — 240s e kono tile ashe ni');
            await failAttempt(item, 'Timeout 240s — generation sesh hoyni');
          }
        }
      }

      if (!sendQueue.length && !retryQueue.length && !pending.length) break;
      await sleepOrStop(1500, epoch);
    }
  } catch (e) {
    if (e !== ABORT) throw e;
  }
  if (stopRequested) {
    let back = 0;
    if (inFlight && inFlight.status === 'active') { inFlight.status = 'pending'; inFlight.stage = ''; inFlight.sentAt = 0; back++; }
    for (const item of pending) { item.status = 'pending'; item.stage = ''; item.sentAt = 0; back++; }
    for (const item of retryQueue) { item.status = 'pending'; item.stage = ''; item.sentAt = 0; back++; }
    if (back) elog('Paced: stop — ' + back + ' ta item pending e ferot gelo (Resume e abar jabe)');
    saveNow();
  }
}

async function runLoop() {
  if (loopActive) return;
  await loadState();
  loopActive = true;
  const myGen = ++runGen;
  stopRequested = false;
  S.running = true;
  S.paused = false;
  if (!S.runStartedAt) S.runStartedAt = Date.now();
  if (!S.runFolder) S.runFolder = sanitizeProject(S.project);
  startHeartbeat();
  saveNow();

  let tab = null;
  try {
    tab = S.tabId ? await chrome.tabs.get(S.tabId).catch(() => null) : null;
    if (!tab || !tab.url || !FLOW_URL_RE.test(tab.url)) tab = await findFlowTab();
    if (!tab) { elog('ERROR: Flow tab paoa jay ni — run bondho'); return; }
    S.tabId = tab.id;
    elog('Run shuru — project: ' + S.project + ', mot ' + S.items.length + ' item, tab ' + tab.id + ' (' + (tab.url || '') + ')');
    if (S.settings && S.settings.refMode && S.settings.refMode !== 'none' && !S.settings.refReady) {
      elog('SABDHAN: reference mode "' + S.settings.refMode + '" select chilo kintu clipboard e image jay ni — run REF CHARA cholbe');
    }
    try {
      await dbgAttach(tab.id);
      elog('Debugger attach OK (tab ' + tab.id + ')');
    } catch (e) {
      elog('ERROR: Debugger attach FAIL (' + e.message + ') — Flow tab e DevTools khola thakle bondho kore abar try koro.');
      return;
    }

    // v2.0: reference lifecycle BEFORE any generation — upload first
    // and once, gated on full upload completion (user rules 1-2). A
    // failed gate aborts the run start; nothing is generated.
    try {
      const refOk = await ensureReference(tab.id);
      if (!refOk) { elog('Run bondho — reference ready korte parini (uporer karon dekho)'); return; }
    } catch (e) {
      if (e === ABORT) { elog('Run bondho — reference dhap e stop chaowa hoyeche'); return; }
      throw e;
    }

    if (S.settings && S.settings.runMode === 'paced') {
      await runPacedLoop(tab.id, myGen);
    } else for (let idx = 0; idx < S.items.length; idx++) {
      const item = S.items[idx];
      if (stopRequested) break;
      if (item.status === 'done') continue;
      if (item.status === 'failed') continue;
      if (item.status === 'generated') continue; // v2.2: image ready, awaiting the Download-Later pass
      if (await parkWhilePaused(tab.id)) { if (stopRequested) break; }
      if (myGen !== runGen) return; // v2.3: a newer run superseded this loop
      if (item.status !== 'pending' && item.status !== 'active') item.status = 'pending';
      item.status = 'active';
      item.stage = 'shuru hocche';
      item.failReason = '';
      saveNow();
      elog(item.id + ': kaj cholche (' + (idx + 1) + '/' + S.items.length + ')');
      try {
        await ensureAttached(tab.id); // v1.4: a fresh item never begins on a dead debugger session
        const outcome = await processItem(tab.id, item, myGen);
        if (myGen !== runGen) return; // v2.3: superseded while the item ran
        // v2.3: ONE advance point. Whichever terminal status the item
        // produced — "done" (downloaded now) or "generated" (Download
        // Later: the image exists in Flow and its file comes down in
        // the Download-generated pass) — it is applied right here and
        // the loop moves on to the next item. No outcome branch can
        // stall the advance.
        const term = terminalStatusFor(outcome);
        item.status = term;
        item.stage = term;
        item.failReason = '';
        if (term === 'generated') {
          elog(item.id + ': generated — image ready, download baki (Download Later)');
        } else {
          const note = (outcome && outcome.note) || '';
          item.note = note;
          elog(item.id + ': done' + (note ? ' (' + note + ')' : ''));
        }
      } catch (e) {
        if (myGen !== runGen) return; // v2.3: superseded — the new run owns the items now
        if (e === ABORT) {
          item.status = 'pending';
          item.stage = '';
          elog(item.id + ': stop er jonno item pending rakha holo');
          break;
        }
        item.status = 'failed';
        item.stage = 'failed';
        item.note = e.message || String(e);
        item.failReason = e.finalReason || e.message || String(e);
        elog(item.id + ': FAILED — ' + item.failReason);
        elog(item.id + ': ERROR screenshot neowa hocche');
        await screenshotError(tab.id, sanitizeProject(S.project), item.id);
      }
      saveNow();
      // No separate between-item pacing — the interval gap is
      // enforced at every send inside processItem (enforceSendGap).
    }
  } catch (e) {
    elog('ERROR: run theme gelo — ' + (e && e.message ? e.message : String(e)));
  } finally {
    const stoppedByUser = stopRequested;
    // v2.3: clear the run flags FIRST. In v2.2 this block awaited the
    // debugger detach before clearing loopActive — a cleanup call
    // that never settled left the flag on forever and silently
    // swallowed every later Start. A superseded loop (myGen stale)
    // skips cleanup entirely: the newer run owns the state now.
    if (myGen === runGen) {
      S.running = false;
      S.paused = false;
      pauseRequested = false;
      loopActive = false;
    }
    if (tab && myGen === runGen) await dbgDetach(tab.id);
    if (myGen === runGen) {
      const c = counts();
      const drained = c.pending === 0 && c.active === 0;
      // v2.2 retry-at-end: the queue drained with failures left → reset
      // them and run another round (max 3), unless the user stopped.
      const wantRound = drained && c.failed > 0 && !stopRequested &&
        !!(S.settings && S.settings.retryAtEnd) && (S.retryRoundsUsed || 0) < 3;
      // v2.3: a Download-Later run that drains naturally downloads its
      // generated items right away — in v2.2 they sat at "generated"
      // forever because the pass only ran from the panel button.
      const autoPass = drained && c.generated > 0 && !stopRequested && !wantRound;
      if (wantRound) {
        S.retryRoundsUsed = (S.retryRoundsUsed || 0) + 1;
        for (const it of S.items) {
          if (it.status === 'failed') { it.status = 'pending'; it.note = ''; it.failReason = ''; it.stage = ''; }
        }
        elog('seshe failed gula abar cholche (round ' + S.retryRoundsUsed + '/3) — ' + c.failed + ' item');
      } else if (drained) {
        S.runFinishedAt = Date.now();
        S.lastReport = buildReport();
        elog('Run sesh — Done ' + c.done + ' / ' + c.total + ', Failed ' + c.failed + (c.generated ? ', Generated (download baki) ' + c.generated : '') + '.');
        if (c.generated > 0 && !autoPass) {
          elog('Download Later: ' + c.generated + ' ta image generated ache — panel er "Download generated" button chap dile sob ekbare download hobe');
        }
        // v2.2: one finish notification per natural run finish.
        if (!stopRequested) {
          try {
            await chrome.notifications.create('sfa-finish-' + Date.now(), {
              type: 'basic',
              iconUrl: chrome.runtime.getURL('icons/icon128.png'),
              title: 'SHEIKH Flow Auto',
              message: 'Run finished — Done ' + c.done + ', Failed ' + c.failed
            });
          } catch (e) { /* notifications are best-effort */ }
        }
        await downloadReportFile();
      } else {
        elog('Run theme ache — Done ' + c.done + ', Pending ' + (c.pending + c.active) + ', Failed ' + c.failed + '. Resume kore baki kaj hobe.');
      }
      stopHeartbeat();
      await saveNow();
      if (stoppedByUser && !wantRound) elog('Engine stopped — notun Start er jonno ready');
      if (wantRound) runLoop();
      else if (autoPass) {
        elog('run sesh — generated gula ekhon download hocche');
        await downloadGeneratedPass().catch((e) => elog('Download generated auto-pass e badha: ' + (e && e.message ? e.message : String(e))));
      }
    }
  }
}

/* ---------------- v2.2 verify + match report ----------------
 * For every item, is its file actually on disk? Done items downloaded
 * directly are "<ID>.png"; menu downloads (2K/4K) carry dlName. */
async function verifyDownloads() {
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const map = {};
  for (const it of S.items) {
    let found = false;
    let filename = '';
    if (it.dlName) {
      const res = await chrome.downloads.search({ filenameRegex: esc(it.dlName) + '$' });
      const hit = (res || []).find((d) => d.state === 'complete' && (d.fileSize || d.totalBytes || 0) > 10000 && d.filename.replace(/\\/g, '/').endsWith('/' + it.dlName));
      if (hit) { found = true; filename = it.dlName; }
    }
    if (!found) {
      const res = await chrome.downloads.search({ filenameRegex: esc(it.id) + '\\.png$' });
      const hit = (res || []).find((d) => d.state === 'complete' && (d.fileSize || d.totalBytes || 0) > 10000 && d.filename.replace(/\\/g, '/').endsWith('/' + it.id + '.png'));
      if (hit) { found = true; filename = it.id + '.png'; }
    }
    map[it.id] = { found, filename };
  }
  return map;
}

/* ---------------- v2.2 Download-Later pass ----------------
 * Walks the "generated" items IN ORDER and downloads each through the
 * quality route (menu for 2K/4K via the tile, direct URL otherwise),
 * marking them done (or failed with the reason). Runs outside the
 * generation loop; S.dlPass mirrors activity into the saved state so
 * the panel can disable its button while a pass is going. */
let laterPassActive = false;
async function downloadGeneratedPass() {
  await loadState();
  if (laterPassActive || loopActive || retryOneActive) return { ok: false, error: 'Run ba download pass cholche — opekkha koro' };
  const gens = S.items.filter((i) => i.status === 'generated');
  if (!gens.length) return { ok: true, count: 0 };
  laterPassActive = true;
  S.dlPass = true;
  await saveNow();
  let tab = null;
  let doneN = 0;
  try {
    tab = S.tabId ? await chrome.tabs.get(S.tabId).catch(() => null) : null;
    if (!tab || !tab.url || !FLOW_URL_RE.test(tab.url)) tab = await findFlowTab();
    if (tab) {
      S.tabId = tab.id;
      await dbgAttach(tab.id).catch(() => {});
    }
    elog('Download generated shuru — ' + gens.length + ' ta image por por download hobe');
    for (const item of gens) {
      if (item.status !== 'generated') continue;
      try {
        let note = '';
        if (tab && item.tileMediaId) {
          note = await downloadFromTile(tab.id, item, { mediaId: item.tileMediaId });
        } else if (item.tileUrl && item.tileUrl.indexOf('blob:') !== 0) {
          const fname = targetPath(S.project, item.id);
          const size = await downloadAndVerify(upgradeUrl(item.tileUrl), fname);
          elog(item.id + ': download done (' + size + ' bytes)');
        } else if (tab) {
          note = await fallbackDownload(tab.id, item.tileMediaId ? { mediaId: item.tileMediaId } : null);
        } else {
          throw new Error('Flow tab o nai, tile URL o nai — download er upay nai');
        }
        item.status = 'done';
        item.stage = 'done';
        item.failReason = '';
        item.note = note || '';
        doneN++;
        elog(item.id + ': done (Download-Later pass)');
      } catch (e) {
        item.status = 'failed';
        item.stage = 'failed';
        item.note = e.message || String(e);
        item.failReason = e.finalReason || e.message || String(e);
        elog(item.id + ': Download-Later FAILED — ' + item.failReason);
      }
      await saveNow();
    }
    elog('Download generated sesh — ' + doneN + '/' + gens.length + ' done');
  } finally {
    if (tab) await dbgDetach(tab.id).catch(() => {});
    laterPassActive = false;
    S.dlPass = false;
    await saveNow();
  }
  return { ok: true, count: doneN };
}

/* ---------------- v2.4 single-item retry ----------------
 * Panel message {type:'retryOne', itemId} — regenerates ONE failed
 * item and nothing else. NUMBERING INTEGRITY (user's explicit spec):
 * the item keeps its own ID end to end; processItem/completeItem
 * download under targetPath(project, item.id) exactly like the run
 * loop, and no other item is read for writing, renumbered or
 * re-downloaded. Refused while the run loop (or a download pass, or
 * another single retry) is active. Download semantics follow the
 * CURRENT settings: autoDownload off → the item becomes "generated"
 * and its file comes down in the Download-Later pass. */
let retryOneActive = false;
async function retryOneItem(itemId) {
  await loadState();
  if (loopActive || laterPassActive || retryOneActive) {
    elog('Retry ' + itemId + ': neya holo na — run cholche, ses hole retry koro');
    return { ok: false, error: 'busy' };
  }
  const item = S.items.find((i) => i.id === itemId);
  if (!item) return { ok: false, error: 'Item paoa jay ni: ' + itemId };
  if (item.status !== 'failed') return { ok: false, error: 'Item failed obosthay nei: ' + itemId };
  retryOneActive = true;
  stopRequested = false;
  let tab = null;
  const prevReason = item.failReason;
  const prevNote = item.note;
  try {
    elog('Retry ' + item.id + ': shuru — sudhu ei item tai abar hobe, or number ei download hobe');
    tab = S.tabId ? await chrome.tabs.get(S.tabId).catch(() => null) : null;
    if (!tab || !tab.url || !FLOW_URL_RE.test(tab.url)) tab = await findFlowTab();
    if (!tab) {
      elog('Retry ' + item.id + ': FAILED — Flow tab paoa jay ni');
      return { ok: false, error: 'Flow tab paoa jay ni' };
    }
    S.tabId = tab.id;
    await dbgAttach(tab.id);
    // If this item needs the reference, make sure it is in the project
    // (same one-time lifecycle as a normal run start).
    const refOk = await ensureReference(tab.id);
    if (!refOk) {
      elog('Retry ' + item.id + ': FAILED — reference ready korte parini');
      return { ok: false, error: 'Reference ready na' };
    }
    // Fresh attempt for THIS item only; stale tile/dlName from the
    // failed attempt are cleared so the new download is recorded
    // under this item's own ID name.
    item.status = 'active';
    item.stage = 'retry hocche';
    item.failReason = '';
    item.tileMediaId = null;
    item.tileUrl = '';
    item.dlName = '';
    await saveNow();
    const outcome = await processItem(tab.id, item, runGen);
    const term = terminalStatusFor(outcome);
    item.status = term;
    item.stage = term;
    item.failReason = '';
    item.note = term === 'generated' ? '' : ((outcome && outcome.note) || '');
    elog('Retry ' + item.id + ': ' + (term === 'generated'
      ? 'generated — download pore hobe (Download Later)'
      : 'done — ' + item.id + ' name ei download hoyeche'));
    await saveNow();
    return { ok: true, status: term };
  } catch (e) {
    if (e === ABORT) {
      // Stopped/reset mid-retry: the item goes back to failed with
      // its original reason — nothing about it was half-changed.
      item.status = 'failed';
      item.stage = 'failed';
      item.failReason = prevReason;
      item.note = prevNote;
      elog('Retry ' + item.id + ': theme gelo (abort) — item failed ei roilo');
      await saveNow().catch(() => {});
      return { ok: false, error: 'Retry theme geche' };
    }
    item.status = 'failed';
    item.stage = 'failed';
    item.note = e.message || String(e);
    item.failReason = e.finalReason || e.message || String(e);
    elog('Retry ' + item.id + ': FAILED — ' + item.failReason);
    if (tab) await screenshotError(tab.id, sanitizeProject(S.project), item.id).catch(() => {});
    await saveNow().catch(() => {});
    return { ok: false, error: item.failReason };
  } finally {
    retryOneActive = false;
    if (tab) await dbgDetach(tab.id).catch(() => {});
    await saveNow().catch(() => {});
  }
}

/* ---------------- gap fill ---------------- */
async function skipDownloaded(items, project) {
  await loadState();
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  let marked = 0;
  const list = items && items.length ? items : S.items;
  for (const it of list) {
    if (it.status === 'done') continue;
    const res = await chrome.downloads.search({ filenameRegex: esc(it.id) + '\\.png$' });
    const hit = (res || []).find((d) => d.state === 'complete' && (d.fileSize || d.totalBytes || 0) > 10000 && d.filename.replace(/\\/g, '/').endsWith('/' + it.id + '.png'));
    if (hit) { it.status = 'done'; it.note = 'existing'; marked++; }
  }
  if (items && items.length) { S.items = items; if (project) S.project = project; }
  elog('Skip-downloaded check: ' + marked + ' item age thekei download ache bole done mark holo');
  saveNow();
  return marked;
}

/* ---------------- messages ---------------- */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    await loadState();
    try {
      switch (msg && msg.type) {
        case 'preflight': {
          const r = await runPreflight();
          sendResponse({ ok: true, result: r });
          break;
        }
        case 'start': {
          if (retryOneActive) {
            elog('Start neya holo na: ekta single-item retry cholche');
            sendResponse({ ok: false, error: 'Single retry cholche — ektu opekkha koro' });
            break;
          }
          if (loopActive && !shouldForceResetLoop(loopActive, S.engineHeartbeat, Date.now())) {
            // v2.3: a refusal is LOGGED, never silent — in v2.2 this
            // branch swallowed three Start presses without a trace in
            // the engine log.
            elog('Start neya holo na: run ekhono cholche (engine busy)');
            sendResponse({ ok: false, error: 'Run already cholche' });
            break;
          }
          if (loopActive) {
            elog('Start: ager run atke chilo — reset kore notun run shuru');
            forceResetRun();
          }
          elog('Run shuru hocche — start request neya holo');
          if (msg.items && msg.items.length) {
            S.items = msg.items.map((i) => ({ id: i.id, prompt: i.prompt, needsRef: !!i.needsRef, status: 'pending', attempts: 0, note: '', failReason: '', stage: '', tileMediaId: null, tileUrl: '', completedAt: 0, dlName: '' }));
          }
          if (msg.project !== undefined) S.project = sanitizeProject(msg.project);
          if (msg.settings) {
            const rm = msg.settings.refMode;
            const prevDl = S.settings || {};
            S.settings = Object.assign(DEFAULT_SETTINGS(), {
              autoDownload: prevDl.autoDownload, quality: prevDl.quality,
              datedFolder: prevDl.datedFolder, retryAtEnd: prevDl.retryAtEnd,
              intervalSec: prevDl.intervalSec, runMode: prevDl.runMode,
              refMode: (rm === 'marked' || rm === 'all' || rm === 'none') ? rm : 'marked',
              refReady: !!msg.settings.refReady
            });
            // v2.2: the panel also sends the Download-section values
            // with Start; they win over the stored ones.
            applyDownloadSettings(msg.settings);
            // Fresh start (items were sent): record the reference file
            // name and reset the v2 lifecycle — ensureReference will
            // re-discover the asset in this project or upload it once.
            // v2.2: also fix this run's download folder + retry rounds.
            if (msg.items && msg.items.length) {
              S.refFileName = msg.settings.refFileName || '';
              S.refMediaId = null;
              S.refAssetName = '';
              S.refPickerName = '';
              S.refStatus = '';
              S.pacedBase = null;
              S.retryRoundsUsed = 0;
              S.runFolder = S.settings.datedFolder
                ? datedFolderName(S.project, Date.now())
                : sanitizeProject(S.project);
            }
          }
          if (msg.tabId) S.tabId = msg.tabId;
          S.runStartedAt = Date.now();
          S.runFinishedAt = null;
          pauseRequested = false; stopRequested = false;
          await saveNow();
          runLoop();
          sendResponse({ ok: true });
          break;
        }
        case 'pause': {
          pauseRequested = true;
          elog('Engine: pause request pelam — cholti item sesh hole thamba');
          sendResponse({ ok: true });
          break;
        }
        case 'resume': {
          if (retryOneActive) { sendResponse({ ok: false, error: 'Single retry cholche — ektu opekkha koro' }); break; }
          if (loopActive && !shouldForceResetLoop(loopActive, S.engineHeartbeat, Date.now())) { pauseRequested = false; sendResponse({ ok: true }); break; }
          if (loopActive) {
            elog('Resume: ager run atke chilo — reset kore resume hocche');
            forceResetRun();
          }
          // loop not active (e.g. service worker restarted): restart from saved items
          elog('Engine: resume request pelam — saved state theke loop abar shuru hocche');
          pauseRequested = false; stopRequested = false;
          for (const it of S.items) if (it.status === 'active') { it.status = 'pending'; it.stage = ''; }
          await saveNow();
          runLoop();
          sendResponse({ ok: true });
          break;
        }
        case 'stop': {
          stopRequested = true;
          pauseRequested = false;
          bumpAbortEpoch(); // v2.3: wake every wait loop NOW, not at its next poll
          elog('Engine: stop request pelam');
          sendResponse({ ok: true });
          break;
        }
        case 'retryFailed': {
          if (loopActive || retryOneActive) { sendResponse({ ok: false, error: 'Run cholche — age stop koro' }); break; }
          let n = 0;
          for (const it of S.items) if (it.status === 'failed') { it.status = 'pending'; it.note = ''; it.failReason = ''; it.stage = ''; n++; }
          await saveNow();
          elog('Retry failed: ' + n + ' item abar pending kora holo');
          if (n > 0) { stopRequested = false; pauseRequested = false; runLoop(); }
          sendResponse({ ok: true, count: n });
          break;
        }
        case 'skipDownloaded': {
          const marked = await skipDownloaded(msg.items || null, msg.project);
          sendResponse({ ok: true, marked });
          break;
        }
        case 'getState': {
          sendResponse({ ok: true, state: S, loopActive });
          break;
        }
        case 'clearState': {
          if (loopActive) { sendResponse({ ok: false, error: 'Run cholche' }); break; }
          S = DEFAULT_STATE();
          await saveNow();
          sendResponse({ ok: true });
          break;
        }
        case 'buildReport': {
          S.lastReport = buildReport();
          await saveNow();
          sendResponse({ ok: true, report: S.lastReport });
          break;
        }
        case 'settings': {
          // v2.2: live Download-section settings from the panel.
          const before = JSON.stringify([S.settings.autoDownload, S.settings.quality, S.settings.datedFolder, S.settings.retryAtEnd, S.settings.intervalSec, S.settings.runMode]);
          applyDownloadSettings(msg.settings || {});
          await saveNow();
          const after = JSON.stringify([S.settings.autoDownload, S.settings.quality, S.settings.datedFolder, S.settings.retryAtEnd, S.settings.intervalSec, S.settings.runMode]);
          if (before !== after) {
            elog('Settings bodleche — auto-download ' + (S.settings.autoDownload ? 'ON' : 'OFF (Download Later)') + ', quality ' + S.settings.quality + ', interval ' + S.settings.intervalSec + 's, dated folder ' + (S.settings.datedFolder ? 'ON' : 'OFF') + ', retry-at-end ' + (S.settings.retryAtEnd ? 'ON' : 'OFF') + ', run mode ' + S.settings.runMode);
          }
          sendResponse({ ok: true, settings: S.settings });
          break;
        }
        case 'thumbs': {
          // v2.2: session thumbnails for done/generated item rows.
          const out = {};
          for (const id of msg.ids || []) {
            if (thumbCache.has(id)) out[id] = thumbCache.get(id);
          }
          sendResponse({ ok: true, thumbs: out });
          break;
        }
        case 'verify': {
          const map = await verifyDownloads();
          sendResponse({ ok: true, verify: map });
          break;
        }
        case 'matchReport': {
          const map = await verifyDownloads();
          sendResponse({ ok: true, report: buildMatchReport(S.items, map) });
          break;
        }
        case 'downloadGenerated': {
          const r = await downloadGeneratedPass();
          sendResponse(r);
          break;
        }
        case 'retryOne': {
          // v2.4: single-item retry (panel Items tab). All the logic
          // (busy refusal, numbering integrity) lives in retryOneItem.
          const r = await retryOneItem(String((msg && msg.itemId) || ''));
          sendResponse(r);
          break;
        }
        default:
          sendResponse({ ok: false, error: 'Unknown message type' });
      }
    } catch (e) {
      sendResponse({ ok: false, error: e && e.message ? e.message : String(e) });
    }
  })();
  return true; // async response
});

chrome.runtime.onStartup.addListener(() => { loadState(); });
loadState();
