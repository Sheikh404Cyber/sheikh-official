"use strict";

const ALLOWED_HOST = /(^|\.)elevenreader\.io$/i;

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id || !tab.url) return;

  let hostname = "";
  try {
    hostname = new URL(tab.url).hostname;
  } catch {
    return;
  }

  if (!ALLOWED_HOST.test(hostname)) {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        alert("ElevenRec শুধু elevenreader.io তে কাজ করবে।");
      }
    });
    return;
  }

  try {
    const result = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: () => {
        if (window.ElevenRec && typeof window.ElevenRec.togglePanel === "function") {
          window.ElevenRec.togglePanel();
          return true;
        }
        return false;
      }
    });

    const alreadyLoaded = Boolean(result?.[0]?.result);

    if (!alreadyLoaded) {
      await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: ["inject.js"],
        world: "MAIN"
      });
    }

    // Badge update
    await chrome.action.setBadgeText({ text: "ON", tabId: tab.id });
    await chrome.action.setBadgeBackgroundColor({ color: "#00C853", tabId: tab.id });

  } catch (err) {
    console.error("[ElevenRec] Injection error:", err);
    await chrome.action.setBadgeText({ text: "ERR", tabId: tab.id });
    await chrome.action.setBadgeBackgroundColor({ color: "#FF1744", tabId: tab.id });
  }
});

// Badge clear on navigation
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status === "complete") {
    const isTarget = ALLOWED_HOST.test((() => {
      try { return new URL(tab.url || "").hostname; } catch { return ""; }
    })());
    if (!isTarget) {
      chrome.action.setBadgeText({ text: "", tabId });
    }
  }
});
