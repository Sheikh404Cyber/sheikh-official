/*
 * SHEIKH Flow Auto — side panel logic (v2.6).
 * The panel loads/imports prompts and renders state; the background
 * owns the run and the saved state (chrome.storage.local "sfa_state").
 * Panel polls getState every 1s.
 *
 * i18n: STRINGS below is the single source for every panel UI string.
 * English is the source of truth; the completeness test
 * (tests/test-v22.js) fails if any language misses a key. The engine's
 * background log lines are diagnostics and are NOT translated.
 */
'use strict';

/* eslint-disable */
const STRINGS = {
en: {
  done: "Done", failed: "Failed", pending: "Pending", generated: "Generated",
  project: "Project", timeLeft: "Time left", nowGenerating: "Now generating",
  setup: "Setup",
  fileLabel: "Storyboard (.md) or prompt list (.txt) file:",
  pasteLabel: "Or paste prompts here (one prompt per line):",
  pastePlaceholder: "Paste prompts here, one per line...",
  loadPasted: "Load pasted prompts",
  projectLabel: "Project name (download folder):",
  projectPlaceholder: "e.g. BanksVideo",
  startNumberLabel: "Start number (text / paste only):",
  reference: "Reference image",
  refFileLabel: "Reference image (optional):",
  refModeLabel: "Use reference on:",
  refModeMarked: "Only prompts marked for reference (storyboard)",
  refModeAll: "Every prompt",
  refModeNone: "No reference",
  refStChecking: "Checking…", refStUploading: "Uploading…", refStReady: "Ready in the project", refStFailed: "Failed", refStNone: "—",
  refConfirmText: "Reference is set in the project ({n} need it)",
  refConvertFail: "Reference image could not be read: {msg}",
  download: "Download",
  autoDownload: "Auto download",
  qualityLabel: "Image quality:",
  datedFolder: "New dated folder for every run",
  retryAtEnd: "Retry failed at the end (3 rounds)",
  intervalLabel: "Seconds between generations:",
  runModeLabel: "Run mode:",
  runModeSerial: "One by one",
  runModePaced: "Paced",
  matchModeLabel: "Match mode:",
  matchModePrompt: "Prompt check",
  matchModeFast: "Fast order",
  intervalHint: "Minimum gap between sends.",
  generation: "Generation", genTypeLabel: "Type:", genTypeImage: "Image", genTypeVideo: "Video",
  genModelLabel: "Model:", genRatioLabel: "Aspect ratio:", genCountLabel: "Images per prompt:",
  pfVideoOk: "✓ Video mode looks selected", pfImageBad: "✗ IMAGE mode — you picked Video. Select Video in Flow.",
  downloadGenerated: "Download generated",
  generatedReady: "{n} image(s) generated — not downloaded yet.",
  flowCheck: "Flow tab check", checkBtn: "Check Flow Tab", checkingNow: "Checking...",
  checkFail: "Check failed: {msg}",
  pfFlowOk: "✓ Flow project page is open",
  pfFlowBad: "✗ No Flow page found — {reason}",
  pfInputOk: "✓ Prompt input found ({how})",
  pfInputBad: "✗ Prompt input not found",
  pfSendOk: "✓ Generate/Send button found ({how})",
  pfSendBad: "✗ Generate button not found",
  pfPlusOk: "✓ Reference add (+) button found",
  pfPlusWarn: "! + button not found — the picker cannot open",
  pfAgentBad: "✗ Agent mode is ON — turn it off",
  pfAgentOk: "✓ Agent mode is off",
  pfVideoBad: "✗ VIDEO mode — run blocked. Select Image in Flow.",
  pfImageOk: "✓ Image mode looks selected",
  pfModeUnknown: "? Mode is not certain — please make sure Image mode is selected",
  pfDurationWarn: "! Duration selector visible — a video-mode sign",
  pfSharedRefWarn: "! {n} prompt(s) need a reference — tick the box or pick an image",
  run: "Run", start: "Start", pause: "Pause", resume: "Resume", stop: "Stop",
  retryFailed: "Retry failed only", skipDownloaded: "Skip already downloaded", clearRun: "Clear saved run",
  detachCanceled: "Last detach: Cancel was pressed — never press it during a run",
  detachReason: "Last detach reason: {r}",
  bannerResume: "A previous run is half done — Resume continues the rest.",
  bannerStale: "Engine looks stopped — Resume restarts the saved run",
  tabItems: "Items", tabLog: "Log", tabReport: "Report",
  stPending: "pending", stActive: "active", stDone: "done", stFailed: "failed", stGenerated: "generated",
  matchTitle: "QuickVid match report",
  matchIdle: "Press \"Check downloads\" to verify the files on disk.",
  checkDownloads: "Check downloads", copyMissing: "Copy missing list", downloadReport: "Download report",
  copied: "Copied!", copyFail: "Copy failed",
  rExpected: "Expected files", rVerified: "Downloaded & verified", rMissing: "Missing",
  rFailed: "Failed", rGenerated: "Generated (not downloaded)", rFlowNamed: "Saved with Flow names", rNone: "None",
  reportEmpty: "No run yet — finish a run first.",
  help: "Help",
  noPrompts: "No prompts loaded yet.",
  loadedInfo: "{n} prompt(s) loaded ({kind})",
  kindStoryboard: "storyboard", kindTxt: "text list",
  refNeededInfo: " — {n} need a character reference",
  logLoadedLine: "{n} prompt(s) loaded. First: {first}, last: {last}",
  logParseWarn: "Parse warning: {w}",
  logNoPromptsFound: "WARNING: no prompts found — check the file / format",
  logFileReadFail: "Could not read the file",
  logRefSelected: "Reference image selected: {name}",
  logClipboardOk: "Reference copied — uploads once at Start",
  logClipboardFail: "WARNING: clipboard write failed ({msg}) — run goes without a reference",
  logLoadFirst: "Load prompts first",
  logBlockedVideo: "START BLOCKED: Flow is in VIDEO mode — pick Image and Check again",
  logBlockedRef: "START BLOCKED: {n} prompt(s) need a reference — tick the box or pick an image",
  logStartSent: "Run start sent — project: {project}, ref mode: {mode}",
  logStartSentRef: " (clipboard ref: {state})",
  refStateReady: "ready", refStateFail: "FAILED — will run without ref",
  logStartFail: "Start failed: {msg}",
  logResumeFail: "Resume failed: {msg}",
  logStopReq: "Stop requested",
  logRetryFail: "Retry failed: {msg}",
  logRetryCount: "Failed items will be retried: {n} item(s)",
  logSkipFail: "Skip check failed: {msg}",
  logSkipMarked: "Skip-downloaded: {n} item(s) marked done",
  logClearDone: "Saved run cleared",
  logClearFail: "Clear failed: {msg}",
  logReportEmpty: "No report yet — run something first",
  logDlDone: "Download generated finished: {n} image(s)",
  logDlFail: "Download generated failed: {msg}",
  logVerifying: "Checking downloads…",
  logVerifyFail: "Check failed: {msg}",
  checkAllGood: "All good",
  checkShortFlow: "Flow page", checkShortInput: "No prompt input", checkShortSend: "No Generate button",
  checkShortPlus: "No + button", checkShortAgent: "Agent mode ON", checkShortMode: "Video mode",
  endsAt: "Ends ~",
  dropToImport: "Drop to import",
  chooseFile: "Choose file", noFileChosen: "No file chosen",
  retryOne: "Retry",
  toastRunDone: "Run finished — Done {done}, Failed {failed}",
  toastDlDone: "Download finished — {n} image(s)",
  toastRetryOk: "Retry {id}: done",
  toastRetryFail: "Retry {id}: failed — {msg}",
  toastRetryBusy: "A run is going — retry after it ends",
  toastImportOk: "{n} prompt(s) loaded",
  toastImportFail: "Could not import that file",
  toastCheckFail: "Flow Tab Check found a problem"
},
bn: {
  done: "হয়েছে", failed: "ব্যর্থ", pending: "বাকি", generated: "তৈরি",
  project: "প্রজেক্ট", timeLeft: "বাকি সময়", nowGenerating: "এখন তৈরি হচ্ছে",
  setup: "সেটআপ",
  fileLabel: "স্টোরিবোর্ড (.md) বা প্রম্পট লিস্ট (.txt) ফাইল:",
  pasteLabel: "অথবা এখানে প্রম্পট পেস্ট করো (এক লাইনে একটা):",
  pastePlaceholder: "এখানে প্রম্পট পেস্ট করো, এক লাইনে একটা...",
  loadPasted: "পেস্ট করা প্রম্পট লোড করো",
  projectLabel: "প্রজেক্টের নাম (ডাউনলোড ফোল্ডার):",
  projectPlaceholder: "যেমন BanksVideo",
  startNumberLabel: "শুরুর নম্বর (শুধু টেক্সট / পেস্ট):",
  reference: "রেফারেন্স ছবি",
  refFileLabel: "রেফারেন্স ছবি (ঐচ্ছিক):",
  refModeLabel: "রেফারেন্স ব্যবহার হবে:",
  refModeMarked: "শুধু যেসব প্রম্পটে রেফারেন্স চিহ্নিত (স্টোরিবোর্ড)",
  refModeAll: "সব প্রম্পটে",
  refModeNone: "রেফারেন্স লাগবে না",
  refStChecking: "দেখা হচ্ছে…", refStUploading: "আপলোড হচ্ছে…", refStReady: "প্রজেক্টে তৈরি আছে", refStFailed: "ব্যর্থ", refStNone: "—",
  refConfirmText: "রেফারেন্স প্রজেক্টে সেট করা আছে ({n}টা লাগবে)",
  refConvertFail: "রেফারেন্স ছবি পড়া যায়নি: {msg}",
  download: "ডাউনলোড",
  autoDownload: "অটো ডাউনলোড",
  qualityLabel: "ছবির মান:",
  datedFolder: "প্রতিটা রানের জন্য তারিখসহ নতুন ফোল্ডার",
  retryAtEnd: "শেষে ব্যর্থগুলো আবার চেষ্টা (৩ রাউন্ড)",
  intervalLabel: "দুই তৈরির মাঝে কত সেকেন্ড:",
  runModeLabel: "রান মোড:",
  runModeSerial: "একটা একটা করে",
  runModePaced: "ফাঁক দিয়ে",
  matchModeLabel: "ম্যাচ মোড:",
  matchModePrompt: "প্রম্পট যাচাই",
  matchModeFast: "দ্রুত ক্রম",
  intervalHint: "দুটি সেন্ডের মাঝে সর্বনিম্ন ফাঁক।",
  generation: "জেনারেশন", genTypeLabel: "ধরন:", genTypeImage: "ছবি", genTypeVideo: "ভিডিও",
  genModelLabel: "মডেল:", genRatioLabel: "অনুপাত:", genCountLabel: "প্রম্পট প্রতি ছবি:",
  pfVideoOk: "✓ VIDEO মোড বেছে নেওয়া মনে হচ্ছে", pfImageBad: "✗ IMAGE মোড — তুমি Video বেছেছ। Flow-তে Video বেছে নাও।",
  downloadGenerated: "তৈরি হওয়াগুলো ডাউনলোড করো",
  generatedReady: "{n}টা ছবি তৈরি — এখনো ডাউনলোড হয়নি।",
  flowCheck: "Flow ট্যাব যাচাই", checkBtn: "Flow ট্যাব দেখো", checkingNow: "দেখা হচ্ছে...",
  checkFail: "যাচাই ব্যর্থ: {msg}",
  pfFlowOk: "✓ Flow প্রজেক্ট পেজ খোলা আছে",
  pfFlowBad: "✗ Flow পেজ পাওয়া যায়নি — {reason}",
  pfInputOk: "✓ প্রম্পট ইনপুট পাওয়া গেছে ({how})",
  pfInputBad: "✗ প্রম্পট ইনপুট পাওয়া যায়নি",
  pfSendOk: "✓ Generate/Send বোতাম পাওয়া গেছে ({how})",
  pfSendBad: "✗ Generate বোতাম পাওয়া যায়নি",
  pfPlusOk: "✓ রেফারেন্স যোগের (+) বোতাম আছে",
  pfPlusWarn: "! (+) বোতাম পাওয়া যায়নি — পিকার খুলবে না",
  pfAgentBad: "✗ Agent মোড চালু — বন্ধ করো",
  pfAgentOk: "✓ Agent মোড বন্ধ আছে",
  pfVideoBad: "✗ VIDEO মোড — রান বন্ধ। Flow-তে Image বেছে নাও।",
  pfImageOk: "✓ Image মোড বেছে নেওয়া মনে হচ্ছে",
  pfModeUnknown: "? মোড নিশ্চিত হওয়া যায়নি — Image মোড আছে কিনা দেখে নাও",
  pfDurationWarn: "! সময় বেছে নেওয়ার অপশন দেখা যাচ্ছে — ভিডিও মোডের লক্ষণ",
  pfSharedRefWarn: "! {n}টা প্রম্পটে রেফারেন্স লাগবে — বাক্সে টিক দাও বা ছবি বেছে নাও",
  run: "রান", start: "শুরু", pause: "থামাও", resume: "আবার শুরু", stop: "বন্ধ",
  retryFailed: "শুধু ব্যর্থগুলো আবার", skipDownloaded: "ডাউনলোড হওয়াগুলো বাদ দাও", clearRun: "সেভ করা রান মুছো",
  detachCanceled: "শেষ বিচ্ছিন্ন: Cancel চাপা হয়েছিল — রান চলার সময় চাপবে না",
  detachReason: "শেষ বিচ্ছিন্নের কারণ: {r}",
  bannerResume: "আগের রান অর্ধেক বাকি আছে — Resume দিলে বাকিগুলো হবে।",
  bannerStale: "ইঞ্জিন থেমে গেছে মনে হচ্ছে — Resume সেভ করা রান আবার শুরু করবে",
  tabItems: "আইটেম", tabLog: "লগ", tabReport: "রিপোর্ট",
  stPending: "বাকি", stActive: "চলছে", stDone: "হয়েছে", stFailed: "ব্যর্থ", stGenerated: "তৈরি",
  matchTitle: "QuickVid মিল রিপোর্ট",
  matchIdle: "ডিস্কের ফাইল যাচাই করতে \"ডাউনলোড যাচাই\" চাপ দাও।",
  checkDownloads: "ডাউনলোড যাচাই", copyMissing: "বাদ পড়া তালিকা কপি", downloadReport: "রিপোর্ট ডাউনলোড",
  copied: "কপি হয়েছে!", copyFail: "কপি ব্যর্থ",
  rExpected: "থাকার কথা এমন ফাইল", rVerified: "ডাউনলোড ও যাচাই হয়েছে", rMissing: "বাদ পড়েছে",
  rFailed: "ব্যর্থ", rGenerated: "তৈরি (ডাউনলোড হয়নি)", rFlowNamed: "Flow-এর নামে সেভ হয়েছে", rNone: "নেই",
  reportEmpty: "এখনো কোনো রান হয়নি — আগে একটা রান শেষ করো।",
  help: "সাহায্য",
  noPrompts: "এখনো কোনো প্রম্পট লোড হয়নি।",
  loadedInfo: "{n}টা প্রম্পট লোড হয়েছে ({kind})",
  kindStoryboard: "স্টোরিবোর্ড", kindTxt: "টেক্সট লিস্ট",
  refNeededInfo: " — {n}টায় চরিত্রের রেফারেন্স লাগবে",
  logLoadedLine: "{n}টা প্রম্পট লোড হয়েছে। প্রথম: {first}, শেষ: {last}",
  logParseWarn: "পার্স সতর্কতা: {w}",
  logNoPromptsFound: "সাবধান: কোনো প্রম্পট পাওয়া যায়নি — ফাইল / ফরম্যাট দেখো",
  logFileReadFail: "ফাইল পড়া যায়নি",
  logRefSelected: "রেফারেন্স ছবি বেছে নেওয়া হয়েছে: {name}",
  logClipboardOk: "রেফারেন্স কপি হয়েছে — Start-এ একবার আপলোড হবে",
  logClipboardFail: "সাবধান: ক্লিপবোর্ডে লেখা যায়নি ({msg}) — রান রেফারেন্স ছাড়াই চলবে",
  logLoadFirst: "আগে প্রম্পট লোড করো",
  logBlockedVideo: "শুরু বন্ধ: Flow-তে VIDEO মোড — Image বেছে আবার যাচাই করো",
  logBlockedRef: "শুরু বন্ধ: {n}টা প্রম্পটে রেফারেন্স লাগবে — বাক্সে টিক দাও বা ছবি বেছে নাও",
  logStartSent: "রান শুরু পাঠানো হয়েছে — প্রজেক্ট: {project}, রেফ মোড: {mode}",
  logStartSentRef: " (ক্লিপবোর্ড রেফ: {state})",
  refStateReady: "তৈরি", refStateFail: "ব্যর্থ — রেফ ছাড়া চলবে",
  logStartFail: "শুরু ব্যর্থ: {msg}",
  logResumeFail: "Resume ব্যর্থ: {msg}",
  logStopReq: "বন্ধ চাওয়া হয়েছে",
  logRetryFail: "আবার চেষ্টা ব্যর্থ: {msg}",
  logRetryCount: "ব্যর্থ আইটেম আবার চেষ্টা হবে: {n}টা",
  logSkipFail: "বাদ-দেওয়া যাচাই ব্যর্থ: {msg}",
  logSkipMarked: "বাদ-দেওয়া: {n}টা আইটেম হয়েছে বলে চিহ্নিত হলো",
  logClearDone: "সেভ করা রান মোছা হলো",
  logClearFail: "মোছা ব্যর্থ: {msg}",
  logReportEmpty: "এখনো রিপোর্ট নেই — আগে কিছু চালাও",
  logDlDone: "তৈরি হওয়া ডাউনলোড শেষ: {n}টা ছবি",
  logDlFail: "তৈরি হওয়া ডাউনলোড ব্যর্থ: {msg}",
  logVerifying: "ডাউনলোড যাচাই হচ্ছে…",
  logVerifyFail: "যাচাই ব্যর্থ: {msg}",
  checkAllGood: "সব ঠিক আছে",
  checkShortFlow: "Flow পেজ", checkShortInput: "প্রম্পট ইনপুট নেই", checkShortSend: "Generate বোতাম নেই",
  checkShortPlus: "+ বোতাম নেই", checkShortAgent: "Agent মোড চালু", checkShortMode: "Video মোড",
  endsAt: "শেষ হবে ~",
  dropToImport: "আনতে এখানে ছাড়ো",
  chooseFile: "ফাইল বাছো", noFileChosen: "কোনো ফাইল বাছা হয়নি",
  retryOne: "আবার",
  toastRunDone: "রান শেষ — হয়েছে {done}, ব্যর্থ {failed}",
  toastDlDone: "ডাউনলোড শেষ — {n}টা ছবি",
  toastRetryOk: "আবার {id}: হয়েছে",
  toastRetryFail: "আবার {id}: ব্যর্থ — {msg}",
  toastRetryBusy: "রান চলছে — শেষ হলে আবার চেষ্টা করো",
  toastImportOk: "{n}টা প্রম্পট লোড হয়েছে",
  toastImportFail: "ফাইলটা আনা যায়নি",
  toastCheckFail: "Flow ট্যাব যাচাইয়ে সমস্যা পাওয়া গেছে"
},
hi: {
  done: "हो गया", failed: "विफल", pending: "बाकी", generated: "बन गया",
  project: "प्रोजेक्ट", timeLeft: "बचा समय", nowGenerating: "अभी बन रहा है",
  setup: "सेटअप",
  fileLabel: "स्टोरीबोर्ड (.md) या प्रॉम्प्ट सूची (.txt) फ़ाइल:",
  pasteLabel: "या यहाँ प्रॉम्प्ट चिपकाएँ (एक लाइन में एक):",
  pastePlaceholder: "यहाँ प्रॉम्प्ट चिपकाएँ, एक लाइन में एक...",
  loadPasted: "चिपकाए प्रॉम्प्ट लोड करें",
  projectLabel: "प्रोजेक्ट का नाम (डाउनलोड फ़ोल्डर):",
  projectPlaceholder: "जैसे BanksVideo",
  startNumberLabel: "शुरुआती नंबर (सिर्फ़ टेक्स्ट / पेस्ट):",
  reference: "संदर्भ छवि",
  refFileLabel: "संदर्भ छवि (वैकल्पिक):",
  refModeLabel: "संदर्भ इन पर लगे:",
  refModeMarked: "सिर्फ़ चिह्नित प्रॉम्प्ट पर (स्टोरीबोर्ड)",
  refModeAll: "हर प्रॉम्प्ट पर",
  refModeNone: "कोई संदर्भ नहीं",
  refStChecking: "जाँच हो रही है…", refStUploading: "अपलोड हो रहा है…", refStReady: "प्रोजेक्ट में तैयार", refStFailed: "विफल", refStNone: "—",
  refConfirmText: "संदर्भ प्रोजेक्ट में सेट है ({n} को चाहिए)",
  refConvertFail: "संदर्भ छवि पढ़ी नहीं गई: {msg}",
  download: "डाउनलोड",
  autoDownload: "ऑटो डाउनलोड",
  qualityLabel: "छवि गुणवत्ता:",
  datedFolder: "हर रन के लिए तारीख़ वाला नया फ़ोल्डर",
  retryAtEnd: "अंत में विफल फिर से प्रयास (3 राउंड)",
  intervalLabel: "दो निर्माणों के बीच सेकंड:",
  runModeLabel: "रन मोड:",
  runModeSerial: "एक-एक करके",
  runModePaced: "अंतराल से",
  matchModeLabel: "मैच मोड:",
  matchModePrompt: "प्रॉम्प्ट जांच",
  matchModeFast: "तेज़ क्रम",
  intervalHint: "दो सेंड के बीच न्यूनतम अंतर।",
  generation: "जनरेशन", genTypeLabel: "प्रकार:", genTypeImage: "छवि", genTypeVideo: "वीडियो",
  genModelLabel: "मॉडल:", genRatioLabel: "आस्पेक्ट रेशियो:", genCountLabel: "प्रति प्रॉम्प्ट छवियाँ:",
  pfVideoOk: "✓ VIDEO मोड चुना लगता है", pfImageBad: "✗ IMAGE मोड — आपने Video चुना था। Flow में Video चुनें।",
  downloadGenerated: "बनी हुई डाउनलोड करें",
  generatedReady: "{n} छवि(याँ) बन गईं — अभी डाउनलोड नहीं हुईं।",
  flowCheck: "Flow टैब जाँच", checkBtn: "Flow टैब जाँचें", checkingNow: "जाँच हो रही है...",
  checkFail: "जाँच विफल: {msg}",
  pfFlowOk: "✓ Flow प्रोजेक्ट पेज खुला है",
  pfFlowBad: "✗ Flow पेज नहीं मिला — {reason}",
  pfInputOk: "✓ प्रॉम्प्ट इनपुट मिला ({how})",
  pfInputBad: "✗ प्रॉम्प्ट इनपुट नहीं मिला",
  pfSendOk: "✓ Generate/Send बटन मिला ({how})",
  pfSendBad: "✗ Generate बटन नहीं मिला",
  pfPlusOk: "✓ संदर्भ जोड़ने का (+) बटन मिला",
  pfPlusWarn: "! (+) बटन नहीं मिला — पिकर नहीं खुलेगा",
  pfAgentBad: "✗ Agent मोड चालू है — बंद करें",
  pfAgentOk: "✓ Agent मोड बंद है",
  pfVideoBad: "✗ VIDEO मोड — रन रोका। Flow में Image चुनें।",
  pfImageOk: "✓ Image मोड चुना हुआ लगता है",
  pfModeUnknown: "? मोड निश्चित नहीं — कृपया Image मोड चुना हो यह सुनिश्चित करें",
  pfDurationWarn: "! अवधि चुनने वाला दिख रहा है — वीडियो मोड का संकेत",
  pfSharedRefWarn: "! {n} प्रॉम्प्ट को संदर्भ चाहिए — बॉक्स टिक करें या छवि चुनें",
  run: "रन", start: "शुरू", pause: "रोकें", resume: "फिर शुरू", stop: "बंद",
  retryFailed: "सिर्फ़ विफल फिर से", skipDownloaded: "डाउनलोड हुए छोड़ें", clearRun: "सहेजा रन मिटाएँ",
  detachCanceled: "आख़िरी अलगाव: Cancel दबा था — रन के दौरान कभी न दबाएँ",
  detachReason: "आख़िरी अलगाव का कारण: {r}",
  bannerResume: "पिछला रन आधा बाकी है — Resume बाकी पूरा करेगा।",
  bannerStale: "इंजन रुका लगता है — Resume सहेजा रन फिर शुरू करेगा",
  tabItems: "आइटम", tabLog: "लॉग", tabReport: "रिपोर्ट",
  stPending: "बाकी", stActive: "चल रहा", stDone: "हो गया", stFailed: "विफल", stGenerated: "बन गया",
  matchTitle: "QuickVid मिलान रिपोर्ट",
  matchIdle: "डिस्क की फ़ाइलें जाँचने के लिए \"डाउनलोड जाँचें\" दबाएँ।",
  checkDownloads: "डाउनलोड जाँचें", copyMissing: "छूटी सूची कॉपी करें", downloadReport: "रिपोर्ट डाउनलोड",
  copied: "कॉपी हुआ!", copyFail: "कॉपी विफल",
  rExpected: "होनी चाहिए फ़ाइलें", rVerified: "डाउनलोड और जाँच हुईं", rMissing: "छूटी हुईं",
  rFailed: "विफल", rGenerated: "बनी हुईं (डाउनलोड नहीं)", rFlowNamed: "Flow के नाम से सहेजीं", rNone: "कोई नहीं",
  reportEmpty: "अभी कोई रन नहीं — पहले एक रन खत्म करें।",
  help: "मदद",
  noPrompts: "अभी कोई प्रॉम्प्ट लोड नहीं हुआ।",
  loadedInfo: "{n} प्रॉम्प्ट लोड हुए ({kind})",
  kindStoryboard: "स्टोरीबोर्ड", kindTxt: "टेक्स्ट सूची",
  refNeededInfo: " — {n} को किरदार संदर्भ चाहिए",
  logLoadedLine: "{n} प्रॉम्प्ट लोड हुए। पहला: {first}, आख़िरी: {last}",
  logParseWarn: "पार्स चेतावनी: {w}",
  logNoPromptsFound: "चेतावनी: कोई प्रॉम्प्ट नहीं मिला — फ़ाइल / फ़ॉर्मैट देखें",
  logFileReadFail: "फ़ाइल पढ़ी नहीं गई",
  logRefSelected: "संदर्भ छवि चुनी गई: {name}",
  logClipboardOk: "संदर्भ कॉपी हुआ — Start पर एक बार अपलोड होगा",
  logClipboardFail: "चेतावनी: क्लिपबोर्ड लिखा नहीं गया ({msg}) — रन बिना संदर्भ चलेगा",
  logLoadFirst: "पहले प्रॉम्प्ट लोड करें",
  logBlockedVideo: "शुरू रोका: Flow VIDEO मोड में है — Image चुनकर फिर जाँचें",
  logBlockedRef: "शुरू रोका: {n} प्रॉम्प्ट को संदर्भ चाहिए — बॉक्स टिक करें या छवि चुनें",
  logStartSent: "रन शुरू भेजा गया — प्रोजेक्ट: {project}, रेफ़ मोड: {mode}",
  logStartSentRef: " (क्लिपबोर्ड रेफ़: {state})",
  refStateReady: "तैयार", refStateFail: "विफल — बिना रेफ़ चलेगा",
  logStartFail: "शुरू विफल: {msg}",
  logResumeFail: "Resume विफल: {msg}",
  logStopReq: "बंद माँगा गया",
  logRetryFail: "फिर प्रयास विफल: {msg}",
  logRetryCount: "विफल आइटम फिर से चलेंगे: {n} आइटम",
  logSkipFail: "छोड़ने की जाँच विफल: {msg}",
  logSkipMarked: "छोड़ना: {n} आइटम हो गए चिह्नित हुए",
  logClearDone: "सहेजा रन मिट गया",
  logClearFail: "मिटाना विफल: {msg}",
  logReportEmpty: "अभी रिपोर्ट नहीं — पहले कुछ चलाएँ",
  logDlDone: "बनी हुई डाउनलोड खत्म: {n} छवि(याँ)",
  logDlFail: "बनी हुई डाउनलोड विफल: {msg}",
  logVerifying: "डाउनलोड जाँच हो रही है…",
  logVerifyFail: "जाँच विफल: {msg}",
  checkAllGood: "सब ठीक है",
  checkShortFlow: "Flow पेज", checkShortInput: "प्रॉम्प्ट इनपुट नहीं", checkShortSend: "Generate बटन नहीं",
  checkShortPlus: "+ बटन नहीं", checkShortAgent: "Agent मोड चालू", checkShortMode: "वीडियो मोड",
  endsAt: "खत्म ~",
  dropToImport: "इंपोर्ट करने के लिए छोड़ें",
  chooseFile: "फ़ाइल चुनें", noFileChosen: "कोई फ़ाइल नहीं चुनी",
  retryOne: "फिर से",
  toastRunDone: "रन खत्म — हो गया {done}, विफल {failed}",
  toastDlDone: "डाउनलोड खत्म — {n} छवि(याँ)",
  toastRetryOk: "फिर से {id}: हो गया",
  toastRetryFail: "फिर से {id}: विफल — {msg}",
  toastRetryBusy: "रन चल रहा है — खत्म होने पर फिर प्रयास करें",
  toastImportOk: "{n} प्रॉम्प्ट लोड हुए",
  toastImportFail: "वह फ़ाइल इंपोर्ट नहीं हुई",
  toastCheckFail: "Flow टैब जाँच में समस्या मिली"
},
tr: {
  done: "Bitti", failed: "Başarısız", pending: "Bekliyor", generated: "Üretildi",
  project: "Proje", timeLeft: "Kalan süre", nowGenerating: "Şimdi üretiliyor",
  setup: "Kurulum",
  fileLabel: "Storyboard (.md) veya komut listesi (.txt) dosyası:",
  pasteLabel: "Ya da komutları buraya yapıştır (her satıra bir tane):",
  pastePlaceholder: "Komutları buraya yapıştır, her satıra bir tane...",
  loadPasted: "Yapıştırılanları yükle",
  projectLabel: "Proje adı (indirme klasörü):",
  projectPlaceholder: "örn. BanksVideo",
  startNumberLabel: "Başlangıç numarası (sadece metin / yapıştır):",
  reference: "Referans görsel",
  refFileLabel: "Referans görsel (isteğe bağlı):",
  refModeLabel: "Referans şunlarda kullanılsın:",
  refModeMarked: "Sadece referans işaretli komutlarda (storyboard)",
  refModeAll: "Her komutta",
  refModeNone: "Referans yok",
  refStChecking: "Kontrol ediliyor…", refStUploading: "Yükleniyor…", refStReady: "Projede hazır", refStFailed: "Başarısız", refStNone: "—",
  refConfirmText: "Referans projede ayarlı ({n} komut istiyor)",
  refConvertFail: "Referans görsel okunamadı: {msg}",
  download: "İndirme",
  autoDownload: "Otomatik indir",
  qualityLabel: "Görsel kalitesi:",
  datedFolder: "Her çalışma için tarihli yeni klasör",
  retryAtEnd: "Başarısızları sonda tekrar dene (3 tur)",
  intervalLabel: "Üretimler arası saniye:",
  runModeLabel: "Çalışma modu:",
  runModeSerial: "Tek tek",
  runModePaced: "Aralıklı",
  matchModeLabel: "Eşleştirme modu:",
  matchModePrompt: "İstem denetimi",
  matchModeFast: "Hızlı sıra",
  intervalHint: "Gönderimler arası en küçük boşluk.",
  generation: "Üretim", genTypeLabel: "Tür:", genTypeImage: "Görüntü", genTypeVideo: "Video",
  genModelLabel: "Model:", genRatioLabel: "En-boy oranı:", genCountLabel: "Komut başına görüntü:",
  pfVideoOk: "✓ Video modu seçili görünüyor", pfImageBad: "✗ GÖRÜNTÜ modu — Video seçmiştin. Flow'da Video seç.",
  downloadGenerated: "Üretilenleri indir",
  generatedReady: "{n} görsel üretildi — henüz indirilmedi.",
  flowCheck: "Flow sekme kontrolü", checkBtn: "Flow Sekmesini Kontrol Et", checkingNow: "Kontrol ediliyor...",
  checkFail: "Kontrol başarısız: {msg}",
  pfFlowOk: "✓ Flow proje sayfası açık",
  pfFlowBad: "✗ Flow sayfası bulunamadı — {reason}",
  pfInputOk: "✓ Komut girişi bulundu ({how})",
  pfInputBad: "✗ Komut girişi bulunamadı",
  pfSendOk: "✓ Generate/Send düğmesi bulundu ({how})",
  pfSendBad: "✗ Generate düğmesi bulunamadı",
  pfPlusOk: "✓ Referans ekleme (+) düğmesi bulundu",
  pfPlusWarn: "! (+) düğmesi bulunamadı — seçici açılmaz",
  pfAgentBad: "✗ Agent modu AÇIK — kapat",
  pfAgentOk: "✓ Agent modu kapalı",
  pfVideoBad: "✗ VIDEO modu — çalışma engellendi. Flow'da Image seç.",
  pfImageOk: "✓ Image modu seçili görünüyor",
  pfModeUnknown: "? Mod kesin değil — Image modunun seçili olduğundan emin ol",
  pfDurationWarn: "! Süre seçici görünüyor — video modu işareti",
  pfSharedRefWarn: "! {n} komut referans istiyor — kutuyu işaretle ya da görsel seç",
  run: "Çalıştır", start: "Başlat", pause: "Duraklat", resume: "Sürdür", stop: "Durdur",
  retryFailed: "Sadece başarısızları dene", skipDownloaded: "İndirilenleri atla", clearRun: "Kayıtlı çalışmayı temizle",
  detachCanceled: "Son ayrılma: Cancel'a basıldı — çalışma sırasında asla basma",
  detachReason: "Son ayrılma nedeni: {r}",
  bannerResume: "Önceki çalışma yarım kaldı — Sürdür kalanını tamamlar.",
  bannerStale: "Motor durmuş görünüyor — Sürdür kayıtlı çalışmayı başlatır",
  tabItems: "Öğeler", tabLog: "Kayıt", tabReport: "Rapor",
  stPending: "bekliyor", stActive: "çalışıyor", stDone: "bitti", stFailed: "başarısız", stGenerated: "üretildi",
  matchTitle: "QuickVid eşleşme raporu",
  matchIdle: "Diskteki dosyaları doğrulamak için \"İndirmeleri kontrol et\"e bas.",
  checkDownloads: "İndirmeleri kontrol et", copyMissing: "Eksik listesini kopyala", downloadReport: "Raporu indir",
  copied: "Kopyalandı!", copyFail: "Kopyalama başarısız",
  rExpected: "Beklenen dosyalar", rVerified: "İndirildi ve doğrulandı", rMissing: "Eksik",
  rFailed: "Başarısız", rGenerated: "Üretildi (indirilmedi)", rFlowNamed: "Flow adlarıyla kaydedildi", rNone: "Yok",
  reportEmpty: "Henüz çalışma yok — önce bir çalışmayı bitir.",
  help: "Yardım",
  noPrompts: "Henüz komut yüklenmedi.",
  loadedInfo: "{n} komut yüklendi ({kind})",
  kindStoryboard: "storyboard", kindTxt: "metin listesi",
  refNeededInfo: " — {n} tanesinin karakter referansına ihtiyacı var",
  logLoadedLine: "{n} komut yüklendi. İlk: {first}, son: {last}",
  logParseWarn: "Ayrıştırma uyarısı: {w}",
  logNoPromptsFound: "UYARI: komut bulunamadı — dosya / biçimi kontrol et",
  logFileReadFail: "Dosya okunamadı",
  logRefSelected: "Referans görsel seçildi: {name}",
  logClipboardOk: "Referans kopyalandı — Başlat'ta bir kez yüklenir",
  logClipboardFail: "UYARI: panoya yazılamadı ({msg}) — çalışma referanssız gidecek",
  logLoadFirst: "Önce komutları yükle",
  logBlockedVideo: "BAŞLATMA ENGELLENDİ: Flow VIDEO modunda — Image seçip tekrar kontrol et",
  logBlockedRef: "BAŞLATMA ENGELLENDİ: {n} komut referans istiyor — kutuyu işaretle ya da görsel seç",
  logStartSent: "Çalışma başlatma gönderildi — proje: {project}, ref modu: {mode}",
  logStartSentRef: " (pano ref: {state})",
  refStateReady: "hazır", refStateFail: "BAŞARISIZ — ref olmadan gidecek",
  logStartFail: "Başlatma başarısız: {msg}",
  logResumeFail: "Sürdürme başarısız: {msg}",
  logStopReq: "Durdurma istendi",
  logRetryFail: "Tekrar deneme başarısız: {msg}",
  logRetryCount: "Başarısız öğeler tekrar denenecek: {n} öğe",
  logSkipFail: "Atlama kontrolü başarısız: {msg}",
  logSkipMarked: "Atlama: {n} öğe bitti işaretlendi",
  logClearDone: "Kayıtlı çalışma temizlendi",
  logClearFail: "Temizleme başarısız: {msg}",
  logReportEmpty: "Henüz rapor yok — önce bir şey çalıştır",
  logDlDone: "Üretilenlerin indirmesi bitti: {n} görsel",
  logDlFail: "Üretilenlerin indirmesi başarısız: {msg}",
  logVerifying: "İndirmeler kontrol ediliyor…",
  logVerifyFail: "Kontrol başarısız: {msg}",
  checkAllGood: "Her şey tamam",
  checkShortFlow: "Flow sayfası", checkShortInput: "Komut girişi yok", checkShortSend: "Generate düğmesi yok",
  checkShortPlus: "+ düğmesi yok", checkShortAgent: "Agent modu AÇIK", checkShortMode: "Video modu",
  endsAt: "Bitiş ~",
  dropToImport: "İçe aktarmak için bırak",
  chooseFile: "Dosya seç", noFileChosen: "Dosya seçilmedi",
  retryOne: "Tekrar",
  toastRunDone: "Çalışma bitti — Bitti {done}, Başarısız {failed}",
  toastDlDone: "İndirme bitti — {n} görsel",
  toastRetryOk: "Tekrar {id}: bitti",
  toastRetryFail: "Tekrar {id}: başarısız — {msg}",
  toastRetryBusy: "Bir çalışma sürüyor — bitince tekrar dene",
  toastImportOk: "{n} komut yüklendi",
  toastImportFail: "Bu dosya içe aktarılamadı",
  toastCheckFail: "Flow sekme kontrolü bir sorun buldu"
},
fr: {
  done: "Terminé", failed: "Échoué", pending: "En attente", generated: "Généré",
  project: "Projet", timeLeft: "Temps restant", nowGenerating: "Génération en cours",
  setup: "Configuration",
  fileLabel: "Fichier storyboard (.md) ou liste de prompts (.txt) :",
  pasteLabel: "Ou collez les prompts ici (un par ligne) :",
  pastePlaceholder: "Collez les prompts ici, un par ligne...",
  loadPasted: "Charger les prompts collés",
  projectLabel: "Nom du projet (dossier de téléchargement) :",
  projectPlaceholder: "ex. BanksVideo",
  startNumberLabel: "Numéro de départ (texte / coller uniquement) :",
  reference: "Image de référence",
  refFileLabel: "Image de référence (optionnel) :",
  refModeLabel: "Utiliser la référence sur :",
  refModeMarked: "Uniquement les prompts marqués (storyboard)",
  refModeAll: "Chaque prompt",
  refModeNone: "Aucune référence",
  refStChecking: "Vérification…", refStUploading: "Envoi…", refStReady: "Prête dans le projet", refStFailed: "Échoué", refStNone: "—",
  refConfirmText: "Référence définie dans le projet ({n} en ont besoin)",
  refConvertFail: "Image de référence illisible : {msg}",
  download: "Téléchargement",
  autoDownload: "Téléchargement auto",
  qualityLabel: "Qualité d'image :",
  datedFolder: "Nouveau dossier daté pour chaque exécution",
  retryAtEnd: "Réessayer les échecs à la fin (3 tours)",
  intervalLabel: "Secondes entre les générations :",
  runModeLabel: "Mode d'exécution :",
  runModeSerial: "Un par un",
  runModePaced: "Espacé",
  matchModeLabel: "Mode d'appariement :",
  matchModePrompt: "Vérif. du prompt",
  matchModeFast: "Ordre rapide",
  intervalHint: "Écart minimum entre les envois.",
  generation: "Génération", genTypeLabel: "Type :", genTypeImage: "Image", genTypeVideo: "Vidéo",
  genModelLabel: "Modèle :", genRatioLabel: "Format :", genCountLabel: "Images par prompt :",
  pfVideoOk: "✓ Mode vidéo sélectionné", pfImageBad: "✗ Mode IMAGE — tu as choisi Vidéo. Choisis Vidéo dans Flow.",
  downloadGenerated: "Télécharger les générées",
  generatedReady: "{n} image(s) générée(s) — pas encore téléchargée(s).",
  flowCheck: "Vérification de l'onglet Flow", checkBtn: "Vérifier l'onglet Flow", checkingNow: "Vérification...",
  checkFail: "Vérification échouée : {msg}",
  pfFlowOk: "✓ La page du projet Flow est ouverte",
  pfFlowBad: "✗ Aucune page Flow trouvée — {reason}",
  pfInputOk: "✓ Champ de prompt trouvé ({how})",
  pfInputBad: "✗ Champ de prompt introuvable",
  pfSendOk: "✓ Bouton Generate/Send trouvé ({how})",
  pfSendBad: "✗ Bouton Generate introuvable",
  pfPlusOk: "✓ Bouton d'ajout de référence (+) trouvé",
  pfPlusWarn: "! Bouton (+) introuvable — le sélecteur ne s'ouvrira pas",
  pfAgentBad: "✗ Mode Agent ACTIVÉ — désactive-le",
  pfAgentOk: "✓ Le mode Agent est désactivé",
  pfVideoBad: "✗ Mode VIDÉO — exécution bloquée. Choisis Image dans Flow.",
  pfImageOk: "✓ Le mode Image semble sélectionné",
  pfModeUnknown: "? Mode incertain — vérifie que le mode Image est bien sélectionné",
  pfDurationWarn: "! Sélecteur de durée visible — signe du mode vidéo",
  pfSharedRefWarn: "! {n} prompt(s) sans référence — coche la case ou choisis une image",
  run: "Exécution", start: "Démarrer", pause: "Pause", resume: "Reprendre", stop: "Arrêter",
  retryFailed: "Réessayer les échecs", skipDownloaded: "Ignorer les déjà téléchargés", clearRun: "Effacer l'exécution sauvée",
  detachCanceled: "Dernier détachement : Cancel pressé — jamais pendant une exécution",
  detachReason: "Raison du dernier détachement : {r}",
  bannerResume: "Une exécution précédente est à moitié faite — Reprendre continue le reste.",
  bannerStale: "Moteur semble arrêté — Reprendre relance l'exécution sauvée",
  tabItems: "Éléments", tabLog: "Journal", tabReport: "Rapport",
  stPending: "en attente", stActive: "en cours", stDone: "terminé", stFailed: "échoué", stGenerated: "généré",
  matchTitle: "Rapport de correspondance QuickVid",
  matchIdle: "Appuie sur « Vérifier les téléchargements » pour contrôler les fichiers sur le disque.",
  checkDownloads: "Vérifier les téléchargements", copyMissing: "Copier la liste des manquants", downloadReport: "Télécharger le rapport",
  copied: "Copié !", copyFail: "Copie échouée",
  rExpected: "Fichiers attendus", rVerified: "Téléchargés et vérifiés", rMissing: "Manquants",
  rFailed: "Échoués", rGenerated: "Générés (non téléchargés)", rFlowNamed: "Enregistrés avec les noms Flow", rNone: "Aucun",
  reportEmpty: "Aucune exécution pour l'instant — termine d'abord une exécution.",
  help: "Aide",
  noPrompts: "Aucun prompt chargé pour l'instant.",
  loadedInfo: "{n} prompt(s) chargé(s) ({kind})",
  kindStoryboard: "storyboard", kindTxt: "liste texte",
  refNeededInfo: " — {n} ont besoin d'une référence de personnage",
  logLoadedLine: "{n} prompt(s) chargé(s). Premier : {first}, dernier : {last}",
  logParseWarn: "Avertissement d'analyse : {w}",
  logNoPromptsFound: "ATTENTION : aucun prompt trouvé — vérifie le fichier / format",
  logFileReadFail: "Fichier illisible",
  logRefSelected: "Image de référence choisie : {name}",
  logClipboardOk: "Référence copiée — envoyée une fois au démarrage",
  logClipboardFail: "ATTENTION : écriture presse-papiers impossible ({msg}) — sans référence",
  logLoadFirst: "Charge d'abord des prompts",
  logBlockedVideo: "DÉMARRAGE BLOQUÉ : Flow en mode VIDÉO — choisis Image et revérifie",
  logBlockedRef: "DÉMARRAGE BLOQUÉ : {n} prompt(s) sans référence — coche la case ou choisis une image",
  logStartSent: "Démarrage envoyé — projet : {project}, mode réf : {mode}",
  logStartSentRef: " (réf presse-papiers : {state})",
  refStateReady: "prête", refStateFail: "ÉCHOUÉ — sans réf",
  logStartFail: "Démarrage échoué : {msg}",
  logResumeFail: "Reprise échouée : {msg}",
  logStopReq: "Arrêt demandé",
  logRetryFail: "Nouvel essai échoué : {msg}",
  logRetryCount: "Les éléments échoués seront réessayés : {n} élément(s)",
  logSkipFail: "Vérification d'ignorés échouée : {msg}",
  logSkipMarked: "Ignorés : {n} élément(s) marqués terminés",
  logClearDone: "Exécution sauvée effacée",
  logClearFail: "Effacement échoué : {msg}",
  logReportEmpty: "Pas encore de rapport — lance quelque chose d'abord",
  logDlDone: "Téléchargement des générées terminé : {n} image(s)",
  logDlFail: "Téléchargement des générées échoué : {msg}",
  logVerifying: "Vérification des téléchargements…",
  logVerifyFail: "Vérification échouée : {msg}",
  checkAllGood: "Tout est bon",
  checkShortFlow: "Page Flow", checkShortInput: "Aucun champ prompt", checkShortSend: "Aucun bouton Generate",
  checkShortPlus: "Aucun bouton +", checkShortAgent: "Mode Agent ACTIVÉ", checkShortMode: "Mode vidéo",
  endsAt: "Fin ~",
  dropToImport: "Dépose pour importer",
  chooseFile: "Choisir un fichier", noFileChosen: "Aucun fichier choisi",
  retryOne: "Réessayer",
  toastRunDone: "Exécution terminée — Terminé {done}, Échoué {failed}",
  toastDlDone: "Téléchargement terminé — {n} image(s)",
  toastRetryOk: "Nouvel essai {id} : terminé",
  toastRetryFail: "Nouvel essai {id} : échoué — {msg}",
  toastRetryBusy: "Une exécution est en cours — réessaie après",
  toastImportOk: "{n} prompt(s) chargé(s)",
  toastImportFail: "Impossible d'importer ce fichier",
  toastCheckFail: "La vérification Flow a trouvé un problème"
},
de: {
  done: "Fertig", failed: "Fehlgeschlagen", pending: "Offen", generated: "Erstellt",
  project: "Projekt", timeLeft: "Restzeit", nowGenerating: "Wird jetzt erstellt",
  setup: "Einrichtung",
  fileLabel: "Storyboard- (.md) oder Promptlisten-Datei (.txt):",
  pasteLabel: "Oder Prompts hier einfügen (einer pro Zeile):",
  pastePlaceholder: "Prompts hier einfügen, einer pro Zeile...",
  loadPasted: "Eingefügte laden",
  projectLabel: "Projektname (Download-Ordner):",
  projectPlaceholder: "z. B. BanksVideo",
  startNumberLabel: "Startnummer (nur Text / Einfügen):",
  reference: "Referenzbild",
  refFileLabel: "Referenzbild (optional):",
  refModeLabel: "Referenz verwenden bei:",
  refModeMarked: "Nur markierten Prompts (Storyboard)",
  refModeAll: "Jedem Prompt",
  refModeNone: "Keine Referenz",
  refStChecking: "Prüfe…", refStUploading: "Lade hoch…", refStReady: "Im Projekt bereit", refStFailed: "Fehlgeschlagen", refStNone: "—",
  refConfirmText: "Referenz im Projekt gesetzt ({n} brauchen sie)",
  refConvertFail: "Referenzbild konnte nicht gelesen werden: {msg}",
  download: "Download",
  autoDownload: "Auto-Download",
  qualityLabel: "Bildqualität:",
  datedFolder: "Für jeden Lauf ein neuer datierter Ordner",
  retryAtEnd: "Fehler am Ende erneut versuchen (3 Runden)",
  intervalLabel: "Sekunden zwischen den Erstellungen:",
  runModeLabel: "Laufmodus:",
  runModeSerial: "Eins nach dem anderen",
  runModePaced: "Getaktet",
  matchModeLabel: "Zuordnungsmodus:",
  matchModePrompt: "Prompt-Prüfung",
  matchModeFast: "Schnelle Reihenfolge",
  intervalHint: "Mindestabstand zwischen den Sends.",
  generation: "Generierung", genTypeLabel: "Typ:", genTypeImage: "Bild", genTypeVideo: "Video",
  genModelLabel: "Modell:", genRatioLabel: "Seitenverhältnis:", genCountLabel: "Bilder pro Prompt:",
  pfVideoOk: "✓ Video-Modus scheint gewählt", pfImageBad: "✗ BILD-Modus — du hast Video gewählt. In Flow Video wählen.",
  downloadGenerated: "Erstellte herunterladen",
  generatedReady: "{n} Bild(er) erstellt — noch nicht heruntergeladen.",
  flowCheck: "Flow-Tab prüfen", checkBtn: "Flow-Tab prüfen", checkingNow: "Prüfe...",
  checkFail: "Prüfung fehlgeschlagen: {msg}",
  pfFlowOk: "✓ Flow-Projektseite ist offen",
  pfFlowBad: "✗ Keine Flow-Seite gefunden — {reason}",
  pfInputOk: "✓ Prompt-Eingabe gefunden ({how})",
  pfInputBad: "✗ Prompt-Eingabe nicht gefunden",
  pfSendOk: "✓ Generate/Send-Button gefunden ({how})",
  pfSendBad: "✗ Generate-Button nicht gefunden",
  pfPlusOk: "✓ Referenz-Button (+) gefunden",
  pfPlusWarn: "! (+)-Button fehlt — Auswahl öffnet sich nicht",
  pfAgentBad: "✗ Agent-Modus ist AN — ausschalten",
  pfAgentOk: "✓ Agent-Modus ist aus",
  pfVideoBad: "✗ VIDEO-Modus — Lauf blockiert. In Flow Image wählen.",
  pfImageOk: "✓ Image-Modus scheint gewählt",
  pfModeUnknown: "? Modus unsicher — bitte prüfe, ob der Image-Modus gewählt ist",
  pfDurationWarn: "! Dauer-Auswahl sichtbar — Video-Modus-Zeichen",
  pfSharedRefWarn: "! {n} Prompt(s) ohne Referenz — Kästchen anhaken oder Bild wählen",
  run: "Lauf", start: "Start", pause: "Pause", resume: "Weiter", stop: "Stopp",
  retryFailed: "Nur Fehler erneut", skipDownloaded: "Heruntergeladene überspringen", clearRun: "Gespeicherten Lauf löschen",
  detachCanceled: "Letzte Trennung: Cancel gedrückt — im Lauf nie drücken",
  detachReason: "Grund der letzten Trennung: {r}",
  bannerResume: "Ein früherer Lauf ist halb fertig — Weiter macht den Rest.",
  bannerStale: "Engine wirkt gestoppt — Weiter startet den gespeicherten Lauf neu",
  tabItems: "Elemente", tabLog: "Protokoll", tabReport: "Bericht",
  stPending: "offen", stActive: "läuft", stDone: "fertig", stFailed: "fehlgeschlagen", stGenerated: "erstellt",
  matchTitle: "QuickVid-Abgleichbericht",
  matchIdle: "Drücke \"Downloads prüfen\", um die Dateien auf der Platte zu kontrollieren.",
  checkDownloads: "Downloads prüfen", copyMissing: "Fehlende Liste kopieren", downloadReport: "Bericht herunterladen",
  copied: "Kopiert!", copyFail: "Kopieren fehlgeschlagen",
  rExpected: "Erwartete Dateien", rVerified: "Heruntergeladen & geprüft", rMissing: "Fehlend",
  rFailed: "Fehlgeschlagen", rGenerated: "Erstellt (nicht geladen)", rFlowNamed: "Mit Flow-Namen gespeichert", rNone: "Keine",
  reportEmpty: "Noch kein Lauf — beende zuerst einen Lauf.",
  help: "Hilfe",
  noPrompts: "Noch keine Prompts geladen.",
  loadedInfo: "{n} Prompt(s) geladen ({kind})",
  kindStoryboard: "Storyboard", kindTxt: "Textliste",
  refNeededInfo: " — {n} brauchen eine Figuren-Referenz",
  logLoadedLine: "{n} Prompt(s) geladen. Erster: {first}, letzter: {last}",
  logParseWarn: "Parse-Warnung: {w}",
  logNoPromptsFound: "WARNUNG: keine Prompts gefunden — Datei / Format prüfen",
  logFileReadFail: "Datei konnte nicht gelesen werden",
  logRefSelected: "Referenzbild gewählt: {name}",
  logClipboardOk: "Referenz kopiert — lädt beim Start einmal hoch",
  logClipboardFail: "WARNUNG: Zwischenablage fehlgeschlagen ({msg}) — Lauf ohne Referenz",
  logLoadFirst: "Zuerst Prompts laden",
  logBlockedVideo: "START BLOCKIERT: Flow ist im VIDEO-Modus — Image wählen, erneut prüfen",
  logBlockedRef: "START BLOCKIERT: {n} Prompt(s) ohne Referenz — Kästchen anhaken oder Bild wählen",
  logStartSent: "Laufstart gesendet — Projekt: {project}, Ref-Modus: {mode}",
  logStartSentRef: " (Zwischenablage-Ref: {state})",
  refStateReady: "bereit", refStateFail: "FEHLGESCHLAGEN — läuft ohne Ref",
  logStartFail: "Start fehlgeschlagen: {msg}",
  logResumeFail: "Weiter fehlgeschlagen: {msg}",
  logStopReq: "Stopp angefordert",
  logRetryFail: "Erneut fehlgeschlagen: {msg}",
  logRetryCount: "Fehlerhafte Elemente werden erneut versucht: {n} Element(e)",
  logSkipFail: "Überspring-Prüfung fehlgeschlagen: {msg}",
  logSkipMarked: "Überspringen: {n} Element(e) als fertig markiert",
  logClearDone: "Gespeicherter Lauf gelöscht",
  logClearFail: "Löschen fehlgeschlagen: {msg}",
  logReportEmpty: "Noch kein Bericht — starte zuerst etwas",
  logDlDone: "Download der Erstellten fertig: {n} Bild(er)",
  logDlFail: "Download der Erstellten fehlgeschlagen: {msg}",
  logVerifying: "Prüfe Downloads…",
  logVerifyFail: "Prüfung fehlgeschlagen: {msg}",
  checkAllGood: "Alles gut",
  checkShortFlow: "Flow-Seite", checkShortInput: "Keine Prompt-Eingabe", checkShortSend: "Kein Generate-Button",
  checkShortPlus: "Kein +-Button", checkShortAgent: "Agent-Modus AN", checkShortMode: "Video-Modus",
  endsAt: "Ende ~",
  dropToImport: "Zum Importieren loslassen",
  chooseFile: "Datei wählen", noFileChosen: "Keine Datei gewählt",
  retryOne: "Erneut",
  toastRunDone: "Lauf fertig — Fertig {done}, Fehlgeschlagen {failed}",
  toastDlDone: "Download fertig — {n} Bild(er)",
  toastRetryOk: "Erneut {id}: fertig",
  toastRetryFail: "Erneut {id}: fehlgeschlagen — {msg}",
  toastRetryBusy: "Ein Lauf läuft — danach erneut versuchen",
  toastImportOk: "{n} Prompt(s) geladen",
  toastImportFail: "Diese Datei konnte nicht importiert werden",
  toastCheckFail: "Flow-Tab-Prüfung hat ein Problem gefunden"
},
it: {
  done: "Fatto", failed: "Falliti", pending: "In attesa", generated: "Generati",
  project: "Progetto", timeLeft: "Tempo rimasto", nowGenerating: "Generazione in corso",
  setup: "Impostazione",
  fileLabel: "File storyboard (.md) o lista prompt (.txt):",
  pasteLabel: "Oppure incolla i prompt qui (uno per riga):",
  pastePlaceholder: "Incolla i prompt qui, uno per riga...",
  loadPasted: "Carica i prompt incollati",
  projectLabel: "Nome progetto (cartella download):",
  projectPlaceholder: "es. BanksVideo",
  startNumberLabel: "Numero iniziale (solo testo / incolla):",
  reference: "Immagine di riferimento",
  refFileLabel: "Immagine di riferimento (facoltativa):",
  refModeLabel: "Usa il riferimento su:",
  refModeMarked: "Solo prompt marcati per riferimento (storyboard)",
  refModeAll: "Ogni prompt",
  refModeNone: "Nessun riferimento",
  refStChecking: "Controllo…", refStUploading: "Caricamento…", refStReady: "Pronto nel progetto", refStFailed: "Fallito", refStNone: "—",
  refConfirmText: "Riferimento impostato nel progetto (serve a {n})",
  refConvertFail: "Immagine di riferimento non leggibile: {msg}",
  download: "Download",
  autoDownload: "Download automatico",
  qualityLabel: "Qualità immagine:",
  datedFolder: "Nuova cartella con data per ogni sessione",
  retryAtEnd: "Riprova i falliti alla fine (3 giri)",
  intervalLabel: "Secondi tra le generazioni:",
  runModeLabel: "Modalità:",
  runModeSerial: "Uno alla volta",
  runModePaced: "Cadenzato",
  matchModeLabel: "Modalità abbinamento:",
  matchModePrompt: "Controllo prompt",
  matchModeFast: "Ordine rapido",
  intervalHint: "Intervallo minimo tra gli invii.",
  generation: "Generazione", genTypeLabel: "Tipo:", genTypeImage: "Immagine", genTypeVideo: "Video",
  genModelLabel: "Modello:", genRatioLabel: "Proporzioni:", genCountLabel: "Immagini per prompt:",
  pfVideoOk: "✓ Modalità video selezionata", pfImageBad: "✗ Modalità IMMAGINE — hai scelto Video. Seleziona Video in Flow.",
  downloadGenerated: "Scarica i generati",
  generatedReady: "{n} immagine/i generata/e — non ancora scaricata/e.",
  flowCheck: "Controllo scheda Flow", checkBtn: "Controlla scheda Flow", checkingNow: "Controllo...",
  checkFail: "Controllo fallito: {msg}",
  pfFlowOk: "✓ La pagina del progetto Flow è aperta",
  pfFlowBad: "✗ Nessuna pagina Flow trovata — {reason}",
  pfInputOk: "✓ Campo prompt trovato ({how})",
  pfInputBad: "✗ Campo prompt non trovato",
  pfSendOk: "✓ Pulsante Generate/Send trovato ({how})",
  pfSendBad: "✗ Pulsante Generate non trovato",
  pfPlusOk: "✓ Pulsante aggiungi riferimento (+) trovato",
  pfPlusWarn: "! Pulsante (+) non trovato — il selettore non si aprirà",
  pfAgentBad: "✗ Modalità Agent ATTIVA — disattivala",
  pfAgentOk: "✓ La modalità Agent è disattivata",
  pfVideoBad: "✗ Modalità VIDEO — sessione bloccata. Seleziona Image in Flow.",
  pfImageOk: "✓ La modalità Image sembra selezionata",
  pfModeUnknown: "? Modalità non certa — assicurati che sia selezionata la modalità Image",
  pfDurationWarn: "! Selettore di durata visibile — segno di modalità video",
  pfSharedRefWarn: "! {n} prompt senza riferimento — spunta la casella o scegli un'immagine",
  run: "Sessione", start: "Avvia", pause: "Pausa", resume: "Riprendi", stop: "Ferma",
  retryFailed: "Riprova solo i falliti", skipDownloaded: "Salta già scaricati", clearRun: "Cancella sessione salvata",
  detachCanceled: "Ultimo distacco: Cancel premuto — mai durante una sessione",
  detachReason: "Motivo ultimo distacco: {r}",
  bannerResume: "Una sessione precedente è a metà — Riprendi continua il resto.",
  bannerStale: "Motore sembra fermo — Riprendi rilancia la sessione salvata",
  tabItems: "Elementi", tabLog: "Registro", tabReport: "Rapporto",
  stPending: "in attesa", stActive: "in corso", stDone: "fatto", stFailed: "fallito", stGenerated: "generato",
  matchTitle: "Rapporto di corrispondenza QuickVid",
  matchIdle: "Premi \"Controlla download\" per verificare i file sul disco.",
  checkDownloads: "Controlla download", copyMissing: "Copia elenco mancanti", downloadReport: "Scarica rapporto",
  copied: "Copiato!", copyFail: "Copia fallita",
  rExpected: "File attesi", rVerified: "Scaricati e verificati", rMissing: "Mancanti",
  rFailed: "Falliti", rGenerated: "Generati (non scaricati)", rFlowNamed: "Salvati con nomi Flow", rNone: "Nessuno",
  reportEmpty: "Ancora nessuna sessione — prima finiscine una.",
  help: "Aiuto",
  noPrompts: "Nessun prompt caricato finora.",
  loadedInfo: "{n} prompt caricati ({kind})",
  kindStoryboard: "storyboard", kindTxt: "lista testo",
  refNeededInfo: " — {n} hanno bisogno di un riferimento personaggio",
  logLoadedLine: "{n} prompt caricati. Primo: {first}, ultimo: {last}",
  logParseWarn: "Avviso di analisi: {w}",
  logNoPromptsFound: "ATTENZIONE: nessun prompt trovato — controlla file / formato",
  logFileReadFail: "File non leggibile",
  logRefSelected: "Immagine di riferimento scelta: {name}",
  logClipboardOk: "Riferimento copiato — si carica una volta all'avvio",
  logClipboardFail: "ATTENZIONE: appunti non scritti ({msg}) — sessione senza riferimento",
  logLoadFirst: "Prima carica i prompt",
  logBlockedVideo: "AVVIO BLOCCATO: Flow in modalità VIDEO — scegli Image e ricontrolla",
  logBlockedRef: "AVVIO BLOCCATO: {n} prompt senza riferimento — spunta la casella o scegli un'immagine",
  logStartSent: "Avvio inviato — progetto: {project}, modo rif: {mode}",
  logStartSentRef: " (rif appunti: {state})",
  refStateReady: "pronto", refStateFail: "FALLITO — andrà senza rif",
  logStartFail: "Avvio fallito: {msg}",
  logResumeFail: "Ripresa fallita: {msg}",
  logStopReq: "Fermata richiesta",
  logRetryFail: "Nuovo tentativo fallito: {msg}",
  logRetryCount: "Gli elementi falliti saranno riprovati: {n} elemento/i",
  logSkipFail: "Controllo salta fallito: {msg}",
  logSkipMarked: "Salta: {n} elemento/i marcati fatti",
  logClearDone: "Sessione salvata cancellata",
  logClearFail: "Cancellazione fallita: {msg}",
  logReportEmpty: "Ancora nessun rapporto — prima avvia qualcosa",
  logDlDone: "Download dei generati finito: {n} immagine/i",
  logDlFail: "Download dei generati fallito: {msg}",
  logVerifying: "Controllo download…",
  logVerifyFail: "Controllo fallito: {msg}",
  checkAllGood: "Tutto a posto",
  checkShortFlow: "Pagina Flow", checkShortInput: "Nessun campo prompt", checkShortSend: "Nessun pulsante Generate",
  checkShortPlus: "Nessun pulsante +", checkShortAgent: "Modalità Agent ATTIVA", checkShortMode: "Modalità video",
  endsAt: "Fine ~",
  dropToImport: "Rilascia per importare",
  chooseFile: "Scegli file", noFileChosen: "Nessun file scelto",
  retryOne: "Riprova",
  toastRunDone: "Sessione finita — Fatti {done}, Falliti {failed}",
  toastDlDone: "Download finito — {n} immagine/i",
  toastRetryOk: "Riprova {id}: fatto",
  toastRetryFail: "Riprova {id}: fallito — {msg}",
  toastRetryBusy: "C'è una sessione in corso — riprova alla fine",
  toastImportOk: "{n} prompt caricati",
  toastImportFail: "Impossibile importare quel file",
  toastCheckFail: "Il controllo Flow ha trovato un problema"
},
es: {
  done: "Hecho", failed: "Fallido", pending: "Pendiente", generated: "Generado",
  project: "Proyecto", timeLeft: "Tiempo restante", nowGenerating: "Generando ahora",
  setup: "Configuración",
  fileLabel: "Archivo storyboard (.md) o lista de prompts (.txt):",
  pasteLabel: "O pega los prompts aquí (uno por línea):",
  pastePlaceholder: "Pega los prompts aquí, uno por línea...",
  loadPasted: "Cargar los pegados",
  projectLabel: "Nombre del proyecto (carpeta de descarga):",
  projectPlaceholder: "ej. BanksVideo",
  startNumberLabel: "Número inicial (solo texto / pegar):",
  reference: "Imagen de referencia",
  refFileLabel: "Imagen de referencia (opcional):",
  refModeLabel: "Usar referencia en:",
  refModeMarked: "Solo prompts marcados para referencia (storyboard)",
  refModeAll: "Cada prompt",
  refModeNone: "Sin referencia",
  refStChecking: "Comprobando…", refStUploading: "Subiendo…", refStReady: "Lista en el proyecto", refStFailed: "Fallido", refStNone: "—",
  refConfirmText: "Referencia puesta en el proyecto ({n} la necesitan)",
  refConvertFail: "No se pudo leer la imagen de referencia: {msg}",
  download: "Descarga",
  autoDownload: "Descarga automática",
  qualityLabel: "Calidad de imagen:",
  datedFolder: "Carpeta nueva con fecha para cada sesión",
  retryAtEnd: "Reintentar los fallidos al final (3 rondas)",
  intervalLabel: "Segundos entre generaciones:",
  runModeLabel: "Modo de ejecución:",
  runModeSerial: "Uno por uno",
  runModePaced: "Espaciado",
  matchModeLabel: "Modo de coincidencia:",
  matchModePrompt: "Revisión del prompt",
  matchModeFast: "Orden rápido",
  intervalHint: "Espacio mínimo entre envíos.",
  generation: "Generación", genTypeLabel: "Tipo:", genTypeImage: "Imagen", genTypeVideo: "Video",
  genModelLabel: "Modelo:", genRatioLabel: "Relación de aspecto:", genCountLabel: "Imágenes por prompt:",
  pfVideoOk: "✓ Modo video seleccionado", pfImageBad: "✗ Modo IMAGEN — elegiste Video. Selecciona Video en Flow.",
  downloadGenerated: "Descargar los generados",
  generatedReady: "{n} imagen(es) generada(s) — aún no descargada(s).",
  flowCheck: "Comprobación de la pestaña Flow", checkBtn: "Comprobar pestaña Flow", checkingNow: "Comprobando...",
  checkFail: "Comprobación fallida: {msg}",
  pfFlowOk: "✓ La página del proyecto Flow está abierta",
  pfFlowBad: "✗ No se encontró página Flow — {reason}",
  pfInputOk: "✓ Campo de prompt encontrado ({how})",
  pfInputBad: "✗ Campo de prompt no encontrado",
  pfSendOk: "✓ Botón Generate/Send encontrado ({how})",
  pfSendBad: "✗ Botón Generate no encontrado",
  pfPlusOk: "✓ Botón de añadir referencia (+) encontrado",
  pfPlusWarn: "! Botón (+) no encontrado — el selector no se abrirá",
  pfAgentBad: "✗ Modo Agent ACTIVADO — desactívalo",
  pfAgentOk: "✓ El modo Agent está desactivado",
  pfVideoBad: "✗ Modo VIDEO — sesión bloqueada. Selecciona Image en Flow.",
  pfImageOk: "✓ El modo Image parece seleccionado",
  pfModeUnknown: "? Modo no seguro — asegúrate de que el modo Image esté seleccionado",
  pfDurationWarn: "! Selector de duración visible — señal de modo video",
  pfSharedRefWarn: "! {n} prompt(s) sin referencia — marca la casilla o elige una imagen",
  run: "Sesión", start: "Iniciar", pause: "Pausar", resume: "Continuar", stop: "Detener",
  retryFailed: "Reintentar solo fallidos", skipDownloaded: "Saltar ya descargados", clearRun: "Borrar sesión guardada",
  detachCanceled: "Última desconexión: Cancel pulsado — nunca durante una sesión",
  detachReason: "Motivo de la última desconexión: {r}",
  bannerResume: "Una sesión anterior está a medias — Continuar hace el resto.",
  bannerStale: "El motor parece detenido — Continuar reinicia la sesión guardada",
  tabItems: "Elementos", tabLog: "Registro", tabReport: "Informe",
  stPending: "pendiente", stActive: "en curso", stDone: "hecho", stFailed: "fallido", stGenerated: "generado",
  matchTitle: "Informe de coincidencia QuickVid",
  matchIdle: "Pulsa \"Comprobar descargas\" para verificar los archivos en disco.",
  checkDownloads: "Comprobar descargas", copyMissing: "Copiar lista de faltantes", downloadReport: "Descargar informe",
  copied: "¡Copiado!", copyFail: "Copia fallida",
  rExpected: "Archivos esperados", rVerified: "Descargados y verificados", rMissing: "Faltantes",
  rFailed: "Fallidos", rGenerated: "Generados (sin descargar)", rFlowNamed: "Guardados con nombres Flow", rNone: "Ninguno",
  reportEmpty: "Aún no hay sesión — termina una primero.",
  help: "Ayuda",
  noPrompts: "Aún no se cargó ningún prompt.",
  loadedInfo: "{n} prompt(s) cargado(s) ({kind})",
  kindStoryboard: "storyboard", kindTxt: "lista de texto",
  refNeededInfo: " — {n} necesitan referencia de personaje",
  logLoadedLine: "{n} prompt(s) cargado(s). Primero: {first}, último: {last}",
  logParseWarn: "Aviso de análisis: {w}",
  logNoPromptsFound: "AVISO: no se encontró ningún prompt — revisa el archivo / formato",
  logFileReadFail: "No se pudo leer el archivo",
  logRefSelected: "Imagen de referencia elegida: {name}",
  logClipboardOk: "Referencia copiada — se sube una vez al iniciar",
  logClipboardFail: "AVISO: portapapeles falló ({msg}) — sesión sin referencia",
  logLoadFirst: "Primero carga los prompts",
  logBlockedVideo: "INICIO BLOQUEADO: Flow en modo VIDEO — elige Image y vuelve a comprobar",
  logBlockedRef: "INICIO BLOQUEADO: {n} prompt(s) sin referencia — marca la casilla o elige una imagen",
  logStartSent: "Inicio enviado — proyecto: {project}, modo ref: {mode}",
  logStartSentRef: " (ref portapapeles: {state})",
  refStateReady: "lista", refStateFail: "FALLIDA — irá sin ref",
  logStartFail: "Inicio fallido: {msg}",
  logResumeFail: "Continuación fallida: {msg}",
  logStopReq: "Detención pedida",
  logRetryFail: "Reintento fallido: {msg}",
  logRetryCount: "Los elementos fallidos se reintentarán: {n} elemento(s)",
  logSkipFail: "Comprobación de salto fallida: {msg}",
  logSkipMarked: "Salto: {n} elemento(s) marcados como hechos",
  logClearDone: "Sesión guardada borrada",
  logClearFail: "Borrado fallido: {msg}",
  logReportEmpty: "Aún no hay informe — ejecuta algo primero",
  logDlDone: "Descarga de generados terminada: {n} imagen(es)",
  logDlFail: "Descarga de generados fallida: {msg}",
  logVerifying: "Comprobando descargas…",
  logVerifyFail: "Comprobación fallida: {msg}",
  checkAllGood: "Todo bien",
  checkShortFlow: "Página Flow", checkShortInput: "Sin campo de prompt", checkShortSend: "Sin botón Generate",
  checkShortPlus: "Sin botón +", checkShortAgent: "Modo Agent ACTIVADO", checkShortMode: "Modo vídeo",
  endsAt: "Termina ~",
  dropToImport: "Suelta para importar",
  chooseFile: "Elegir archivo", noFileChosen: "Ningún archivo elegido",
  retryOne: "Reintentar",
  toastRunDone: "Sesión terminada — Hecho {done}, Fallido {failed}",
  toastDlDone: "Descarga terminada — {n} imagen(es)",
  toastRetryOk: "Reintento {id}: hecho",
  toastRetryFail: "Reintento {id}: fallido — {msg}",
  toastRetryBusy: "Hay una sesión en curso — reintenta al terminar",
  toastImportOk: "{n} prompt(s) cargado(s)",
  toastImportFail: "No se pudo importar ese archivo",
  toastCheckFail: "La comprobación Flow encontró un problema"
}
};

/* ---------------- i18n ---------------- */
/* v2.4: real flag IMAGES (assets/flags/*.svg) — Windows Chrome does
 * not render flag emoji (it shows "GB"/"BD" letters), so emoji flags
 * are not used anywhere in the picker. */
const LANGS = [
  { code: 'en', flagFile: 'gb', name: 'English' },
  { code: 'bn', flagFile: 'bd', name: 'বাংলা' },
  { code: 'hi', flagFile: 'in', name: 'हिन्दी' },
  { code: 'tr', flagFile: 'tr', name: 'Türkçe' },
  { code: 'fr', flagFile: 'fr', name: 'Français' },
  { code: 'de', flagFile: 'de', name: 'Deutsch' },
  { code: 'it', flagFile: 'it', name: 'Italiano' },
  { code: 'es', flagFile: 'es', name: 'Español' }
];
const FLAG_SRC = (L) => 'assets/flags/' + L.flagFile + '.svg';
let curLang = 'en';
function t(key, params) {
  const dict = STRINGS[curLang] || STRINGS.en;
  let s = dict[key] !== undefined ? dict[key] : (STRINGS.en[key] !== undefined ? STRINGS.en[key] : key);
  if (params) {
    for (const k of Object.keys(params)) s = s.split('{' + k + '}').join(String(params[k]));
  }
  return s;
}
function panelFormatClock(ts) {
  const d = new Date(ts);
  let h = d.getHours();
  const ap = h >= 12 ? 'PM' : 'AM';
  h = h % 12; if (h === 0) h = 12;
  return h + ':' + String(d.getMinutes()).padStart(2, '0') + ' ' + ap;
}
function panelFormatEta(sec) {
  if (sec === null || sec === undefined || !isFinite(sec) || sec < 0) return '—';
  sec = Math.round(sec);
  if (sec < 60) return sec + 's';
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  if (m < 60) return m + 'm ' + s + 's';
  return Math.floor(m / 60) + 'h ' + (m % 60) + 'm';
}

/* ---------------- panel state ---------------- */
const P = window.SFAParse;
const $ = (id) => document.getElementById(id);

let displayItems = [];
let sourceKind = null;
let lastImportAt = 0;
let lastPreflight = null;
let bgState = null;
let bgLoopActive = false;
let adoptNext = false;
let lastItemSig = '';
let lastLogSig = '';
const localLog = [];
let refBlob = null;
let refFileName = '';
let engineStale = false;
let lastParse = null;        // {n, kind, ref} — for re-render on language change
let refInfo = { kind: 'none' }; // {kind:'none'|'ready'|'fail', name, kb, msg}
let settingsHydrated = false;
let qualitySel = '1K';
let runModeSel = 'serial';
let matchModeSel = 'prompt'; // v2.6.2: 'prompt' (viewer check) | 'fast' (FIFO + repair)
/* v2.6 generation options (GENERATION card) */
const GEN_MODELS_PANEL = {
  image: ['Nano Banana 2.1', 'Nano Banana Pro', 'Imagen 4'],
  video: ['Veo 3.1 Fast', 'Veo 3.1 Quality']
};
let genTypeSel = 'image';
let genModelSel = 'Nano Banana 2.1';
let genRatioSel = '16:9';
let genCountSel = 1;
let muted = false;
/* v2.4: Flow Tab Check verdict lives ON the button itself.
 * checkVerdict: null (not run yet) | { state:'pass' } |
 * { state:'fail', labelKey } | { state:'failText', text } */
let checkVerdict = null;
let dlToastAt = 0;
let prevDlPass = false;
let prevGenCount = 0;
let lastFinishAt = null;
let activeSeen = { id: '', at: 0 };
let ringShown = -1;
let ringTarget = 0;
let ringAnim = false;
const thumbLocal = new Map();
const thumbAsked = new Set();
let matchData = null;

function plog(msg) {
  localLog.push(new Date().toTimeString().slice(0, 8) + '  ' + msg);
  renderLog();
}
function send(msg) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(msg, (res) => {
      const err = chrome.runtime.lastError;
      resolve(err ? { ok: false, error: err.message } : (res || { ok: false, error: 'No response' }));
    });
  });
}
function needsRefCount() { return P.countNeedsRef(displayItems); }
function itemCounts() {
  const c = { done: 0, failed: 0, pending: 0, active: 0, generated: 0, total: displayItems.length };
  for (const it of displayItems) c[it.status] = (c[it.status] || 0) + 1;
  return c;
}

/* ---------------- toasts (v2.4) ---------------- */
function toast(msg, type) {
  const box = $('toasts');
  if (!box || !msg) return;
  const d = document.createElement('div');
  d.className = 'toast ' + (type || 'info');
  d.textContent = msg;
  box.appendChild(d);
  requestAnimationFrame(() => d.classList.add('in'));
  setTimeout(() => {
    d.classList.add('out');
    setTimeout(() => d.remove(), 320);
  }, 4000);
  while (box.children.length > 3) box.firstChild.remove();
}

/* ---------------- language picker ---------------- */
function buildLangMenu() {
  const menu = $('langMenu');
  menu.innerHTML = '';
  for (const L of LANGS) {
    const b = document.createElement('button');
    b.className = 'langrow' + (L.code === curLang ? ' sel' : '');
    b.dataset.lang = L.code;
    const fl = document.createElement('img'); fl.className = 'flagimg'; fl.src = FLAG_SRC(L); fl.alt = '';
    const nm = document.createElement('span'); nm.textContent = L.name;
    b.appendChild(fl); b.appendChild(nm);
    b.addEventListener('click', () => { setLang(L.code); $('langMenu').classList.add('hidden'); });
    menu.appendChild(b);
  }
  const cur = LANGS.find((L) => L.code === curLang) || LANGS[0];
  $('langFlagImg').src = FLAG_SRC(cur);
}
function setLang(code) {
  if (!STRINGS[code]) code = 'en';
  curLang = code;
  try { chrome.storage.local.set({ sfa_lang: code }); } catch (e) { /* ignore */ }
  buildLangMenu();
  applyLang();
}
$('langBtn').addEventListener('click', (ev) => {
  ev.stopPropagation();
  $('langMenu').classList.toggle('hidden');
});
document.addEventListener('click', (ev) => {
  if (!$('langMenu').classList.contains('hidden') && !ev.target.closest('.langwrap')) {
    $('langMenu').classList.add('hidden');
  }
  if (!$('refModeMenu').classList.contains('hidden') && !ev.target.closest('#refModeDD')) {
    closeRefDD();
  }
});
function applyLang() {
  document.querySelectorAll('[data-i18n]').forEach((el) => { el.textContent = t(el.getAttribute('data-i18n')); });
  document.querySelectorAll('[data-i18n-ph]').forEach((el) => { el.setAttribute('placeholder', t(el.getAttribute('data-i18n-ph'))); });
  if (!($('fileInput').files && $('fileInput').files.length)) $('fileChosen').textContent = t('noFileChosen');
  if (!($('refImageInput').files && $('refImageInput').files.length)) $('refFileChosen').textContent = t('noFileChosen');
  syncRefDD();
  renderCheckBtn();
  lastItemSig = '';
  lastLogSig = '';
  renderParseInfo();
  renderRefInfo();
  renderRefStatus();
  renderItems();
  renderLog();
  renderStatus();
  renderLive();
  renderReportSummary();
  renderMatch();
  syncControls();
}

/* ---------------- import ---------------- */
function renderParseInfo() {
  if (!lastParse) { $('parseInfo').textContent = t('noPrompts'); return; }
  $('parseInfo').textContent = t('loadedInfo', { n: lastParse.n, kind: t(lastParse.kind === 'storyboard' ? 'kindStoryboard' : 'kindTxt') }) +
    (lastParse.ref ? t('refNeededInfo', { n: lastParse.ref }) : '');
}
function setItems(items, kind, warnings) {
  displayItems = items.map((i) => ({ id: i.id, prompt: i.prompt, needsRef: !!i.needsRef, status: 'pending', attempts: 0, note: '' }));
  sourceKind = kind;
  lastImportAt = Date.now();
  lastItemSig = '';
  lastParse = { n: items.length, kind, ref: needsRefCount() };
  renderParseInfo();
  (warnings || []).forEach((w) => plog(t('logParseWarn', { w })));
  if (items.length === 0) { plog(t('logNoPromptsFound')); toast(t('toastImportFail'), 'error'); }
  else {
    plog(t('logLoadedLine', { n: items.length, first: items[0].id, last: items[items.length - 1].id }));
    toast(t('toastImportOk', { n: items.length }), 'success');
  }
  syncRefRow();
  renderItems();
  renderStatus();
  syncControls();
}
function parseFileText(name, text) {
  const isMd = /\.md$/i.test(name) || /\.markdown$/i.test(name);
  if (isMd || text.indexOf('**Image assignment:**') !== -1) {
    const r = P.parseStoryboard(text);
    setItems(r.items, 'storyboard', r.warnings);
  } else {
    const r = P.parseTxt(text, parseInt($('startNumber').value, 10) || 1);
    setItems(r.items, 'txt', r.warnings);
  }
}
function importFile(f) {
  if (!f) return;
  const reader = new FileReader();
  reader.onload = () => parseFileText(f.name, String(reader.result || ''));
  reader.onerror = () => { plog(t('logFileReadFail')); toast(t('toastImportFail'), 'error'); };
  reader.readAsText(f);
}
$('fileInput').addEventListener('change', (ev) => {
  const f = ev.target.files && ev.target.files[0];
  $('fileChosen').textContent = f ? f.name : t('noFileChosen');
  importFile(f);
});
/* v2.4: drag & drop a .txt/.md file anywhere on the panel to import
 * it — same parse path and feedback as the file picker. */
let dragDepth = 0;
document.addEventListener('dragenter', (ev) => {
  if (!ev.dataTransfer || !Array.from(ev.dataTransfer.types || []).includes('Files')) return;
  ev.preventDefault();
  dragDepth++;
  $('dropOverlay').classList.remove('hidden');
});
document.addEventListener('dragover', (ev) => { ev.preventDefault(); });
document.addEventListener('dragleave', (ev) => {
  dragDepth = Math.max(0, dragDepth - 1);
  if (dragDepth === 0) $('dropOverlay').classList.add('hidden');
});
document.addEventListener('drop', (ev) => {
  ev.preventDefault();
  dragDepth = 0;
  $('dropOverlay').classList.add('hidden');
  const f = ev.dataTransfer && ev.dataTransfer.files && ev.dataTransfer.files[0];
  if (!f) return;
  if (!/\.(txt|md|markdown)$/i.test(f.name)) { toast(t('toastImportFail'), 'error'); return; }
  $('fileChosen').textContent = f.name;
  importFile(f);
});
$('loadPasteBtn').addEventListener('click', () => {
  const r = P.parseTxt($('pasteBox').value, parseInt($('startNumber').value, 10) || 1);
  setItems(r.items, 'txt', r.warnings);
});
$('startNumber').addEventListener('change', () => {
  if (sourceKind === 'txt' && $('pasteBox').value.trim()) {
    const r = P.parseTxt($('pasteBox').value, parseInt($('startNumber').value, 10) || 1);
    setItems(r.items, 'txt', r.warnings);
  }
});

/* ---------------- reference image (clipboard route) ---------------- */
/* v2.6: ONE short status chip replaces the old three text lines.
 * A picked file shows "✓ <filename>"; a reference that only exists
 * in the project (saved run) shows its file name from state; engine
 * lifecycle states show their short status word. Nothing picked and
 * nothing in the project -> the chip hides. */
function renderRefInfo() {
  const chip = $('refChip');
  const tx = $('refChipText');
  let cls = '';
  let text = '';
  if (refInfo.kind === 'fail') { cls = 'bad'; text = '✗ ' + t('refConvertFail', { msg: refInfo.msg }); }
  else if (refInfo.kind === 'ready') { cls = 'ok'; text = '✓ ' + refInfo.name; }
  else {
    const st = bgState && bgState.refStatus;
    if (st === 'ready') { cls = 'ok'; text = '✓ ' + ((bgState && bgState.refFileName) || t('refStReady')); }
    else if (st === 'uploading') text = t('refStUploading');
    else if (st === 'checking') text = t('refStChecking');
    else if (st === 'failed') { cls = 'bad'; text = '✗ ' + t('refStFailed'); }
  }
  if (!text) { chip.classList.add('hidden'); return; }
  chip.className = 'refchip' + (cls ? ' ' + cls : '');
  tx.textContent = text;
}
function toPngBlob(file) {
  return new Promise((resolve, reject) => {
    if (file.type === 'image/png') { resolve(file); return; }
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      try {
        const c = document.createElement('canvas');
        c.width = img.naturalWidth;
        c.height = img.naturalHeight;
        c.getContext('2d').drawImage(img, 0, 0);
        URL.revokeObjectURL(url);
        c.toBlob((b) => (b ? resolve(b) : reject(new Error('PNG convert fail'))), 'image/png');
      } catch (err) { reject(err); }
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('Image read fail')); };
    img.src = url;
  });
}
$('refImageInput').addEventListener('change', async (ev) => {
  const f = ev.target.files && ev.target.files[0];
  $('refFileChosen').textContent = f ? f.name : t('noFileChosen');
  refBlob = null;
  refFileName = '';
  // v2.6: small thumbnail preview next to the file chip — a FileReader
  // data URL kept only in this panel session, never stored or sent.
  const thumb = $('refThumb');
  if (f) {
    try {
      const fr = new FileReader();
      fr.onload = () => { thumb.src = String(fr.result || ''); thumb.classList.remove('hidden'); };
      fr.onerror = () => thumb.classList.add('hidden');
      fr.readAsDataURL(f);
    } catch (e) { thumb.classList.add('hidden'); }
  } else {
    thumb.classList.add('hidden');
    thumb.removeAttribute('src');
  }
  if (!f) { refInfo = { kind: 'none' }; renderRefInfo(); return; }
  try {
    refBlob = await toPngBlob(f);
    refFileName = f.name;
    refInfo = { kind: 'ready', name: f.name, kb: Math.round(refBlob.size / 1024) };
    plog(t('logRefSelected', { name: f.name }));
  } catch (e) {
    refInfo = { kind: 'fail', msg: e.message };
  }
  renderRefInfo();
  syncControls();
});
async function writeRefToClipboard() {
  if (!refBlob) return false;
  try {
    await navigator.clipboard.write([new ClipboardItem({ 'image/png': refBlob })]);
    plog(t('logClipboardOk'));
    return true;
  } catch (e) {
    plog(t('logClipboardFail', { msg: e.message }));
    return false;
  }
}
function refImageChosen() { return !!refBlob && $('refMode').value !== 'none'; }
$('refMode').addEventListener('change', () => { syncRefDD(); syncControls(); });

/* ---------------- refMode custom dropdown (v2.4) ----------------
 * The native <select id="refMode"> stays in the DOM (hidden) as the
 * single source of the value — every existing reader keeps working.
 * The visible control is a styled button + popup; picking a row sets
 * the select's value and fires its change event. */
const REF_MODE_KEYS = { marked: 'refModeMarked', all: 'refModeAll', none: 'refModeNone' };
function syncRefDD() {
  const v = $('refMode').value;
  $('refModeLabel').textContent = t(REF_MODE_KEYS[v] || 'refModeMarked');
  document.querySelectorAll('#refModeMenu .ddrow').forEach((row) => {
    const sel = row.dataset.val === v;
    row.classList.toggle('sel', sel);
    row.setAttribute('aria-selected', sel ? 'true' : 'false');
    row.querySelector('.tick').textContent = sel ? '✓' : '';
  });
}
function closeRefDD() {
  $('refModeMenu').classList.add('hidden');
  $('refModeDD').classList.remove('open');
  $('refModeBtn').setAttribute('aria-expanded', 'false');
}
function openRefDD() {
  $('refModeMenu').classList.remove('hidden');
  $('refModeDD').classList.add('open');
  $('refModeBtn').setAttribute('aria-expanded', 'true');
  const sel = document.querySelector('#refModeMenu .ddrow.sel') || document.querySelector('#refModeMenu .ddrow');
  if (sel) sel.focus();
}
$('refModeBtn').addEventListener('click', (ev) => {
  ev.stopPropagation();
  if ($('refModeMenu').classList.contains('hidden')) openRefDD(); else closeRefDD();
});
document.querySelectorAll('#refModeMenu .ddrow').forEach((row) => {
  row.addEventListener('click', () => {
    $('refMode').value = row.dataset.val;
    $('refMode').dispatchEvent(new Event('change'));
    closeRefDD();
    $('refModeBtn').focus();
  });
});
$('refModeDD').addEventListener('keydown', (ev) => {
  const rows = Array.from(document.querySelectorAll('#refModeMenu .ddrow'));
  const cur = rows.indexOf(document.activeElement);
  if (ev.key === 'Escape') { closeRefDD(); $('refModeBtn').focus(); }
  else if (ev.key === 'ArrowDown' || ev.key === 'ArrowUp') {
    ev.preventDefault();
    if ($('refModeMenu').classList.contains('hidden')) { openRefDD(); return; }
    const next = ev.key === 'ArrowDown'
      ? rows[(cur + 1) % rows.length]
      : rows[(cur - 1 + rows.length) % rows.length];
    if (next) next.focus();
  }
});
function renderRefStatus() { renderRefInfo(); }

/* ---------------- preflight (v2.4: verdict on the button) ----------
 * The per-check lines go to the panel Log; the button itself carries
 * the verdict: green "Flow Tab Check: ✓ All good" or red
 * "Flow Tab Check: ✗ <first failed check>". No results list. */
function preflightChecks(r) {
  // [{cls:'ok'|'bad'|'warn', text, shortKey?}] in display order.
  const out = [];
  if (!r) return out;
  out.push(r.flowPage
    ? { cls: 'ok', text: t('pfFlowOk') }
    : { cls: 'bad', text: t('pfFlowBad', { reason: r.blockReason || '' }), shortKey: 'checkShortFlow' });
  if (r.flowPage) {
    out.push(r.input
      ? { cls: 'ok', text: t('pfInputOk', { how: r.input.strategy }) }
      : { cls: 'bad', text: t('pfInputBad'), shortKey: 'checkShortInput' });
    out.push(r.send
      ? { cls: 'ok', text: t('pfSendOk', { how: r.send.strategy }) }
      : { cls: 'bad', text: t('pfSendBad'), shortKey: 'checkShortSend' });
    out.push(r.plusBtn
      ? { cls: 'ok', text: t('pfPlusOk') }
      : { cls: 'warn', text: t('pfPlusWarn'), shortKey: 'checkShortPlus' });
    if (r.agent && r.agent.present && r.agent.active) out.push({ cls: 'bad', text: t('pfAgentBad'), shortKey: 'checkShortAgent' });
    else if (r.agent && r.agent.present) out.push({ cls: 'ok', text: t('pfAgentOk') });
    // v2.6: the mode verdict follows the GENERATION card's type —
    // video mode is correct for a Video run, wrong for an Image run.
    if (r.mode === 'video') {
      if (genTypeSel === 'video') out.push({ cls: 'ok', text: t('pfVideoOk') });
      else out.push({ cls: 'bad', text: t('pfVideoBad'), shortKey: 'checkShortMode' });
    } else if (r.mode === 'image') {
      if (genTypeSel === 'video') out.push({ cls: 'bad', text: t('pfImageBad'), shortKey: 'checkShortMode' });
      else out.push({ cls: 'ok', text: t('pfImageOk') });
    } else out.push({ cls: 'warn', text: t('pfModeUnknown'), shortKey: 'checkShortMode' });
    if (r.modeSignals && r.modeSignals.durationSignal) out.push({ cls: 'warn', text: t('pfDurationWarn') });
  }
  const ref = needsRefCount();
  if (ref > 0) out.push({ cls: 'warn', text: t('pfSharedRefWarn', { n: ref }) });
  return out;
}
function checkLabel() {
  const s = t('flowCheck');
  return s.charAt(0).toUpperCase() + s.slice(1);
}
function renderCheckBtn() {
  const btn = $('checkBtn');
  btn.classList.remove('checking', 'pass', 'fail');
  if (!checkVerdict) { btn.textContent = checkLabel(); return; }
  if (checkVerdict.state === 'pass') {
    btn.classList.add('pass');
    btn.textContent = checkLabel() + ': ✓ ' + t('checkAllGood');
  } else {
    btn.classList.add('fail');
    btn.textContent = checkLabel() + ': ✗ ' + (checkVerdict.labelKey ? t(checkVerdict.labelKey) : (checkVerdict.text || ''));
  }
}
function renderPreflight(logIt) {
  const checks = preflightChecks(lastPreflight);
  if (logIt) checks.forEach((c) => plog(c.text));
  const firstBad = checks.find((c) => c.cls === 'bad');
  checkVerdict = firstBad
    ? { state: 'fail', labelKey: firstBad.shortKey || null, text: firstBad.text }
    : { state: 'pass' };
  renderCheckBtn();
}
$('checkBtn').addEventListener('click', async () => {
  const btn = $('checkBtn');
  btn.disabled = true;
  btn.classList.remove('pass', 'fail');
  btn.classList.add('checking');
  btn.textContent = checkLabel() + ': ' + t('checkingNow');
  const res = await send({ type: 'preflight' });
  btn.disabled = false;
  btn.classList.remove('checking');
  if (!res.ok) {
    plog(t('checkFail', { msg: res.error || '' }));
    checkVerdict = { state: 'fail', labelKey: null, text: res.error || '' };
    renderCheckBtn();
    toast(t('toastCheckFail'), 'error');
    return;
  }
  lastPreflight = res.result;
  renderPreflight(true);
  if (checkVerdict && checkVerdict.state === 'fail') toast(t('toastCheckFail'), 'error');
  syncControls();
});

/* ---------------- ref confirm row ---------------- */
function syncRefRow() {
  const ref = needsRefCount();
  $('refRow').classList.toggle('hidden', ref === 0);
  if (ref > 0) $('refText').textContent = t('refConfirmText', { n: ref });
}
$('refConfirm').addEventListener('change', syncControls);

/* ---------------- download settings ---------------- */
function collectDlSettings() {
  let iv = parseInt($('intervalSec').value, 10);
  if (!isFinite(iv)) iv = 10;
  iv = Math.min(120, Math.max(3, iv));
  return {
    autoDownload: $('autoDownload').checked,
    quality: qualitySel,
    datedFolder: $('datedFolder').checked,
    retryAtEnd: $('retryAtEnd').checked,
    intervalSec: iv,
    runMode: runModeSel,
    matchMode: matchModeSel,
    genType: genTypeSel,
    genModel: genModelSel,
    genRatio: genRatioSel,
    genCount: genCountSel
  };
}
async function pushSettings() {
  await send({ type: 'settings', settings: collectDlSettings() });
}
function hydrateSettings(s) {
  if (!s || settingsHydrated) return;
  settingsHydrated = true;
  $('autoDownload').checked = s.autoDownload !== false;
  $('datedFolder').checked = !!s.datedFolder;
  $('retryAtEnd').checked = !!s.retryAtEnd;
  setIntervalUi(s.intervalSec || 10);
  runModeSel = s.runMode === 'paced' ? 'paced' : 'serial';
  document.querySelectorAll('#runModePills .pill').forEach((p) => p.classList.toggle('sel', p.dataset.m === runModeSel));
  matchModeSel = s.matchMode === 'fast' ? 'fast' : 'prompt';
  document.querySelectorAll('#matchModePills .pill').forEach((p) => p.classList.toggle('sel', p.dataset.mm === matchModeSel));
  qualitySel = (s.quality === '2K' || s.quality === '4K') ? s.quality : '1K';
  document.querySelectorAll('#qualityPills .pill').forEach((p) => p.classList.toggle('sel', p.dataset.q === qualitySel));
  // v2.6 generation options
  genTypeSel = s.genType === 'video' ? 'video' : 'image';
  genModelSel = (GEN_MODELS_PANEL[genTypeSel] || []).includes(s.genModel) ? s.genModel : GEN_MODELS_PANEL[genTypeSel][0];
  genRatioSel = ['16:9', '9:16', '1:1', '4:3', '3:4'].includes(s.genRatio) ? s.genRatio : '16:9';
  genCountSel = [1, 2, 3, 4].includes(s.genCount) ? s.genCount : 1;
  syncGenPills();
}
/* v2.6: GENERATION card pill sync — the model list depends on the
 * type, so its pills are (re)built whenever the type changes. */
function syncGenPills() {
  document.querySelectorAll('#genTypePills .pill').forEach((p) => p.classList.toggle('sel', p.dataset.gt === genTypeSel));
  const box = $('genModelPills');
  box.innerHTML = '';
  for (const m of GEN_MODELS_PANEL[genTypeSel] || []) {
    const b = document.createElement('button');
    b.className = 'pill' + (m === genModelSel ? ' sel' : '');
    b.textContent = m;
    b.dataset.gm = m;
    b.addEventListener('click', () => {
      genModelSel = m;
      document.querySelectorAll('#genModelPills .pill').forEach((x) => x.classList.toggle('sel', x === b));
      pushSettings();
    });
    box.appendChild(b);
  }
  document.querySelectorAll('#genRatioPills .pill').forEach((p) => p.classList.toggle('sel', p.dataset.gr === genRatioSel));
  document.querySelectorAll('#genCountPills .pill').forEach((p) => p.classList.toggle('sel', parseInt(p.dataset.gc, 10) === genCountSel));
}
$('autoDownload').addEventListener('change', pushSettings);
$('datedFolder').addEventListener('change', pushSettings);
$('retryAtEnd').addEventListener('change', pushSettings);
/* v2.5: interval stepper + preset chips. The hidden #intervalSec
 * input stays the value store (collectDlSettings reads it as before);
 * the visible control is the − value + stepper and the preset chips. */
function ivLabel(v) {
  if (v % 60 === 0) return (v / 60) + 'm';
  return v + 's';
}
function setIntervalUi(v) {
  let n = parseInt(v, 10);
  if (!isFinite(n)) n = 10;
  n = Math.min(120, Math.max(3, n));
  $('intervalSec').value = n;
  $('ivVal').textContent = ivLabel(n);
  document.querySelectorAll('#ivChips .ivchip').forEach((c) => c.classList.toggle('sel', parseInt(c.dataset.sec, 10) === n));
}
$('ivMinus').addEventListener('click', () => { setIntervalUi((parseInt($('intervalSec').value, 10) || 10) - 5); pushSettings(); });
$('ivPlus').addEventListener('click', () => { setIntervalUi((parseInt($('intervalSec').value, 10) || 10) + 5); pushSettings(); });
document.querySelectorAll('#ivChips .ivchip').forEach((c) => {
  c.addEventListener('click', () => { setIntervalUi(parseInt(c.dataset.sec, 10)); pushSettings(); });
});
document.querySelectorAll('#runModePills .pill').forEach((p) => {
  p.addEventListener('click', () => {
    runModeSel = p.dataset.m === 'paced' ? 'paced' : 'serial';
    document.querySelectorAll('#runModePills .pill').forEach((x) => x.classList.toggle('sel', x === p));
    pushSettings();
  });
});
document.querySelectorAll('#matchModePills .pill').forEach((p) => {
  p.addEventListener('click', () => {
    matchModeSel = p.dataset.mm === 'fast' ? 'fast' : 'prompt';
    document.querySelectorAll('#matchModePills .pill').forEach((x) => x.classList.toggle('sel', x === p));
    pushSettings();
  });
});
document.querySelectorAll('#qualityPills .pill').forEach((p) => {
  p.addEventListener('click', () => {
    qualitySel = p.dataset.q;
    document.querySelectorAll('#qualityPills .pill').forEach((x) => x.classList.toggle('sel', x === p));
    pushSettings();
  });
});
/* v2.6: GENERATION card wiring — switching type swaps the model list
 * (and resets the model to that type's default when the current one
 * does not belong to it). */
document.querySelectorAll('#genTypePills .pill').forEach((p) => {
  p.addEventListener('click', () => {
    genTypeSel = p.dataset.gt === 'video' ? 'video' : 'image';
    if (!(GEN_MODELS_PANEL[genTypeSel] || []).includes(genModelSel)) genModelSel = GEN_MODELS_PANEL[genTypeSel][0];
    syncGenPills();
    pushSettings();
  });
});
document.querySelectorAll('#genRatioPills .pill').forEach((p) => {
  p.addEventListener('click', () => {
    genRatioSel = p.dataset.gr;
    document.querySelectorAll('#genRatioPills .pill').forEach((x) => x.classList.toggle('sel', x === p));
    pushSettings();
  });
});
document.querySelectorAll('#genCountPills .pill').forEach((p) => {
  p.addEventListener('click', () => {
    genCountSel = parseInt(p.dataset.gc, 10) || 1;
    document.querySelectorAll('#genCountPills .pill').forEach((x) => x.classList.toggle('sel', x === p));
    pushSettings();
  });
});
syncGenPills();
$('downloadGeneratedBtn').addEventListener('click', async () => {
  $('downloadGeneratedBtn').disabled = true;
  const res = await send({ type: 'downloadGenerated' });
  if (!res.ok) plog(t('logDlFail', { msg: res.error || '' }));
  else {
    plog(t('logDlDone', { n: res.count || 0 }));
    if ((res.count || 0) > 0) { dlToastAt = Date.now(); toast(t('toastDlDone', { n: res.count }), 'success'); }
  }
  await pollState(true);
});

/* ---------------- run controls ---------------- */
$('startBtn').addEventListener('click', async () => {
  if (!displayItems.length) { plog(t('logLoadFirst')); return; }
  if (lastPreflight && lastPreflight.blocked) { plog(t('logBlockedVideo')); return; }
  const ref = needsRefCount();
  if (ref > 0 && !$('refConfirm').checked && !refImageChosen()) {
    plog(t('logBlockedRef', { n: ref }));
    return;
  }
  // Clipboard write must happen inside this user gesture (Start click).
  const refMode = refImageChosen() ? $('refMode').value : 'none';
  let refReady = false;
  if (refMode !== 'none') refReady = await writeRefToClipboard();
  const project = P.sanitizeProject($('projectName').value || 'Project');
  const res = await send({
    type: 'start',
    items: displayItems.map((i) => ({ id: i.id, prompt: i.prompt, needsRef: i.needsRef })),
    project,
    settings: Object.assign({ refMode, refReady, refFileName }, collectDlSettings()),
    tabId: lastPreflight ? lastPreflight.tabId : undefined
  });
  if (!res.ok) plog(t('logStartFail', { msg: res.error || '' }));
  else plog(t('logStartSent', { project, mode: refMode }) + (refMode !== 'none' ? t('logStartSentRef', { state: refReady ? t('refStateReady') : t('refStateFail') }) : ''));
});
$('pauseBtn').addEventListener('click', async () => { await send({ type: 'pause' }); });
$('resumeBtn').addEventListener('click', async () => {
  const res = await send({ type: 'resume' });
  if (!res.ok) plog(t('logResumeFail', { msg: res.error || '' }));
});
$('stopBtn').addEventListener('click', async () => { await send({ type: 'stop' }); plog(t('logStopReq')); });
$('retryBtn').addEventListener('click', async () => {
  const res = await send({ type: 'retryFailed' });
  if (!res.ok) plog(t('logRetryFail', { msg: res.error || '' }));
  else plog(t('logRetryCount', { n: res.count || 0 }));
});
$('skipBtn').addEventListener('click', async () => {
  const res = await send({
    type: 'skipDownloaded',
    items: displayItems.map((i) => ({ id: i.id, prompt: i.prompt, needsRef: i.needsRef, status: i.status, attempts: i.attempts || 0, note: i.note || '' })),
    project: $('projectName').value
  });
  if (!res.ok) plog(t('logSkipFail', { msg: res.error || '' }));
  else { plog(t('logSkipMarked', { n: res.marked })); adoptNext = true; await pollState(true); }
});
$('clearBtn').addEventListener('click', async () => {
  const res = await send({ type: 'clearState' });
  if (res.ok) {
    displayItems = []; lastItemSig = ''; lastParse = null; matchData = null;
    renderItems(); renderStatus(); renderParseInfo(); renderMatch(); renderReportSummary();
    plog(t('logClearDone')); syncControls();
  } else plog(t('logClearFail', { msg: res.error || '' }));
});
$('reportBtn').addEventListener('click', async () => {
  const res = await send({ type: 'buildReport' });
  const text = (res && res.report) || (bgState && bgState.lastReport) || '';
  if (!text) { plog(t('logReportEmpty')); return; }
  const blob = new Blob([text], { type: 'text/plain' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'run-report.txt';
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 4000);
});
$('verifyBtn').addEventListener('click', async () => {
  plog(t('logVerifying'));
  const res = await send({ type: 'matchReport' });
  if (!res.ok) { plog(t('logVerifyFail', { msg: res.error || '' })); return; }
  matchData = res.report;
  renderMatch();
});
$('copyMissingBtn').addEventListener('click', async () => {
  const missing = (matchData && matchData.missing) || [];
  try {
    await navigator.clipboard.writeText(missing.join(', '));
    $('copyMissingBtn').textContent = t('copied');
    setTimeout(() => { $('copyMissingBtn').textContent = t('copyMissing'); }, 1500);
  } catch (e) { plog(t('copyFail')); }
});
/* ---------------- tabs ---------------- */
document.querySelectorAll('.tab').forEach((tab) => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach((x) => x.classList.toggle('sel', x === tab));
    for (const name of ['items', 'log', 'report']) {
      $('tab-' + name).classList.toggle('hidden', name !== tab.dataset.tab);
    }
    if (tab.dataset.tab === 'report') { renderReportSummary(); renderMatch(); }
    if (tab.dataset.tab === 'log') renderLog(true);
  });
});

/* ---------------- sound + completion celebration ---------------- */
let audioCtx = null;
function playChime() {
  if (muted) return;
  try {
    audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
    if (audioCtx.state === 'suspended') audioCtx.resume();
    const t0 = audioCtx.currentTime;
    [[880, 0], [1318.5, 0.13]].forEach((pair) => {
      const o = audioCtx.createOscillator();
      const g = audioCtx.createGain();
      o.type = 'sine';
      o.frequency.value = pair[0];
      const at = t0 + pair[1];
      g.gain.setValueAtTime(0.0001, at);
      g.gain.exponentialRampToValueAtTime(0.14, at + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, at + 0.12);
      o.connect(g); g.connect(audioCtx.destination);
      o.start(at); o.stop(at + 0.14);
    });
  } catch (e) { /* sound is best-effort */ }
}
function burstConfetti() {
  const box = $('confetti');
  if (!box) return;
  box.innerHTML = '';
  const colors = ['#34d399', '#10b981', '#6ee7b7', '#4ade80', '#a7f3d0', '#ffffff'];
  for (let i = 0; i < 42; i++) {
    const d = document.createElement('div');
    d.className = 'confetto';
    const size = 5 + Math.random() * 5;
    d.style.left = (Math.random() * 100) + '%';
    d.style.width = size + 'px';
    d.style.height = (size * (0.5 + Math.random())) + 'px';
    d.style.background = colors[i % colors.length];
    d.style.borderRadius = Math.random() > 0.5 ? '50%' : '2px';
    d.style.animationDuration = (1.1 + Math.random() * 0.5) + 's';
    d.style.animationDelay = (Math.random() * 0.2) + 's';
    box.appendChild(d);
  }
  setTimeout(() => { box.innerHTML = ''; }, 2100);
}
$('soundBtn').addEventListener('click', () => {
  muted = !muted;
  $('soundBtn').textContent = muted ? '🔇' : '🔊';
  try { chrome.storage.local.set({ sfa_muted: muted }); } catch (e) { /* ignore */ }
  if (!muted) playChime();
});

/* ---------------- rendering: status card / ring / ETA ---------------- */
function setRing(pct) {
  ringTarget = Math.max(0, Math.min(100, pct));
  if (ringShown < 0) ringShown = 0;
  if (ringAnim) return;
  ringAnim = true;
  const step = () => {
    const diff = ringTarget - ringShown;
    if (Math.abs(diff) < 0.6) { ringShown = ringTarget; }
    else ringShown += diff * 0.25;
    const C = 188.5;
    $('ringFg').style.strokeDashoffset = String(C * (1 - ringShown / 100));
    $('ringPct').textContent = Math.round(ringShown) + '%';
    if (ringShown !== ringTarget) requestAnimationFrame(step);
    else ringAnim = false;
  };
  requestAnimationFrame(step);
}
function renderStatus() {
  const c = itemCounts();
  $('statDone').textContent = c.done;
  $('statFailed').textContent = c.failed;
  $('statPending').textContent = c.pending + c.active;
  $('statGenerated').textContent = c.generated;
  const proj = (bgState && (bgState.runFolder || bgState.project)) || $('projectName').value || '';
  $('statProject').textContent = proj || '—';
  const finished = c.done + c.generated;
  setRing(c.total ? (100 * finished / c.total) : 0);
  // v2.6: Time left / Ends ~ are computed by the ENGINE from this
  // run's real measured pace (per-item send->finish cycles) and ride
  // in the polled state. Before the first completion the engine sends
  // null and the panel honestly shows a dash.
  let etaTxt = '—';
  let endsTxt = '—';
  if (bgState && bgState.running && bgState.etaMs !== null && bgState.etaMs !== undefined) {
    etaTxt = panelFormatEta(bgState.etaMs / 1000);
    if (bgState.endsAt) endsTxt = panelFormatClock(bgState.endsAt);
  }
  $('statEta').textContent = etaTxt;
  $('endsLabel').textContent = t('endsAt');
  $('statEnds').textContent = endsTxt;
  const gen = c.generated;
  $('dlLaterInfo').classList.toggle('hidden', gen === 0);
  if (gen > 0) $('dlLaterInfo').textContent = t('generatedReady', { n: gen });
  $('downloadGeneratedBtn').classList.toggle('hidden', gen === 0);
  document.body.classList.toggle('running', !!(bgState && bgState.running));
  renderRefStatus();
}
function renderLive() {
  const active = displayItems.find((i) => i.status === 'active');
  const card = $('liveCard');
  if (!active || !(bgState && bgState.running)) {
    card.classList.add('hidden');
    activeSeen = { id: '', at: 0 };
    return;
  }
  card.classList.remove('hidden');
  if (activeSeen.id !== active.id) activeSeen = { id: active.id, at: Date.now() };
  $('liveId').textContent = active.id;
  $('liveStage').textContent = active.stage || t('stActive');
  $('liveElapsed').textContent = panelFormatEta((Date.now() - activeSeen.at) / 1000);
}

/* ---------------- rendering: items ---------------- */
function renderItems() {
  const thumbSig = Array.from(thumbLocal.keys()).sort().join(',');
  const sig = curLang + '|' + thumbSig + '|' + displayItems.map((i) => i.id + ':' + i.status + ':' + (i.stage || '') + ':' + (i.failReason ? 'F' : '')).join('|');
  if (sig === lastItemSig) return;
  lastItemSig = sig;
  const box = $('itemList');
  box.innerHTML = '';
  const frag = document.createDocumentFragment();
  const stKey = { pending: 'stPending', active: 'stActive', done: 'stDone', failed: 'stFailed', generated: 'stGenerated' };
  for (const it of displayItems) {
    const row = document.createElement('div');
    row.className = 'item';
    if (it.status === 'failed' && (it.failReason || it.note)) row.title = (it.failReason || it.note);
    const dot = document.createElement('span'); dot.className = 'dot ' + (it.status || 'pending');
    const id = document.createElement('span'); id.className = 'id'; id.textContent = it.id;
    row.appendChild(dot);
    row.appendChild(id);
    if (it.needsRef) { const b = document.createElement('span'); b.className = 'refbadge'; b.textContent = 'REF'; row.appendChild(b); }
    const pv = document.createElement('span'); pv.className = 'pv'; pv.textContent = it.prompt.slice(0, 90);
    if (it.status === 'failed' && (it.failReason || it.note)) pv.title = (it.failReason || it.note);
    row.appendChild(pv);
    const thumb = thumbLocal.get(it.id);
    if (thumb) { const im = document.createElement('img'); im.className = 'itemthumb'; im.src = thumb; im.alt = it.id; row.appendChild(im); }
    const st = document.createElement('span');
    st.className = 'st ' + (it.status || 'pending');
    st.textContent = (it.status === 'active' && it.stage) ? it.stage : t(stKey[it.status] || 'stPending');
    row.appendChild(st);
    if (it.status === 'failed') {
      // v2.4: single-item retry — regenerates ONLY this item; the
      // engine downloads it under this item's own ID (see retryOne).
      const rb = document.createElement('button');
      rb.className = 'btn small retryone';
      rb.textContent = t('retryOne');
      rb.addEventListener('click', async (ev) => {
        ev.stopPropagation();
        rb.disabled = true;
        const res = await send({ type: 'retryOne', itemId: it.id });
        if (res.ok) toast(t('toastRetryOk', { id: it.id }), 'success');
        else if (res.error === 'busy') toast(t('toastRetryBusy'), 'error');
        else toast(t('toastRetryFail', { id: it.id, msg: res.error || '' }), 'error');
        lastItemSig = '';
        await pollState(true);
      });
      row.appendChild(rb);
    }
    frag.appendChild(row);
  }
  box.appendChild(frag);
  requestThumbs();
}
async function requestThumbs() {
  const want = displayItems
    .filter((i) => (i.status === 'done' || i.status === 'generated') && !thumbLocal.has(i.id) && !thumbAsked.has(i.id))
    .map((i) => i.id);
  if (!want.length) return;
  want.forEach((id) => thumbAsked.add(id));
  const res = await send({ type: 'thumbs', ids: want });
  if (res.ok && res.thumbs) {
    let got = false;
    for (const id of Object.keys(res.thumbs)) { thumbLocal.set(id, res.thumbs[id]); got = true; }
    // Items the background has no thumbnail for: allow one later retry
    // (the fetch may still be in flight right after completion).
    setTimeout(() => { want.forEach((id) => { if (!thumbLocal.has(id)) thumbAsked.delete(id); }); }, 8000);
    if (got) { lastItemSig = ''; renderItems(); }
  }
}

/* ---------------- rendering: log / report ---------------- */
/* v2.5: log lines render as styled status rows — a green ✓ chip for
 * ok, red ✗ for failures, amber ! for warnings, green i for info.
 * The underlying log strings (engine + panel) are unchanged; only
 * the presentation is classified here. */
function classifyLogLine(line) {
  const s = String(line || '');
  if (s.indexOf('✓') !== -1) return 'ok';
  if (s.indexOf('✗') !== -1) return 'bad';
  if (/\bERROR\b|\bFAILED\b/.test(s)) return 'bad';
  const msg = s.replace(/^\[(engine|panel)\] \d{2}:\d{2}:\d{2}\s+/, '');
  if (msg.charAt(0) === '!' || msg.charAt(0) === '?') return 'warn';
  if (/SABDHAN|WARNING/.test(msg)) return 'warn';
  return 'info';
}
function renderLog(force) {
  const stateLog = (bgState && bgState.log) || [];
  const all = stateLog.concat(localLog.map((l) => '[panel] ' + l));
  const sig = all.length + ':' + all.reduce((a, l) => a + l.length, 0) + ':' + (all[all.length - 1] || '');
  if (!force && sig === lastLogSig) return;
  lastLogSig = sig;
  const box = $('logBox');
  box.innerHTML = '';
  const frag = document.createDocumentFragment();
  const glyph = { ok: '✓', bad: '✗', warn: '!', info: 'i' };
  for (const line of all) {
    const cls = classifyLogLine(line);
    const row = document.createElement('div');
    row.className = 'logrow ' + cls;
    const chip = document.createElement('span');
    chip.className = 'logchip';
    chip.textContent = glyph[cls];
    const tx = document.createElement('span');
    tx.className = 'logtext';
    tx.textContent = line;
    row.appendChild(chip);
    row.appendChild(tx);
    frag.appendChild(row);
  }
  box.appendChild(frag);
  box.scrollTop = box.scrollHeight;
}
function reportRow(label, val) {
  const d = document.createElement('div'); d.className = 'rrow';
  const a = document.createElement('span'); a.textContent = label;
  const b = document.createElement('b'); b.textContent = val;
  d.appendChild(a); d.appendChild(b);
  return d;
}
function idsLine(ids, cls) {
  const d = document.createElement('div'); d.className = 'ids' + (cls ? ' ' + cls : '');
  d.textContent = ids && ids.length ? ids.join(', ') : t('rNone');
  return d;
}
function renderReportSummary() {
  const box = $('reportSummary');
  if (!box) return;
  box.innerHTML = '';
  if (!displayItems.length) { box.textContent = t('reportEmpty'); return; }
  const c = itemCounts();
  box.appendChild(reportRow(t('rExpected'), String(c.total)));
  box.appendChild(reportRow(t('done'), String(c.done)));
  box.appendChild(reportRow(t('failed'), String(c.failed)));
  box.appendChild(reportRow(t('generated'), String(c.generated)));
  box.appendChild(reportRow(t('pending'), String(c.pending + c.active)));
}
function renderMatch() {
  const box = $('matchReport');
  if (!box) return;
  box.innerHTML = '';
  if (!matchData) return;
  const r = matchData;
  box.appendChild(reportRow(t('rExpected'), String(r.total)));
  box.appendChild(reportRow(t('rVerified'), String(r.verified.length)));
  box.appendChild(reportRow(t('rMissing'), String(r.missing.length)));
  if (r.missing.length) box.appendChild(idsLine(r.missing, 'miss'));
  box.appendChild(reportRow(t('rFailed'), String(r.failed.length)));
  if (r.failed.length) box.appendChild(idsLine(r.failed, 'miss'));
  box.appendChild(reportRow(t('rGenerated'), String(r.generated.length)));
  if (r.generated.length) box.appendChild(idsLine(r.generated, ''));
  box.appendChild(reportRow(t('rFlowNamed'), String(r.flowNamed.length)));
  if (r.flowNamed.length) {
    const d = document.createElement('div'); d.className = 'ids flow';
    d.textContent = r.flowNamed.map((f) => f.id + ' → ' + f.name).join(', ');
    box.appendChild(d);
  }
  $('copyMissingBtn').disabled = !r.missing.length;
}

/* ---------------- controls state ---------------- */
function syncControls() {
  const running = (!!(bgState && bgState.running) || bgLoopActive) && !engineStale;
  const paused = !!(bgState && bgState.paused);
  const hasItems = displayItems.length > 0;
  const hasFailed = displayItems.some((i) => i.status === 'failed');
  const incomplete = displayItems.some((i) => i.status === 'pending' || i.status === 'active');
  const refBlock = needsRefCount() > 0 && !$('refConfirm').checked && !refImageChosen();
  const videoBlock = !!(lastPreflight && lastPreflight.blocked);
  const resumable = (running && paused) || (!bgLoopActive && incomplete && bgState && bgState.runStartedAt) || (engineStale && incomplete);
  $('startBtn').disabled = !hasItems || running || refBlock || videoBlock;
  $('pauseBtn').disabled = !running || paused;
  $('resumeBtn').disabled = !resumable;
  $('stopBtn').disabled = !running;
  $('retryBtn').disabled = !hasFailed || running;
  $('skipBtn').disabled = !hasItems || running;
  $('fileInput').disabled = running;
  $('loadPasteBtn').disabled = running;
  $('downloadGeneratedBtn').disabled = running || !!(bgState && bgState.dlPass) ||
    !displayItems.some((i) => i.status === 'generated');
  const showBanner = (!bgLoopActive && incomplete && bgState && bgState.runStartedAt) || (engineStale && incomplete);
  $('resumeBanner').classList.toggle('hidden', !showBanner);
  $('resumeBanner').textContent = engineStale ? t('bannerStale') : t('bannerResume');
}
/* v2.4.1: the bottom bar no longer repeats status text (Done/Total,
 * engine state, current item — all of that lives in the top zone now).
 * Only the detach warning remains, rendered under the live card. */
function renderEngineStatus() {
  const dEl = $('detachStatus');
  if (!dEl) return;
  const dr = bgState ? (bgState.lastDetachReason || '') : '';
  if (dr) {
    dEl.textContent = dr === 'canceled_by_user' ? t('detachCanceled') : t('detachReason', { r: dr });
    dEl.classList.remove('hidden');
  } else {
    dEl.classList.add('hidden');
    dEl.textContent = '';
  }
}

/* ---------------- state polling ---------------- */
let wasRunning = false;
async function pollState(force) {
  const res = await send({ type: 'getState' });
  if (!res.ok) return;
  bgState = res.state;
  bgLoopActive = !!res.loopActive;
  const st = bgState;
  hydrateSettings(st.settings);
  engineStale = !!(st.running && !bgLoopActive && (!st.engineHeartbeat || Date.now() - st.engineHeartbeat > 30000));
  const idsMatch = st.items && st.items.length === displayItems.length &&
    st.items.every((it, k) => displayItems[k] && it.id === displayItems[k].id);
  if (adoptNext && idsMatch) { displayItems = st.items; adoptNext = false; syncRefRow(); }
  if (st.items && st.items.length && st.runStartedAt && st.runStartedAt >= lastImportAt) {
    displayItems = st.items;
    if (st.project && !$('projectName').value) $('projectName').value = st.project;
    sourceKind = sourceKind || 'storyboard';
    syncRefRow();
  }
  // Setup section: open while idle, closed while a run is going.
  const runningNow = !!st.running;
  if (runningNow !== wasRunning) {
    wasRunning = runningNow;
    $('setupSec').open = !runningNow;
  }
  // Natural finish → celebration + toast (once per run finish).
  const finAt = st.runFinishedAt || 0;
  if (lastFinishAt === null) lastFinishAt = finAt;
  else if (finAt !== lastFinishAt) {
    lastFinishAt = finAt;
    const doneN = (st.items || []).filter((i) => i.status === 'done').length;
    const failN = (st.items || []).filter((i) => i.status === 'failed').length;
    if (finAt > 0) {
      if (doneN > 0) { burstConfetti(); playChime(); }
      toast(t('toastRunDone', { done: doneN, failed: failN }), failN > 0 ? 'info' : 'success');
    }
  }
  // v2.4: Download-Later pass (panel button or the engine's automatic
  // end-of-run pass) finished → toast once, unless the button handler
  // just toasted it. "n" = generated items that left that status
  // during the pass.
  const dlNow = !!st.dlPass;
  const genNow = (st.items || []).filter((i) => i.status === 'generated').length;
  if (prevDlPass && !dlNow && Date.now() - dlToastAt > 3000) {
    const n = Math.max(0, prevGenCount - genNow);
    if (n > 0) { dlToastAt = Date.now(); toast(t('toastDlDone', { n }), 'success'); }
  }
  prevDlPass = dlNow;
  prevGenCount = genNow;
  renderItems();
  renderStatus();
  renderLive();
  renderLog();
  renderEngineStatus();
  syncControls();
}

/* ---------------- init ---------------- */
buildLangMenu();
renderParseInfo();
renderRefInfo();
renderCheckBtn();
syncControls();
try {
  chrome.storage.local.get(['sfa_lang', 'sfa_muted'], (got) => {
    if (got) {
      if (got.sfa_muted) { muted = true; $('soundBtn').textContent = '🔇'; }
      if (got.sfa_lang && STRINGS[got.sfa_lang]) setLang(got.sfa_lang);
    }
    applyLang();
  });
} catch (e) { applyLang(); }
setInterval(() => pollState(false), 1000);
pollState(true);
