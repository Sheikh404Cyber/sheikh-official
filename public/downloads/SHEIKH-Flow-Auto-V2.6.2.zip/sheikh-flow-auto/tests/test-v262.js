'use strict';
/* SHEIKH Flow Auto v2.6.2 unit tests.
   - Prompt matching (pure): promptNormText / promptExactMatch /
     promptOverlapScore / matchPromptToItems — exact, truncated
     (containment), token-overlap >= 0.85, boilerplate-tie = no
     confident match, unrelated = null.
   - serialTileVerdict: current / other (late leftover) / foreign,
     current item wins ties.
   - fdrTransition: freeze-drain-repair phase machine on scripted
     event sequences (failure freezes, drain, solo repair, resume;
     final-failure fast path back to normal).
   - pacedPromptAssign with a scripted viewer-read: out-of-order
     finishes still assign by prompt; unreadable tiles wait, then
     fall back to FIFO at round 3 with the verdict cache honoured;
     Count=2 quota (first downloads, second is an extra).
   - sfaTilePrompt probe is self-contained (evalFn contract).
   - Wiring: matchMode default 'prompt' + validation, panel Match
     mode pills + collect/hydrate, i18n keys x8, bigger pill CSS,
     manifest/panel 2.6.2.
   Run: node tests/test-v262.js */
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');

let pass = 0, fail = 0;
function ok(cond, label) {
  if (cond) { pass++; }
  else { fail++; console.log('FAIL: ' + label); }
}
function eq(a, b, label) { ok(JSON.stringify(a) === JSON.stringify(b), label + ` — got ${JSON.stringify(a)}, want ${JSON.stringify(b)}`); }

const bg = fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8');
const panel = fs.readFileSync(path.join(ROOT, 'panel.js'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'panel.html'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'panel.css'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.json'), 'utf8'));

function extractFn(srcText, name, asyncToo) {
  let start = srcText.indexOf('function ' + name + '(');
  if (asyncToo) {
    const a = srcText.indexOf('async function ' + name + '(');
    if (a !== -1 && (start === -1 || a < start)) start = a;
  }
  if (start === -1) throw new Error('function not found: ' + name);
  let i = srcText.indexOf('{', start);
  let depth = 0;
  for (; i < srcText.length; i++) {
    if (srcText[i] === '{') depth++;
    else if (srcText[i] === '}') { depth--; if (depth === 0) break; }
  }
  return srcText.slice(start, i + 1);
}
function revive(srcText, name, prelude, asyncToo) {
  return new Function('"use strict";\n' + (prelude || '') + extractFn(srcText, name, asyncToo) + '\nreturn ' + name + ';')();
}

const promptNormText = revive(bg, 'promptNormText');
const promptDeps = extractFn(bg, 'promptNormText') + '\n' + extractFn(bg, 'promptTokenSet') + '\n' +
  extractFn(bg, 'promptExactMatch') + '\n' + extractFn(bg, 'promptOverlapScore');
const promptExactMatch = revive(bg, 'promptExactMatch', extractFn(bg, 'promptNormText'));
const promptOverlapScore = revive(bg, 'promptOverlapScore', extractFn(bg, 'promptNormText') + '\n' + extractFn(bg, 'promptTokenSet'));
const matchPromptToItems = revive(bg, 'matchPromptToItems', promptDeps);
const serialTileVerdict = revive(bg, 'serialTileVerdict', promptDeps + '\n' + extractFn(bg, 'matchPromptToItems'));
const fdrTransition = revive(bg, 'fdrTransition');

/* ---------- prompt matching ---------- */
const BOILER = 'Editorial Economic Storybook illustration, ivory paper background, navy and charcoal ink, rust orange accents, muted green details, flat 2D hand-drawn style, no text in image';
const PA = 'A woman baker in a cream apron puts a tray of bread into a brick oven at sunrise. ' + BOILER;
const PB = 'A fisherman mends a torn net beside a wooden boat on a quiet harbour wall. ' + BOILER;
const CANDS = [{ id: '001A', prompt: PA }, { id: '002A', prompt: PB }];

{
  eq(promptNormText('  Hello,  WORLD! x2 '), 'hello world x2', 'norm: case/punct/space folded');
  ok(promptExactMatch(PA, PA.toUpperCase()), 'exact: identical modulo case');
  ok(promptExactMatch(PA.slice(0, 120), PA), 'exact: truncated viewer text contained in the sent prompt');
  ok(!promptExactMatch(PA.slice(0, 30), PA), 'exact: containment under 40 chars does not count');
  eq(matchPromptToItems(PB, CANDS).itemId, '002A', 'match: full text picks its own item over a boilerplate twin');
  eq(matchPromptToItems(PB, CANDS).how, 'exact', 'match: full text is an exact hit');
  // near-verbatim with a few words dropped -> token overlap, still its own item
  const dropped = PB.replace('torn ', '').replace('quiet ', '').replace('wooden ', '');
  const mDrop = matchPromptToItems(dropped, CANDS);
  ok(mDrop && mDrop.itemId === '002A' && mDrop.how === 'overlap', 'match: word-dropped text matches by overlap >= 0.85');
  ok(promptOverlapScore(dropped, PB) >= 0.85, 'overlap: dropped-words score reaches 0.85');
  // boilerplate alone fits BOTH prompts perfectly -> tie -> no confident match
  eq(matchPromptToItems(BOILER, CANDS), null, 'match: shared boilerplate alone is a tie -> null');
  eq(matchPromptToItems('quantum bananas dancing on a purple moon made of cheese', CANDS), null, 'match: unrelated text -> null');
  eq(matchPromptToItems('', CANDS), null, 'match: empty tile text -> null');
  eq(matchPromptToItems(PA, []), null, 'match: no candidates -> null');
  // single candidate: overlap just under the bar must not match
  const weak = 'baker oven bread tray sunrise cream apron woman puts into brick at a of the ' + 'zzq qzz xqq';
  ok(matchPromptToItems(weak, [{ id: '001A', prompt: PA }]) === null || promptOverlapScore(weak, PA) >= 0.85, 'match: single-candidate result respects the 0.85 bar');
}

/* ---------- serialTileVerdict ---------- */
{
  const cur = { id: '005A', prompt: PA };
  const others = [{ id: '003A', prompt: PB }];
  eq(serialTileVerdict(PA, cur, others).kind, 'current', 'serial verdict: own tile -> current');
  const vOther = serialTileVerdict(PB, cur, others);
  ok(vOther.kind === 'other' && vOther.itemId === '003A', 'serial verdict: late leftover -> other + its id');
  eq(serialTileVerdict('a completely different scene with pirates and treasure maps', cur, others).kind, 'foreign', 'serial verdict: readable but unsent -> foreign');
  // current priority: text exact for current even if an older prompt contains it too
  const container = { id: '001A', prompt: 'PREFIX ' + PA + ' SUFFIX' };
  eq(serialTileVerdict(PA, cur, [container]).kind, 'current', 'serial verdict: current item wins over a containing older prompt');
}

/* ---------- fdrTransition scripted sequences ---------- */
{
  // story: 3 in flight, one fails -> freeze; drain the rest; repair; resume
  let ph = 'normal';
  ph = fdrTransition(ph, 'tick', { pending: 3, repair: 0 });
  eq(ph, 'normal', 'fdr: tick in normal stays normal');
  ph = fdrTransition(ph, 'failure', {});
  eq(ph, 'draining', 'fdr: failure freezes sends (draining)');
  ph = fdrTransition(ph, 'failure', {});
  eq(ph, 'draining', 'fdr: second failure while draining changes nothing');
  ph = fdrTransition(ph, 'tick', { pending: 2, repair: 1 });
  eq(ph, 'draining', 'fdr: still draining while pending remain');
  ph = fdrTransition(ph, 'tick', { pending: 0, repair: 1 });
  eq(ph, 'repair', 'fdr: pending drained + repairs waiting -> repair');
  ph = fdrTransition(ph, 'failure', {});
  eq(ph, 'repair', 'fdr: failure during repair stays in repair');
  ph = fdrTransition(ph, 'tick', { pending: 0, repair: 1 });
  eq(ph, 'repair', 'fdr: repair continues while the queue is non-empty');
  ph = fdrTransition(ph, 'tick', { pending: 0, repair: 0 });
  eq(ph, 'normal', 'fdr: repair queue empty -> normal (sends resume)');
  // fast path: the failed item was already final (attempts spent) -> nothing to repair
  let ph2 = fdrTransition('normal', 'failure', {});
  ph2 = fdrTransition(ph2, 'tick', { pending: 0, repair: 0 });
  eq(ph2, 'normal', 'fdr: drained with no repairs -> straight back to normal');
  eq(fdrTransition('draining', 'bogus-event', { pending: 0, repair: 0 }), 'draining', 'fdr: unknown event leaves the phase alone');
  eq(fdrTransition(undefined, 'tick', {}), 'normal', 'fdr: missing phase defaults to normal');
}

/* ---------- pacedPromptAssign with a scripted viewer ---------- */
{
  const readPrelude = 'let stopRequested = false;\nfunction elog() {}\n' +
    'async function readTilePromptText(tabId, mid) { return globalThis.__sfaFakeRead(mid); }\n' + promptDeps + '\n' + extractFn(bg, 'matchPromptToItems') + '\n';
  const pacedPromptAssign = revive(bg, 'pacedPromptAssign', readPrelude, true);

  const mkItem = (id, prompt) => ({ id, prompt, tileGot: 0, quotaTile: null, extraNoted: false });
  const run = async () => {
    // out-of-order finish: B's tile arrives before A's, both in one poll
    const texts = { tB: PB, tA: PA };
    globalThis.__sfaFakeRead = async (mid) => ({ ok: true, text: texts[mid] || '' });
    const A = mkItem('001A', PA), B = mkItem('002A', PB);
    const pending = [A, B];
    const handled = new Set();
    const ctx = { fresh: [{ mediaId: 'tB' }, { mediaId: 'tA' }], pending, handled, genCount: 1, tileVerdicts: {}, verifyRounds: {} };
    const done = await pacedPromptAssign(0, ctx);
    eq(A.quotaTile && A.quotaTile.mediaId, 'tA', 'paced prompt: A gets A\'s tile even though B finished first');
    eq(B.quotaTile && B.quotaTile.mediaId, 'tB', 'paced prompt: B gets B\'s tile');
    eq(done.slice().sort(), ['001A', '002A'], 'paced prompt: both complete in the pass');
    ok(handled.has('tA') && handled.has('tB'), 'paced prompt: matched tiles are handled');

    // unreadable tile: waits rounds 1-2, FIFO fallback at round 3
    const C = mkItem('003A', 'prompt gamma unique words here');
    const pending2 = [C];
    const handled2 = new Set();
    const ctx2 = { fresh: [{ mediaId: 'tX' }], pending: pending2, handled: handled2, genCount: 1, tileVerdicts: {}, verifyRounds: {} };
    globalThis.__sfaFakeRead = async () => ({ ok: false, text: '' });
    let d = await pacedPromptAssign(0, ctx2);
    eq(d, [], 'paced prompt: unreadable tile completes nothing on round 1');
    ok(!handled2.has('tX'), 'paced prompt: unreadable tile is NOT consumed on round 1');
    d = await pacedPromptAssign(0, ctx2);
    eq(d, [], 'paced prompt: still waiting on round 2');
    d = await pacedPromptAssign(0, ctx2);
    eq(d, ['003A'], 'paced prompt: round 3 falls back to FIFO (oldest pending)');
    eq(C.quotaTile && C.quotaTile.mediaId, 'tX', 'paced prompt: fallback tile lands on the oldest pending item');

    // Count=2: two tiles of the same prompt — first is the download, second an extra
    const D = mkItem('004A', PA);
    const pending3 = [D];
    const ctx3 = { fresh: [{ mediaId: 'tD1' }, { mediaId: 'tD2' }], pending: pending3, handled: new Set(), genCount: 2, tileVerdicts: {}, verifyRounds: {} };
    globalThis.__sfaFakeRead = async () => ({ ok: true, text: PA });
    const d3 = await pacedPromptAssign(0, ctx3);
    eq(d3, ['004A'], 'paced prompt: Count=2 item completes when its quota fills');
    eq(D.quotaTile && D.quotaTile.mediaId, 'tD1', 'paced prompt: Count=2 first tile is the download');
    eq(D.tileGot, 2, 'paced prompt: Count=2 both tiles consumed by the item');
    ok(D.extraNoted, 'paced prompt: Count=2 extra is noted once');
  };
  run().then(() => {
    /* ---------- sfaTilePrompt probe self-containment ---------- */
    {
      const code = extractFn(bg, 'sfaTilePrompt');
      const forbidden = ['evalFn', 'scriptFn', 'cdp(', 'elog(', 'realClick', 'save(', 'beat(', 'chrome.', 'targetPath', 'attachedTabId', 'stopRequested', 'ABORT'];
      const bad = forbidden.filter((f) => code.includes(f));
      ok(bad.length === 0 && !/\bS\./.test(code), 'sfaTilePrompt is self-contained' + (bad.length ? ' (refs: ' + bad.join(',') + ')' : ''));
      let fn = null;
      try { fn = new Function('return (' + code + ')')(); } catch (e) { /* asserted below */ }
      ok(typeof fn === 'function', 'sfaTilePrompt revives standalone');
    }

    /* ---------- wiring ---------- */
    ok(bg.includes("matchMode: 'prompt'"), 'DEFAULT_SETTINGS: matchMode defaults to prompt');
    ok(bg.includes("obj.matchMode === 'prompt' || obj.matchMode === 'fast'"), 'applyDownloadSettings validates matchMode');
    ok(bg.includes('matchMode: prevDl.matchMode'), 'start handler preserves matchMode across runs');
    ok(bg.includes('async function readTilePromptText('), 'readTilePromptText exists');
    ok(bg.includes('async function pacedPromptAssign('), 'pacedPromptAssign exists');
    ok(bg.includes("typeof opts.verifyTile === 'function'"), 'waitForCompletion runs the verify hook');
    ok(bg.includes('serialTileVerdict(rd.text, item, others)'), 'serial processItem verdicts tiles by prompt');
    ok(bg.includes('const repairQueue = []') && bg.includes("fdrTransition(phase, 'tick'"), 'paced loop carries freeze-drain-repair');
    ok(bg.includes("matchMode === 'prompt'") && bg.includes("matchMode === 'fast'"), 'paced loop branches on matchMode');
    ok(html.includes('id="matchModePills"') && html.includes('data-mm="prompt"') && html.includes('data-mm="fast"'), 'panel: Match mode pills (Prompt check | Fast order)');
    ok(panel.includes('matchMode: matchModeSel'), 'panel: collect includes matchMode');
    ok(panel.includes("matchModeSel = s.matchMode === 'fast' ? 'fast' : 'prompt'"), 'panel: hydrate restores matchMode');
    eq((panel.match(/matchModeLabel:/g) || []).length, 8, 'i18n: matchModeLabel in all 8 languages');
    eq((panel.match(/matchModePrompt:/g) || []).length, 8, 'i18n: matchModePrompt in all 8 languages');
    eq((panel.match(/matchModeFast:/g) || []).length, 8, 'i18n: matchModeFast in all 8 languages');
    ok(css.includes('min-height: 34px'), 'css: pills are at least 34px tall');
    ok(css.includes('font-size: 13.5px'), 'css: pill labels are 13.5px');
    ok(css.includes('padding: 7px 20px'), 'css: pill padding widened');
    ok(css.includes('box-shadow: 0 4px 16px rgba(16, 185, 129, .5)'), 'css: selected pill has the green glow');
    ok(css.includes('.pill:hover { color: #fff; transform: translateY(-1px)'), 'css: unselected pills lift on hover');
    eq(manifest.version, '2.6.2', 'manifest version 2.6.2');
    ok(html.includes('class="vtag">v2.6.2'), 'panel shows v2.6.2');

    console.log(`\ntest-v262: ${pass} passed, ${fail} failed`);
    if (fail) process.exit(1);
    console.log('ALL TESTS PASSED');
  }).catch((e) => { console.log('FAIL: pacedPromptAssign simulation threw — ' + (e && e.stack || e)); process.exit(1); });
}
