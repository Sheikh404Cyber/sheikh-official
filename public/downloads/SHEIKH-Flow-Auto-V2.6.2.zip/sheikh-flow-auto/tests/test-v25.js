'use strict';
/* SHEIKH Flow Auto v2.5 unit tests.
   - Paced mode pure helpers extracted from background.js
     (pacedCompletedNew, pacedAssign, pacedErrorDelta,
     pacedIsTimedOut) driven through simulated watcher polls:
       A) tiles completing OUT OF ORDER still get assigned (and
          would download) in SEND order — FIFO by send order, with
          baseline + reference media-ids never matched;
       B) a NEW error tile consumes the oldest pending item as a
          failed attempt exactly once (baseline re-sync after the
          tile leaves, then a later error counts again);
       C) the 240s pending timeout boundary.
   - Panel: classifyLogLine (status-row chips) behaviour, run-mode
     pills + interval stepper markup, new i18n keys.
   - Theme: green system in panel.css (v2.6.1; no turquoise/violet leftovers),
     green Download-generated action, log-row styles.
   - Engine wiring (source level): runLoop branches on runMode,
     the paced loop reuses sendPromptOnce with enforceGap:false,
     settings carry runMode, manifest 2.5.0.
   Run: node tests/test-v25.js */
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');

let pass = 0, fail = 0;
function ok(cond, label) {
  if (cond) { pass++; }
  else { fail++; console.log('FAIL: ' + label); }
}
function eq(a, b, label) { ok(JSON.stringify(a) === JSON.stringify(b), label + ` — got ${JSON.stringify(a)}, want ${JSON.stringify(b)}`); }

const bg = fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8');
const panel = fs.readFileSync(path.join(ROOT, 'panel.js'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'panel.html'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'panel.css'), 'utf8');

function extractFn(srcText, name) {
  const start = srcText.indexOf('function ' + name + '(');
  if (start === -1) throw new Error('function not found: ' + name);
  let i = srcText.indexOf('{', start);
  let depth = 0;
  for (; i < srcText.length; i++) {
    if (srcText[i] === '{') depth++;
    else if (srcText[i] === '}') { depth--; if (depth === 0) break; }
  }
  return srcText.slice(start, i + 1);
}
function revive(srcText, name) {
  return new Function('"use strict";\n' + extractFn(srcText, name) + '\nreturn ' + name + ';')();
}
const pacedCompletedNew = revive(bg, 'pacedCompletedNew');
const pacedAssign = revive(bg, 'pacedAssign');
const pacedErrorDelta = revive(bg, 'pacedErrorDelta');
const pacedIsTimedOut = revive(bg, 'pacedIsTimedOut');
const classifyLogLine = revive(panel, 'classifyLogLine');

/* ---------- tile factories (sfaTiles shape) ---------- */
const img = (mediaId, extra) => Object.assign({ mediaId, kind: 'image', hasThumb: true, hasPct: false, pct: null, label: '', retryBtn: null, key: 'mid:' + mediaId }, extra || {});
const errTile = (n) => ({ mediaId: null, kind: 'error', hasThumb: false, hasPct: false, pct: null, label: 'Failed', retryBtn: { x: 1, y: 2 }, key: 'pos:e' + n });

/* ---------- pacedCompletedNew filtering ---------- */
{
  const tiles = [
    img('done1'),
    img('stillPct', { hasPct: true, pct: 42 }),
    img('noThumb', { hasThumb: false }),
    { mediaId: null, kind: 'image', hasThumb: true, hasPct: false },
    errTile(0),
    img('REF'),
    img('baseOld')
  ];
  const fresh = pacedCompletedNew(tiles, ['baseOld'], 'REF');
  eq(fresh.map((t) => t.mediaId), ['done1'], 'only the new finished image tile is fresh (pct/no-thumb/no-id/error/handled/ref excluded)');
  eq(pacedCompletedNew(null, [], null), [], 'null tiles -> empty');
  eq(pacedCompletedNew(tiles, ['baseOld', 'done1'], 'REF'), [], 'everything handled -> empty');
}

/* ---------- pacedAssign: FIFO pairing ---------- */
{
  // grid order is newest-first: [newerFinish, olderFinish]
  const pairs = pacedAssign(['A', 'B', 'C'], [img('newer'), img('older')]);
  eq(pairs.map((p) => [p.itemId, p.tile.mediaId]), [['A', 'older'], ['B', 'newer']],
    'oldest pending gets the OLDEST new tile (document order reversed)');
  eq(pacedAssign(['A'], [img('x'), img('y')]).length, 1, 'extra tiles stay unmatched this poll');
  eq(pacedAssign([], [img('x')]), [], 'no pending -> no pairs');
}

/* ---------- Scenario A: out-of-order completion, send-order downloads ----------
 * Mirrors runPacedLoop's watch step: handled set + pending queue of
 * ids; each poll assigns fresh tiles FIFO and records the download
 * assignment order. 002's generation finishes first, then 003's,
 * then 001's — the assignments must still come out 001, 002, 003. */
{
  const handled = new Set(['baseOld', 'REF']);
  let pending = ['001', '002', '003'];
  const downloads = [];
  const poll = (tiles) => {
    const fresh = pacedCompletedNew(tiles, Array.from(handled), 'REF');
    const pairs = pacedAssign(pending, fresh);
    for (const pr of pairs) {
      handled.add(pr.tile.mediaId);
      pending = pending.filter((id) => id !== pr.itemId);
      downloads.push([pr.itemId, pr.tile.mediaId]);
    }
  };
  // Poll 1: 002 finished (mB); 001 still generating (%); baseline + ref tiles sit complete in the grid.
  poll([img('mB'), img('mA', { hasPct: true, pct: 55 }), img('baseOld'), img('REF')]);
  eq(downloads, [['001', 'mB']], 'A1: first finished tile goes to the OLDEST sent item (001), not to its real owner');
  eq(pending, ['002', '003'], 'A1: 001 matched, 002/003 still pending');
  // Poll 2: 003 finished (mC); 001's tile still at %.
  poll([img('mC'), img('mA', { hasPct: true, pct: 80 }), img('mB'), img('baseOld'), img('REF')]);
  eq(downloads, [['001', 'mB'], ['002', 'mC']], 'A2: next finished tile goes to 002');
  // Poll 3: 001's own tile finally completes.
  poll([img('mA'), img('mC'), img('mB'), img('baseOld'), img('REF')]);
  eq(downloads, [['001', 'mB'], ['002', 'mC'], ['003', 'mA']], 'A3: downloads locked to send order 001,002,003 despite finish order B,C,A');
  eq(pending, [], 'A3: queue drained');
  ok(!downloads.some((d) => d[1] === 'baseOld' || d[1] === 'REF'), 'baseline + reference tiles were never assigned');
}

/* ---------- Scenario B: error tile consumes the oldest pending item ----------
 * Mirrors the loop's error bookkeeping: baseline count re-syncs every
 * poll; delta > 0 consumes oldest pending as a failed attempt; the
 * item (attempts 1/3) is re-queued AHEAD of unsent items. */
{
  let errBaseline = 0;
  const pending = ['001', '002'];
  const sendQueue = ['003'];
  const retryQueue = [];
  const attempts = { '001': 1, '002': 1 };
  const consume = (tiles) => {
    const ed = pacedErrorDelta(errBaseline, tiles);
    errBaseline = ed.now;
    const consumed = [];
    for (let k = 0; k < ed.delta; k++) {
      if (!pending.length) break;
      const victim = pending.shift();
      consumed.push(victim);
      if ((attempts[victim] || 0) < 3) retryQueue.unshift(victim);
    }
    return consumed;
  };
  eq(consume([img('x'), errTile(0)]), ['001'], 'B1: one new error tile consumes the oldest pending item (001)');
  eq(retryQueue, ['001'], 'B1: failed-attempt item re-queued for resend');
  ok(retryQueue[0] === '001' && sendQueue[0] === '003', 'B1: resend goes ahead of unsent items');
  eq(consume([img('x'), errTile(0)]), [], 'B2: the SAME error tile next poll is not consumed twice');
  eq(consume([img('x')]), [], 'B3: error tile gone (retried/cleared) — baseline re-syncs down, no consume');
  attempts['001'] = 2; pending.push('001'); // 001 re-sent -> joins the BACK of pending: ['002', '001']
  eq(consume([img('x'), errTile(1)]), ['002'], 'B4: a NEW error tile after re-sync consumes again — the oldest pending (002, sent before the 001 resend)');
  // attempts exhausted: 3 sends used -> no requeue (marked failed by the loop)
  attempts['002'] = 3;
  const qBefore = retryQueue.length;
  const ed = pacedErrorDelta(errBaseline, [errTile(1), errTile(2)]);
  eq(ed.delta, 1, 'B5: second simultaneous error tile yields delta 1 against the raised baseline');
}

/* ---------- Scenario C: timeout boundary ---------- */
{
  const t0 = 1000000;
  eq(pacedIsTimedOut(t0, t0 + 239999), false, 'C: 239.999s pending -> not timed out');
  eq(pacedIsTimedOut(t0, t0 + 240000), false, 'C: exactly 240s -> not timed out (needs > limit)');
  eq(pacedIsTimedOut(t0, t0 + 240001), true, 'C: 240.001s -> timed out');
  eq(pacedIsTimedOut(0, t0 + 9999999), false, 'C: never sent (sentAt 0) -> never timed out');
  eq(pacedIsTimedOut(null, t0 + 9999999), false, 'C: sentAt null -> never timed out');
  eq(pacedIsTimedOut(t0, t0 + 5001, 5000), true, 'C: custom limit honoured');
}

/* ---------- classifyLogLine: status-row chips ---------- */
{
  eq(classifyLogLine('[panel] 10:00:01  ✓ Flow project page is open'), 'ok', 'check line -> ok chip');
  eq(classifyLogLine('[panel] 10:00:01  ✗ Prompt input not found'), 'bad', 'cross line -> bad chip');
  eq(classifyLogLine('[panel] 10:00:01  ! Reference add (+) button not found'), 'warn', 'bang line -> warn chip');
  eq(classifyLogLine('[panel] 10:00:01  ? Mode is not certain'), 'warn', 'question line -> warn chip');
  eq(classifyLogLine('[engine] 10:00:02  001A: FAILED — Flow error'), 'bad', 'engine FAILED -> bad chip');
  eq(classifyLogLine('[engine] 10:00:02  ERROR: run theme gelo'), 'bad', 'engine ERROR -> bad chip');
  eq(classifyLogLine('[engine] 10:00:02  SABDHAN: reference mode select chilo'), 'warn', 'engine SABDHAN -> warn chip');
  eq(classifyLogLine('[engine] 10:00:02  Run shuru — project: X, mot 5 item'), 'info', 'plain engine line -> info chip');
  eq(classifyLogLine('[engine] 10:00:02  001A: done'), 'info', 'done line stays info (no false ok)');
}

/* ---------- engine wiring (source level) ---------- */
ok(bg.includes('async function runPacedLoop('), 'paced loop exists');
ok(/runMode === 'paced'\) \{\s*\n\s*await runPacedLoop\(/.test(bg), 'runLoop branches to the paced loop on runMode paced');
ok(bg.includes("runMode: 'serial'"), 'DEFAULT_SETTINGS defaults runMode to serial');
ok(/obj\.runMode === 'serial' \|\| obj\.runMode === 'paced'/.test(bg), 'applyDownloadSettings validates runMode');
ok(bg.includes('S.pacedBase'), 'paced baseline persisted in state (resume-safe)');
ok(bg.includes('async function sendPromptOnce('), 'sendPromptOnce factored out');
ok(/await sendPromptOnce\(tabId, item, sendCtx\)/.test(bg), 'serial processItem reuses sendPromptOnce');
ok(/sendPromptOnce\(tabId, item, \{ typeFails: 0 \}, \{ enforceGap: false \}\)/.test(bg), 'paced sends reuse sendPromptOnce without the internal gap (loop paces sends)');
for (const h of ['pacedCompletedNew(', 'pacedQuotaAssign(', 'pacedErrorDelta(', 'pacedIsTimedOut(']) {
  ok((bg.match(new RegExp(h.replace('(', '\\('), 'g')) || []).length >= 2, h + ' helper is used by the paced loop (not just defined)');
}
ok(/addEventListener\('click'/.test(panel) && panel.includes("type: 'retryOne'"), 'panel retryOne wiring untouched');

/* ---------- panel structure: run mode + interval ---------- */
ok(html.includes('id="runModePills"'), 'run mode segmented control exists');
ok(html.includes('data-m="serial"') && html.includes('data-m="paced"'), 'both run modes always present');
ok(html.includes('data-i18n="runModeSerial"') && html.includes('data-i18n="runModePaced"'), 'run mode labels are i18n keys');
ok(html.includes('id="ivMinus"') && html.includes('id="ivPlus"') && html.includes('id="ivVal"'), 'interval stepper markup exists');
for (const s of ['10', '30', '60', '90', '120']) {
  ok(html.includes('data-sec="' + s + '"'), 'interval preset chip ' + s + 's present');
}
ok(html.includes('data-i18n="intervalHint"'), 'interval one-line hint present');
ok(html.includes('<input type="hidden" id="intervalSec"'), 'intervalSec kept as hidden value store');
ok(!html.includes('type="number" id="intervalSec"'), 'raw number input is gone');
ok(html.includes('class="vtag">v2.6.2'), 'panel shows v2.6.2');
ok(html.includes('btn small dlgreen hidden'), 'Download generated carries the green action class');
ok(panel.includes('function classifyLogLine('), 'classifyLogLine exists in panel.js');
ok(panel.includes("row.className = 'logrow ' + cls"), 'renderLog builds status rows');
ok(!panel.includes("box.textContent = all.join"), 'log is no longer dumped as raw text');
ok(panel.includes('setIntervalUi'), 'stepper UI sync exists');
ok(panel.includes('runMode: runModeSel'), 'panel sends runMode with the download settings');

/* ---------- i18n: new keys ---------- */
const dictStart = panel.indexOf('const STRINGS = ');
const litStart = panel.indexOf('{', dictStart);
let depth = 0, litEnd = -1;
for (let i = litStart; i < panel.length; i++) {
  if (panel[i] === '{') depth++;
  else if (panel[i] === '}') { depth--; if (depth === 0) { litEnd = i; break; } }
}
const STRINGS = new Function('"use strict"; return (' + panel.slice(litStart, litEnd + 1) + ');')();
for (const k of ['runModeLabel', 'runModeSerial', 'runModePaced', 'intervalHint']) {
  ok(typeof STRINGS.en[k] === 'string' && STRINGS.en[k].length > 0, 'en has v2.5 key ' + k);
}
eq(STRINGS.en.runModeSerial, 'One by one', 'serial mode label is "One by one"');
eq(STRINGS.en.runModePaced, 'Paced', 'paced mode label is "Paced"');

/* ---------- theme: green system (v2.6.1; was violet in v2.5/v2.6) ---------- */
ok(css.includes('--acc: #34d399'), 'green accent variable');
ok(css.includes('--acc-deep: #059669'), 'deep green variable');
ok(css.includes('--hdr: #a8c3ae'), 'pale grey-green header variable');
ok(/h2 \{[^}]*color: var\(--hdr\)/.test(css), 'section headers use the pale grey-green');
ok(css.includes('--bg: #0a0a0f'), 'near-black neutral background (v2.6)');
ok(css.includes('.logrow') && css.includes('.logchip'), 'log status-row styles exist');
ok(css.includes('.logrow.ok .logchip') && css.includes('.logrow.bad .logchip') && css.includes('.logrow.warn .logchip'), 'ok/bad/warn chip styles exist');
ok(css.includes('.ivstep') && css.includes('.ivchip.sel'), 'stepper + preset chip styles exist');
ok(css.includes('.btn.dlgreen { background: linear-gradient(135deg, #22c55e, #16a34a)'), 'Download generated is the single green action');
ok(!css.includes('#0d9488') && !css.includes('#2dd4bf') && !css.includes('#14b8a6'), 'no turquoise leftovers in CSS');
ok(!bg.includes("'#0d9488'"), 'badge colour moved off turquoise');

/* ---------- manifest ---------- */
const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.json'), 'utf8'));
eq(manifest.version, '2.6.2', 'manifest version 2.6.2');

console.log(`\ntest-v25: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
