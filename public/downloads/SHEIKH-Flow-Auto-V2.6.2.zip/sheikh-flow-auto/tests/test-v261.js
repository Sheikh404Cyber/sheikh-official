'use strict';
/* SHEIKH Flow Auto v2.6.1 unit tests.
   - genClickVerdict: the containment gate for settings / clear /
     picker-opener clicks — grid points and destructive labels are
     refused, the required zone must match, a blind probe is refused.
   - refPresenceVerdict: reference survival — present by id, adopt by
     name, unknown when the probe is blind or the grid scan is
     capped, lost only on proven absence in a fully-scanned grid.
   - sfaPointCheck survives extraction standalone (evalFn contract).
   - Wiring: settings BEFORE the reference gate in runLoop; survival
     verify after the gate; recovery wired into attach (entry check +
     picker no-match path); every settings/clear/plus click goes
     through guardedClick; settings menu-close verification.
   - Theme: emerald green accent system, grey-green headers, badge
     green, Download-generated keeps its brighter green; no violet
     or cyan leftovers. Manifest/panel version 2.6.1.
   Run: node tests/test-v261.js */
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');

let pass = 0, fail = 0;
function ok(cond, label) {
  if (cond) { pass++; }
  else { fail++; console.log('FAIL: ' + label); }
}
function eq(a, b, label) { ok(JSON.stringify(a) === JSON.stringify(b), label + ` — got ${JSON.stringify(a)}, want ${JSON.stringify(b)}`); }

const bg = fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8');
const panel = fs.readFileSync(path.join(ROOT, 'panel.js'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'panel.html'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'panel.css'), 'utf8');

function extractFn(srcText, name) {
  const start = srcText.indexOf('function ' + name + '(');
  if (start === -1) throw new Error('function not found: ' + name);
  let i = srcText.indexOf('{', start);
  let depth = 0;
  for (; i < srcText.length; i++) {
    if (srcText[i] === '{') depth++;
    else if (srcText[i] === '}') { depth--; if (depth === 0) break; }
  }
  return srcText.slice(start, i + 1);
}
function revive(srcText, name, prelude) {
  return new Function('"use strict";\n' + (prelude || '') + extractFn(srcText, name) + '\nreturn ' + name + ';')();
}
const genClickVerdict = revive(bg, 'genClickVerdict');
const refPresenceVerdict = revive(bg, 'refPresenceVerdict');

/* ---------- genClickVerdict: containment gate ---------- */
{
  const base = { found: true, inGrid: false, inComposer: false, inOverlay: false, label: '', tag: 'DIV' };
  eq(genClickVerdict(null, { zone: 'composer' }).ok, false, 'null check (blind probe) is refused');
  eq(genClickVerdict({ found: false }, { zone: 'composer' }).ok, false, 'not-found point is refused');
  eq(genClickVerdict({ ...base, inGrid: true, inComposer: true }, { zone: 'composer' }).ok, false,
    'grid point refused even inside a composer-flagged element');
  eq(genClickVerdict({ ...base, inComposer: true, label: 'Move to bin' }, { zone: 'composer' }).ok, false,
    '"Move to bin" label refused');
  eq(genClickVerdict({ ...base, inOverlay: true, label: 'Delete' }, { zone: 'composerOrOverlay' }).ok, false,
    '"Delete" label refused in overlay zone');
  eq(genClickVerdict({ ...base, inComposer: true, label: 'Remove image' }, { zone: 'composer' }).ok, false,
    '"Remove" label refused');
  eq(genClickVerdict({ ...base, inComposer: true, label: 'Clear prompt' }, { zone: 'composer' }).ok, true,
    'Clear prompt inside the composer is allowed');
  eq(genClickVerdict({ ...base, inComposer: true, label: 'Add ingredients to the prompt box' }, { zone: 'composer' }).ok, true,
    'picker "+" inside the composer is allowed');
  eq(genClickVerdict({ ...base, inOverlay: true, label: 'Nano Banana 2.1' }, { zone: 'composerOrOverlay' }).ok, true,
    'menu option inside an open overlay is allowed for settings');
  eq(genClickVerdict({ ...base, inOverlay: true, label: 'Nano Banana 2.1' }, { zone: 'composer' }).ok, false,
    'overlay-only point refused when the composer zone is required');
  eq(genClickVerdict({ ...base, label: 'Nano Banana 2.1' }, { zone: 'composerOrOverlay' }).ok, false,
    'point outside composer AND overlay refused for settings');
  eq(genClickVerdict({ ...base, inComposer: true, label: 'x2' }, { zone: 'composerOrOverlay' }).ok, true,
    'count option on the composer chip is allowed');
  eq(genClickVerdict({ ...base, label: 'Somewhere' }, {}).ok, true,
    'no zone requirement: plain safe point allowed');
}

/* ---------- refPresenceVerdict: survival ---------- */
{
  const T = (mediaId, hasPct) => ({ mediaId, hasPct: !!hasPct });
  eq(refPresenceVerdict([], null, null), 'present', 'no recorded reference -> present (nothing to lose)');
  eq(refPresenceVerdict(null, null, 'm1'), 'unknown', 'blind tile probe -> unknown');
  eq(refPresenceVerdict([T('m1')], null, 'm1'), 'present', 'recorded id in grid -> present');
  eq(refPresenceVerdict([T('m1', true)], null, 'm1'), 'present', 'recorded id still processing -> present (existence, not readiness)');
  eq(refPresenceVerdict([T('m2')], { mediaId: 'm2' }, 'm1'), 'adopt', 'asset re-found by name -> adopt');
  eq(refPresenceVerdict([T('m2')], null, 'm1'), 'lost', 'small fully-scanned grid without the asset -> lost');
  const big = Array.from({ length: 60 }, (_, i) => T('g' + i));
  eq(refPresenceVerdict(big, null, 'm1'), 'unknown', 'capped 60-tile scan without the asset -> unknown (absence unprovable)');
  eq(refPresenceVerdict(big.slice(0, 59), null, 'm1'), 'lost', '59-tile scan without the asset -> lost');
  eq(refPresenceVerdict([], { mediaId: 'm9' }, 'm1'), 'adopt', 'empty grid but name lookup hits -> adopt');
}

/* ---------- sfaPointCheck is self-contained (evalFn contract) ---------- */
{
  const forbidden = ['evalFn', 'scriptFn', 'cdp(', 'elog(', 'realClick', 'save(', 'beat(', 'sleep(', 'chrome.', 'targetPath', 'upgradeUrl', 'attachedTabId', 'stopRequested', 'ABORT'];
  const code = extractFn(bg, 'sfaPointCheck');
  const bad = forbidden.filter((f) => code.includes(f));
  ok(bad.length === 0 && !/\bS\./.test(code), 'sfaPointCheck is self-contained' + (bad.length ? ' (refs: ' + bad.join(',') + ')' : ''));
  let fn = null;
  try { fn = new Function('return (' + code + ')')(); } catch (e) { /* asserted below */ }
  ok(typeof fn === 'function', 'sfaPointCheck revives standalone');
}

/* ---------- wiring: reorder + guards + recovery ---------- */
{
  ok(bg.indexOf('await applyGenerationSettings(tab.id)') < bg.indexOf('await ensureReference(tab.id)'),
    'runLoop: settings-apply runs BEFORE the reference gate');
  ok(bg.includes('refPresentInProject(tab.id)'), 'survival check is wired (runLoop + attach)');
  ok(bg.includes("elog('Reference lost — re-uploaded')"), 'recovery logs the short line');
  ok((bg.match(/await recoverReference\(tab/g) || []).length >= 3,
    'recoverReference is called from runLoop verify, attach entry and picker no-match paths');
  ok(bg.includes('async function guardedClick('), 'guardedClick exists');
  ok(bg.includes('guardedClick(tabId, chip.open.x'), 'settings chip click is guarded');
  ok(bg.includes('guardedClick(tabId, c2.open.x'), 'settings menu re-open click is guarded');
  ok(bg.includes('guardedClick(tabId, opt.x'), 'settings option clicks are guarded');
  ok(bg.includes('guardedClick(tabId, bar.clear.x'), '"Clear prompt" click is guarded');
  ok(bg.includes('guardedClick(tabId, bar.plus.x'), 'picker "+" click is guarded');
  const settings = extractFn(bg, 'applyGenerationSettings');
  ok(!settings.includes('realClick('), 'applyGenerationSettings contains NO unguarded realClick');
  ok(settings.includes('leftover'), 'settings menu-close (leftover) verification exists');
  const clear = extractFn(bg, 'clearComposerAfterUpload');
  ok(clear.includes('guardedClick') && clear.includes('clearFocusedInput'),
    'clear-composer uses the guarded click and keeps the Ctrl+A fallback');
  const attach = extractFn(bg, 'attachRefFromProject');
  ok(attach.includes('refPresentInProject') && attach.includes('recoverReference'),
    'attach runs the survival check and the recovery path');
  ok(attach.includes('guardedClick'), 'attach "+" click is guarded');
}

/* ---------- theme: green system ---------- */
{
  ok(css.includes('--acc: #34d399'), 'emerald accent variable');
  ok(css.includes('--acc-strong: #10b981'), 'emerald strong variable');
  ok(css.includes('--acc-deep: #059669'), 'emerald deep variable');
  ok(css.includes('--acc-hi: #6ee7b7'), 'emerald highlight variable');
  ok(css.includes('--accSoft: rgba(16, 185, 129, .16)'), 'emerald soft wash variable');
  ok(css.includes('--hdr: #a8c3ae'), 'soft grey-green header variable');
  ok(css.includes('--bg: #0a0a0f') && css.includes('--card: #131318'), 'neutral near-black base unchanged');
  ok(css.includes('.btn.primary { background: linear-gradient(135deg, #10b981, #059669)'), 'Start uses the emerald gradient');
  ok(css.includes('.btn.dlgreen { background: linear-gradient(135deg, #22c55e, #16a34a)'),
    'Download-generated keeps its brighter distinct green');
  for (const hex of ['#a78bfa', '#8b5cf6', '#7c3aed', '#c4b5fd', '#a5f3fc', '#9d6bff']) {
    ok(!css.includes(hex), 'no violet/cyan leftover in CSS: ' + hex);
  }
  ok(!css.includes('139, 92, 246') && !css.includes('124, 58, 237'), 'no violet rgba leftovers in CSS');
  ok(bg.includes("setBadgeBackgroundColor({ color: '#059669' })"), 'toolbar badge uses the emerald green');
  ok(!bg.includes("'#7c3aed'"), 'no violet badge colour left in the engine');
  ok(panel.includes("'#34d399'") && !panel.includes('#a78bfa') && !panel.includes('#f0abfc'),
    'confetti colours are green-family');
}

/* ---------- version ---------- */
{
  const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.json'), 'utf8'));
  eq(manifest.version, '2.6.2', 'manifest version 2.6.2');
  ok(html.includes('class="vtag">v2.6.2'), 'panel shows v2.6.2');
}

console.log(`\ntest-v261: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
