'use strict';
/* SHEIKH Flow Auto v2.4 unit tests.
   - i18n: compact/expand keys REMOVED in all 8 languages; the v2.4
     key set present and identical across all 8 languages.
   - Panel structure: app-shell zones (top holds header + status card,
     bottom bar holds every run button + Help in its bar, no footer,
     no compact remnant), verdict-on-button check (no results list),
     custom ref dropdown with a hidden native select, flag <img>
     wiring for all 8 languages, drag & drop + toast code present.
   - v2.4.1: accent picker REMOVED (no swatches, no sfa_accent, no
     data-accent themes, 'accent' key gone); the bottom bar carries
     NO repeated status text (no Done/Total line, no version text,
     no engine line, no current-item line); ambient animation hooks
     present (logo glow, ring sweep, Start breathing, load stagger).
   - Flags + fonts bundled on disk; manifest version (2.6.1 since v2.6.1).
   - Engine: badge helper (pure) + retryOne handler present, and the
     loop-active refusal is asserted at source level to run BEFORE
     any processItem call inside retryOneItem.
   Run: node tests/test-v24.js */
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');

let pass = 0, fail = 0;
function ok(cond, label) {
  if (cond) { pass++; }
  else { fail++; console.log('FAIL: ' + label); }
}
function eq(a, b, label) { ok(JSON.stringify(a) === JSON.stringify(b), label + ` — got ${JSON.stringify(a)}, want ${JSON.stringify(b)}`); }

/* ---------- load STRINGS from panel.js ---------- */
const panel = fs.readFileSync(path.join(ROOT, 'panel.js'), 'utf8');
const dictStart = panel.indexOf('const STRINGS = ');
ok(dictStart !== -1, 'panel.js has STRINGS dictionary');
const litStart = panel.indexOf('{', dictStart);
let depth = 0, litEnd = -1;
for (let i = litStart; i < panel.length; i++) {
  if (panel[i] === '{') depth++;
  else if (panel[i] === '}') { depth--; if (depth === 0) { litEnd = i; break; } }
}
const STRINGS = new Function('"use strict"; return (' + panel.slice(litStart, litEnd + 1) + ');')();
const langCodes = Object.keys(STRINGS).sort();
eq(langCodes, ['bn', 'de', 'en', 'es', 'fr', 'hi', 'it', 'tr'], 'exactly 8 languages');
const enKeys = Object.keys(STRINGS.en).sort();
for (const code of langCodes) {
  eq(Object.keys(STRINGS[code]).sort(), enKeys, 'language "' + code + '" matches the English key set');
  ok(!('compact' in STRINGS[code]), code + ': compact key removed');
  ok(!('expand' in STRINGS[code]), code + ': expand key removed');
  ok(!('accent' in STRINGS[code]), code + ': accent key removed (v2.4.1, picker gone)');
  for (const gone of ['progressLine', 'engRunning', 'engStopped', 'engStalled', 'engUnknown', 'currentLine']) {
    ok(!(gone in STRINGS[code]), code + ': bottom-bar status key ' + gone + ' removed (v2.4.1)');
  }
}
const NEW_KEYS = ['checkAllGood', 'checkShortFlow', 'checkShortInput', 'checkShortSend',
  'checkShortPlus', 'checkShortAgent', 'checkShortMode', 'endsAt', 'dropToImport',
  'chooseFile', 'noFileChosen', 'retryOne', 'toastRunDone', 'toastDlDone',
  'toastRetryOk', 'toastRetryFail', 'toastRetryBusy', 'toastImportOk', 'toastImportFail',
  'toastCheckFail'];
for (const k of NEW_KEYS) ok(typeof STRINGS.en[k] === 'string' && STRINGS.en[k].length > 0, 'en has new key ' + k);

/* ---------- panel.html structure ---------- */
const html = fs.readFileSync(path.join(ROOT, 'panel.html'), 'utf8');
const topStart = html.indexOf('id="topZone"');
const scrollStart = html.indexOf('id="scrollBody"');
const bottomStart = html.indexOf('id="bottomBar"');
ok(topStart !== -1 && scrollStart !== -1 && bottomStart !== -1, 'app-shell zones exist');
ok(topStart < scrollStart && scrollStart < bottomStart, 'zones in order: top < scroll < bottom');
const topZone = html.slice(topStart, scrollStart);
const bottomBar = html.slice(bottomStart);
ok(topZone.includes('id="logoImg"'), 'top zone has the header logo');
ok(topZone.includes('id="statusCard"'), 'top zone has the status/count card');
ok(topZone.includes('id="langFlagImg"'), 'top zone language button uses a flag <img>');
/* accent picker fully removed — one fixed theme (turquoise in v2.4.1, violet since v2.5) */
ok(!html.includes('accentRow') && !html.includes('swatch'), 'no accent swatches in HTML (v2.4.1)');
ok(!panel.includes('sfa_accent'), 'no sfa_accent setting in panel.js (v2.4.1)');
ok(!panel.includes('setAccent') && !panel.includes('accentSel'), 'no accent JS in panel.js (v2.4.1)');
for (const id of ['startBtn', 'pauseBtn', 'resumeBtn', 'stopBtn', 'retryBtn', 'skipBtn', 'clearBtn', 'downloadGeneratedBtn', 'resumeBanner']) {
  ok(bottomBar.includes('id="' + id + '"'), 'bottom bar contains ' + id);
}
/* v2.4.1: bottom bar carries ONLY controls — no repeated status text */
ok(!bottomBar.includes('id="progress"'), 'no Done/Total line in the bottom bar (v2.4.1)');
ok(!bottomBar.includes('footver') && !bottomBar.includes('SHEIKH Flow Auto v2'), 'no version text in the bottom bar (v2.4.1)');
ok(!bottomBar.includes('id="engineStatus"'), 'no engine line in the bottom bar (v2.4.1)');
ok(!bottomBar.includes('id="currentItem"'), 'no current-item line in the bottom bar (v2.4.1)');
ok(topZone.includes('id="detachStatus"'), 'detach warning lives in the top zone (v2.4.1)');
ok(bottomBar.includes('id="helpLink"'), 'Help link is inside the bottom bar');
ok(bottomBar.includes('https://web.facebook.com/AMIN.SHEIKH.404'), 'Help link URL unchanged');
ok(!html.includes('<footer'), 'no footer element remains');
ok(!html.includes('compactBtn') && !html.includes('compactControls'), 'no compact controls in HTML');
ok(!panel.includes("$('compactBtn')") && !panel.includes('sfa_compact') && !panel.includes('compacted'), 'no compact logic in panel.js');
const css = fs.readFileSync(path.join(ROOT, 'panel.css'), 'utf8');
ok(!/body\.compact|\.compactcontrols/.test(css), 'no compact CSS remains');
ok(html.includes('id="checkBtn"'), 'check button exists');
ok(!html.includes('id="checkResults"'), 'no preflight results list in HTML');
ok(!panel.includes("$('checkResults')"), 'panel.js no longer renders a results list');
ok(panel.includes('renderCheckBtn'), 'verdict-on-button renderer exists');
ok(html.includes('<select id="refMode" class="hidden"'), 'refMode native select is hidden (kept as value store)');
ok(html.includes('id="refModeDD"') && html.includes('id="refModeMenu"') && html.includes('id="refModeBtn"'), 'custom dropdown markup present');
ok(html.includes('id="dropOverlay"'), 'drop overlay present');
ok(panel.includes('dropToImport') && panel.includes("addEventListener('drop'"), 'drag & drop import wired');
ok(panel.includes('function toast('), 'toast system present');
ok(panel.includes("type: 'retryOne'"), 'panel sends retryOne for failed rows');
ok(html.includes('id="statEnds"'), 'finish clock-time element present');
ok(css.includes("'Inter'"), 'Inter in the font stack');
ok(css.includes('Hind Siliguri') && css.includes('Noto Sans Bengali'), 'Bengali fallbacks in the font stack');
ok(css.includes('prefers-reduced-motion'), 'reduced-motion support in CSS');
/* v2.4.1: one fixed theme + visible ambient animation */
ok(!css.includes('data-accent'), 'no data-accent themes in CSS (v2.4.1)');
ok(!css.includes('.swatch') && !css.includes('.accents'), 'no swatch CSS remains (v2.4.1)');
ok(!css.includes('.runmeta') && !css.includes('.footver'), 'no bottom-bar meta CSS remains (v2.4.1)');
ok(css.includes('@keyframes logoglow') && css.includes('logoglow 2.4s'), 'logo glow pulse animation present (v2.4.1)');
ok(html.includes('class="ringshim"'), 'ring shimmer element present (v2.4.1)');
ok(css.includes('.ringshim') && css.includes('@keyframes ringspin') && css.includes('body.running .ringshim'), 'ring sweep rotates while running (v2.4.1)');
ok(css.includes('@keyframes startbreathe') && css.includes('body:not(.running) #startBtn'), 'Start button breathes while idle (v2.4.1)');
ok(css.includes('#scrollBody > .card:nth-child(2)') && css.includes('animation-delay: .04s'), 'load stagger delays present (v2.4.1)');
ok(css.includes('.btn.primary { background: linear-gradient(135deg, #10b981, #059669)'), 'Start uses the green gradient fill (v2.6.1 theme)');
ok(css.includes('.btn.danger { background: #262626; border-color: #b04040; color: #ff8585'), 'Stop is dark with red border/text, not solid red (v2.4.1)');
ok(css.includes('#bottomBar .subrow .btn { background: transparent'), 'secondary buttons are ghost style (v2.4.1)');

/* ---------- flags + fonts on disk, picker wiring ---------- */
for (const f of ['gb', 'bd', 'in', 'tr', 'fr', 'de', 'it', 'es']) {
  const p = path.join(ROOT, 'assets', 'flags', f + '.svg');
  ok(fs.existsSync(p), 'flag bundled: assets/flags/' + f + '.svg');
  if (fs.existsSync(p)) ok(fs.readFileSync(p, 'utf8').includes('<svg'), f + '.svg is an SVG');
  ok(panel.includes("flagFile: '" + f + "'"), 'panel LANGS wires flag ' + f);
}
ok(panel.includes('assets/flags/'), 'panel builds flag <img> srcs from assets/flags/');
ok(!/flag: '🇬🇧'|flag: '🇧🇩'/.test(panel), 'no flag emoji used as picker data');
for (const w of [400, 500, 600, 700]) {
  ok(fs.existsSync(path.join(ROOT, 'assets', 'fonts', 'Inter-' + w + '.woff2')), 'Inter ' + w + ' bundled');
  ok(css.includes('Inter-' + w + '.woff2'), 'CSS @font-face references Inter ' + w);
}

/* ---------- manifest ---------- */
const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.json'), 'utf8'));
eq(manifest.version, '3.0.0', 'manifest version 3.0.0');

/* ---------- engine: badge + retryOne ---------- */
const bg = fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8');
ok(bg.includes('chrome.action.setBadgeText'), 'badge: setBadgeText used');
ok(bg.includes('chrome.action.setBadgeBackgroundColor'), 'badge: background color set');
{
  const start = bg.indexOf('function badgePctFor(');
  ok(start !== -1, 'badgePctFor helper exists');
  let i = bg.indexOf('{', start), d = 0;
  for (; i < bg.length; i++) { if (bg[i] === '{') d++; else if (bg[i] === '}') { d--; if (d === 0) break; } }
  const badgePctFor = new Function('"use strict";\n' + bg.slice(start, i + 1) + '\nreturn badgePctFor;')();
  eq(badgePctFor(false, 5, 0, 10), -1, 'badge hidden when idle');
  eq(badgePctFor(true, 0, 0, 0), -1, 'badge hidden with no items');
  eq(badgePctFor(true, 5, 0, 10), 50, 'badge 50% done');
  eq(badgePctFor(true, 4, 1, 12), 41, 'badge counts generated too (floor)');
  eq(badgePctFor(true, 10, 0, 10), 100, 'badge 100%');
}
ok(bg.includes("case 'retryOne':"), 'retryOne message case exists');
ok(bg.includes('retryOneItem'), 'retryOneItem implemented');
{
  const start = bg.indexOf('async function retryOneItem(');
  ok(start !== -1, 'retryOneItem function found');
  const body = bg.slice(start, start + 7000);
  const guardAt = body.indexOf('if (loopActive');
  const processAt = body.indexOf('processItem(');
  ok(guardAt !== -1, 'retryOne refuses while loopActive (guard present)');
  ok(processAt !== -1, 'retryOne calls processItem');
  ok(guardAt !== -1 && processAt !== -1 && guardAt < processAt, 'busy refusal runs BEFORE any processItem call');
  ok(body.includes("error: 'busy'"), 'busy refusal returns the busy error the panel toasts');
  ok(body.includes('ensureReference'), 'retryOne ensures the reference first');
  ok(body.includes('terminalStatusFor'), 'retryOne uses the single advance decision (Download Later semantics)');
  ok(body.includes("elog('Retry ' + item.id"), 'retryOne logs Retry <id> lines');
  // Numbering integrity: the retried item is looked up by its own ID
  // and is the only item written in the flow.
  ok(body.includes("S.items.find((i) => i.id === itemId)"), 'retryOne targets exactly the requested item ID');
}
ok(bg.includes('retryOneActive'), 'retryOneActive re-entry guard exists');

console.log(`\ntest-v24: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
