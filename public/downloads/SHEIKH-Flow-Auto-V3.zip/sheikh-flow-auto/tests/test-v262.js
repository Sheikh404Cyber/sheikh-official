'use strict';
/* SHEIKH Flow Auto v2.6.2 unit tests.
   - Prompt matching (pure): promptNormText / promptExactMatch /
     promptOverlapScore / matchPromptToItems — exact, truncated
     (containment), token-overlap >= 0.85, boilerplate-tie = no
     confident match, unrelated = null.
   - serialTileVerdict: current / other (late leftover) / foreign,
     current item wins ties.
   - fdrTransition: freeze-drain-repair phase machine on scripted
     event sequences (failure freezes, drain, solo repair, resume;
     final-failure fast path back to normal).
   - pacedPromptAssign with a scripted viewer-read: out-of-order
     finishes still assign by prompt; unreadable tiles wait, then
     fall back to FIFO at round 3 with the verdict cache honoured;
     Count=2 quota (first downloads, second is an extra).
   - sfaTilePrompt probe is self-contained (evalFn contract).
   - Wiring: matchMode default 'prompt' + validation, panel Match
     mode pills + collect/hydrate, i18n keys x8, bigger pill CSS,
     manifest/panel 2.6.2.
   Run: node tests/test-v262.js */
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');

let pass = 0, fail = 0;
function ok(cond, label) {
  if (cond) { pass++; }
  else { fail++; console.log('FAIL: ' + label); }
}
function eq(a, b, label) { ok(JSON.stringify(a) === JSON.stringify(b), label + ` — got ${JSON.stringify(a)}, want ${JSON.stringify(b)}`); }

const bg = fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8');
const panel = fs.readFileSync(path.join(ROOT, 'panel.js'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'panel.html'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'panel.css'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.json'), 'utf8'));

function extractFn(srcText, name, asyncToo) {
  let start = srcText.indexOf('function ' + name + '(');
  if (asyncToo) {
    const a = srcText.indexOf('async function ' + name + '(');
    if (a !== -1 && (start === -1 || a < start)) start = a;
  }
  if (start === -1) throw new Error('function not found: ' + name);
  let i = srcText.indexOf('{', start);
  let depth = 0;
  for (; i < srcText.length; i++) {
    if (srcText[i] === '{') depth++;
    else if (srcText[i] === '}') { depth--; if (depth === 0) break; }
  }
  return srcText.slice(start, i + 1);
}
function revive(srcText, name, prelude, asyncToo) {
  return new Function('"use strict";\n' + (prelude || '') + extractFn(srcText, name, asyncToo) + '\nreturn ' + name + ';')();
}

const promptNormText = revive(bg, 'promptNormText');
const promptDeps = extractFn(bg, 'promptNormText') + '\n' + extractFn(bg, 'promptTokenSet') + '\n' +
  extractFn(bg, 'promptExactMatch') + '\n' + extractFn(bg, 'promptOverlapScore');
const promptExactMatch = revive(bg, 'promptExactMatch', extractFn(bg, 'promptNormText'));
const promptOverlapScore = revive(bg, 'promptOverlapScore', extractFn(bg, 'promptNormText') + '\n' + extractFn(bg, 'promptTokenSet'));
const matchPromptToItems = revive(bg, 'matchPromptToItems', promptDeps);
const serialTileVerdict = revive(bg, 'serialTileVerdict', promptDeps + '\n' + extractFn(bg, 'matchPromptToItems'));

/* ---------- prompt matching ---------- */
const BOILER = 'Editorial Economic Storybook illustration, ivory paper background, navy and charcoal ink, rust orange accents, muted green details, flat 2D hand-drawn style, no text in image';
const PA = 'A woman baker in a cream apron puts a tray of bread into a brick oven at sunrise. ' + BOILER;
const PB = 'A fisherman mends a torn net beside a wooden boat on a quiet harbour wall. ' + BOILER;
const CANDS = [{ id: '001A', prompt: PA }, { id: '002A', prompt: PB }];

{
  eq(promptNormText('  Hello,  WORLD! x2 '), 'hello world x2', 'norm: case/punct/space folded');
  ok(promptExactMatch(PA, PA.toUpperCase()), 'exact: identical modulo case');
  ok(promptExactMatch(PA.slice(0, 120), PA), 'exact: truncated viewer text contained in the sent prompt');
  ok(!promptExactMatch(PA.slice(0, 30), PA), 'exact: containment under 40 chars does not count');
  eq(matchPromptToItems(PB, CANDS).itemId, '002A', 'match: full text picks its own item over a boilerplate twin');
  eq(matchPromptToItems(PB, CANDS).how, 'exact', 'match: full text is an exact hit');
  // near-verbatim with a few words dropped -> token overlap, still its own item
  const dropped = PB.replace('torn ', '').replace('quiet ', '').replace('wooden ', '');
  const mDrop = matchPromptToItems(dropped, CANDS);
  ok(mDrop && mDrop.itemId === '002A' && mDrop.how === 'overlap', 'match: word-dropped text matches by overlap >= 0.85');
  ok(promptOverlapScore(dropped, PB) >= 0.85, 'overlap: dropped-words score reaches 0.85');
  // boilerplate alone fits BOTH prompts perfectly -> tie -> no confident match
  eq(matchPromptToItems(BOILER, CANDS), null, 'match: shared boilerplate alone is a tie -> null');
  eq(matchPromptToItems('quantum bananas dancing on a purple moon made of cheese', CANDS), null, 'match: unrelated text -> null');
  eq(matchPromptToItems('', CANDS), null, 'match: empty tile text -> null');
  eq(matchPromptToItems(PA, []), null, 'match: no candidates -> null');
  // single candidate: overlap just under the bar must not match
  const weak = 'baker oven bread tray sunrise cream apron woman puts into brick at a of the ' + 'zzq qzz xqq';
  ok(matchPromptToItems(weak, [{ id: '001A', prompt: PA }]) === null || promptOverlapScore(weak, PA) >= 0.85, 'match: single-candidate result respects the 0.85 bar');
}

/* ---------- serialTileVerdict ---------- */
{
  const cur = { id: '005A', prompt: PA };
  const others = [{ id: '003A', prompt: PB }];
  eq(serialTileVerdict(PA, cur, others).kind, 'current', 'serial verdict: own tile -> current');
  const vOther = serialTileVerdict(PB, cur, others);
  ok(vOther.kind === 'other' && vOther.itemId === '003A', 'serial verdict: late leftover -> other + its id');
  eq(serialTileVerdict('a completely different scene with pirates and treasure maps', cur, others).kind, 'foreign', 'serial verdict: readable but unsent -> foreign');
  // current priority: text exact for current even if an older prompt contains it too
  const container = { id: '001A', prompt: 'PREFIX ' + PA + ' SUFFIX' };
  eq(serialTileVerdict(PA, cur, [container]).kind, 'current', 'serial verdict: current item wins over a containing older prompt');
}

/* ---------- v3: freeze-drain-repair is DELETED ---------- */
{
  ok(!bg.includes('function fdrTransition('), 'v3: fdrTransition deleted (no freeze/repair phases)');
  ok(!bg.includes('repairQueue'), 'v3: no repair queue in the paced loop');
  ok(!bg.includes('function pacedPromptAssign('), 'v3: pacedPromptAssign deleted (FIFO fallback included)');
}

/* ---------- v3: pickAttributions (catalog-prompt attribution) ----------
 * The v2.6.2 scripted-viewer scenarios, re-expressed against the V3
 * mechanism: rows carry their prompt from the project listing, so
 * attribution needs no viewer at all in the main path. The FIFO
 * fallback scenario is replaced by its negation: an unverifiable row
 * is NEVER order-paired. */
{
  const pickAttributions = revive(bg, 'pickAttributions', promptDeps + '\n' + extractFn(bg, 'matchPromptToItems'));
  const row = (uuid, prompt, createdAt) => ({ uuid, prompt, kind: 'image', createdAt: createdAt || 0 });

  // out-of-order finish: B's row is newer, both arrive in one pass
  const res = pickAttributions(
    [row('tB', PB, 2000), row('tA', PA, 1000)],
    [{ id: '001A', prompt: PA, got: 0, quota: 1 }, { id: '002A', prompt: PB, got: 0, quota: 1 }]);
  eq(res.assign.map((a) => [a.itemId, a.uuid]).sort(), [['001A', 'tA'], ['002A', 'tB']],
    'v3 attribution: each row lands on its prompt owner, finish order irrelevant');
  eq(res.unverified, [], 'v3 attribution: nothing unverified when prompts are present');

  // prompt-less row: unverified - parked by the engine, never paired
  const res2 = pickAttributions([row('tX', '', 3000)], [{ id: '003A', prompt: 'prompt gamma unique words here', got: 0, quota: 1 }]);
  eq(res2.assign, [], 'v3 attribution: prompt-less row is assigned to NOBODY (no FIFO fallback)');
  eq(res2.unverified.map((r) => r.uuid), ['tX'], 'v3 attribution: prompt-less row comes back unverified for the ladder');

  // Count=2: two rows of the same prompt - first is primary, second extra
  const res3 = pickAttributions(
    [row('tD1', PA, 1000), row('tD2', PA, 2000)],
    [{ id: '004A', prompt: PA, got: 0, quota: 2 }]);
  eq(res3.assign.map((a) => [a.uuid, a.extra]), [['tD1', false], ['tD2', true]],
    'v3 attribution: Count=2 - oldest row is the download, the second is an extra');
  eq(res3.sends[0].got, 2, 'v3 attribution: quota fills to 2');
}

/* ---------- sfaTilePrompt probe self-containment ---------- */
{
  const code = extractFn(bg, 'sfaTilePrompt');
  const forbidden = ['evalFn', 'scriptFn', 'cdp(', 'elog(', 'realClick', 'save(', 'beat(', 'chrome.', 'targetPath', 'attachedTabId', 'stopRequested', 'ABORT'];
  const bad = forbidden.filter((f) => code.includes(f));
  ok(bad.length === 0 && !/\bS\./.test(code), 'sfaTilePrompt is self-contained' + (bad.length ? ' (refs: ' + bad.join(',') + ')' : ''));
  let fn = null;
  try { fn = new Function('return (' + code + ')')(); } catch (e) { /* asserted below */ }
  ok(typeof fn === 'function', 'sfaTilePrompt revives standalone');
}

/* ---------- wiring ---------- */
ok(bg.includes("matchMode: 'prompt'"), 'DEFAULT_SETTINGS: matchMode defaults to prompt');
ok(bg.includes("obj.matchMode === 'prompt' || obj.matchMode === 'fast'"), 'applyDownloadSettings validates matchMode');
ok(bg.includes('matchMode: prevDl.matchMode'), 'start handler preserves matchMode across runs');
ok(bg.includes('async function readTilePromptText('), 'readTilePromptText exists (v3: fallback ladder only)');
ok(!bg.includes('async function pacedPromptAssign('), 'v3: pacedPromptAssign gone');
ok(bg.includes('async function waitForCompletionDom('), 'v3: the DOM wait survives as the catalog fallback');
ok(bg.includes('async function waitForCompletion('), 'v3: catalog-first waitForCompletion exists');
ok(bg.includes('serialTileVerdict(rd.text, item, others)'), 'serial DOM fallback still verdicts tiles by prompt');
ok(bg.includes("matchMode === 'prompt'") && bg.includes("matchMode === 'fast'"), 'engine branches on matchMode');
ok(html.includes('id="matchModePills"') && html.includes('data-mm="prompt"') && html.includes('data-mm="fast"'), 'panel: Match mode pills (Prompt check | Fast order)');
ok(panel.includes('matchMode: matchModeSel'), 'panel: collect includes matchMode');
ok(panel.includes("matchModeSel = s.matchMode === 'fast' ? 'fast' : 'prompt'"), 'panel: hydrate restores matchMode');
eq((panel.match(/matchModeLabel:/g) || []).length, 8, 'i18n: matchModeLabel in all 8 languages');
eq((panel.match(/matchModePrompt:/g) || []).length, 8, 'i18n: matchModePrompt in all 8 languages');
eq((panel.match(/matchModeFast:/g) || []).length, 8, 'i18n: matchModeFast in all 8 languages');
ok(css.includes('min-height: 34px'), 'css: pills are at least 34px tall');
ok(css.includes('font-size: 13.5px'), 'css: pill labels are 13.5px');
ok(css.includes('padding: 7px 20px'), 'css: pill padding widened');
ok(css.includes('box-shadow: 0 4px 16px rgba(16, 185, 129, .5)'), 'css: selected pill has the green glow');
ok(css.includes('.pill:hover { color: #fff; transform: translateY(-1px)'), 'css: unselected pills lift on hover');
eq(manifest.version, '3.0.0', 'manifest version 3.0.0');
ok(html.includes('class="vtag">v3.0.0'), 'panel shows v3.0.0');

console.log(`\ntest-v262: ${pass} passed, ${fail} failed`);
if (fail) process.exit(1);
console.log('ALL TESTS PASSED');
