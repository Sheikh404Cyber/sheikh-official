# SHEIKH Flow Auto V3.0 - simulation results

Final battery, 2026-11-02 (tests/sim-harness.js; jsdom fake Flow;
42 items per combo; scripted adversities: out-of-order finishes,
generic error tile + guarded Retry (scene 7), unusual-activity
error + 60s cooldown with attempt refund (scene 9, prompt modes),
late duplicate tile at +25s (scene 11), prompt-less catalog row
(scene 21), 30-upload flood at the 15th tile sinking the reference
out of the 27-tile window, duplicate reference upload at the 18th
tile, mid-run Stop at 20 done -> Start with the same list).

| combo          | result | wall  |
|----------------|--------|-------|
| serial-prompt  | PASS   | 616 s |
| serial-fast    | PASS   | 527 s |
| paced-prompt   | PASS   | 504 s |
| paced-fast     | PASS   | 486 s |

PASS bar (audited from ground truth, not engine claims): all 42
items done; exactly one download per item; every downloaded
asset's true generating prompt equals that item's prompt; zero
upload-origin downloads; reference uploaded exactly once;
runStartedAt unchanged across the Stop -> Start (resume, not
restart).

Real engine defects the harness caught and that are now fixed
(each with a regression assertion in tests/test-v3.js):
1. bare `typeFails` ReferenceError in the type-retry log line;
2. error tiles matched by `t.error` instead of `kind==='error'`
   (dead classification in the catalog wait AND the paced watcher);
3. `snap.ids.has` on an Array snapshot;
4. stale error tiles re-failing resends (fixed with the DOM wait's
   pre-send error-count baseline);
5. downloads re-looked-up after grid churn instead of using the
   URL captured at resolution time;
6. viewer fallback guessing the first grid tile when its target
   was unresolvable (now fails honestly with a tile identity).
