'use strict';
/* SHEIKH Flow Auto v2.5 unit tests.
   - Paced mode pure helpers extracted from background.js
     (pacedIsTimedOut, classifyLogLine) - v3: the
     FIFO pairing (pacedAssign) and error-count (pacedErrorDelta)
     helpers were DELETED by the V3 design (order is not evidence);
     their scenarios below are replaced by removal assertions and
     attribution is covered by tests/test-v3.js (pickAttributions).
     pacedIsTimedOut) driven through simulated watcher polls:
       A) tiles completing OUT OF ORDER still get assigned (and
          would download) in SEND order — FIFO by send order, with
          baseline + reference media-ids never matched;
       B) a NEW error tile consumes the oldest pending item as a
          failed attempt exactly once (baseline re-sync after the
          tile leaves, then a later error counts again);
       C) the 240s pending timeout boundary.
   - Panel: classifyLogLine (status-row chips) behaviour, run-mode
     pills + interval stepper markup, new i18n keys.
   - Theme: green system in panel.css (v2.6.1; no turquoise/violet leftovers),
     green Download-generated action, log-row styles.
   - Engine wiring (source level): runLoop branches on runMode,
     the paced loop reuses sendPromptOnce with enforceGap:false,
     settings carry runMode, manifest 2.5.0.
   Run: node tests/test-v25.js */
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');

let pass = 0, fail = 0;
function ok(cond, label) {
  if (cond) { pass++; }
  else { fail++; console.log('FAIL: ' + label); }
}
function eq(a, b, label) { ok(JSON.stringify(a) === JSON.stringify(b), label + ` — got ${JSON.stringify(a)}, want ${JSON.stringify(b)}`); }

const bg = fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8');
const panel = fs.readFileSync(path.join(ROOT, 'panel.js'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'panel.html'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'panel.css'), 'utf8');

function extractFn(srcText, name) {
  const start = srcText.indexOf('function ' + name + '(');
  if (start === -1) throw new Error('function not found: ' + name);
  let i = srcText.indexOf('{', start);
  let depth = 0;
  for (; i < srcText.length; i++) {
    if (srcText[i] === '{') depth++;
    else if (srcText[i] === '}') { depth--; if (depth === 0) break; }
  }
  return srcText.slice(start, i + 1);
}
function revive(srcText, name) {
  return new Function('"use strict";\n' + extractFn(srcText, name) + '\nreturn ' + name + ';')();
}
const pacedIsTimedOut = revive(bg, 'pacedIsTimedOut');
const classifyLogLine = revive(panel, 'classifyLogLine');

/* ---------- tile factories (sfaTiles shape) ---------- */
const img = (mediaId, extra) => Object.assign({ mediaId, kind: 'image', hasThumb: true, hasPct: false, pct: null, label: '', retryBtn: null, key: 'mid:' + mediaId }, extra || {});
const errTile = (n) => ({ mediaId: null, kind: 'error', hasThumb: false, hasPct: false, pct: null, label: 'Failed', retryBtn: { x: 1, y: 2 }, key: 'pos:e' + n });

/* ---------- v3: FIFO pairing + error-by-order are GONE ----------
 * V2.5's Scenario A asserted the first finished tile goes to the
 * OLDEST sent item "not to its real owner" - that behaviour WAS the
 * misnumbering defect Amin ordered removed. V3 attributes by catalog
 * prompt (pickAttributions, tests/test-v3.js). What remains here:
 * the helpers are deleted, and error tiles are classified by key,
 * never counted against the oldest pending item. */
{
  ok(!bg.includes('function pacedAssign('), 'v3: pacedAssign (FIFO pairing) deleted from the engine');
  ok(!bg.includes('function pacedCompletedNew('), 'v3: pacedCompletedNew (grid-snapshot filtering) deleted - the catalog filter (attributionCandidates) replaces it');
  ok(!bg.includes('function pacedErrorDelta('), 'v3: pacedErrorDelta (error count -> oldest pending) deleted from the engine');
  ok(!bg.includes('function pacedQuotaAssign('), 'v3: pacedQuotaAssign (order pairing with quota) deleted from the engine');
  ok(!bg.includes('function pacedPromptAssign('), 'v3: pacedPromptAssign (viewer FIFO fallback) deleted from the engine');
  ok(bg.includes('pickAttributions('), 'v3: attribution goes through pickAttributions (catalog prompt)');
}

/* ---------- Scenario C: timeout boundary ---------- */
{
  const t0 = 1000000;
  eq(pacedIsTimedOut(t0, t0 + 239999), false, 'C: 239.999s pending -> not timed out');
  eq(pacedIsTimedOut(t0, t0 + 240000), false, 'C: exactly 240s -> not timed out (needs > limit)');
  eq(pacedIsTimedOut(t0, t0 + 240001), true, 'C: 240.001s -> timed out');
  eq(pacedIsTimedOut(0, t0 + 9999999), false, 'C: never sent (sentAt 0) -> never timed out');
  eq(pacedIsTimedOut(null, t0 + 9999999), false, 'C: sentAt null -> never timed out');
  eq(pacedIsTimedOut(t0, t0 + 5001, 5000), true, 'C: custom limit honoured');
}

/* ---------- classifyLogLine: status-row chips ---------- */
{
  eq(classifyLogLine('[panel] 10:00:01  ✓ Flow project page is open'), 'ok', 'check line -> ok chip');
  eq(classifyLogLine('[panel] 10:00:01  ✗ Prompt input not found'), 'bad', 'cross line -> bad chip');
  eq(classifyLogLine('[panel] 10:00:01  ! Reference add (+) button not found'), 'warn', 'bang line -> warn chip');
  eq(classifyLogLine('[panel] 10:00:01  ? Mode is not certain'), 'warn', 'question line -> warn chip');
  eq(classifyLogLine('[engine] 10:00:02  001A: FAILED — Flow error'), 'bad', 'engine FAILED -> bad chip');
  eq(classifyLogLine('[engine] 10:00:02  ERROR: run theme gelo'), 'bad', 'engine ERROR -> bad chip');
  eq(classifyLogLine('[engine] 10:00:02  SABDHAN: reference mode select chilo'), 'warn', 'engine SABDHAN -> warn chip');
  eq(classifyLogLine('[engine] 10:00:02  Run shuru — project: X, mot 5 item'), 'info', 'plain engine line -> info chip');
  eq(classifyLogLine('[engine] 10:00:02  001A: done'), 'info', 'done line stays info (no false ok)');
}

/* ---------- engine wiring (source level) ---------- */
ok(bg.includes('async function runPacedLoop('), 'paced loop exists');
ok(/runMode === 'paced'\) \{\s*\n\s*await runPacedLoop\(/.test(bg), 'runLoop branches to the paced loop on runMode paced');
ok(bg.includes("runMode: 'serial'"), 'DEFAULT_SETTINGS defaults runMode to serial');
ok(/obj\.runMode === 'serial' \|\| obj\.runMode === 'paced'/.test(bg), 'applyDownloadSettings validates runMode');
ok(bg.includes('S.pacedBase'), 'paced baseline persisted in state (resume-safe)');
ok(bg.includes('async function sendPromptOnce('), 'sendPromptOnce factored out');
ok(/await sendPromptOnce\(tabId, item, sendCtx\)/.test(bg), 'serial processItem reuses sendPromptOnce');
ok(/sendPromptOnce\(tabId, item, \{ typeFails: 0 \}, \{ enforceGap: false \}\)/.test(bg), 'paced sends reuse sendPromptOnce without the internal gap (loop paces sends)');
for (const h of ['pacedIsTimedOut(']) {
  ok((bg.match(new RegExp(h.replace('(', '\\('), 'g')) || []).length >= 2, h + ' helper is used by the paced loop (not just defined)');
}
ok(/addEventListener\('click'/.test(panel) && panel.includes("type: 'retryOne'"), 'panel retryOne wiring untouched');

/* ---------- panel structure: run mode + interval ---------- */
ok(html.includes('id="runModePills"'), 'run mode segmented control exists');
ok(html.includes('data-m="serial"') && html.includes('data-m="paced"'), 'both run modes always present');
ok(html.includes('data-i18n="runModeSerial"') && html.includes('data-i18n="runModePaced"'), 'run mode labels are i18n keys');
ok(html.includes('id="ivMinus"') && html.includes('id="ivPlus"') && html.includes('id="ivVal"'), 'interval stepper markup exists');
for (const s of ['10', '30', '60', '90', '120']) {
  ok(html.includes('data-sec="' + s + '"'), 'interval preset chip ' + s + 's present');
}
ok(html.includes('data-i18n="intervalHint"'), 'interval one-line hint present');
ok(html.includes('<input type="hidden" id="intervalSec"'), 'intervalSec kept as hidden value store');
ok(!html.includes('type="number" id="intervalSec"'), 'raw number input is gone');
ok(html.includes('class="vtag">v3.0.0'), 'panel shows v3.0.0');
ok(html.includes('btn small dlgreen hidden'), 'Download generated carries the green action class');
ok(panel.includes('function classifyLogLine('), 'classifyLogLine exists in panel.js');
ok(panel.includes("row.className = 'logrow ' + cls"), 'renderLog builds status rows');
ok(!panel.includes("box.textContent = all.join"), 'log is no longer dumped as raw text');
ok(panel.includes('setIntervalUi'), 'stepper UI sync exists');
ok(panel.includes('runMode: runModeSel'), 'panel sends runMode with the download settings');

/* ---------- i18n: new keys ---------- */
const dictStart = panel.indexOf('const STRINGS = ');
const litStart = panel.indexOf('{', dictStart);
let depth = 0, litEnd = -1;
for (let i = litStart; i < panel.length; i++) {
  if (panel[i] === '{') depth++;
  else if (panel[i] === '}') { depth--; if (depth === 0) { litEnd = i; break; } }
}
const STRINGS = new Function('"use strict"; return (' + panel.slice(litStart, litEnd + 1) + ');')();
for (const k of ['runModeLabel', 'runModeSerial', 'runModePaced', 'intervalHint']) {
  ok(typeof STRINGS.en[k] === 'string' && STRINGS.en[k].length > 0, 'en has v2.5 key ' + k);
}
eq(STRINGS.en.runModeSerial, 'One by one', 'serial mode label is "One by one"');
eq(STRINGS.en.runModePaced, 'Paced', 'paced mode label is "Paced"');

/* ---------- theme: green system (v2.6.1; was violet in v2.5/v2.6) ---------- */
ok(css.includes('--acc: #34d399'), 'green accent variable');
ok(css.includes('--acc-deep: #059669'), 'deep green variable');
ok(css.includes('--hdr: #a8c3ae'), 'pale grey-green header variable');
ok(/h2 \{[^}]*color: var\(--hdr\)/.test(css), 'section headers use the pale grey-green');
ok(css.includes('--bg: #0a0a0f'), 'near-black neutral background (v2.6)');
ok(css.includes('.logrow') && css.includes('.logchip'), 'log status-row styles exist');
ok(css.includes('.logrow.ok .logchip') && css.includes('.logrow.bad .logchip') && css.includes('.logrow.warn .logchip'), 'ok/bad/warn chip styles exist');
ok(css.includes('.ivstep') && css.includes('.ivchip.sel'), 'stepper + preset chip styles exist');
ok(css.includes('.btn.dlgreen { background: linear-gradient(135deg, #22c55e, #16a34a)'), 'Download generated is the single green action');
ok(!css.includes('#0d9488') && !css.includes('#2dd4bf') && !css.includes('#14b8a6'), 'no turquoise leftovers in CSS');
ok(!bg.includes("'#0d9488'"), 'badge colour moved off turquoise');

/* ---------- manifest ---------- */
const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.json'), 'utf8'));
eq(manifest.version, '3.0.0', 'manifest version 3.0.0');

console.log(`\ntest-v25: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
