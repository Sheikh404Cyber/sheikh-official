/*
 * SHEIKH Flow Auto — background service worker.
 * Owns the run engine and the CDP (chrome.debugger) layer.
 * Truth lives in chrome.storage.local under "sfa_state".
 */
'use strict';

/* Clicking the toolbar icon must open the side panel (MV3: not automatic). */
if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
}

/* License lock (v3.1): FA1 keys from the SHEIKH OFFICIAL admin License tab.
 * The engine refuses to start/resume/retry without a valid license. */
importScripts('lib/license.js');
async function licenseGate() {
  try {
    const st = await FA_LIC.status();
    return st && st.licensed ? null : (st || { reason: 'unknown' });
  } catch (e) { return { reason: 'check-failed' }; }
}

/* ---------------- small utils ---------------- */
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const nowTime = () => new Date().toTimeString().slice(0, 8);
const FLOW_URL_RE = /(labs\.google\/.+\/flow|flow\.google\.com)/i;
/* Generation-start spacing: v2.0 fixed a 10s floor (user rule);
 * v2.2 makes it a user setting (settings.intervalSec, 3–120s,
 * default 10) enforced at every send by enforceSendGap. */

/* v2.2 pure helpers (unit-tested in tests/test-v22.js). */
function clampIntervalSec(v) {
  const n = parseInt(v, 10);
  if (!isFinite(n)) return 10;
  return Math.min(120, Math.max(3, n));
}
function formatEta(sec) {
  if (sec === null || sec === undefined || !isFinite(sec) || sec < 0) return '—';
  sec = Math.round(sec);
  if (sec < 60) return sec + 's';
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  if (m < 60) return m + 'm ' + s + 's';
  const h = Math.floor(m / 60);
  const mm = m % 60;
  return h + 'h ' + mm + 'm';
}
/* Dated run folder base: "Project-YYYYMMDD-HHmm" (local time). */
function datedFolderName(project, ts) {
  const d = new Date(ts || Date.now());
  const p2 = (n) => String(n).padStart(2, '0');
  return sanitizeProject(project) + '-' + d.getFullYear() + p2(d.getMonth() + 1) + p2(d.getDate()) + '-' + p2(d.getHours()) + p2(d.getMinutes());
}
/* QuickVid match report builder (pure): items + a verify map
 * (id -> {found, filename}) built by verifyDownloads(). A "done" item
 * whose file is not found on disk is MISSING; items downloaded through
 * Flow's own menu (2K/4K) carry dlName and are listed as flowNamed. */
function buildMatchReport(items, verifyMap) {
  const rep = { total: (items || []).length, verified: [], missing: [], failed: [], generated: [], pending: [], flowNamed: [] };
  for (const it of items || []) {
    const v = (verifyMap && verifyMap[it.id]) || { found: false, filename: '' };
    if (it.status === 'failed') rep.failed.push(it.id);
    else if (it.status === 'generated') rep.generated.push(it.id);
    else if (it.status === 'done') {
      if (v.found) rep.verified.push(it.id); else rep.missing.push(it.id);
      if (it.dlName) rep.flowNamed.push({ id: it.id, name: it.dlName });
    } else rep.pending.push(it.id);
  }
  return rep;
}

/* v2.3 pure helpers (unit-tested in tests/test-v23.js).
 * shouldForceResetLoop: the start/resume handlers may force-reset a
 * run whose loop flag is on but whose heartbeat has not moved for
 * over 20s — every live wait in the engine beats at least every 2s
 * and the heartbeat interval beats every 4s, so 20s of silence means
 * the loop is wedged (e.g. parked inside a CDP call that will never
 * settle) and can be safely invalidated.
 * terminalStatusFor: the single advance decision in the run loop —
 * an item outcome is either "generated" (Download Later: image made,
 * file comes down in the pass) or "done" (everything else). */
function shouldForceResetLoop(isLoopActive, heartbeatMs, nowMs) {
  if (!isLoopActive) return false;
  return (nowMs - (heartbeatMs || 0)) > 20000;
}
function terminalStatusFor(outcome) {
  return outcome && outcome.generatedOnly ? 'generated' : 'done';
}

/* ---------------- state ---------------- */
const DEFAULT_SETTINGS = () => ({
  refMode: 'marked', refReady: false,
  // v2.2 download settings (panel Download section)
  autoDownload: true,   // false = Download Later mode
  quality: '1K',        // '1K' | '2K' | '4K'
  datedFolder: false,   // run folder = <Project>-<YYYYMMDD-HHmm>
  retryAtEnd: false,    // auto-retry failed items when the queue drains (max 3 rounds)
  intervalSec: 10,      // seconds between generation starts (3–120)
  runMode: 'serial',    // v2.5: 'serial' (one by one) | 'paced' (send every interval, FIFO match)
  matchMode: 'prompt',  // v2.6.2: 'prompt' (viewer prompt check, ground truth) | 'fast' (FIFO; paced adds freeze-drain-repair)
  // v2.6 generation options (panel GENERATION card; applied to Flow's
  // composer at run start, fail-soft)
  genType: 'image',           // 'image' | 'video'
  genModel: 'Nano Banana 2.1',
  genRatio: '16:9',
  genCount: 1                 // tiles per prompt (1–4); first downloads, rest are extras
});
const DEFAULT_STATE = () => ({
  version: 1,
  running: false,
  paused: false,
  project: '',
  runFolder: '',        // v2.2: effective download folder base for this run (set at start; resume keeps it)
  retryRoundsUsed: 0,   // v2.2: retry-at-end rounds already spent this run
  dlPass: false,        // v2.2: a Download-Later pass is running right now
  items: [],            // {id, prompt, needsRef, status, attempts, note, failReason, stage, tileMediaId, tileUrl, completedAt, dlName}
  settings: DEFAULT_SETTINGS(),
  // v2.0 reference lifecycle: the reference uploads FIRST and ONCE per
  // project; afterwards each item re-adds it from the project via the
  // ingredient picker. refStatus: '' | 'checking' | 'uploading' | 'ready' | 'failed'
  refMediaIds: [],      // v3: SET of every UUID ever confirmed as the reference (only grows; exclusion is by identity, not position)
  baselineUuids: null,  // v3: catalog UUIDs present at run start (attribution baseline; null = catalog unavailable at capture)
  runSignature: '',     // v3: signature of (project, item list, ref file) — Start resumes when it matches the saved run
  refRecovered: false,  // v3: the one allowed mid-run reference re-upload has been spent
  cooldownUntil: 0,     // v3: unusual-activity cooldown — no sends before this timestamp
  cooldownLevel: 0,     // v3: consecutive unusual-activity hits (backoff escalation)
  catalogOk: null,      // v3: last catalog fetch status (true/false/null=never)
  unclaimedUuids: [],   // v3: parked catalog rows (prompt-less, unproven) - re-examined every pass, never order-paired
  watchdogUnwind: false, // v3: set by the stage watchdog - loops unwind to pending and runLoop re-enters
  watchdogFiredFor: '', // v3: item id the watchdog last fired for (serial converts it to a failed attempt)
  watchdogFiredStage: '', // v3: stage string the watchdog fired on (for the failure reason)
  refFileName: '',      // file name the panel sent (asset name in Flow)
  refMediaId: null,     // data-media-id of the uploaded reference asset
  refAssetName: '',     // label Flow shows for that asset (may be generic)
  refPickerName: '',    // v2.1: name the picker shows/searches (from the tile label's filename, else 'image')
  refStatus: '',
  pacedBase: null,      // v2.5: {at, ids} tile baseline for paced matching (survives resume)
  cycleSamples: [],     // v2.6: send->finish cycle ms of the last <=8 completed items (ETA input)
  consumedTiles: [],    // v2.6: mediaIds already consumed as results/extras (never re-matched)
  etaMs: null,          // v2.6: engine-computed time-left (null until the first completion)
  endsAt: null,         // v2.6: engine-computed wall-clock finish time
  lastSendAt: 0,        // ms timestamp of the last generation start (10s gap)
  log: [],
  engineHeartbeat: 0,   // ms timestamp, updated by the engine while the run loop lives
  lastDetachReason: '', // last unexpected chrome.debugger detach reason (v1.4)
  lastPreflight: null,
  lastReport: '',
  tabId: null,
  runStartedAt: null,
  runFinishedAt: null
});
let S = DEFAULT_STATE();
let loopActive = false;
let pauseRequested = false;
let stopRequested = false;
let stateLoaded = false;
/* v2.3 — run generation + abort epoch.
 * runGen increments on every runLoop entry and on a force-reset; a
 * loop whose generation is no longer current stops touching state
 * (its finally also skips cleanup, which the newer run owns).
 * abortEpoch is bumped by Stop and by force-reset: every long wait
 * captures the epoch at entry and aborts the moment it changes, and
 * sleepOrStop races its sleep against the epoch so a stop wakes the
 * wait immediately instead of at its next poll (up to 2s later, or —
 * for the 15s attempt backoff — 15s later). */
let runGen = 0;
let abortEpoch = 0;
const epochWaiters = new Set();
function bumpAbortEpoch() {
  abortEpoch++;
  const ws = Array.from(epochWaiters);
  epochWaiters.clear();
  ws.forEach((r) => { try { r(); } catch (e) { /* waiter already gone */ } });
}
function epochChangedPromise(from) {
  if (from !== abortEpoch) return Promise.resolve();
  return new Promise((r) => epochWaiters.add(r));
}
/* Sleep that throws ABORT the instant Stop (or a force-reset) lands.
 * `epoch` is the caller's captured abort epoch; default: current. */
async function sleepOrStop(ms, epoch) {
  const ep = (epoch === undefined ? abortEpoch : epoch);
  if (stopRequested || ep !== abortEpoch) throw ABORT;
  if (!(ms > 0)) return;
  const r = await Promise.race([
    sleep(ms).then(() => 'tick'),
    epochChangedPromise(ep).then(() => 'abort')
  ]);
  if (r === 'abort' || stopRequested || ep !== abortEpoch) throw ABORT;
}

async function loadState() {
  if (stateLoaded) return;
  try {
    const got = await chrome.storage.local.get('sfa_state');
    if (got && got.sfa_state) {
      S = Object.assign(DEFAULT_STATE(), got.sfa_state);
      // v2.2: older saved states lack the new settings — merge defaults.
      S.settings = Object.assign(DEFAULT_SETTINGS(), S.settings || {});
    }
  } catch (e) { /* fresh start */ }
  stateLoaded = true;
  // v3 fossil reconciliation: if the persisted state claims a run is
  // live but THIS worker has no loop running (the worker died mid-run
  // - MV3 kills idle workers), the run is a fossil: the panel would
  // show a stage that nothing will ever advance again. Reconcile
  // once, here: back to a resumable pending state, one honest line.
  if (S.running && !loopActive) {
    S.running = false;
    S.paused = false;
    S.watchdogUnwind = false;
    for (const it of S.items || []) if (it.status === 'active') { it.status = 'pending'; it.stage = ''; }
    if (!Array.isArray(S.log)) S.log = [];
    S.log.push('[engine] ' + nowTime() + '  Ager run majhpothe theme giyechilo - state thik kore pending e rakha holo; Start/Resume dile okhan thekei cholbe');
    if (S.log.length > 300) S.log = S.log.slice(-300);
  }
}
let saveTimer = null;
function save() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    refreshEta();
    updateBadge();
    chrome.storage.local.set({ sfa_state: S }).catch(() => {});
  }, 120);
}
function saveNow() {
  if (saveTimer) { clearTimeout(saveTimer); saveTimer = null; }
  refreshEta();
  updateBadge();
  return chrome.storage.local.set({ sfa_state: S }).catch(() => {});
}

/* v2.4 — toolbar icon badge: while a run is going, the action icon
 * shows the done-percent ("42%"); it clears when the run ends. Driven
 * from the save path (already throttled) and itself only touches
 * Chrome when the integer percent actually changes. */
let lastBadgePct = -1;
function badgePctFor(isRunning, doneCount, generatedCount, totalCount) {
  if (!isRunning || !totalCount) return -1;
  return Math.floor(100 * (doneCount + generatedCount) / totalCount);
}
function updateBadge() {
  try {
    if (!chrome.action || !chrome.action.setBadgeText) return;
    const c = counts();
    const pct = badgePctFor(S.running, c.done, c.generated, c.total);
    if (pct === lastBadgePct) return;
    lastBadgePct = pct;
    if (pct < 0) {
      chrome.action.setBadgeText({ text: '' }).catch(() => {});
    } else {
      chrome.action.setBadgeBackgroundColor({ color: '#059669' }).catch(() => {});
      chrome.action.setBadgeText({ text: pct + '%' }).catch(() => {});
    }
  } catch (e) { /* badge is best-effort */ }
}
/* v2.6 — ETA lives in the engine, from measured pace (cycleSamples).
 * Recomputed on every save so the state the panel polls always
 * carries fresh etaMs / endsAt. */
function refreshEta() {
  try {
    const c = counts();
    const remaining = (c.pending || 0) + (c.active || 0);
    let eta = null;
    if (remaining > 0 && (S.cycleSamples || []).length) {
      // v3: samples persist across stop/resume of the same run, and
      // the last estimate stays on screen while paused/stopped with
      // work remaining - null is reserved for "no measurement yet".
      eta = computeEtaMs({
        samples: S.cycleSamples || [],
        mode: (S.settings && S.settings.runMode) || 'serial',
        remainingItems: remaining,
        unsentItems: c.pending || 0,
        intervalSec: S.settings && S.settings.intervalSec
      });
    } else if (S.running && remaining > 0) {
      eta = null; // running but nothing measured yet
    } else if (S.running) eta = 0;
    S.etaMs = eta;
    S.endsAt = (eta === null || eta === undefined) ? null : Date.now() + eta;
  } catch (e) { /* ETA is best-effort */ }
}
/* v2.6 — record one finished item's real cycle time (send -> finish)
 * into the rolling sample window the ETA is computed from. */
function noteItemCycle(item) {
  try {
    if (!item || !item.sentAt) return;
    // v3: one sample per send - completeItem is the single funnel
    // that records; scattered call sites can no longer double-count.
    if (item.cycleNotedFor === item.sentAt) return;
    item.cycleNotedFor = item.sentAt;
    const end = item.completedAt || Date.now();
    const cyc = end - item.sentAt;
    if (!(cyc > 0) || cyc > 3600000) return;
    if (!Array.isArray(S.cycleSamples)) S.cycleSamples = [];
    S.cycleSamples.push(Math.round(cyc));
    if (S.cycleSamples.length > 8) S.cycleSamples = S.cycleSamples.slice(-8);
  } catch (e) { /* samples are best-effort */ }
}
function beat() { S.engineHeartbeat = Date.now(); }
function elog(msg) {
  S.log.push('[engine] ' + nowTime() + '  ' + msg);
  if (S.log.length > 300) S.log = S.log.slice(-300);
  beat();
  save();
}
/* v3 stage watchdog: while a run is live, a supervisor checks every
 * 5s whether the currently-displayed stage has exceeded its budget
 * (stageBudgetFor). A stuck stage is EXACTLY how the V2.6.2 run died
 * silently ('generation start check' forever). On fire: record the
 * item + stage, set the unwind flag, and bump the abort epoch so
 * every in-flight wait throws at once. The serial loop converts the
 * fire into that item's failed attempt and continues; the paced loop
 * unwinds to pending and runLoop re-enters. Pause and cooldown exempt. */
let watchdogTimer = null;
const watchdogSeen = new Map(); // itemId|stage -> first-seen ms
function startWatchdog() {
  if (watchdogTimer) return;
  watchdogSeen.clear();
  watchdogTimer = setInterval(watchdogTick, 5000);
}
function stopWatchdog() {
  if (watchdogTimer) { clearInterval(watchdogTimer); watchdogTimer = null; }
  watchdogSeen.clear();
}
function watchdogTick() {
  try {
    if (!S.running || S.paused || pauseRequested) return;
    if (S.cooldownUntil && Date.now() < S.cooldownUntil) return;
    const item = (S.items || []).find((i) => i.status === 'active' && i.stage);
    if (!item) { watchdogSeen.clear(); return; }
    const key = item.id + '|' + item.stage;
    const now = Date.now();
    if (!watchdogSeen.has(key)) { watchdogSeen.set(key, now); return; }
    if (!stageOverBudget(item.stage, watchdogSeen.get(key), now)) return;
    watchdogSeen.delete(key);
    S.watchdogFiredFor = item.id;
    S.watchdogFiredStage = item.stage;
    S.watchdogUnwind = true;
    elog('Watchdog: ' + item.id + ' stage "' + item.stage + '" onekkhon atke chilo - unwind hocche (run nijei abar shuru hobe)');
    saveNow();
    bumpAbortEpoch();
  } catch (e) { /* the watchdog never throws */ }
}
let hbTimer = null;
function startHeartbeat() {
  beat();
  if (hbTimer) return;
  hbTimer = setInterval(() => { beat(); save(); }, 4000);
}
function stopHeartbeat() {
  if (hbTimer) { clearInterval(hbTimer); hbTimer = null; }
}
function counts() {
  const c = { done: 0, failed: 0, pending: 0, active: 0, generated: 0, total: S.items.length };
  for (const it of S.items) c[it.status] = (c[it.status] || 0) + 1;
  return c;
}

/* ---------------- page-side functions (self-contained; run in Flow tab) --- */
function sfaFindComposer() {
  function vis(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
  }
  function center(el) {
    const r = el.getBoundingClientRect();
    return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2), w: Math.round(r.width), h: Math.round(r.height) };
  }
  const cands = [];
  document.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"]').forEach((el) => {
    if (!vis(el)) return;
    const kind = el.tagName.toLowerCase() === 'textarea' ? 'textarea'
      : (el.getAttribute('contenteditable') === 'true' ? 'contenteditable' : 'textbox');
    const hint = ((el.getAttribute('placeholder') || '') + ' ' + (el.getAttribute('aria-label') || '')).toLowerCase();
    const r = el.getBoundingClientRect();
    let score = (r.width * r.height) / 1000;
    if (/what do you want|describe|prompt|create|imagine/.test(hint)) score += 5000;
    if (r.top > window.innerHeight * 0.35) score += 2000;
    cands.push({ el, kind, score });
  });
  cands.sort((a, b) => b.score - a.score);
  if (!cands.length) return { input: null, send: null };
  const inputEl = cands[0].el;
  const ic = center(inputEl);
  let btns = [];
  let container = inputEl;
  for (let up = 0; up < 7 && container; up++) {
    container = container.parentElement;
    if (!container) break;
    const found = [];
    container.querySelectorAll('button, [role="button"]').forEach((b) => { if (vis(b)) found.push(b); });
    if (found.length) { btns = found; break; }
  }
  if (!btns.length) {
    document.querySelectorAll('button, [role="button"]').forEach((b) => {
      if (!vis(b)) return;
      const r = b.getBoundingClientRect();
      if (r.top > window.innerHeight * 0.5 && r.left > window.innerWidth * 0.45) btns.push(b);
    });
  }
  let send = null;
  btns.forEach((b) => {
    const label = ((b.getAttribute('aria-label') || '') + ' ' + (b.getAttribute('title') || '') + ' ' + (b.textContent || '')).toLowerCase();
    // BLACKLIST: a clear/close (x) control can appear in or near the composer
    // once text is present — clicking it ERASES the prompt instead of sending
    // (that is exactly the v1.2 bug). Never pick such a candidate, here or in
    // the preflight (which uses this same finder).
    if (/close|clear|remove|cancel|delete|dismiss|backspace/.test(label)) return;
    const c = center(b);
    let sc = c.x / 10; // prefer right side of the composer row
    if (/send|generate|create|submit|arrow/.test(label)) sc += 1000;
    if (!send || sc > send._sc) {
      const rawLabel = (b.getAttribute('aria-label') || b.getAttribute('title') || (b.textContent || '').trim());
      send = { x: c.x, y: c.y, w: c.w, h: c.h, label: String(rawLabel).slice(0, 60), strategy: /send|generate|create|submit/.test(label) ? 'label-match' : 'rightmost-in-composer', _sc: sc };
    }
  });
  if (send) delete send._sc;
  return { input: { x: ic.x, y: ic.y, w: ic.w, h: ic.h, strategy: cands[0].kind }, send };
}

/* Verify a stored click point: the element at (x, y) — or its closest
 * button ancestor — must be button-like and NOT a blacklisted control
 * (close/clear/remove/cancel/delete/dismiss/backspace). Used before the
 * fallback click so pre-typing coordinates are never trusted blindly. */
function sfaVerifyPoint(pos) {
  const x = pos && typeof pos.x === 'number' ? pos.x : -1;
  const y = pos && typeof pos.y === 'number' ? pos.y : -1;
  if (x < 0 || y < 0) return { ok: false, reason: 'bad coords' };
  const el = document.elementFromPoint(x, y);
  if (!el) return { ok: false, reason: 'point e kichu nai' };
  const btn = el.closest ? el.closest('button, [role="button"]') : null;
  if (!btn) return { ok: false, reason: 'button na', tag: el.tagName || '' };
  const label = ((btn.getAttribute('aria-label') || '') + ' ' + (btn.getAttribute('title') || '') + ' ' + (btn.textContent || '')).toLowerCase();
  if (/close|clear|remove|cancel|delete|dismiss|backspace/.test(label)) {
    return { ok: false, reason: 'blacklisted button', label: label.trim().slice(0, 60) };
  }
  const rawLabel = (btn.getAttribute('aria-label') || btn.getAttribute('title') || (btn.textContent || '').trim());
  return { ok: true, label: String(rawLabel).slice(0, 60), tag: btn.tagName || '' };
}

/* v2.6.1 — containment check for a click point, companion to
 * sfaVerifyPoint: where does (x, y) actually land? Reports whether the
 * element at the point (or its closest button ancestor) sits inside
 * the media GRID (a tile — never clickable by the settings/clear/plus
 * flows), inside the COMPOSER (the prompt input's own button-bearing
 * container, found with the same scoring as sfaFindComposer), or
 * inside an open OVERLAY (menu / popover / dialog — where the composer
 * settings menu legitimately lives). The background side decides with
 * the pure genClickVerdict(); coordinates harvested from a DOM
 * snapshot are never clicked blind again in those flows. */
function sfaPointCheck(pos) {
  var x = pos && typeof pos.x === 'number' ? pos.x : -1;
  var y = pos && typeof pos.y === 'number' ? pos.y : -1;
  var out = { found: false, inGrid: false, inComposer: false, inOverlay: false, label: '', tag: '' };
  if (x < 0 || y < 0) return out;
  var el = null;
  try { el = document.elementFromPoint(x, y); } catch (e) { el = null; }
  if (!el) return out;
  out.found = true;
  out.tag = el.tagName || '';
  var btn = el.closest ? el.closest('button, [role="button"], [role="menuitem"], a') : null;
  var labEl = btn || el;
  var label = ((labEl.getAttribute && labEl.getAttribute('aria-label')) || '') + ' ' +
    ((labEl.getAttribute && labEl.getAttribute('title')) || '') + ' ' + (labEl.textContent || '');
  out.label = label.replace(/\s+/g, ' ').trim().slice(0, 80);
  try {
    out.inGrid = !!(el.closest && el.closest('.flow-grid-tile-container, [class*="flow-image-tile" i], [class*="flow-video-tile" i], [class*="flow-error-tile" i]'));
  } catch (e) { /* keep false */ }
  try {
    out.inOverlay = !!(el.closest && el.closest('[role="menu"], [role="listbox"], [role="dialog"], [data-radix-popper-content-wrapper], [data-state="open"], [class*="popover" i], [class*="dropdown" i], [class*="menu" i]'));
  } catch (e) { /* keep false */ }
  try {
    function vis2(n) {
      if (!n) return false;
      var r = n.getBoundingClientRect();
      if (r.width < 2 || r.height < 2) return false;
      var s = getComputedStyle(n);
      return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
    }
    var best = null;
    var bestScore = -1;
    document.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"]').forEach(function (cand) {
      if (!vis2(cand)) return;
      var hint = ((cand.getAttribute('placeholder') || '') + ' ' + (cand.getAttribute('aria-label') || '')).toLowerCase();
      var r = cand.getBoundingClientRect();
      var score = (r.width * r.height) / 1000;
      if (/what do you want|describe|prompt|create|imagine/.test(hint)) score += 5000;
      if (r.top > window.innerHeight * 0.35) score += 2000;
      if (score > bestScore) { bestScore = score; best = cand; }
    });
    if (best) {
      if (el === best || (best.contains && best.contains(el))) out.inComposer = true;
      var cont = best;
      for (var up = 0; up < 7 && cont && !out.inComposer; up++) {
        cont = cont.parentElement;
        if (!cont) break;
        var hasBtn = false;
        cont.querySelectorAll('button, [role="button"]').forEach(function (b) { if (vis2(b)) hasBtn = true; });
        if (hasBtn) { if (cont.contains && cont.contains(el)) out.inComposer = true; break; }
      }
    }
  } catch (e) { /* keep flags as they are */ }
  return out;
}

function sfaProbe() {
  let count = 0;
  document.querySelectorAll('img').forEach((im) => {
    const src = im.currentSrc || im.src || '';
    if (!/googleusercontent|blob:/.test(src)) return;
    const r = im.getBoundingClientRect();
    if (r.width > 100 && r.height > 60) count++;
  });
  let busy = false;
  document.querySelectorAll('[role="progressbar"]').forEach((e) => {
    const r = e.getBoundingClientRect();
    if (r.width > 0 && r.height > 0) busy = true;
  });
  if (!busy) document.querySelectorAll('[aria-label]').forEach((e) => {
    if (busy) return;
    const a = (e.getAttribute('aria-label') || '').toLowerCase();
    if (/generating|loading|working on/.test(a)) {
      const r = e.getBoundingClientRect();
      if (r.width > 0 && r.height > 0) busy = true;
    }
  });
  if (!busy) document.querySelectorAll('[class*="spinner" i], [class*="loading" i]').forEach((e) => {
    if (busy) return;
    const r = e.getBoundingClientRect();
    if (r.width > 4 && r.height > 4) {
      const s = getComputedStyle(e);
      if (s.display !== 'none' && s.visibility !== 'hidden') busy = true;
    }
  });
  let error = '';
  document.querySelectorAll('[role="alert"], [class*="toast" i], [class*="snackbar" i], [class*="error" i]').forEach((e) => {
    if (error) return;
    const t = (e.textContent || '').trim();
    if (t && /couldn'?t generate|can'?t generate|something went wrong|unable to generate|failed to generate|violates|policy/i.test(t)) {
      const r = e.getBoundingClientRect();
      if (r.width > 0 && r.height > 0) error = t.slice(0, 200);
    }
  });
  return { count, busy, error };
}

/* v1.6 — combined media scan. Proven by the user's v1.5 run report:
 * generation finished and the completed tile sat in the Flow project
 * grid, yet every wait poll for 211+ seconds logged "image count 0
 * (baseline 0, busy=false)". flow.google.com does NOT render generated
 * tiles as plain <img src=googleusercontent|blob:> elements that
 * sfaProbe counts — the tiles are CSS background-image elements (or
 * another DOM shape). This probe counts BOTH kinds in one document-order
 * walk (capped at ~5000 elements for perf): matching <img> elements and
 * elements whose computed background-image URL matches. lastUrl prefers
 * a googleusercontent URL (size-upgradeable) over blob:. Busy/error
 * detection is the same logic as sfaProbe. Diagnostics (totalImgs,
 * sampleSrcs) ride along so any future DOM mismatch is visible in the
 * run report alone. */
function sfaMediaScan() {
  const MEDIA = /googleusercontent|blob:/i;
  let imgCount = 0;
  let bgCount = 0;
  let lastAny = null;
  let lastGc = null;
  const matchSrcs = [];
  function noteMatch(url) {
    if (!url) return;
    lastAny = url;
    if (/googleusercontent/i.test(url)) lastGc = url;
  }
  let els = [];
  try {
    els = document.body ? Array.prototype.slice.call(document.body.querySelectorAll('*')) : [];
  } catch (e) { els = []; }
  const CAP = 5000;
  const n = Math.min(els.length, CAP);
  for (let i = 0; i < n; i++) {
    const el = els[i];
    let matched = false;
    if (el.tagName === 'IMG') {
      const src = el.currentSrc || el.src || '';
      if (src && MEDIA.test(src)) {
        const r = el.getBoundingClientRect();
        if (r.width >= 80 && r.height >= 50) {
          imgCount++;
          matched = true;
          noteMatch(src);
          if (matchSrcs.length < 3) matchSrcs.push(src.slice(0, 90));
        }
      }
    }
    if (!matched) {
      let bg = '';
      try { bg = getComputedStyle(el).backgroundImage || ''; } catch (e) { bg = ''; }
      if (bg && bg !== 'none' && MEDIA.test(bg)) {
        const parts = bg.match(/url\(["']?[^"')]+["']?\)/g) || [];
        for (let k = 0; k < parts.length; k++) {
          const inner = parts[k].replace(/^url\(["']?/, '').replace(/["']?\)$/, '');
          if (MEDIA.test(inner)) { bgCount++; noteMatch(inner); break; }
        }
      }
    }
  }
  const allImgs = document.images || [];
  const sampleSrcs = matchSrcs.slice(0, 3);
  if (!sampleSrcs.length) {
    for (let i = 0; i < allImgs.length && sampleSrcs.length < 2; i++) {
      const s = allImgs[i].currentSrc || allImgs[i].src || '';
      if (s) sampleSrcs.push(s.slice(0, 90));
    }
  }
  let busy = false;
  document.querySelectorAll('[role="progressbar"]').forEach((e) => {
    const r = e.getBoundingClientRect();
    if (r.width > 0 && r.height > 0) busy = true;
  });
  if (!busy) document.querySelectorAll('[aria-label]').forEach((e) => {
    if (busy) return;
    const a = (e.getAttribute('aria-label') || '').toLowerCase();
    if (/generating|loading|working on/.test(a)) {
      const r = e.getBoundingClientRect();
      if (r.width > 0 && r.height > 0) busy = true;
    }
  });
  if (!busy) document.querySelectorAll('[class*="spinner" i], [class*="loading" i]').forEach((e) => {
    if (busy) return;
    const r = e.getBoundingClientRect();
    if (r.width > 4 && r.height > 4) {
      const s = getComputedStyle(e);
      if (s.display !== 'none' && s.visibility !== 'hidden') busy = true;
    }
  });
  let error = '';
  document.querySelectorAll('[role="alert"], [class*="toast" i], [class*="snackbar" i], [class*="error" i]').forEach((e) => {
    if (error) return;
    const t = (e.textContent || '').trim();
    if (t && /couldn'?t generate|can'?t generate|something went wrong|unable to generate|failed to generate|violates|policy/i.test(t)) {
      const r = e.getBoundingClientRect();
      if (r.width > 0 && r.height > 0) error = t.slice(0, 200);
    }
  });
  return {
    imgCount, bgCount, total: imgCount + bgCount,
    lastUrl: lastGc || lastAny,
    totalImgs: allImgs.length,
    sampleSrcs, busy, error
  };
}

function sfaLastImg() {
  let best = null;
  document.querySelectorAll('img').forEach((im) => {
    const src = im.currentSrc || im.src || '';
    if (!/googleusercontent|blob:/.test(src)) return;
    const r = im.getBoundingClientRect();
    if (r.width <= 100 || r.height <= 60) return;
    best = { src, x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2), w: Math.round(r.width), h: Math.round(r.height) };
  });
  return best;
}

function sfaFindDownloadBtn() {
  let best = null;
  document.querySelectorAll('button, [role="button"], a').forEach((b) => {
    const label = ((b.getAttribute('aria-label') || '') + ' ' + (b.getAttribute('title') || '') + ' ' + (b.textContent || '')).toLowerCase();
    if (!/download/.test(label)) return;
    const r = b.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return;
    const s = getComputedStyle(b);
    if (s.display === 'none' || s.visibility === 'hidden') return;
    const c = { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2), top: r.top };
    if (!best || c.top < best.top) best = c; // prefer the topmost (viewer toolbar)
  });
  return best;
}

function sfaModeProbe() {
  const out = { modelText: '', selectedMode: '', hasVeo: false, hasImageModel: false, durationSignal: false };
  const bodyText = (document.body && document.body.innerText) || '';
  out.hasVeo = /\bveo\b/i.test(bodyText);
  out.hasImageModel = /nano banana|imagen/i.test(bodyText);
  document.querySelectorAll('button, [role="button"], [role="tab"], [aria-pressed], [aria-selected]').forEach((e) => {
    const t = (e.textContent || '').trim();
    const pressed = e.getAttribute('aria-pressed') === 'true' || e.getAttribute('aria-selected') === 'true';
    if (pressed && /^(image|images|video|videos)$/i.test(t)) out.selectedMode = t.toLowerCase();
    if (/veo|nano banana|imagen/i.test(t) && t.length > 0 && t.length < 60) out.modelText = t;
    if (/^\d+\s*s$/.test(t) || /^\d+:\d{2}$/.test(t)) out.durationSignal = true;
  });
  return out;
}

function sfaComposerText() {
  function vis(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
  }
  const cands = [];
  document.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"]').forEach((el) => {
    if (!vis(el)) return;
    const hint = ((el.getAttribute('placeholder') || '') + ' ' + (el.getAttribute('aria-label') || '')).toLowerCase();
    const r = el.getBoundingClientRect();
    let score = (r.width * r.height) / 1000;
    if (/what do you want|describe|prompt|create|imagine/.test(hint)) score += 5000;
    if (r.top > window.innerHeight * 0.35) score += 2000;
    cands.push({ el, score });
  });
  cands.sort((a, b) => b.score - a.score);
  if (!cands.length) return { text: '', found: false };
  const el = cands[0].el;
  const text = el.tagName.toLowerCase() === 'textarea' ? (el.value || '') : (el.innerText || el.textContent || '');
  return { text, found: true };
}

function sfaComposerChips() {
  function vis(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
  }
  const cands = [];
  document.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"]').forEach((el) => {
    if (!vis(el)) return;
    const hint = ((el.getAttribute('placeholder') || '') + ' ' + (el.getAttribute('aria-label') || '')).toLowerCase();
    const r = el.getBoundingClientRect();
    let score = (r.width * r.height) / 1000;
    if (/what do you want|describe|prompt|create|imagine/.test(hint)) score += 5000;
    if (r.top > window.innerHeight * 0.35) score += 2000;
    cands.push({ el, score });
  });
  cands.sort((a, b) => b.score - a.score);
  if (!cands.length) return { chips: -1 };
  // Walk up to the composer container (same strategy as the composer finder),
  // then count visible ingredient-like elements inside it.
  let container = cands[0].el;
  for (let up = 0; up < 7 && container; up++) {
    container = container.parentElement;
    if (!container) break;
    let hasBtn = false;
    container.querySelectorAll('button, [role="button"]').forEach((b) => { if (vis(b)) hasBtn = true; });
    if (hasBtn) break;
  }
  if (!container) container = cands[0].el.parentElement || document.body;
  let chips = 0;
  container.querySelectorAll('img, [class*="chip" i], [class*="ingredient" i], [class*="attachment" i], [class*="thumbnail" i]').forEach((e) => {
    if (e === cands[0].el) return;
    if (vis(e)) chips++;
  });
  return { chips };
}

/* v1.5 — count REAL reference ingredients inside the composer and detect
 * an in-progress upload. The old chip counter in sfaComposerChips matched
 * UI icons too (a paste read "chip 2 -> 7"), so it could not tell a real
 * uploaded thumbnail from composer chrome. An ingredient here is either
 * (a) an <img> that actually loaded pixels (naturalWidth >= 50) — UI
 * icons are smaller — or (b) a filename label: Flow labels a pasted
 * upload "image.png", so a leaf-ish element whose text names a .png/.jpg
 * counts, unless it wraps one of the counted thumbnails (no double count).
 * uploading = a progressbar / spinner / percent label inside the composer
 * container, or an <img> in the container that has not finished loading. */
function sfaIngredients() {
  function vis(el) {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    const s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
  }
  const cands = [];
  document.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"]').forEach((el) => {
    if (!vis(el)) return;
    const hint = ((el.getAttribute('placeholder') || '') + ' ' + (el.getAttribute('aria-label') || '')).toLowerCase();
    const r = el.getBoundingClientRect();
    let score = (r.width * r.height) / 1000;
    if (/what do you want|describe|prompt|create|imagine/.test(hint)) score += 5000;
    if (r.top > window.innerHeight * 0.35) score += 2000;
    cands.push({ el, score });
  });
  cands.sort((a, b) => b.score - a.score);
  if (!cands.length) return { ingredients: -1, uploading: false };
  let container = cands[0].el;
  for (let up = 0; up < 7 && container; up++) {
    container = container.parentElement;
    if (!container) break;
    let hasBtn = false;
    container.querySelectorAll('button, [role="button"]').forEach((b) => { if (vis(b)) hasBtn = true; });
    if (hasBtn) break;
  }
  if (!container) container = cands[0].el.parentElement || document.body;

  const thumbs = [];
  let uploading = false;
  container.querySelectorAll('img').forEach((im) => {
    if (im === cands[0].el) return;
    if (!vis(im)) return;
    if (im.naturalWidth >= 50) thumbs.push(im);
    else if (!im.complete) uploading = true; // still loading inside the composer
  });
  let labels = 0;
  container.querySelectorAll('*').forEach((e) => {
    if (e === cands[0].el) return;
    if (!vis(e)) return;
    const t = (e.textContent || '').trim();
    if (!t || t.length > 60) return;
    if (!/\.(png|jpe?g)\b/i.test(t)) return;
    // Must be a leaf-ish label (the filename text itself), not an ancestor
    // whose textContent merely contains the filename deeper down.
    let own = '';
    e.childNodes.forEach((n) => { if (n.nodeType === 3) own += n.textContent; });
    if (!/\.(png|jpe?g)\b/i.test(own)) return;
    // Pair the label with a thumbnail when a small wrapper holds both:
    // walk up (max 3 levels) to the nearest ancestor containing counted
    // thumbnails — exactly 1 means this label belongs to that same
    // ingredient; more than 1 means a shared row, where the label is a
    // unit of its own. The walk stops at the composer level itself (the
    // ancestor that also holds the input): a thumbnail and a label that
    // only meet there are SEPARATE ingredients in the same row.
    let wrapsThumb = false;
    let anc = e;
    for (let up = 0; up < 3 && anc; up++) {
      if (up > 0 && anc.contains(cands[0].el)) break;
      let n = 0;
      thumbs.forEach((im) => { if (anc.contains(im)) n++; });
      if (n === 1) { wrapsThumb = true; break; }
      if (n > 1) break;
      anc = anc.parentElement;
    }
    if (!wrapsThumb) labels++;
  });
  container.querySelectorAll('[role="progressbar"], progress, [class*="spinner" i], [class*="progress" i], [aria-label*="upload" i]').forEach((e) => {
    if (vis(e)) uploading = true;
  });
  container.querySelectorAll('*').forEach((e) => {
    if (!vis(e)) return;
    const t = (e.textContent || '').trim();
    if (/^\d{1,3}\s*%$/.test(t) || /uploading/i.test(t)) uploading = true;
  });
  return { ingredients: thumbs.length + labels, uploading };
}

/* v2.0 — tile snapshot. Google Flow renders the project grid as
 * flow-grid-tile-container elements; generated thumbnails are <img>
 * with signed https://flow.google.com/asb/... URLs (NOT
 * googleusercontent — that is why the v1.6 counter was blind) and
 * carry data-media-id. Error tiles contain flow-error-tile with an
 * .error-title "Failed" and Retry / Reuse prompt / Delete buttons.
 * In-progress tiles show "NN%" text that vanishes at completion, but a
 * brand-new tile may show no % in its first seconds — so completion
 * also requires a thumbnail. One snapshot entry per tile, document
 * order (newest first in the grid), capped at 60. */
function sfaTiles() {
  function vis(el) {
    if (!el) return false;
    var r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    var s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
  }
  function center(el) {
    var r = el.getBoundingClientRect();
    return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) };
  }
  var containers = [];
  try {
    containers = Array.prototype.slice.call(document.querySelectorAll('.flow-grid-tile-container'));
  } catch (e) { containers = []; }
  if (!containers.length) {
    var seen = [];
    var markers = [];
    try {
      markers = document.querySelectorAll('[class*="flow-image-tile"], [class*="flow-error-tile"], [class*="flow-video-tile"], img[data-media-id]');
    } catch (e) { markers = []; }
    Array.prototype.forEach.call(markers, function (m) {
      var t = m;
      for (var up = 0; up < 4 && t; up++) {
        if (/tile/.test(t.className || '')) break;
        t = t.parentElement;
      }
      var wrap = t || m.parentElement || m;
      if (seen.indexOf(wrap) === -1) { seen.push(wrap); containers.push(wrap); }
    });
  }
  var out = [];
  for (var i = 0; i < containers.length && out.length < 60; i++) {
    var c = containers[i];
    if (!vis(c)) continue;
    var midEl = null;
    try { midEl = c.querySelector('[data-media-id]'); } catch (e) { midEl = null; }
    var mediaId = midEl ? midEl.getAttribute('data-media-id') : null;
    if (!mediaId && c.getAttribute) mediaId = c.getAttribute('data-media-id');
    var img = null;
    try { img = c.querySelector('img'); } catch (e) { img = null; }
    var text = (c.textContent || '').replace(/\s+/g, ' ').trim();
    var isError = false;
    var isImage = false;
    var isVideo = false;
    try {
      isError = !!c.querySelector('[class*="flow-error-tile"], .error-title');
      isImage = !!c.querySelector('[class*="flow-image-tile"]');
      isVideo = !!c.querySelector('[class*="flow-video-tile"], video');
    } catch (e) { /* partial info is fine */ }
    var kind = isError ? 'error' : (isImage ? 'image' : (isVideo ? 'video' : (img ? 'image' : 'other')));
    var pctM = text.match(/(\d{1,3})\s*%/);
    var retryBtn = null;
    if (isError) {
      var btns = [];
      try { btns = c.querySelectorAll('button, [role="button"]'); } catch (e) { btns = []; }
      for (var b = 0; b < btns.length; b++) {
        var bl = ((btns[b].getAttribute('aria-label') || '') + ' ' + (btns[b].textContent || '')).replace(/\s+/g, ' ').trim();
        if (/retry/i.test(bl) && vis(btns[b])) { retryBtn = center(btns[b]); break; }
      }
    }
    var videoSrc = '';
    if (isVideo) {
      try {
        var vEl = c.querySelector('video');
        if (vEl) {
          videoSrc = vEl.currentSrc || vEl.src || '';
          if (!videoSrc && vEl.querySelector) {
            var vSrcEl = null;
            try { vSrcEl = vEl.querySelector('source'); } catch (e2) { vSrcEl = null; }
            if (vSrcEl) videoSrc = vSrcEl.getAttribute('src') || vSrcEl.src || '';
          }
        }
      } catch (e) { videoSrc = ''; }
    }
    var label = (c.getAttribute && c.getAttribute('aria-label')) || (img && img.getAttribute('alt')) || text;
    out.push({
      mediaId: mediaId || null,
      kind: kind,
      hasPct: !!pctM,
      pct: pctM ? parseInt(pctM[1], 10) : null,
      hasThumb: !!(img && (img.currentSrc || img.src)),
      videoSrc: videoSrc,
      label: String(label || '').slice(0, 60),
      text: text.slice(0, 240),
      retryBtn: retryBtn,
      key: mediaId ? ('mid:' + mediaId) : ('pos:' + i)
    });
  }
  return out;
}

/* v2.0 — find a project asset (grid tile) whose shown name matches the
 * reference file name. Uploads persist per project and an uploaded
 * asset's name is its file name; a clipboard paste lands with a generic
 * name. Matching: case-insensitive, full name or extension-stripped
 * base name as substring of the tile label. */
function sfaFindAsset(name) {
  function vis(el) {
    if (!el) return false;
    var r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    var s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
  }
  function center(el) {
    var r = el.getBoundingClientRect();
    return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) };
  }
  var target = String(name || '').toLowerCase().trim();
  if (!target) return { found: false };
  var base = target.replace(/\.[a-z0-9]{1,5}$/, '');
  var containers = [];
  try {
    containers = Array.prototype.slice.call(document.querySelectorAll('.flow-grid-tile-container'));
  } catch (e) { containers = []; }
  if (!containers.length) {
    try {
      containers = Array.prototype.slice.call(document.querySelectorAll('[data-media-id]')).map(function (el) {
        return (el.closest && el.closest('[class*="tile"]')) || el.parentElement || el;
      });
    } catch (e) { containers = []; }
  }
  var uniq = [];
  containers.forEach(function (c) { if (c && uniq.indexOf(c) === -1) uniq.push(c); });
  for (var i = 0; i < uniq.length; i++) {
    var c = uniq[i];
    if (!vis(c)) continue;
    var midEl = null;
    try { midEl = c.querySelector('[data-media-id]'); } catch (e) { midEl = null; }
    var mediaId = midEl ? midEl.getAttribute('data-media-id') : (c.getAttribute ? c.getAttribute('data-media-id') : null);
    var img = null;
    try { img = c.querySelector('img'); } catch (e) { img = null; }
    var label = ((c.getAttribute && c.getAttribute('aria-label')) || (img && img.getAttribute('alt')) || (c.textContent || '')).replace(/\s+/g, ' ').trim();
    var low = label.toLowerCase();
    var match = low === target || low.indexOf(target) !== -1 || (base.length >= 3 && low.indexOf(base) !== -1);
    if (!match) continue;
    var ctr = center(c);
    return { found: true, mediaId: mediaId || null, label: label.slice(0, 60), hasPct: /\d+\s*%/.test(c.textContent || ''), x: ctr.x, y: ctr.y };
  }
  return { found: false };
}

/* v2.1 — ingredient picker state. The REAL Flow picker is a custom
 * panel (field-proven by the user's V2 run report + screenshot):
 * a "Search assets" input at the top, category rows (All / Images /
 * Videos / Voices / Characters / Avatars / Uploads) as icon+text rows,
 * asset rows with a thumbnail + two-line text ("image.png" / "Image"),
 * a large preview, an "Upload media" button and an "Add to prompt"
 * button. The v2.0 probe looked for role=listbox/option markup and
 * data-media-id thumbnails; on the real page it saw exactly 1 option
 * it could not match. v2.1 therefore identifies the picker container
 * as the smallest visible ancestor holding BOTH the search input and
 * the "Add to prompt" button, and extracts tabs/options generically
 * inside it. Fallback: the v2.0 listbox-based detection. */
function sfaPicker() {
  function vis(el) {
    if (!el) return false;
    var r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    var s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
  }
  function center(el) {
    var r = el.getBoundingClientRect();
    return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) };
  }
  function clean(s) { return String(s || '').replace(/\s+/g, ' ').trim(); }
  var TABNAMES = ['All', 'Images', 'Videos', 'Voices', 'Characters', 'Avatars', 'Uploads'];
  var FILERX = /\S+\.(png|jpe?g|webp)/i;

  // "Add to prompt" / "Upload media" buttons (document-wide).
  var addBtnEl = null;
  var uploadBtnEl = null;
  try {
    document.querySelectorAll('button, [role="button"]').forEach(function (b) {
      if (!vis(b)) return;
      var label = clean((b.getAttribute('aria-label') || '') + ' ' + (b.textContent || ''));
      if (!addBtnEl && /add to prompt/i.test(label)) addBtnEl = b;
      if (!uploadBtnEl && /upload media/i.test(label)) uploadBtnEl = b;
    });
  } catch (e) { /* partial info is fine */ }

  // "Search assets" input.
  var searchEl = null;
  try {
    document.querySelectorAll('input').forEach(function (inp) {
      if (searchEl || !vis(inp)) return;
      var hint = (inp.getAttribute('placeholder') || '') + ' ' + (inp.getAttribute('aria-label') || '');
      if (/search assets/i.test(hint)) searchEl = inp;
    });
  } catch (e) { searchEl = null; }

  var addBtn = addBtnEl ? center(addBtnEl) : null;
  var searchInput = searchEl ? center(searchEl) : null;

  // Picker container: smallest ancestor of the search input that also
  // holds the "Add to prompt" button.
  var container = null;
  if (searchEl && addBtnEl) {
    var up0 = searchEl.parentElement;
    while (up0 && up0 !== document.body) {
      if (up0.contains && up0.contains(addBtnEl)) { container = up0; break; }
      up0 = up0.parentElement;
    }
  }

  if (container) {
    // Tabs: any element whose whole trimmed text is exactly a category
    // name; keep the leaf-most element per name (a row wrapper and its
    // inner label can both match).
    var tabs = [];
    try {
      var tabCands = [];
      container.querySelectorAll('*').forEach(function (el) {
        if (!vis(el)) return;
        if (TABNAMES.indexOf(clean(el.textContent)) !== -1) tabCands.push(el);
      });
      tabCands.forEach(function (el) {
        var wrapped = false;
        for (var ti = 0; ti < tabCands.length; ti++) {
          if (tabCands[ti] !== el && el.contains && el.contains(tabCands[ti])) { wrapped = true; break; }
        }
        if (wrapped) return;
        var nm = clean(el.textContent);
        var dup = false;
        for (var tj = 0; tj < tabs.length; tj++) if (tabs[tj].name === nm) dup = true;
        if (dup) return;
        var tc = center(el);
        tabs.push({ name: nm, x: tc.x, y: tc.y });
      });
    } catch (e) { tabs = []; }

    // Options: elements inside the results area holding an img AND
    // short visible text. Smallest area first; an element wrapping an
    // already-taken row (or nested inside one) is skipped, so the
    // panel wrappers and the preview pane do not pollute the list.
    var options = [];
    try {
      var cands = [];
      container.querySelectorAll('*').forEach(function (el) {
        if (!vis(el)) return;
        var im = null;
        try { im = el.querySelector('img'); } catch (e2) { im = null; }
        if (!im) return;
        var tx = clean(el.textContent);
        if (!tx || tx.length > 80) return;
        if (TABNAMES.indexOf(tx) !== -1) return;
        if (searchEl && el.contains && el.contains(searchEl)) return;
        if (addBtnEl && el.contains && el.contains(addBtnEl)) return;
        if (uploadBtnEl && el.contains && el.contains(uploadBtnEl)) return;
        var rr = el.getBoundingClientRect();
        cands.push({ el: el, area: rr.width * rr.height });
      });
      cands.sort(function (a, b) { return a.area - b.area; });
      var taken = [];
      cands.forEach(function (cd) {
        if (options.length >= 40) return;
        var el = cd.el;
        var clash = false;
        for (var ki = 0; ki < taken.length; ki++) {
          if (taken[ki] === el || (taken[ki].contains && taken[ki].contains(el)) || (el.contains && el.contains(taken[ki]))) { clash = true; break; }
        }
        if (clash) return;
        taken.push(el);
        var midEl = null;
        try { midEl = (el.getAttribute && el.getAttribute('data-media-id')) ? el : el.querySelector('[data-media-id]'); } catch (e3) { midEl = null; }
        var mediaId = midEl ? midEl.getAttribute('data-media-id') : null;
        var raw = (typeof el.innerText === 'string' && el.innerText) ? el.innerText : (el.textContent || '');
        var lines = String(raw).split('\n').map(function (s) { return clean(s); }).filter(function (s) { return !!s; });
        var name = '';
        for (var li = 0; li < lines.length; li++) {
          var mm = lines[li].match(FILERX);
          if (mm) { name = mm[0]; break; }
        }
        if (!name) name = (lines[0] || clean(el.textContent)).slice(0, 60);
        var oc = center(el);
        options.push({ mediaId: mediaId || null, name: String(name).slice(0, 60), x: oc.x, y: oc.y });
      });
    } catch (e) { options = []; }
    return { open: true, tabs: tabs, options: options, addBtn: addBtn, uploadBtn: !!uploadBtnEl, searchInput: searchInput };
  }

  // ---- fallback: v2.0 listbox-based detection ----
  var listbox = null;
  try {
    document.querySelectorAll('[role="listbox"]').forEach(function (lb) {
      if (!listbox && vis(lb)) listbox = lb;
    });
  } catch (e) { listbox = null; }
  var scope = listbox || document;
  if (listbox) {
    var up = listbox;
    for (var i = 0; i < 5 && up; i++) {
      up = up.parentElement;
      if (!up) break;
      var hasTabs = false;
      try { hasTabs = !!up.querySelector('[role="tab"]'); } catch (e) { hasTabs = false; }
      if (hasTabs) { scope = up; break; }
    }
  }
  var tabs2 = [];
  try {
    scope.querySelectorAll('[role="tab"], button').forEach(function (t) {
      if (!vis(t)) return;
      var tx = (t.textContent || '').replace(/\s+/g, ' ').trim();
      if (TABNAMES.indexOf(tx) !== -1) {
        var ctr = center(t);
        tabs2.push({ name: tx, x: ctr.x, y: ctr.y });
      }
    });
  } catch (e) { tabs2 = []; }
  var options2 = [];
  var optEls = [];
  try {
    (listbox || scope).querySelectorAll('[role="option"]').forEach(function (o) { optEls.push(o); });
  } catch (e) { optEls = []; }
  if (!optEls.length && listbox) {
    try {
      listbox.querySelectorAll('img[data-media-id]').forEach(function (im) {
        var o = (im.closest && im.closest('[role="option"], li, button')) || im.parentElement || im;
        if (optEls.indexOf(o) === -1) optEls.push(o);
      });
    } catch (e) { /* options stay empty */ }
  }
  optEls.forEach(function (o) {
    if (!vis(o)) return;
    var midEl2 = null;
    try { midEl2 = o.getAttribute && o.getAttribute('data-media-id') ? o : o.querySelector('[data-media-id]'); } catch (e) { midEl2 = null; }
    var mediaId2 = midEl2 ? midEl2.getAttribute('data-media-id') : (o.getAttribute ? o.getAttribute('data-media-id') : null);
    var im2 = null;
    try { im2 = o.querySelector('img'); } catch (e) { im2 = null; }
    var nm2 = (o.getAttribute && o.getAttribute('aria-label')) || (im2 && im2.getAttribute('alt')) || (o.textContent || '');
    var ctr2 = center(o);
    options2.push({ mediaId: mediaId2 || null, name: String(nm2 || '').replace(/\s+/g, ' ').trim().slice(0, 60), x: ctr2.x, y: ctr2.y });
  });
  var uploadBtn2 = false;
  if (scope !== document) {
    try {
      document.querySelectorAll('button, [role="button"]').forEach(function (b) {
        if (!vis(b)) return;
        var label2 = ((b.getAttribute('aria-label') || '') + ' ' + (b.textContent || '')).replace(/\s+/g, ' ').trim();
        if (/upload/i.test(label2) && scope.contains && scope.contains(b)) uploadBtn2 = true;
      });
    } catch (e) { /* uploadBtn stays false */ }
  }
  return { open: !!listbox || (tabs2.length > 0 && options2.length > 0), tabs: tabs2, options: options2, addBtn: addBtn, uploadBtn: uploadBtn2, searchInput: searchInput };
}

/* v2.0 — scroll the picker asset list down one page (for option search). */
function sfaPickerScroll() {
  var lb = null;
  try {
    document.querySelectorAll('[role="listbox"]').forEach(function (e) {
      if (lb) return;
      var r = e.getBoundingClientRect();
      if (r.width > 2 && r.height > 2) lb = e;
    });
  } catch (e) { lb = null; }
  var el = lb;
  for (var up = 0; up < 5 && el; up++) {
    if (el.scrollHeight > el.clientHeight + 10) { el.scrollTop = el.scrollTop + 400; return true; }
    el = el.parentElement;
  }
  if (lb) { lb.scrollTop = lb.scrollTop + 400; return true; }
  return false;
}

/* v2.0 — download URL + click point for a finished tile, by media id.
 * Returns the tile's centre (for the viewer-opening click) and the
 * thumbnail img URL (the signed flow.google.com/asb/... URL). */
function sfaTileUrl(mediaId) {
  if (!mediaId) return null;
  var img = null;
  try { img = document.querySelector('img[data-media-id="' + mediaId + '"]'); } catch (e) { img = null; }
  if (!img) {
    var all = [];
    try { all = document.querySelectorAll('[data-media-id]'); } catch (e) { all = []; }
    for (var i = 0; i < all.length; i++) {
      if (all[i].getAttribute('data-media-id') === mediaId && all[i].tagName === 'IMG') { img = all[i]; break; }
    }
  }
  if (!img) return null;
  var tile = img;
  if (img.closest) tile = img.closest('.flow-grid-tile-container') || img.parentElement || img;
  var r = tile.getBoundingClientRect();
  return {
    url: img.currentSrc || img.src || '',
    x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2),
    w: Math.round(r.width), h: Math.round(r.height)
  };
}

/* v2.0 — composer bar buttons by accessible name: the "+" ("Add
 * ingredients to the prompt box"), "Clear prompt", and the "Agent"
 * toggle state. Agent mode must be OFF: in Agent mode error tiles have
 * no Retry button and the agent asks for confirmations. */
/* v2.6 — fresh media lookup for one tile by media-id: returns the
 * video element's own source for video tiles (poster <img> ignored
 * for the URL when a <video> exists), else the image URL. Coords
 * point at the tile for the viewer fallback. */
function sfaTileMedia(mediaId) {
  if (!mediaId) return null;
  var host = null;
  var all = [];
  try { all = document.querySelectorAll('[data-media-id]'); } catch (e) { all = []; }
  for (var i = 0; i < all.length; i++) {
    if (all[i].getAttribute('data-media-id') === mediaId) {
      host = (all[i].closest ? (all[i].closest('.flow-grid-tile-container') || all[i]) : all[i]);
      break;
    }
  }
  if (!host) return null;
  var vEl = null;
  try { vEl = host.querySelector('video'); } catch (e) { vEl = null; }
  var url = '';
  var kind = 'image';
  if (vEl) {
    kind = 'video';
    url = vEl.currentSrc || vEl.src || '';
    if (!url && vEl.querySelector) {
      var srcEl = null;
      try { srcEl = vEl.querySelector('source'); } catch (e) { srcEl = null; }
      if (srcEl) url = srcEl.getAttribute('src') || srcEl.src || '';
    }
  }
  if (!url && !vEl) {
    var img = null;
    try { img = host.querySelector('img'); } catch (e) { img = null; }
    if (img) url = img.currentSrc || img.src || '';
  }
  var r = host.getBoundingClientRect();
  return {
    url: url, kind: kind,
    x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2),
    w: Math.round(r.width), h: Math.round(r.height)
  };
}

/* v2.6.2 — tile prompt reading for Prompt-check matching, in two
 * stages through one probe (evalFn passes a single argument):
 *  - sfaTilePrompt(mediaId): locate the grid tile with this media id
 *    and return its centre {stage:'tile', found, x, y} — the engine
 *    clicks it to open Flow's viewer.
 *  - sfaTilePrompt(null): a viewer is expected to be open — harvest
 *    the prompt text Flow shows for the open media and return
 *    {stage:'viewer', found, text, close}. An overlay signal is
 *    REQUIRED (a visible Download button, a [role=dialog], or a large
 *    fixed layer): with no viewer open the probe reports found:false
 *    instead of harvesting grid text. Inside the overlay, prompt-
 *    labelled regions win (class / data-testid / aria-label naming a
 *    prompt, textareas, contenteditables); otherwise the longest
 *    sentence-like leaf text block that is not UI chrome is used. */
function sfaTilePrompt(mediaId) {
  function vis(el) {
    if (!el) return false;
    var r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    var s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
  }
  function center(el) {
    var r = el.getBoundingClientRect();
    return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) };
  }
  function txt(el) {
    if (!el) return '';
    var v = (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') ? (el.value || '') : (el.innerText || el.textContent || '');
    return String(v).replace(/\s+/g, ' ').trim();
  }
  if (mediaId) {
    var host = null;
    var all = [];
    try { all = document.querySelectorAll('[data-media-id]'); } catch (e) { all = []; }
    for (var i = 0; i < all.length; i++) {
      if (all[i].getAttribute('data-media-id') === mediaId) {
        host = (all[i].closest ? (all[i].closest('.flow-grid-tile-container') || all[i]) : all[i]);
        break;
      }
    }
    if (!host || !vis(host)) return { stage: 'tile', found: false };
    var c0 = center(host);
    return { stage: 'tile', found: true, x: c0.x, y: c0.y };
  }
  // ---- viewer stage ----
  var dlBtn = null;
  var btns = [];
  try { btns = document.querySelectorAll('button, [role="button"], a'); } catch (e) { btns = []; }
  for (var b = 0; b < btns.length; b++) {
    var bl = ((btns[b].getAttribute('aria-label') || '') + ' ' + (btns[b].getAttribute('title') || '') + ' ' + (btns[b].textContent || '')).toLowerCase();
    if (!/download/.test(bl) || !vis(btns[b])) continue;
    if (!dlBtn || btns[b].getBoundingClientRect().top < dlBtn.getBoundingClientRect().top) dlBtn = btns[b];
  }
  var root = null;
  if (dlBtn) {
    root = dlBtn;
    for (var up = 0; up < 9 && root && root !== document.body; up++) {
      var rr = root.getBoundingClientRect();
      if (rr.width > window.innerWidth * 0.45 && rr.height > window.innerHeight * 0.45) break;
      root = root.parentElement;
    }
    if (!root) root = document.body;
  }
  if (!root || root === document.body) {
    var dlg = null;
    try { dlg = document.querySelector('[role="dialog"]'); } catch (e) { dlg = null; }
    if (dlg && vis(dlg)) root = dlg;
  }
  if (!root || root === document.body) return { stage: 'viewer', found: false, text: '', close: null };
  // close / back control inside the overlay (fallback if Escape fails)
  var closePt = null;
  var cbtns = [];
  try { cbtns = root.querySelectorAll('button, [role="button"], a'); } catch (e) { cbtns = []; }
  for (var cb = 0; cb < cbtns.length; cb++) {
    var cl = ((cbtns[cb].getAttribute('aria-label') || '') + ' ' + (cbtns[cb].textContent || '')).replace(/\s+/g, ' ').trim().toLowerCase();
    if (/^(close|back|done)$/.test(cl) && vis(cbtns[cb])) { closePt = center(cbtns[cb]); break; }
  }
  // 1) prompt-labelled regions
  var labelled = [];
  var lq = [];
  try { lq = root.querySelectorAll('[class*="prompt" i], [data-testid*="prompt" i], [aria-label*="prompt" i], textarea, [contenteditable="true"]'); } catch (e) { lq = []; }
  for (var li = 0; li < lq.length; li++) {
    if (!vis(lq[li])) continue;
    var lt = txt(lq[li]);
    if (lt.length >= 10) labelled.push(lt);
  }
  labelled.sort(function (a, z) { return z.length - a.length; });
  if (labelled.length) return { stage: 'viewer', found: true, text: labelled[0].slice(0, 6000), close: closePt };
  // 2) longest sentence-like leaf block that is not UI chrome
  var best = '';
  var blocks = [];
  try { blocks = root.querySelectorAll('p, div, span, pre'); } catch (e) { blocks = []; }
  for (var bi = 0; bi < blocks.length; bi++) {
    var el = blocks[bi];
    if (!vis(el)) continue;
    if (el.closest && el.closest('button, [role="button"], a')) continue;
    var inner = 0;
    try { inner = el.querySelectorAll('p, div, span, pre').length; } catch (e) { inner = 99; }
    if (inner > 3) continue;
    var t = txt(el);
    if (t.length < 25 || t.length > 6000) continue;
    if (!/ /.test(t)) continue;
    if (/^(download|remix|extend|animate|add to project|delete|share|copy prompt)$/i.test(t)) continue;
    if (t.length > best.length) best = t;
  }
  if (best) return { stage: 'viewer', found: true, text: best.slice(0, 6000), close: closePt };
  // v3.0.1: reaching here means a viewer overlay WAS open (its root
  // was found above) but no prompt text exists anywhere in it.
  // overlayOpen keeps that verdict distinct from "no viewer at all"
  // (the early return above) — a prompt-less viewer is decisive for
  // uploads, a missing viewer is just a retryable failure.
  return { stage: 'viewer', found: false, text: '', close: closePt, overlayOpen: true };
}

/* v3 — the truth layer: the project's own media listing, fetched from
 * the page (authenticated fetch, cookies ride along). Flow loads the
 * whole library through this tRPC call on project open; the payload is
 * complete (not paginated, not virtualized), every asset carries its
 * UUID, generated rows are distinguishable from uploads by their
 * sub-key (generatedImage vs userUploadedImage), and generated rows
 * carry their original request data — including the prompt. This probe
 * normalizes that payload to compact rows; it never throws — any
 * failure is {ok:false} and the engine falls back to DOM behaviour. */
async function sfaProjectData() {
  function digPrompt(obj, depth) {
    if (!obj || typeof obj !== 'object' || depth > 5) return '';
    var keys = Object.keys(obj);
    for (var i = 0; i < keys.length; i++) {
      var k = keys[i];
      var v = obj[k];
      if (typeof v === 'string' && v.length >= 20 && /prompt/i.test(k)) return v;
    }
    for (var j = 0; j < keys.length; j++) {
      var sub = obj[keys[j]];
      if (sub && typeof sub === 'object') {
        var r = digPrompt(sub, depth + 1);
        if (r) return r;
      }
    }
    return '';
  }
  function findContents(obj, depth) {
    if (!obj || typeof obj !== 'object' || depth > 6) return null;
    if (Array.isArray(obj.media)) return obj;
    var keys = Object.keys(obj);
    for (var i = 0; i < keys.length; i++) {
      var r = findContents(obj[keys[i]], depth + 1);
      if (r) return r;
    }
    return null;
  }
  try {
    var segs = String(location.pathname || '').split('/').filter(Boolean);
    var projectId = '';
    for (var s = 0; s < segs.length - 1; s++) {
      if (segs[s] === 'project') { projectId = segs[s + 1]; break; }
    }
    if (!projectId) {
      for (var s2 = 0; s2 < segs.length; s2++) {
        if (/^[0-9a-f-]{16,}$/i.test(segs[s2])) { projectId = segs[s2]; break; }
      }
    }
    if (!projectId) return { ok: false, reason: 'no project id in URL' };
    var input = encodeURIComponent(JSON.stringify({ json: { projectId: projectId, toolName: 'PINHOLE' } }));
    var paths = ['/fx/api/trpc/flow.projectInitialData?input=' + input, '/api/trpc/flow.projectInitialData?input=' + input];
    var payload = null;
    for (var p = 0; p < paths.length && !payload; p++) {
      try {
        var res = await fetch(location.origin + paths[p], { credentials: 'include' });
        if (res && res.ok) payload = await res.json();
      } catch (e) { /* try next path */ }
    }
    if (!payload) return { ok: false, reason: 'listing fetch failed' };
    var contents = findContents(payload, 0);
    if (!contents) return { ok: false, reason: 'listing shape not recognised' };
    var wfNames = {};
    var workflows = [];
    var wfs = Array.isArray(contents.workflows) ? contents.workflows : [];
    for (var w = 0; w < wfs.length; w++) {
      var wf = wfs[w] || {};
      var md = wf.metadata || {};
      var pmid = md.primaryMediaId || '';
      if (pmid && md.displayName) wfNames[pmid] = String(md.displayName);
      workflows.push({
        id: String(wf.name || wf.id || ''),
        primaryMediaId: String(pmid || ''),
        createdAt: Date.parse((wf.metadata && wf.metadata.createTime) || wf.createTime || '') || 0
      });
    }
    var media = [];
    var rows = Array.isArray(contents.media) ? contents.media : [];
    for (var i = 0; i < rows.length; i++) {
      var m = rows[i] || {};
      var uuid = String(m.name || m.id || m.mediaId || '');
      if (!uuid) continue;
      var kindObj = m.image || m.video || null;
      var kind = m.video ? 'video' : 'image';
      var origin = 'generated';
      if (kindObj && typeof kindObj === 'object') {
        var ks = Object.keys(kindObj);
        for (var k = 0; k < ks.length; k++) {
          if (/userUploaded/i.test(ks[k]) && kindObj[ks[k]]) { origin = 'upload'; break; }
        }
      }
      var createdAt = 0;
      if (m.mediaMetadata && m.mediaMetadata.createTime) createdAt = Date.parse(m.mediaMetadata.createTime) || 0;
      if (!createdAt && m.createTime) createdAt = Date.parse(m.createTime) || 0;
      var prompt = '';
      if (origin === 'generated') {
        prompt = digPrompt(m.requestData || null, 0) ||
          digPrompt((m.mediaMetadata && m.mediaMetadata.requestData) || null, 0) ||
          digPrompt(kindObj, 0);
      }
      media.push({
        uuid: uuid,
        kind: kind,
        origin: origin,
        prompt: String(prompt || '').slice(0, 4000),
        displayName: String(wfNames[uuid] || m.displayName || '').slice(0, 200),
        createdAt: createdAt
      });
    }
    return { ok: true, projectId: projectId, media: media, workflows: workflows };
  } catch (e) {
    return { ok: false, reason: String((e && e.message) || e) };
  }
}

/* v3 — bring one tile (by media-id) into the visible grid window: the
 * grid is virtualized, so a tile may not exist in the DOM until it is
 * scrolled to. Returns the tile centre (post-scroll coords are
 * approximate — callers re-probe for precision). */
function sfaRevealTile(mediaId) {
  if (!mediaId) return { found: false };
  var host = null;
  var all = [];
  try { all = document.querySelectorAll('[data-media-id]'); } catch (e) { all = []; }
  for (var i = 0; i < all.length; i++) {
    if (all[i].getAttribute('data-media-id') === mediaId) {
      host = (all[i].closest ? (all[i].closest('.flow-grid-tile-container') || all[i]) : all[i]);
      break;
    }
  }
  if (!host) return { found: false };
  try { host.scrollIntoView({ block: 'center' }); } catch (e) { /* best effort */ }
  var r = host.getBoundingClientRect();
  return { found: true, x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) };
}

/* v2.6 — the composer's settings chip(s): the buttons in the composer
 * bar that name the model ("Nano Banana 2.1"), the ratio or the count
 * ("x1"). open = where to click to open the settings menu (the model
 * chip preferred); text = the settings labels joined, for read-back
 * verification after applying. */
function sfaGenChip() {
  function vis(el) {
    if (!el) return false;
    var r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    var st = getComputedStyle(el);
    return st.display !== 'none' && st.visibility !== 'hidden' && st.opacity !== '0';
  }
  function center(el) {
    var r = el.getBoundingClientRect();
    return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) };
  }
  var cands = [];
  document.querySelectorAll('textarea, [contenteditable="true"], [role="textbox"]').forEach(function (el) {
    if (!vis(el)) return;
    var hint = ((el.getAttribute('placeholder') || '') + ' ' + (el.getAttribute('aria-label') || '')).toLowerCase();
    var r = el.getBoundingClientRect();
    var score = (r.width * r.height) / 1000;
    if (/what do you want|describe|prompt|create|imagine/.test(hint)) score += 5000;
    if (r.top > window.innerHeight * 0.35) score += 2000;
    cands.push({ el: el, score: score });
  });
  cands.sort(function (a, b) { return b.score - a.score; });
  if (!cands.length) return { found: false, text: '', open: null };
  var inputEl = cands[0].el;
  var container = inputEl;
  for (var up = 0; up < 7 && container; up++) {
    container = container.parentElement;
    if (!container) break;
    var hasBtn = false;
    container.querySelectorAll('button, [role="button"]').forEach(function (b) { if (vis(b)) hasBtn = true; });
    if (hasBtn) break;
  }
  if (!container) container = inputEl.parentElement || document.body;
  var modelBtn = null;
  var anyBtn = null;
  var texts = [];
  container.querySelectorAll('button, [role="button"]').forEach(function (b) {
    if (!vis(b)) return;
    var tx = ((b.getAttribute('aria-label') || '') + ' ' + (b.textContent || '')).replace(/\s+/g, ' ').trim();
    if (!tx) return;
    var isModel = /banana|imagen|veo/i.test(tx);
    var isCount = /[x\u00d7]\s*[1-4](?!\d)/.test(tx);
    var isRatio = /(16:9|9:16|1:1|4:3|3:4)/.test(tx);
    if (isModel || isCount || isRatio) {
      texts.push(tx.slice(0, 40));
      var c = center(b);
      var cand = { x: c.x, y: c.y, label: tx.slice(0, 60) };
      if (isModel && !modelBtn) modelBtn = cand;
      if (!anyBtn) anyBtn = cand;
    }
  });
  return { found: !!(modelBtn || anyBtn), text: texts.join(' | '), open: modelBtn || anyBtn };
}

/* v2.6 — the composer settings MENU: option-like elements inside a
 * visible overlay (menu / popover / listbox), classified by visible
 * text into type | model | ratio | count, with a best-effort selected
 * flag (aria checked/selected/pressed, data-state, marker class).
 * Fallback: option-like elements low on the page outside the media
 * grid and the left rail — accepted only if they include a type or
 * ratio option, or at least two options. */
function sfaGenMenu() {
  function vis(el) {
    if (!el) return false;
    var r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    var st = getComputedStyle(el);
    return st.display !== 'none' && st.visibility !== 'hidden' && st.opacity !== '0';
  }
  function center(el) {
    var r = el.getBoundingClientRect();
    return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) };
  }
  function labelOf(el) {
    return ((el.getAttribute('aria-label') || '') + ' ' + (el.textContent || '')).replace(/\s+/g, ' ').trim();
  }
  function classify(tx) {
    var t = String(tx || '').replace(/\s+/g, ' ').trim();
    if (!t || t.length > 60) return '';
    if (/(16:9|9:16|1:1|4:3|3:4)/.test(t)) return 'ratio';
    if (/^[x\u00d7]?\s*[1-4]$/.test(t)) return 'count';
    var low = t.toLowerCase();
    if (low === 'image' || low === 'images' || low === 'video' || low === 'videos') return 'type';
    if (/banana|imagen|veo/.test(low)) return 'model';
    return '';
  }
  function isSelected(el) {
    if (el.getAttribute('aria-checked') === 'true') return true;
    if (el.getAttribute('aria-selected') === 'true') return true;
    if (el.getAttribute('aria-pressed') === 'true') return true;
    var ds = String(el.getAttribute('data-state') || '').toLowerCase();
    if (ds === 'checked' || ds === 'active' || ds === 'on') return true;
    var cls = ' ' + String(el.className || '') + ' ';
    if (/\s(selected|active|checked)\s/.test(cls)) return true;
    return false;
  }
  var out = [];
  function push(el) {
    var tx = labelOf(el);
    var group = classify(tx);
    if (!group) return;
    var c = center(el);
    out.push({ text: tx.slice(0, 60), group: group, selected: isSelected(el), x: c.x, y: c.y });
  }
  var overlays = [];
  try {
    overlays = document.querySelectorAll('[role="menu"], [role="listbox"], [role="dialog"], [data-radix-popper-content-wrapper], [class*="popover" i], [class*="dropdown" i], [class*="menu" i]');
  } catch (e) { overlays = []; }
  var fromOverlay = false;
  Array.prototype.forEach.call(overlays, function (o) {
    if (!vis(o)) return;
    var before = out.length;
    try {
      o.querySelectorAll('button, [role="button"], [role="menuitem"], [role="option"], [role="radio"], [role="tab"], [aria-checked], li').forEach(function (el) {
        if (vis(el)) push(el);
      });
    } catch (e) { /* partial info is fine */ }
    if (out.length > before) fromOverlay = true;
  });
  if (!out.length) {
    var all = [];
    try { all = document.querySelectorAll('button, [role="button"], [role="radio"], [role="tab"]'); } catch (e) { all = []; }
    Array.prototype.forEach.call(all, function (el) {
      if (!vis(el)) return;
      if (el.closest && el.closest('.flow-grid-tile-container')) return;
      var r = el.getBoundingClientRect();
      if (r.top < window.innerHeight * 0.4) return;
      if (r.left < 170 && r.width < 200) return;
      push(el);
    });
    var strong = out.filter(function (o) { return o.group === 'type' || o.group === 'ratio'; });
    if (!strong.length && out.length < 2) out = [];
  }
  return { open: out.length > 0, fromOverlay: fromOverlay, options: out };
}

function sfaComposerBar() {
  function vis(el) {
    if (!el) return false;
    var r = el.getBoundingClientRect();
    if (r.width < 2 || r.height < 2) return false;
    var s = getComputedStyle(el);
    return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
  }
  function center(el) {
    var r = el.getBoundingClientRect();
    return { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2) };
  }
  var plus = null;
  var clear = null;
  var agent = { present: false, active: false };
  try {
    document.querySelectorAll('button, [role="button"]').forEach(function (b) {
      if (!vis(b)) return;
      var al = (b.getAttribute('aria-label') || '').trim();
      var tx = (b.textContent || '').replace(/\s+/g, ' ').trim();
      if (!plus && /add ingredients/i.test(al)) { var c1 = center(b); plus = { x: c1.x, y: c1.y, label: al.slice(0, 60) }; }
      if (!clear && (/clear prompt/i.test(al) || tx === 'Clear prompt')) { var c2 = center(b); clear = { x: c2.x, y: c2.y, label: (al || tx).slice(0, 60) }; }
      if ((al === 'Agent' || tx === 'Agent') && !agent.present) {
        agent.present = true;
        agent.active = b.getAttribute('aria-pressed') === 'true' || b.getAttribute('aria-selected') === 'true' || b.getAttribute('aria-checked') === 'true';
      }
    });
  } catch (e) { /* partial info is fine */ }
  return { plus: plus, clear: clear, agent: agent };
}

/* v2.0 — find a visible button/menu item whose label contains the given
 * text (used for the "1K Original size" entry in the download menu). */
function sfaFindTextBtn(arg) {
  var want = String((arg && arg.text) || '').toLowerCase();
  if (!want) return null;
  var best = null;
  try {
    document.querySelectorAll('button, [role="button"], [role="menuitem"], a').forEach(function (b) {
      if (best) return;
      var label = ((b.getAttribute('aria-label') || '') + ' ' + (b.textContent || '')).replace(/\s+/g, ' ').trim();
      if (label.toLowerCase().indexOf(want) === -1) return;
      var r = b.getBoundingClientRect();
      if (r.width < 2 || r.height < 2) return;
      var s = getComputedStyle(b);
      if (s.display === 'none' || s.visibility === 'hidden') return;
      best = { x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2), label: label.slice(0, 60) };
    });
  } catch (e) { best = null; }
  return best;
}

/* Pure helpers (background scope, unit-tested): picker option
 * matching and result-tile picking: the first image tile that is NEW
 * (mediaId not in the pre-send snapshot), is not the reference upload
 * itself, has a thumbnail and shows no progress %.
 * v2.1 matching order (the winner is tagged on the option as .via):
 * (a) exact data-media-id; (b) name — the option name contains the
 * recorded asset name or the original file name (full or extension-
 * stripped base, case-insensitive); (c) single-option shortcut: only
 * one asset is visible in the picker, so it IS the reference;
 * (d) filename-pattern: with at most 3 options, the first whose name
 * looks like an image file. */
function sfaMatchOption(options, refMediaId, refAssetName, refFileName) {
  if (!options || !options.length) return null;
  var i;
  if (refMediaId) {
    for (i = 0; i < options.length; i++) {
      if (options[i].mediaId && options[i].mediaId === refMediaId) { options[i].via = 'mediaId'; return options[i]; }
    }
  }
  var cands = [];
  [refAssetName, refFileName].forEach(function (v) {
    var s = String(v || '').toLowerCase().trim();
    if (!s) return;
    if (cands.indexOf(s) === -1) cands.push(s);
    var b = s.replace(/\.[a-z0-9]{1,5}$/, '');
    if (b.length >= 3 && cands.indexOf(b) === -1) cands.push(b);
  });
  if (cands.length) {
    for (i = 0; i < options.length; i++) {
      var n = String(options[i].name || '').toLowerCase();
      if (!n) continue;
      for (var ci = 0; ci < cands.length; ci++) {
        if (n.indexOf(cands[ci]) !== -1) { options[i].via = 'name'; return options[i]; }
      }
    }
  }
  if (options.length === 1) { options[0].via = 'single'; return options[0]; }
  if (options.length <= 3) {
    for (i = 0; i < options.length; i++) {
      if (/\.(png|jpe?g|webp)$/i.test(String(options[i].name || ''))) { options[i].via = 'filename'; return options[i]; }
    }
  }
  return null;
}
/* v2.1 pure helper: the name the picker displays for the uploaded
 * reference, taken from the completed upload tile's label — the first
 * filename-looking token in it; clipboard pastes land with a generic
 * name, so the fallback is 'image'. Recorded at gate time as
 * state.refPickerName and used as the picker search term. */
function sfaPickerNameFromLabel(label) {
  var m = String(label || '').match(/\S+\.(png|jpe?g|webp)/i);
  return m ? m[0] : 'image';
}
/* v2.1 pure helper: which term to type into the picker's "Search
 * assets" box. The recorded picker name wins; else the recorded asset
 * name when it is itself a filename; else the original file name's
 * base; else 'image'. */
function sfaSearchTerm(refPickerName, refAssetName, refFileName) {
  var pn = String(refPickerName || '').trim();
  if (pn) return pn;
  var an = String(refAssetName || '').trim();
  if (/\.(png|jpe?g|webp)$/i.test(an)) return an;
  var fn = String(refFileName || '').trim();
  if (fn) return fn.replace(/\.[a-z0-9]{1,5}$/i, '') || fn;
  return 'image';
}
function sfaPickResultTile(tiles, snapIds, refMediaId) {
  if (!tiles) return null;
  var ids = snapIds || [];
  for (var i = 0; i < tiles.length; i++) {
    var t = tiles[i];
    if (!t || t.kind !== 'image' || !t.mediaId) continue;
    if (ids.indexOf(t.mediaId) !== -1) continue;
    if (refMediaId && t.mediaId === refMediaId) continue;
    if (!t.hasThumb || t.hasPct) continue;
    return t;
  }
  return null;
}

function pacedIsTimedOut(sentAt, nowMs, limitMs) {
  if (!sentAt) return false;
  return (nowMs - sentAt) > (limitMs || 240000);
}

/* v2.6 pure helpers (unit-tested in tests/test-v26.js).
 * Generation options: the panel's GENERATION card mirrors Flow's
 * composer settings (type / model / aspect ratio / count). Model
 * labels are the visible menu texts in Flow; matching is done on
 * normalized text (lowercase, alphanumerics only) so "Veo 3.1 - Fast"
 * and "Veo 3.1 Fast" are the same option. */
const GEN_MODELS = {
  image: ['Nano Banana 2.1', 'Nano Banana Pro', 'Imagen 4'],
  video: ['Veo 3.1 Fast', 'Veo 3.1 Quality']
};
const GEN_RATIOS = ['16:9', '9:16', '1:1', '4:3', '3:4'];
function genDefaultModel(type) {
  const list = GEN_MODELS[type] || GEN_MODELS.image;
  return list[0];
}
function clampGenCount(v) {
  const n = parseInt(v, 10);
  if (!isFinite(n)) return 1;
  return Math.min(4, Math.max(1, n));
}
function genNormText(v) {
  return String(v || '').toLowerCase().replace(/[^a-z0-9]/g, '');
}
/* Best menu option for a wanted label: exact normalized match wins,
 * then a containment match either way ("Nano Banana 2.1" inside a
 * longer row label, or the row label inside the wanted text). */
function pickGenOption(options, want) {
  const wn = genNormText(want);
  if (!wn) return null;
  let soft = null;
  for (const o of options || []) {
    const on = genNormText(o && o.text);
    if (!on) continue;
    if (on === wn) return o;
    if (!soft && (on.indexOf(wn) !== -1 || wn.indexOf(on) !== -1)) soft = o;
  }
  return soft;
}
/* Read-back verification against the composer chip text: does it name
 * this model, and which count does it show ("... x2")? */
function chipHasText(chipText, want) {
  const wn = genNormText(want);
  if (!wn) return false;
  return genNormText(chipText).indexOf(wn) !== -1;
}
function chipCountOf(chipText) {
  const m = String(chipText || '').match(/[x\u00d7]\s*([1-4])(?!\d)/i);
  return m ? parseInt(m[1], 10) : null;
}
/* v2.6.1 — pure click gate for the settings / clear / picker-opener
 * clicks (fed by the sfaPointCheck probe). A click is allowed ONLY
 * when the point provably lands in the required zone (composer, or
 * composer-or-overlay for menu driving) and NEVER when it lands in
 * the media grid or on a destructive-labelled control (bin / delete /
 * trash / discard / remove). A blind probe counts as not found and is
 * refused: an unverifiable click does not happen. */
function genClickVerdict(check, opts) {
  opts = opts || {};
  if (!check || !check.found) return { ok: false, reason: 'point verify hoy ni' };
  if (check.inGrid) return { ok: false, reason: 'grid/tile area' };
  var label = String(check.label || '').toLowerCase();
  if (/move to bin|\bbin\b|delete|trash|discard|\bremove\b/.test(label)) {
    return { ok: false, reason: 'destructive label "' + label.slice(0, 40) + '"' };
  }
  if (opts.zone === 'composerOrOverlay' && !check.inComposer && !check.inOverlay) {
    return { ok: false, reason: 'composer/menu er baire' };
  }
  if (opts.zone === 'composer' && !check.inComposer) {
    return { ok: false, reason: 'composer er baire' };
  }
  return { ok: true, reason: '' };
}
/* All NEW finished result tiles of one kind relative to a snapshot,
 * in grid order (newest first). Image tiles need a thumbnail and no
 * %; video tiles need no % and (a poster or a video source). Shared
 * by the serial completion wait's count-quota collection. */
function sfaResultTiles(tiles, snapIds, refMediaId, wantKind) {
  var kind = wantKind === 'video' ? 'video' : 'image';
  var ids = snapIds || [];
  var out = [];
  var list = tiles || [];
  for (var i = 0; i < list.length; i++) {
    var t = list[i];
    if (!t || t.kind !== kind || !t.mediaId) continue;
    if (ids.indexOf(t.mediaId) !== -1) continue;
    if (refMediaId && t.mediaId === refMediaId) continue;
    if (t.hasPct) continue;
    if (kind === 'image' && !t.hasThumb) continue;
    if (kind === 'video' && !t.hasThumb && !t.videoSrc) continue;
    out.push(t);
  }
  return out;
}
/* v2.6 paced quota assignment: with Count = N, each prompt produces
 * N tiles. pendingEntries are [{id, got}] in SEND order; newTiles are
 * grid order (newest first) and are consumed OLDEST-finish-first,
 * filling the oldest item's quota before moving on. The tile that
 * takes an item from got 0 -> 1 is its ASSIGNMENT (its download);
 * later tiles for the same item are EXTRAS (skipped, noted once).
 * An item COMPLETES in the poll where its quota fills. */
/* v2.6.2 pure helpers (unit-tested in tests/test-v262.js).
 * Prompt-check matching: Flow's viewer shows the prompt a tile was
 * generated from — ground truth for assignment, unlike grid order.
 * Normalization is case/punctuation/whitespace-insensitive. A tile
 * matches an item EXACTLY when the normalized texts are equal or one
 * is a PREFIX of the other (a truncated view shows the START of a
 * prompt — a shared style suffix must never count as identity), with
 * a minimum-length guard on the shorter side; if TWO items match
 * exactly, the visible text cannot separate them and the overlap
 * margin rule decides (usually a tie -> no match). Otherwise the token-
 * overlap (intersection over the SMALLER token set — robust to
 * truncation) must reach 0.85 AND beat the runner-up by > 0.03, so
 * two prompts sharing a long style boilerplate cannot steal each
 * other's tiles on boilerplate alone: a near-tie is "no confident
 * match", never a guess. */
function promptNormText(s) {
  return String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').replace(/\s+/g, ' ').trim();
}
function promptTokenSet(s) {
  const n = promptNormText(s);
  const set = new Set();
  if (n) for (const w of n.split(' ')) if (w.length >= 2) set.add(w);
  return set;
}
function promptExactMatch(tileText, itemPrompt) {
  const a = promptNormText(tileText);
  const b = promptNormText(itemPrompt);
  if (!a || !b) return false;
  if (a === b) return true;
  const short = a.length <= b.length ? a : b;
  const long = a.length <= b.length ? b : a;
  return short.length >= 40 && long.indexOf(short) === 0;
}
function promptOverlapScore(tileText, itemPrompt) {
  const A = promptTokenSet(tileText);
  const B = promptTokenSet(itemPrompt);
  if (!A.size || !B.size) return 0;
  let inter = 0;
  for (const w of A) if (B.has(w)) inter++;
  return inter / Math.min(A.size, B.size);
}
function matchPromptToItems(tileText, candidates) {
  const list = (candidates || []).filter((c) => c && c.id && c.prompt);
  if (!list.length || !promptNormText(tileText)) return null;
  const exacts = list.filter((c) => promptExactMatch(tileText, c.prompt));
  if (exacts.length === 1) return { itemId: exacts[0].id, score: 1, how: 'exact' };
  let best = null;
  let second = 0;
  for (const c of list) {
    const sc = promptOverlapScore(tileText, c.prompt);
    if (!best || sc > best.score) { second = best ? best.score : 0; best = { itemId: c.id, score: sc, how: 'overlap' }; }
    else if (sc > second) second = sc;
  }
  if (best && best.score >= 0.85 && best.score > second + 0.03) return best;
  return null;
}
/* Serial-mode verdict for one finished tile: 'current' when it
 * belongs to the item being awaited, 'other' (+ itemId) when it
 * belongs to a DIFFERENT sent item (a late leftover from an earlier
 * send), 'foreign' when the prompt was read fine but matches nothing
 * that was sent. The current item is checked first, so a tile that
 * could fit both the current item and an older one stays with the
 * current item. */
function serialTileVerdict(tileText, currentItem, otherCandidates) {
  if (currentItem && promptExactMatch(tileText, currentItem.prompt)) {
    return { kind: 'current', itemId: currentItem.id, score: 1, how: 'exact' };
  }
  const all = [currentItem].concat(otherCandidates || []).filter(Boolean);
  const m = matchPromptToItems(tileText, all);
  if (m) {
    if (currentItem && m.itemId === currentItem.id) return { kind: 'current', itemId: m.itemId, score: m.score, how: m.how };
    return { kind: 'other', itemId: m.itemId, score: m.score, how: m.how };
  }
  return { kind: 'foreign', itemId: null, score: 0, how: 'none' };
}
/* v2.6.2 — freeze-drain-repair phase machine for paced 'fast' match
 * mode (pure; the paced loop feeds it events and live counts).
 *  - 'failure' (a NEW error tile or a pending timeout consumed an
 *    item): from 'normal' the pipeline freezes into 'draining' — no
 *    new sends; failures while draining/repairing change nothing.
 *  - 'tick' (once per loop pass, with live counts): draining +
 *    pending empty + repairs waiting -> 'repair'; repair + queue
 *    empty -> 'normal' (sends resume). */

/* v2.6 ETA — computed in the ENGINE from this run's real measured
 * pace: samples are the send->finish cycle times (ms) of the last
 * up to 8 completed items. Serial: avg cycle x items remaining.
 * Paced: whichever is longer — the sends still to go (unsent x
 * interval) or the completions still to go (remaining x avg cycle).
 * No samples yet -> null (the panel honestly shows a dash). */
function computeEtaMs(o) {
  o = o || {};
  const samples = (o.samples || []).filter((n) => isFinite(n) && n > 0);
  if (!samples.length) return null;
  const avg = samples.reduce((a, b) => a + b, 0) / samples.length;
  const remaining = Math.max(0, o.remainingItems || 0);
  if (o.mode === 'paced') {
    const sendsMs = Math.max(0, o.unsentItems || 0) * clampIntervalSec(o.intervalSec) * 1000;
    const compMs = remaining * avg;
    return Math.round(Math.max(sendsMs, compMs));
  }
  return Math.round(avg * remaining);
}

/* ---------------- v3 pure helpers ----------------
 * The V3 mechanisms that must be provable without a browser: error
 * classification, listing-based reference presence, prompt attribution
 * over catalog rows, the resume decision, and stage budgets. All pure —
 * the test suites revive them standalone. */
function hashStrV3(s) {
  let h = 5381;
  const str = String(s || '');
  for (let i = 0; i < str.length; i++) h = (((h << 5) + h + str.charCodeAt(i)) | 0);
  return 'h' + (h >>> 0).toString(16);
}
function runSignatureFor(project, items, refFileName) {
  const parts = [String(project || ''), String(refFileName || '')];
  for (const it of items || []) parts.push(String(it.id || '') + '\u0001' + String(it.prompt || ''));
  return hashStrV3(parts.join('\n'));
}
/* Start resumes the saved run iff the incoming list has the SAME
 * signature AND the saved run actually has progress worth keeping. */
function shouldResumeRun(savedSig, savedItems, newSig) {
  if (!savedSig || !newSig || savedSig !== newSig) return false;
  if (!Array.isArray(savedItems) || !savedItems.length) return false;
  return savedItems.some((i) => i && (i.status !== 'pending' || (i.attempts || 0) > 0 || i.tileMediaId));
}
/* Error tiles are classified by their text (the tile shows the reason).
 * 'unusual' = reCAPTCHA/risk block — a session trust signal, never an
 * item failure. 'limit' = daily/model cap — stop and tell the user.
 * Anything else is a per-generation failure. */
function classifyErrorText(text) {
  const t = String(text || '').toLowerCase();
  if (/unusual activity/.test(t)) return 'unusual';
  if (/daily limit|limit reached|quota|too many requests|requesting generations too quickly/.test(t)) return 'limit';
  return 'generic';
}
/* Reference presence, judged ONLY by the listing (complete + typed).
 * 'present' (id = a confirmed ref UUID, possibly newly adopted from an
 * upload row named like the file), 'absent' (the listing is complete
 * and holds no trace), 'unknown' (no listing — never act on it). */
function catalogRefPresence(catalog, refIds, refFileName) {
  if (!catalog || !Array.isArray(catalog.media)) return { status: 'unknown', id: null };
  const ids = new Set(refIds || []);
  for (const row of catalog.media) {
    if (row && ids.has(row.uuid)) return { status: 'present', id: row.uuid };
  }
  if (refFileName) {
    for (const row of catalog.media) {
      if (row && row.origin === 'upload' && row.displayName === refFileName) {
        return { status: 'present', id: row.uuid, adopt: true };
      }
    }
  }
  return { status: 'absent', id: null };
}
/* Prompt attribution over catalog rows. rows: candidate generated rows
 * [{uuid, prompt, kind, createdAt}]. sends: outstanding sends
 * [{id, prompt, got, quota}]. A row is attributed ONLY by prompt
 * verification (matchPromptToItems) — never by order. Rows are dealt
 * oldest-first so an item's FIRST attributed row is its download and
 * later same-prompt rows are extras (Count quota). Rows without a
 * prompt come back as 'unverified' for the fallback ladder. */
function pickAttributions(rows, sends) {
  const work = (sends || []).map((s) => ({ id: s.id, prompt: s.prompt, got: s.got || 0, quota: Math.max(1, s.quota || 1) }));
  const sorted = (rows || []).slice().sort((a, b) => (a.createdAt || 0) - (b.createdAt || 0));
  const assign = [];
  const unverified = [];
  for (const row of sorted) {
    if (!row || !row.uuid) continue;
    if (!row.prompt) { unverified.push(row); continue; }
    const open = work.filter((s) => s.got < s.quota);
    if (!open.length) { unverified.push(row); continue; }
    // Identical prompts are interchangeable BY CONTENT: when two or
    // more open sends carry the row's exact prompt, the exact-tie
    // ambiguity rule must not starve them - any dealing is content-
    // true, so deal deterministically to the first such send.
    const exactSame = open.filter((s) => promptExactMatch(row.prompt, s.prompt));
    if (exactSame.length > 1) {
      const s0 = exactSame[0];
      const extra0 = s0.got >= 1;
      s0.got++;
      assign.push({ uuid: row.uuid, itemId: s0.id, how: 'identical', extra: extra0, kind: row.kind || 'image' });
      continue;
    }
    const hit = matchPromptToItems(row.prompt, open);
    if (!hit || !hit.itemId) { unverified.push(row); continue; }
    const s = work.find((x) => x.id === hit.itemId);
    const extra = s.got >= 1;
    s.got++;
    assign.push({ uuid: row.uuid, itemId: s.id, how: hit.how, extra: extra, kind: row.kind || 'image' });
  }
  return { assign: assign, unverified: unverified, sends: work };
}
/* Stage budgets (ms) for the watchdog. Stages repeat with counters
 * ("waiting 24s") — normalized before lookup. Cooldown/pause exempt. */
const STAGE_BUDGETS_V3 = {
  'typing': 60000, 'typed': 60000, 'ref bosano hocche': 150000,
  'send: enter': 45000, 'send: click': 45000, 'gen shuru check': 45000,
  'waiting': 300000, 'downloading': 180000, 'shuru hocche': 120000,
  'repair send hocche': 300000, 'resend hobe': 300000, 'repair hobe': 300000
};
function stageBudgetFor(stage) {
  const key = String(stage || '').toLowerCase().replace(/\s+\d+s$/, '').trim();
  return Object.prototype.hasOwnProperty.call(STAGE_BUDGETS_V3, key) ? STAGE_BUDGETS_V3[key] : 300000;
}
function stageOverBudget(stage, sinceMs, nowMs) {
  if (!sinceMs) return false;
  return (nowMs - sinceMs) > stageBudgetFor(stage);
}

/* ---------------- v3 catalog layer ----------------
 * fetchCatalog: the listing, cached for 2.5s (it costs ~0.5s live and
 * the watchers poll often). Returns the normalized catalog or null —
 * null means "unknown", and every consumer treats it that way. */
let catalogCache = { at: 0, data: null };
let catalogLogSig = null; // v3.0.1: last LOGGED catalog health signature
/* v3.0.1 — the catalog speaks. One log line whenever its health
 * CHANGES (the first fetch of a session always logs, so run start is
 * covered). Before this, fetchCatalog flipped S.catalogOk in total
 * silence: a dead or prompt-less listing produced a run with sends,
 * finished generations, zero downloads and no evidence anywhere
 * (run-report-4). Health is bucketed (reachable? / rows zero-some /
 * prompts none-some-all) so normal mid-run growth stays quiet. */
function noteCatalogHealth(res) {
  let sig, line;
  if (res && Array.isArray(res.media)) {
    const rows = res.media.length;
    const prompts = res.media.reduce((n, r) => n + (r && r.prompt ? 1 : 0), 0);
    S.catalogStats = { ok: true, rows: rows, prompts: prompts, at: Date.now() };
    sig = 'ok|' + (rows ? 'rows' : 'empty') + '|' + (prompts === 0 ? 'noprompt' : (prompts >= rows ? 'allprompt' : 'someprompt'));
    line = 'Catalog: listing paoa geche — ' + rows + ' ta asset, ' + prompts + ' ta te prompt ache';
  } else {
    S.catalogStats = { ok: false, rows: 0, prompts: 0, at: Date.now() };
    sig = 'dead';
    line = 'Catalog: listing paoa jacche na — DOM fallback diye kaj cholbe';
  }
  if (sig !== catalogLogSig) { catalogLogSig = sig; elog(line); }
}
async function fetchCatalog(tabId, force) {
  const nowMs = Date.now();
  if (!force && catalogCache.data && nowMs - catalogCache.at < 2500) return catalogCache.data;
  const res = await evalFn(tabId, sfaProjectData).catch(() => null);
  if (res && res.ok && Array.isArray(res.media)) {
    catalogCache = { at: Date.now(), data: res };
    S.catalogOk = true;
    noteCatalogHealth(res);
    return res;
  }
  S.catalogOk = false;
  noteCatalogHealth(null);
  return null;
}
/* Rows that may be attributed to this run's sends: generated-origin,
 * not in the start baseline, not the reference (any known UUID), not
 * already consumed. With no baseline (catalog was down at run start),
 * only rows created at/after the run start qualify — an old generation
 * with an identical prompt can never sneak in. */
function attributionCandidates(catalog) {
  if (!catalog || !Array.isArray(catalog.media)) return [];
  const base = Array.isArray(S.baselineUuids) ? new Set(S.baselineUuids) : null;
  const refs = new Set(S.refMediaIds || []);
  if (S.refMediaId) refs.add(S.refMediaId);
  const consumed = new Set(S.consumedTiles || []);
  const since = (S.runStartedAt || 0) - 5000;
  return catalog.media.filter((r) => {
    if (!r || r.origin !== 'generated' || !r.uuid) return false;
    if (refs.has(r.uuid) || consumed.has(r.uuid)) return false;
    if (base) { if (base.has(r.uuid)) return false; }
    else if (!r.createdAt || r.createdAt < since) return false;
    return true;
  });
}

/* ---------------- CDP layer ---------------- */
/* v2.3 — no CDP call may hang forever. The proven v2.2 failure: the
 * user pressed the yellow bar's Cancel (canceled_by_user detach)
 * while a sendCommand was in flight; that promise never settled, the
 * run loop waited inside it forever, loopActive stayed true, and the
 * already-running guard then silently swallowed every later Start.
 * withTimeout races every debugger call; cdp() treats a timeout
 * exactly like a detach (heal the session, retry the command once);
 * a second failure surfaces as a normal error the item logic handles. */
const CDP_TIMEOUT_MS = 8000;
function withTimeout(promise, ms, label) {
  return new Promise((resolve, reject) => {
    const t = setTimeout(() => {
      const e = new Error('CDP timeout: ' + label + ' — ' + ms + 'ms e response ashe ni');
      e.cdpTimeout = true;
      reject(e);
    }, ms);
    Promise.resolve(promise).then(
      (v) => { clearTimeout(t); resolve(v); },
      (e) => { clearTimeout(t); reject(e); }
    );
  });
}
const attachedTabs = new Set();
/* v1.4 — self-healing debugger session. Proven by the user's v1.2 run
 * report: once the debugger session was lost mid-run (yellow-bar Cancel,
 * or an MV3 service-worker restart dropping it), the engine NEVER
 * re-attached — the first "Debugger is not attached to the tab with id"
 * error made every attempt of every later item fail instantly.
 * attachedOk/attachedTabId are the session truth; ensureAttached() heals
 * the session, and cdp() retries a command once after re-attaching. */
let attachedTabId = null;
let attachedOk = false;
const intentionalDetachTabs = new Set();

async function ensureAttached(tabId, force) {
  if (!force && attachedOk && attachedTabId === tabId) return true;
  try {
    await withTimeout(chrome.debugger.attach({ tabId }, '1.3'), CDP_TIMEOUT_MS, 'debugger.attach');
  } catch (e) {
    const m = (e && e.message) || String(e);
    if (/already attached/i.test(m)) {
      // Session actually survived (e.g. service-worker restart) — attached.
      attachedTabs.add(tabId);
      attachedTabId = tabId;
      attachedOk = true;
      return true;
    }
    attachedOk = false;
    elog('Debugger attach FAIL (tab ' + tabId + '): ' + m);
    throw new Error('Debugger attach fail: ' + m);
  }
  attachedTabs.add(tabId);
  attachedTabId = tabId;
  attachedOk = true;
  S.lastDetachReason = '';
  elog('Debugger attach holo (tab ' + tabId + ')');
  save();
  return true;
}

async function dbgAttach(tabId) { return ensureAttached(tabId); }

async function dbgDetach(tabId) {
  if (attachedTabId === tabId) { attachedOk = false; attachedTabId = null; }
  if (!attachedTabs.has(tabId)) return;
  attachedTabs.delete(tabId);
  intentionalDetachTabs.add(tabId);
  try { await withTimeout(chrome.debugger.detach({ tabId }), 3000, 'debugger.detach'); } catch (e) { /* already gone */ }
  setTimeout(() => intentionalDetachTabs.delete(tabId), 1000);
}

chrome.debugger.onDetach.addListener((src, reason) => {
  if (!src || !src.tabId) return;
  attachedTabs.delete(src.tabId);
  if (src.tabId === attachedTabId) { attachedOk = false; attachedTabId = null; }
  if (intentionalDetachTabs.has(src.tabId)) return; // our own detach (pause/stop/end) — no warning
  const r = reason || 'unknown';
  S.lastDetachReason = r;
  if (r === 'canceled_by_user') {
    elog('Debugger detach hoyeche (reason: canceled_by_user) — holud bar er Cancel chaple emon hoy; run cholar somoy Cancel chapba na');
  } else {
    elog('Debugger detach hoyeche (reason: ' + r + ')');
  }
  save();
});

async function cdp(tabId, method, params) {
  try {
    return await withTimeout(chrome.debugger.sendCommand({ tabId }, method, params || {}), CDP_TIMEOUT_MS, method);
  } catch (e) {
    const m = (e && e.message) || String(e);
    const timedOut = !!(e && e.cdpTimeout);
    if (!timedOut && !/not attached/i.test(m)) throw e;
    // A timeout is treated exactly like a detach: the session is in
    // an unknown state, so heal it and retry the command once. If the
    // retry also fails/times out, that error propagates as a normal
    // error — the item logic retries or fails the item, and the run
    // loop keeps moving instead of parking forever.
    if (timedOut) elog('CDP timeout (' + method + ') — session atke chilo, detach dhore abar attach kore retry hocche');
    else elog('Debugger chere giyechilo — abar attach kore retry hocche (' + method + ')');
    attachedOk = false;
    await ensureAttached(tabId, true);
    return withTimeout(chrome.debugger.sendCommand({ tabId }, method, params || {}), CDP_TIMEOUT_MS, method);
  }
}
async function evalFn(tabId, fn, arg) {
  const expr = '(' + fn.toString() + ')(' + JSON.stringify(arg === undefined ? null : arg) + ')';
  const res = await cdp(tabId, 'Runtime.evaluate', { expression: expr, returnByValue: true, awaitPromise: true });
  if (res && res.exceptionDetails) {
    throw new Error('Page evaluate failed: ' + (res.exceptionDetails.text || 'unknown'));
  }
  return res && res.result ? res.result.value : undefined;
}
async function scriptFn(tabId, fn, arg) {
  // v3: bounded like every other transport call - the preflight probe
  // used to be the one call in the engine with NO timeout at all.
  const out = await withTimeout(chrome.scripting.executeScript({ target: { tabId }, func: fn, args: [arg === undefined ? null : arg] }), 20000, 'scripting.executeScript');
  return out && out[0] ? out[0].result : undefined;
}
async function realClick(tabId, x, y) {
  await cdp(tabId, 'Input.dispatchMouseEvent', { type: 'mouseMoved', x, y, button: 'none' });
  await sleep(70);
  await cdp(tabId, 'Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', clickCount: 1 });
  await sleep(60);
  await cdp(tabId, 'Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', clickCount: 1 });
}
/* v2.6.1 — a realClick that must first PROVE its target: the point is
 * checked in-page (sfaPointCheck) and judged by genClickVerdict
 * against the required zone. Used by the flows whose coordinates come
 * from document-wide scans or menu harvests (generation settings,
 * "Clear prompt", the picker "+" opener) — the paths that used to
 * click snapshot coordinates blind. Returns false (and logs) instead
 * of clicking when the target cannot be verified as safe. */
async function guardedClick(tabId, x, y, zone) {
  const chk = await evalFn(tabId, sfaPointCheck, { x: x, y: y }).catch(() => null);
  const v = genClickVerdict(chk, { zone: zone });
  if (!v.ok) {
    elog('Click rokhha kora holo (' + v.reason + ') — point ' + x + ',' + y + ' e click holo na');
    return false;
  }
  await realClick(tabId, x, y);
  return true;
}
async function clearFocusedInput(tabId) {
  const opts = { modifiers: 2, windowsVirtualKeyCode: 65, nativeVirtualKeyCode: 65 };
  await cdp(tabId, 'Input.dispatchKeyEvent', Object.assign({ type: 'keyDown', key: 'a', code: 'KeyA' }, opts));
  await cdp(tabId, 'Input.dispatchKeyEvent', Object.assign({ type: 'keyUp', key: 'a', code: 'KeyA' }, opts));
  await cdp(tabId, 'Input.dispatchKeyEvent', { type: 'keyDown', key: 'Backspace', code: 'Backspace', windowsVirtualKeyCode: 8, nativeVirtualKeyCode: 8 });
  await cdp(tabId, 'Input.dispatchKeyEvent', { type: 'keyUp', key: 'Backspace', code: 'Backspace', windowsVirtualKeyCode: 8, nativeVirtualKeyCode: 8 });
}
/* Trusted Enter key via CDP — Flow's composer is a chat-style input where
 * Enter = send. This is the PRIMARY send method in v1.3: unlike a mouse
 * click it can never land on the wrong (clear/close) control. */
async function pressEnter(tabId) {
  const base = { key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13, nativeVirtualKeyCode: 13 };
  await cdp(tabId, 'Input.dispatchKeyEvent', Object.assign({ type: 'keyDown' }, base));
  await sleep(40);
  await cdp(tabId, 'Input.dispatchKeyEvent', Object.assign({ type: 'keyUp' }, base));
}
/* Trusted Escape via CDP — closes the ingredient picker between open
 * retries (the opener click occasionally produces no picker). */
async function pressEscape(tabId) {
  const base = { key: 'Escape', code: 'Escape', windowsVirtualKeyCode: 27, nativeVirtualKeyCode: 27 };
  await cdp(tabId, 'Input.dispatchKeyEvent', Object.assign({ type: 'keyDown' }, base));
  await sleep(30);
  await cdp(tabId, 'Input.dispatchKeyEvent', Object.assign({ type: 'keyUp' }, base));
}

/* ---------------- downloads ---------------- */
const dlWaiters = new Map();
chrome.downloads.onChanged.addListener((delta) => {
  const w = dlWaiters.get(delta.id);
  if (!w) return;
  if (delta.state && delta.state.current === 'complete') {
    dlWaiters.delete(delta.id);
    chrome.downloads.search({ id: delta.id }).then((items) => w.resolve(items && items[0] ? items[0] : null)).catch(() => w.resolve(null));
  } else if (delta.state && delta.state.current === 'interrupted') {
    dlWaiters.delete(delta.id);
    w.resolve(null);
  }
});
function downloadsDownload(opts) {
  return new Promise((resolve, reject) => {
    chrome.downloads.download(opts, (id) => {
      const err = chrome.runtime.lastError;
      if (err || id === undefined || id === null) reject(new Error('Download start fail: ' + (err ? err.message : 'no id')));
      else resolve(id);
    });
  });
}
function waitDownloadComplete(id, timeoutMs) {
  return new Promise((resolve) => {
    const timer = setTimeout(() => { dlWaiters.delete(id); resolve(null); }, timeoutMs || 90000);
    dlWaiters.set(id, { resolve: (item) => { clearTimeout(timer); resolve(item); } });
    chrome.downloads.search({ id }).then((items) => {
      const it = items && items[0];
      if (it && it.state === 'complete') { clearTimeout(timer); dlWaiters.delete(id); resolve(it); }
      else if (it && it.state === 'interrupted') { clearTimeout(timer); dlWaiters.delete(id); resolve(null); }
    }).catch(() => {});
  });
}
async function downloadAndVerify(url, filename) {
  const id = await downloadsDownload({ url, filename, saveAs: false });
  const item = await waitDownloadComplete(id, 90000);
  if (!item) throw new Error('Download interrupted ba timeout');
  const size = item.fileSize || item.totalBytes || 0;
  if (size <= 10000) throw new Error('Download size khub chhoto (' + size + ' bytes) — verify fail');
  return size;
}
function upgradeUrl(u) {
  if (!/googleusercontent/.test(u)) return u;
  if (/=w\d+/.test(u)) return u.replace(/=w\d+/, '=w2048');
  if (/=s\d+/.test(u)) return u.replace(/=s\d+/, '=s2048');
  return u;
}
async function screenshotError(tabId, project, itemId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
    await downloadsDownload({ url: dataUrl, filename: 'SHEIKH Flow Auto/' + runFolderName() + '/ERROR-' + itemId + '.png', saveAs: false });
  } catch (e) { /* best effort */ }
}

/* ---------------- v2.2 item thumbnails (session only) ----------------
 * After an item's image completes, fetch its tile URL, downscale to a
 * ≤120px-wide JPEG data URL and keep it in an in-memory Map keyed by
 * item ID. Never persisted. Any failure (CORS, decode) is silent apart
 * from one log line — the panel simply shows no thumbnail. */
const thumbCache = new Map();
let thumbFailLogged = false;
function bufferToDataUrl(buf, mime) {
  const bytes = new Uint8Array(buf);
  let bin = '';
  const CH = 0x8000;
  for (let i = 0; i < bytes.length; i += CH) {
    bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CH));
  }
  return 'data:' + mime + ';base64,' + btoa(bin);
}
async function captureThumbnail(id, url) {
  try {
    if (!id || !url || url.indexOf('blob:') === 0 || thumbCache.has(id)) return;
    const resp = await fetch(url, { credentials: 'include' });
    if (!resp || !resp.ok) throw new Error('HTTP ' + (resp ? resp.status : '?'));
    const blob = await resp.blob();
    const bmp = await createImageBitmap(blob);
    const scale = Math.min(1, 120 / (bmp.width || 120));
    const w = Math.max(1, Math.round(bmp.width * scale));
    const h = Math.max(1, Math.round(bmp.height * scale));
    const canvas = new OffscreenCanvas(w, h);
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('no 2d context');
    ctx.drawImage(bmp, 0, 0, w, h);
    if (bmp.close) bmp.close();
    const out = await canvas.convertToBlob({ type: 'image/jpeg', quality: 0.7 });
    const buf = await out.arrayBuffer();
    thumbCache.set(id, bufferToDataUrl(buf, 'image/jpeg'));
  } catch (e) {
    if (!thumbFailLogged) {
      thumbFailLogged = true;
      elog('Thumbnail: kono image er preview ana jay ni (' + (e && e.message ? e.message : String(e)) + ') — preview charai cholbe');
    }
  }
}

/* ---------------- local copies of parse helpers (background is standalone) */
function sanitizeProject(name) {
  const s = String(name == null ? '' : name).replace(/[\\/:*?"<>|#]/g, ' ').replace(/\s+/g, ' ').trim().replace(/[. ]+$/g, '');
  return s || 'Project';
}
/* v2.2: the run's effective folder base — set at run start (dated when
 * the dated-folder setting is on) and kept across resumes. */
function runFolderName() {
  return S.runFolder || sanitizeProject(S.project);
}
function targetPath(project, id) {
  return 'SHEIKH Flow Auto/' + runFolderName() + '/' + String(id).toUpperCase() + '.png';
}
/* v2.6: video items download as .mp4 under the same item name. */
function targetPathFor(project, id, kind) {
  return 'SHEIKH Flow Auto/' + runFolderName() + '/' + String(id).toUpperCase() + (kind === 'video' ? '.mp4' : '.png');
}
function fileExtFor(item) {
  return item && item.mediaKind === 'video' ? '.mp4' : '.png';
}
/* v2.2: merge the panel's Download-section settings into state
 * (validated field by field; refMode/refReady are handled separately
 * by the start flow and are never touched here). */
function applyDownloadSettings(obj) {
  if (!obj) return;
  if (typeof obj.autoDownload === 'boolean') S.settings.autoDownload = obj.autoDownload;
  if (obj.quality === '1K' || obj.quality === '2K' || obj.quality === '4K') S.settings.quality = obj.quality;
  if (typeof obj.datedFolder === 'boolean') S.settings.datedFolder = obj.datedFolder;
  if (typeof obj.retryAtEnd === 'boolean') S.settings.retryAtEnd = obj.retryAtEnd;
  if (obj.intervalSec !== undefined) S.settings.intervalSec = clampIntervalSec(obj.intervalSec);
  if (obj.runMode === 'serial' || obj.runMode === 'paced') S.settings.runMode = obj.runMode;
  if (obj.matchMode === 'prompt' || obj.matchMode === 'fast') S.settings.matchMode = obj.matchMode;
  // v2.6 generation options (validated against the Flow menu vocab;
  // a model that does not belong to the type falls back to its default)
  if (obj.genType === 'image' || obj.genType === 'video') S.settings.genType = obj.genType;
  const gType = S.settings.genType === 'video' ? 'video' : 'image';
  if (!(GEN_MODELS[gType] || []).includes(S.settings.genModel)) S.settings.genModel = genDefaultModel(gType);
  if (typeof obj.genModel === 'string' && (GEN_MODELS[gType] || []).includes(obj.genModel)) S.settings.genModel = obj.genModel;
  if (GEN_RATIOS.includes(obj.genRatio)) S.settings.genRatio = obj.genRatio;
  if (obj.genCount !== undefined) S.settings.genCount = clampGenCount(obj.genCount);
}

/* ---------------- flow tab ---------------- */
async function findFlowTab() {
  let tabs = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  let t = tabs && tabs[0];
  if (t && t.url && FLOW_URL_RE.test(t.url)) return t;
  tabs = await chrome.tabs.query({});
  t = (tabs || []).find((x) => x.url && FLOW_URL_RE.test(x.url));
  return t || null;
}

/* ---------------- preflight ---------------- */
async function runPreflight() {
  await loadState();
  const tab = await findFlowTab();
  const result = { ok: false, tabId: null, url: '', flowPage: false, input: null, send: null, mode: 'unknown', modeSignals: null, blocked: false, blockReason: '', checkedAt: Date.now(), plusBtn: null, clearBtn: null, agent: { present: false, active: false }, catalog: null };
  if (!tab) { result.blockReason = 'Kono Flow tab khola nai — age Flow project tab khule rakho.'; return result; }
  result.tabId = tab.id;
  result.url = tab.url || '';
  result.flowPage = FLOW_URL_RE.test(result.url);
  try {
    const composer = await scriptFn(tab.id, sfaFindComposer);
    if (composer) { result.input = composer.input; result.send = composer.send; }
    // v2.0: ingredient "+" button + Agent toggle (picker attach needs the
    // "+"; Agent mode ON breaks error-tile Retry, so it is surfaced).
    const bar = await scriptFn(tab.id, sfaComposerBar).catch(() => null);
    if (bar) {
      result.plusBtn = bar.plus || null;
      result.clearBtn = bar.clear || null;
      result.agent = bar.agent || { present: false, active: false };
    }
    const mode = await scriptFn(tab.id, sfaModeProbe);
    result.modeSignals = mode;
    if (mode) {
      const selVideo = /^videos?$/.test(mode.selectedMode || '');
      const modelVeo = /veo/i.test(mode.modelText || '');
      const modelImage = /nano banana|imagen/i.test(mode.modelText || '');
      if (selVideo || (modelVeo && !modelImage)) { result.mode = 'video'; }
      else if (/^images?$/.test(mode.selectedMode || '') || modelImage) { result.mode = 'image'; }
      else if (mode.hasImageModel && !mode.hasVeo) { result.mode = 'image'; }
    }
    // v3.0.1: probe the listing too — it is the attribution truth
    // layer, so a dead / prompt-less catalog must be visible BEFORE
    // a run starts, not discovered from a silent run report.
    if (result.flowPage) {
      const cat = await fetchCatalog(tab.id, true).catch(() => null);
      result.catalog = cat
        ? { ok: true, rows: cat.media.length, prompts: cat.media.reduce((n, r) => n + (r && r.prompt ? 1 : 0), 0) }
        : { ok: false, rows: 0, prompts: 0 };
    }
  } catch (e) {
    result.blockReason = 'Page probe fail: ' + e.message;
  }
  if (result.mode === 'video' && !(S.settings && S.settings.genType === 'video')) {
    // v2.6: the block applies to IMAGE runs only — a Video-type run
    // wants Flow in video mode (and applyGenerationSettings sets it).
    result.blocked = true;
    result.blockReason = 'VIDEO mode select kora ache mone hocche — image run er jonno block kora holo. Flow te Image mode / Nano Banana select kore abar Check koro.';
  }
  result.ok = result.flowPage && !!result.input && !!result.send && !result.blocked;
  S.lastPreflight = result;
  S.tabId = result.tabId;
  save();
  return result;
}

/* ---------------- generation wait ---------------- */
const ABORT = Symbol('abort');
/* v2.0 completion wait — tile-based, replacing the count-based wait.
 * Everything is relative to the pre-send snapshot (snap.ids = mediaIds
 * present before the send, snap.errorCount = error tiles then).
 *
 * NEW error tile (error count grows past the handled baseline): Flow's
 * own failures are usually just busy servers — press the tile's Retry
 * button (max 2 per attempt), extend the deadline, keep waiting. With
 * no retries left the attempt fails with the tile's error text. OLD
 * error tiles persist forever, so only the count INCREASE is reacted
 * to, and the toast-style scan.error is only trusted when the page has
 * no error tiles at all (otherwise it is an old tile's text).
 *
 * COMPLETE when a tile exists that is kind 'image', has a mediaId NOT
 * in the snapshot, is not the reference upload itself, has a thumbnail
 * and shows no % — stable across 2 consecutive polls.
 *
 * Last-resort fallback (spec): no new tile and no error after 150s AND
 * busy was seen and has cleared for 3 polls → return with no tile and let
 * the caller try the newest-tile / media-URL download path. */
async function waitForCompletionDom(tabId, snap, item, opts) {
  const epoch = abortEpoch; // v2.3: abort the moment Stop/force-reset bumps it
  const t0 = Date.now();
  let busySeen = !!(opts && opts.busySeen);
  let deadline = t0 + 240000;
  let errBase = snap.errorCount || 0;
  let retries = 0;
  let stableBusy = 0;
  let candId = null;
  let candStable = 0;
  let lastBeatLog = -1;
  let sampleLogged = false;
  let pollErrLogged = false;
  while (Date.now() < deadline) {
    if (stopRequested) throw ABORT;
    if (epoch !== abortEpoch) throw ABORT;
    beat();
    let tiles = null;
    let scan = null;
    try {
      tiles = await evalFn(tabId, sfaTiles);
      pollErrLogged = false;
    } catch (e) {
      if (!pollErrLogged) {
        elog(item.id + ': tile poll e badha (' + (e && e.message ? e.message : String(e)) + ') — opekkha cholche, abar try hobe');
        pollErrLogged = true;
      }
    }
    try { scan = await evalFn(tabId, sfaMediaScan); } catch (e) { scan = null; }
    const elapsed = Math.round((Date.now() - t0) / 1000);
    item.stage = 'waiting ' + elapsed + 's';
    if (elapsed - lastBeatLog >= 30) {
      lastBeatLog = elapsed;
      const newN = tiles ? tiles.filter((t) => t.mediaId && snap.ids.indexOf(t.mediaId) === -1).length : '?';
      const errN = tiles ? tiles.filter((t) => t.kind === 'error').length : '?';
      elog(item.id + ': opekkha cholche — ' + elapsed + 's geche, tile mot ' + (tiles ? tiles.length : '?') + ' (notun ' + newN + ', error ' + errN + ', busy=' + (scan ? !!scan.busy : '?') + ')');
    }
    if (!sampleLogged && scan && elapsed > 60) {
      sampleLogged = true;
      elog(item.id + ': DOM sample: totalImgs=' + scan.totalImgs + ', sampleSrcs=[' + (scan.sampleSrcs && scan.sampleSrcs.length ? scan.sampleSrcs.join(' | ') : 'none') + ']');
    }
    save();
    if (tiles) {
      const errTiles = tiles.filter((t) => t.kind === 'error');
      if (errTiles.length > errBase) {
        const et = errTiles[0];
        if (retries < 2 && et.retryBtn) {
          retries++;
          elog(item.id + ': Flow fail korechilo — Retry chap dilam (' + retries + '/2)');
          await realClick(tabId, et.retryBtn.x, et.retryBtn.y);
          errBase = errTiles.length - 1; // the retried tile should leave error state
          deadline = Math.max(deadline, Date.now() + 120000);
          candId = null;
          candStable = 0;
          await sleepOrStop(2000, epoch);
          continue;
        }
        const err = new Error('Flow error: ' + (et.label || 'generation failed'));
        err.finalReason = err.message;
        throw err;
      }
      const wantKind = (opts && opts.wantKind) || 'image';
      // v2.6: tiles consumed by earlier items (results + count extras)
      // are excluded too — a late extra can never pose as this item's
      // result even if it appeared after this item's snapshot.
      const exclIds = (S.consumedTiles && S.consumedTiles.length) ? snap.ids.concat(S.consumedTiles) : snap.ids;
      const cand = wantKind === 'video'
        ? (sfaResultTiles(tiles, exclIds, S.refMediaId, 'video')[0] || null)
        : sfaPickResultTile(tiles, exclIds, S.refMediaId);
      if (cand) {
        if (cand.mediaId === candId) candStable++;
        else { candId = cand.mediaId; candStable = 1; }
        if (candStable >= 2) {
          elog(item.id + ': completion — notun tile (mediaId=' + cand.mediaId + ')');
          // v2.6.2 Prompt-check: before this tile is claimed for the
          // item, the caller may prove ownership by reading the
          // tile's prompt in the viewer. A non-'accept' verdict drops
          // the candidate (the callback handles foreign-consumption
          // and leftover reassignment) and the wait continues for
          // this item's own tile.
          if (opts && typeof opts.verifyTile === 'function') {
            const verdict = await opts.verifyTile(cand).catch(() => ({ action: 'accept' }));
            if (verdict && verdict.action === 'reassign' && typeof opts.onReassign === 'function') {
              await opts.onReassign(cand, verdict.item).catch(() => {});
            }
            if (verdict && verdict.action !== 'accept') {
              candId = null; candStable = 0;
              await sleepOrStop(600, epoch);
              continue;
            }
          }
          // v2.6 count quota: with Count > 1 this send produces more
          // tiles. Collect the item's tiles for a short settle window
          // and return the extras so the caller marks them consumed.
          const want = Math.max(1, (opts && opts.count) || 1);
          if (want > 1) {
            let got = sfaResultTiles(tiles, exclIds, S.refMediaId, wantKind);
            const settleUntil = Date.now() + 6000;
            while (got.length < want && Date.now() < settleUntil) {
              if (stopRequested || epoch !== abortEpoch) throw ABORT;
              await sleepOrStop(1200, epoch);
              const t2 = await evalFn(tabId, sfaTiles).catch(() => null);
              if (t2) got = sfaResultTiles(t2, exclIds, S.refMediaId, wantKind);
            }
            got = got.slice(0, want);
            if (!got.length) return { tile: cand, extras: [] };
            const primary = got[got.length - 1]; // oldest new tile = first produced
            const extras = got.filter((t) => t.mediaId !== primary.mediaId);
            return { tile: primary, extras: extras };
          }
          return { tile: cand, extras: [] };
        }
      } else {
        candId = null;
        candStable = 0;
      }
    }
    if (scan) {
      if (scan.busy) {
        busySeen = true;
        stableBusy = 0;
      } else if (busySeen) {
        stableBusy++;
        if (stableBusy >= 3 && Date.now() - t0 > 150000) {
          elog(item.id + ': completion — busy-cycle fallback (150s periye geche, notun tile dhora poreni)');
          return { tile: null };
        }
      }
      const errTileCount = tiles ? tiles.filter((t) => t.kind === 'error').length : 0;
      if (scan.error && errTileCount === 0) throw new Error('Flow error: ' + scan.error);
    }
    await sleepOrStop(2000, epoch);
  }
  throw new Error('Timeout 240s — generation sesh hoyni');
}

/* Verify generation ACTUALLY started after sending (fail fast).
 * Success signals (either one, within 15s): a busy / generating
 * indicator is visible, OR a new tile appears in the grid (any kind —
 * including an error tile, which the completion wait then handles via
 * its Retry button), OR the grid grew / a new mediaId showed up.
 * "Composer cleared" is NOT a signal — in v1.2 the post-typing finder
 * clicked a clear/close (x) control that erased the prompt, and the
 * cleared box then falsely read as "generation started". A cleared box
 * is still logged ONCE per wait, as diagnostic info only.
 * Returns {name, busySeen}, or null after ~15s. */
async function waitForStartSignal(tabId, snap, typedLen) {
  const epoch = abortEpoch; // v2.3: abort the moment Stop/force-reset bumps it
  const t0 = Date.now();
  let clearedLogged = false;
  let pollErrLogged = false;
  let busySeen = false;
  while (Date.now() - t0 < 15000) {
    if (stopRequested) throw ABORT;
    if (epoch !== abortEpoch) throw ABORT;
    beat();
    let scan = null;
    let tiles = null;
    try {
      scan = await evalFn(tabId, sfaMediaScan);
      pollErrLogged = false;
    } catch (e) {
      if (!pollErrLogged) {
        elog('Start-signal poll e badha (' + (e && e.message ? e.message : String(e)) + ') — opekkha cholche');
        pollErrLogged = true;
      }
    }
    try { tiles = await evalFn(tabId, sfaTiles); } catch (e) { tiles = null; }
    if (scan && scan.busy) return { name: 'generating indicator dekha geche', busySeen: true };
    if (tiles) {
      const fresh = tiles.find((t) => t.mediaId && snap.ids.indexOf(t.mediaId) === -1);
      if (fresh) return { name: 'notun tile esheche (' + fresh.kind + ')', busySeen };
      if (tiles.length > snap.count) return { name: 'grid e notun tile esheche', busySeen };
      if (tiles.filter((t) => t.kind === 'error').length > snap.errorCount) return { name: 'error tile esheche (Retry diye handle hobe)', busySeen };
      if (scan && scan.error && tiles.filter((t) => t.kind === 'error').length === 0) {
        throw new Error('Flow error: ' + scan.error);
      }
    } else if (scan && scan.error) {
      throw new Error('Flow error: ' + scan.error);
    }
    if (!clearedLogged && typedLen > 20) {
      const ct = await evalFn(tabId, sfaComposerText).catch(() => null);
      const cur = ct && typeof ct.text === 'string' ? ct.text.replace(/\s+/g, ' ').trim() : '';
      if (cur.length < typedLen * 0.2) {
        clearedLogged = true;
        elog('Note: box khali hoyeche, kintu eta signal na — tile/busy signal er opekkhai achi');
      }
    }
    await sleepOrStop(1000, epoch);
  }
  return null;
}

/* Read back the composer text and verify our prompt really landed there. */
async function verifyTyped(tabId, promptText) {
  const ct = await evalFn(tabId, sfaComposerText);
  const norm = (s) => String(s || '').replace(/\s+/g, ' ').trim();
  const boxText = norm(ct && ct.text);
  const probe = norm(promptText).slice(0, 30);
  return { ok: probe.length > 0 && boxText.indexOf(probe) !== -1, len: boxText.length };
}

function itemNeedsRef(item) {
  const st = S.settings || {};
  if (!st.refReady) return false;
  if (st.refMode === 'all') return true;
  if (st.refMode === 'marked') return !!item.needsRef;
  return false;
}

/* Read the composer's real ingredient state (v1.5 probe). ingredients
 * is -1 when the probe could not read the composer at all. */
async function getIngredients(tabId) {
  const info = await evalFn(tabId, sfaIngredients).catch(() => null);
  if (!info || typeof info.ingredients !== 'number') return { ingredients: -1, uploading: false };
  return { ingredients: info.ingredients, uploading: !!info.uploading };
}

/* Generation-start gap (user rule): v2.0 fixed it at 10s; v2.2 reads
 * settings.intervalSec (3–120s, default 10). Enforced immediately
 * before every Enter send; lastSendAt persists in state so the gap
 * holds across items and resumes. */
async function enforceSendGap(item) {
  const gapSec = clampIntervalSec(S.settings && S.settings.intervalSec);
  const last = S.lastSendAt || 0;
  const waitMs = last ? (last + gapSec * 1000 - Date.now()) : 0;
  if (waitMs > 0) {
    elog((item ? item.id : 'send') + ': ' + gapSec + 's gap rakha hocche (aro ' + Math.ceil(waitMs / 1000) + 's)');
    await sleepOrStop(waitMs); // v2.3: Stop wakes the gap instantly (heartbeat interval keeps beat() alive)
  }
  S.lastSendAt = Date.now();
  save();
}

/* v2.0 — upload gate: after the one-time paste, poll the tiles until
 * the new upload tile (a mediaId that was NOT in the pre-upload
 * snapshot) exists AND shows no % — i.e. its processing has fully
 * ended and it has gained data-media-id. Max 90s. Progress % is logged
 * whenever it changes. NOTHING else in the run proceeds before this
 * resolves — that is the user's rule 1. */
async function waitRefUploadGate(tabId, preTiles, name) {
  const preIds = new Set((preTiles || []).map((t) => t.mediaId).filter(Boolean));
  // A tile that was already visible but still processing at snapshot
  // time (the "found but hasPct" path in ensureReference) is also a
  // valid gate success once its % clears.
  const prePctIds = new Set((preTiles || []).filter((t) => t.hasPct).map((t) => t.mediaId).filter(Boolean));
  const epoch = abortEpoch; // v2.3: abort the moment Stop/force-reset bumps it
  const t0 = Date.now();
  let lastPct = -1;
  while (Date.now() - t0 < 90000) {
    if (stopRequested) throw ABORT;
    if (epoch !== abortEpoch) throw ABORT;
    beat();
    const tiles = await evalFn(tabId, sfaTiles).catch(() => null);
    if (tiles) {
      for (const t of tiles) {
        if (t.mediaId && !t.hasPct && (!preIds.has(t.mediaId) || prePctIds.has(t.mediaId))) {
          return { mediaId: t.mediaId, label: t.label || '', secs: Math.round((Date.now() - t0) / 1000) };
        }
      }
      const prog = tiles.find((t) => t.hasPct && (!t.mediaId || !preIds.has(t.mediaId)));
      if (prog && prog.pct !== null && prog.pct !== lastPct) {
        lastPct = prog.pct;
        elog('reference upload cholche… ' + prog.pct + '%');
      }
    }
    await sleepOrStop(2000, epoch);
  }
  return null;
}

/* v3 - the upload gate against the LISTING: poll the catalog until a
 * NEW upload-origin row exists (preferring the one named like the
 * file). The listing is complete, so a landed upload is always visible
 * here - unlike the virtualized grid tile the old gate watched. */
async function waitRefUploadGateCatalog(tabId, preUuids, name) {
  const epoch = abortEpoch;
  const t0 = Date.now();
  while (Date.now() - t0 < 90000) {
    if (stopRequested) throw ABORT;
    if (epoch !== abortEpoch) throw ABORT;
    beat();
    const cat = await fetchCatalog(tabId, true).catch(() => null);
    if (cat) {
      const fresh = cat.media.filter((r) => r && r.origin === 'upload' && r.uuid && !(preUuids && preUuids.has(r.uuid)));
      const named = fresh.find((r) => r.displayName === name);
      const pick = named || fresh[0];
      if (pick) return { mediaId: pick.uuid, label: pick.displayName || '', secs: Math.round((Date.now() - t0) / 1000) };
    }
    await sleepOrStop(2000, epoch);
  }
  return null;
}

/* After the one-time upload, empty the composer with "Clear prompt"
 * (the upload itself stays in the project). Falls back to Ctrl+A +
 * Backspace. Logs the resulting composer state; if the reference chip
 * itself survives the clear, the first item simply uses it (its attach
 * step sees ingredients >= 1 and skips the picker). */
async function clearComposerAfterUpload(tabId) {
  const bar = await evalFn(tabId, sfaComposerBar).catch(() => null);
  // v2.6.1: bar.clear comes from a document-wide first-match scan —
  // the click now has to prove it lands inside the composer (never
  // the grid, never a destructive control) or the fallback below runs.
  let cleared = false;
  if (bar && bar.clear) {
    cleared = await guardedClick(tabId, bar.clear.x, bar.clear.y, 'composer');
    if (cleared) elog('Composer "Clear prompt" diye porishkar kora holo');
  }
  if (!cleared) {
    const composer = await evalFn(tabId, sfaFindComposer).catch(() => null);
    if (composer && composer.input) {
      await realClick(tabId, composer.input.x, composer.input.y);
      await sleep(150);
      await clearFocusedInput(tabId);
      elog('Composer Ctrl+A diye porishkar kora holo (Clear prompt button paoa jay ni)');
    }
  }
  await sleep(500);
  const ct = await evalFn(tabId, sfaComposerText).catch(() => null);
  const ing = await getIngredients(tabId);
  elog('Composer obostha: text ' + (ct && typeof ct.text === 'string' ? ct.text.trim().length : '?') + ' chars, ingredients ' + ing.ingredients + ' — upload project ei theke geche');
}

/* v2.0 reference lifecycle (run start, replaces paste-per-attempt):
 * 1) If the reference asset is already in this project (uploads persist
 *    per project) → ready, no upload at all.
 * 2) Otherwise ONE-TIME upload: clipboard paste into the composer, then
 *    the upload gate (tile has data-media-id AND no %) — max 90s.
 *    Timeout aborts the run start: nothing is generated.
 * 3) Clear the composer; the asset stays in the project and every item
 *    re-adds it via the picker (attachRefFromProject). */
async function ensureReference(tabId) {
  const anyNeed = S.items.some((it) => (it.status === 'pending' || it.status === 'active') && itemNeedsRef(it));
  if (!anyNeed) return true;
  const name = S.refFileName || 'image.png';
  S.refStatus = 'checking';
  save();
  elog('Reference check: project e "' + name + '" khujchi');
  // v3: the LISTING decides presence - it is complete and typed, where
  // the grid is a ~27-tile window that can prove nothing. Present here
  // (by recorded UUID or by the upload row named like the file) means
  // ready with no upload; proven absence goes straight to the upload.
  const cat0 = await fetchCatalog(tabId).catch(() => null);
  const preCatUuids = cat0 ? new Set(cat0.media.map((r) => r.uuid)) : null;
  if (cat0) {
    const pres = catalogRefPresence(cat0, (S.refMediaIds || []).concat(S.refMediaId ? [S.refMediaId] : []), name);
    if (pres.status === 'present' && pres.id) {
      S.refMediaId = pres.id;
      if (!Array.isArray(S.refMediaIds)) S.refMediaIds = [];
      if (!S.refMediaIds.includes(pres.id)) S.refMediaIds.push(pres.id);
      S.refStatus = 'ready';
      elog('reference listing e paoa geche - notun upload lagbe na (mediaId=' + pres.id + ')');
      save();
      return true;
    }
    if (pres.status === 'absent') elog('Listing bolche reference project e nai - upload hocche');
  }
  // v3.0.1: no listing, but this run already RECORDED a reference id
  // (an id is recorded only after a completed upload gate or a
  // listing discovery — it is proof an upload already happened).
  // The remaining checks below read the virtualized grid, which
  // cannot prove the recorded asset is gone; on a Stop -> Start
  // resume they "rediscovered" nothing and uploaded a SECOND copy
  // of a sheet that was never lost (sim nocat audit: uploads = 2).
  // With no listing to prove absence, the record stands: trust it.
  if (!cat0 && S.refMediaId) {
    if (!Array.isArray(S.refMediaIds)) S.refMediaIds = [];
    if (!S.refMediaIds.includes(S.refMediaId)) S.refMediaIds.push(S.refMediaId);
    S.refStatus = 'ready';
    elog('Listing nai — record kora reference id diyei cholche, notun upload hobe na (mediaId=' + S.refMediaId + ')');
    save();
    return true;
  }
  const tiles = await evalFn(tabId, sfaTiles).catch(() => null) || [];
  if (S.refMediaId) {
    const byId = tiles.find((t) => t.mediaId === S.refMediaId);
    if (byId && !byId.hasPct) {
      if (!Array.isArray(S.refMediaIds)) S.refMediaIds = [];
      if (!S.refMediaIds.includes(S.refMediaId)) S.refMediaIds.push(S.refMediaId);
      S.refStatus = 'ready';
      S.refAssetName = byId.label || S.refAssetName || name;
      S.refPickerName = sfaPickerNameFromLabel(byId.label || S.refAssetName);
      elog('reference project ei paoa geche — notun upload lagbe na (mediaId=' + S.refMediaId + ', picker naam="' + S.refPickerName + '")');
      save();
      return true;
    }
  }
  const found = await evalFn(tabId, sfaFindAsset, name).catch(() => null);
  if (found && found.found && found.mediaId && !found.hasPct) {
    S.refMediaId = found.mediaId;
    if (!Array.isArray(S.refMediaIds)) S.refMediaIds = [];
    if (!S.refMediaIds.includes(found.mediaId)) S.refMediaIds.push(found.mediaId);
    S.refAssetName = found.label || name;
    S.refPickerName = sfaPickerNameFromLabel(found.label);
    S.refStatus = 'ready';
    elog('reference project ei paoa geche — notun upload lagbe na (mediaId=' + found.mediaId + ', naam="' + (found.label || '') + '", picker naam="' + S.refPickerName + '")');
    save();
    return true;
  }
  if (!(found && found.found)) {
    elog('Reference prothom bar upload hocche — EKbar-i hobe, pore ar kokhono upload hobe na');
    const composer = await evalFn(tabId, sfaFindComposer);
    if (!composer || !composer.input) {
      S.refStatus = 'failed';
      save();
      elog('ERROR: reference upload er jonno prompt input paoa jay ni — run shuru holona');
      return false;
    }
    await realClick(tabId, composer.input.x, composer.input.y);
    await sleep(250);
    const keyOpts = { key: 'v', code: 'KeyV', modifiers: 2, windowsVirtualKeyCode: 86, nativeVirtualKeyCode: 86 };
    await cdp(tabId, 'Input.dispatchKeyEvent', Object.assign({ type: 'keyDown' }, keyOpts));
    await cdp(tabId, 'Input.dispatchKeyEvent', Object.assign({ type: 'keyUp' }, keyOpts));
    await sleep(1000);
  } else {
    elog('Reference tile project e ache kintu ekhono process hocche — upload gate e opekkha hocche');
  }
  S.refStatus = 'uploading';
  save();
  let gate = null;
  if (preCatUuids) {
    gate = await waitRefUploadGateCatalog(tabId, preCatUuids, name).catch(() => null);
    if (!gate && !S.catalogOk) gate = await waitRefUploadGate(tabId, tiles, name);
  } else {
    gate = await waitRefUploadGate(tabId, tiles, name);
  }
  if (!gate) {
    S.refStatus = 'failed';
    save();
    elog('ERROR: reference upload sesh hoyni — run shuru holona');
    return false;
  }
  S.refMediaId = gate.mediaId;
  if (!Array.isArray(S.refMediaIds)) S.refMediaIds = [];
  if (!S.refMediaIds.includes(gate.mediaId)) S.refMediaIds.push(gate.mediaId);
  S.refAssetName = gate.label || name;
  S.refPickerName = sfaPickerNameFromLabel(gate.label);
  S.refStatus = 'ready';
  elog('reference upload COMPLETE (mediaId=' + gate.mediaId + ', ' + gate.secs + 's)');
  elog('picker e khonjar naam record holo: "' + S.refPickerName + '"');
  await clearComposerAfterUpload(tabId);
  save();
  return true;
}

/* v3 - is the reference still in the project? Judged by the LISTING
 * only (catalogRefPresence). No listing => unknown => treated as
 * present: recovery fires only on proven absence or picker failure. */
async function refPresentInProject(tabId) {
  // v3: presence is a LISTING question. No listing => unknown => the
  // reference is treated as present (recovery never fires on doubt).
  // The old grid-scan verdict is gone: a virtualized window cannot
  // prove absence, and acting on it caused the V2.6.1 re-upload loop.
  const cat = await fetchCatalog(tabId).catch(() => null);
  if (!cat) return true;
  const pres = catalogRefPresence(cat, (S.refMediaIds || []).concat(S.refMediaId ? [S.refMediaId] : []), S.refFileName || 'image.png');
  if (pres.status === 'present') {
    if (pres.id) {
      S.refMediaId = pres.id;
      if (!Array.isArray(S.refMediaIds)) S.refMediaIds = [];
      if (!S.refMediaIds.includes(pres.id)) S.refMediaIds.push(pres.id);
      save();
    }
    return true;
  }
  return pres.status !== 'absent';
}

/* v2.6.1 — reference recovery: ONE re-upload through the exact same
 * upload-once path as run start (ensureReference with the recorded id
 * cleared, so it re-discovers by name or pastes + gates again). Used
 * when survival proves the asset vanished (e.g. binned by a stray
 * click). If the clipboard no longer holds the image the gate times
 * out and this returns false — the caller then fails the item with
 * the usual picker reason, exactly as before. */
/* v3.0.1 — recovery gate for the picker-failure path. A picker miss
 * is WINDOW evidence, not loss evidence: the picker is as
 * virtualized as the grid, and under an upload flood it cannot show
 * a reference that is provably still in the project (sim: the
 * flood buries the sheet, the picker misses, and the old code
 * re-uploaded a sheet that was never lost — the exact V2.6.1
 * failure this design exists to kill). Recovery therefore fires
 * only when the LISTING proves absence: a fresh listing fetched
 * fine and holds no trace of the reference. Listing dead (nocat)
 * or ref present in it => no re-upload, the picker miss stays a
 * plain attach failure. Returns true when a recovery upload
 * actually restored the reference. */
async function recoverReferenceIfProvenAbsent(tabId) {
  const cat = await fetchCatalog(tabId, true).catch(() => null);
  if (!cat) {
    elog('Reference recovery hobe na — listing nai, tai hariye geche kina proman nai (picker miss manei loss na)');
    return false;
  }
  const pres = catalogRefPresence(cat, (S.refMediaIds || []).concat(S.refMediaId ? [S.refMediaId] : []), S.refFileName || 'image.png');
  if (pres.status !== 'absent') {
    elog('Reference recovery hobe na — listing e reference ache (picker window te dhora poreni)');
    return false;
  }
  return recoverReference(tabId);
}

async function recoverReference(tabId) {
  // v3: recovery fires AT MOST ONCE per run, and the identity set is
  // append-only - the old UUID stays excluded from downloads forever,
  // even if Flow kept both copies. Called only when the picker itself
  // found no matching asset (real evidence), never on a grid scan.
  if (S.refRecovered) {
    elog('Reference recovery: ei run e ekbar already hoyeche - ar upload hobe na');
    return false;
  }
  S.refRecovered = true;
  elog('Reference lost — re-uploaded');
  S.refAssetName = '';
  S.refPickerName = '';
  S.refStatus = 'uploading';
  save();
  const ok = await ensureReference(tabId).catch(() => false);
  return !!(ok && S.refMediaId);
}

/* v2.0/v2.1 — re-ADD the already-uploaded reference from the project
 * via the ingredient picker (never a re-upload). Steps, each logged:
 * "+" ("Add ingredients to the prompt box") → picker (retry open 3×
 * with Escape between) → "All" tab row (else "Uploads") → v2.1:
 * "Search assets" box e asset er naam likhe filter (search e 0 option
 * ele search muchhe unfiltered list) → option match: mediaId → naam →
 * ekmatro-option shortcut → filename-pattern (na mille scroll ×2,
 * tarpor ja ja option chilo log e likhe fail) → click option
 * (preview) → "Add to prompt" (absent = option click attached)
 * → verify the composer ingredient count grew. One full retry inside,
 * and processItem gives picker failures a 2nd attempt overall. */
async function attachRefFromProject(tabId, item) {
  const fail = (reason) => { const e = new Error(reason); e.finalReason = reason; return e; };
  const before = await getIngredients(tabId);
  if (before.ingredients >= 1) {
    elog(item.id + ': reference age thekei composer e ache (ingredients=' + before.ingredients + ') — picker lagbe na');
    return;
  }
  // v2.6.1: survival check before every picker attach — if the
  // reference asset provably vanished from the project (binned /
  // deleted after its upload), restore it ONCE via the upload path
  // instead of marching into a picker that cannot contain it.
  let recoveredOnce = false;
  // v3: NO pre-attach presence check. The V2.6.1 check read absence
  // from the virtualized grid and re-uploaded a reference that was
  // never lost. Recovery now lives only in the picker-failure path
  // below (real evidence: the picker itself found no asset).
  for (let attachTry = 1; attachTry <= 2; attachTry++) {
    if (stopRequested) throw ABORT;
    let picker = null;
    for (let openTry = 1; openTry <= 3 && !picker; openTry++) {
      const bar = await evalFn(tabId, sfaComposerBar).catch(() => null);
      if (!bar || !bar.plus) throw fail('picker khola jay ni — "Add ingredients" (+) button paoa jay ni');
      // v2.6.1: the "+" comes from a document-wide first-match scan —
      // prove the point lands inside the composer before clicking it;
      // a refused click simply counts as a failed open try below.
      const plusClicked = await guardedClick(tabId, bar.plus.x, bar.plus.y, 'composer');
      if (plusClicked) {
        elog(item.id + ': picker kholar chesta (' + openTry + '/3) — "+" button e click holo');
        const t0 = Date.now();
        while (Date.now() - t0 < 2500) {
          if (stopRequested) throw ABORT;
          const pk = await evalFn(tabId, sfaPicker).catch(() => null);
          if (pk && pk.open) { picker = pk; break; }
          await sleepOrStop(400);
        }
      }
      if (!picker) {
        elog(item.id + ': picker khule ni — Escape diye abar try hobe');
        await pressEscape(tabId).catch(() => {});
        await sleep(400);
      }
    }
    if (!picker) throw fail('picker khule ni (3 bar try korechi)');
    elog(item.id + ': picker khuleche (' + (picker.options || []).length + ' option dekha jacche)');
    const tabWanted = (picker.tabs || []).find((t) => /^all$/i.test(t.name)) || (picker.tabs || []).find((t) => /^uploads$/i.test(t.name));
    if (tabWanted) {
      await realClick(tabId, tabWanted.x, tabWanted.y);
      elog(item.id + ': picker tab "' + tabWanted.name + '" select holo');
      await sleep(700);
      picker = await evalFn(tabId, sfaPicker).catch(() => picker) || picker;
    } else {
      elog(item.id + ': tab row paoa jay ni — current tab diyei cholche');
    }
    // v2.1 search-first: the real picker has a "Search assets" box —
    // typing the asset name filters the list down to the reference
    // instead of depending on row order or roles.
    if (picker.searchInput) {
      const term = sfaSearchTerm(S.refPickerName, S.refAssetName, S.refFileName);
      const preSearchCount = (picker.options || []).length;
      await realClick(tabId, picker.searchInput.x, picker.searchInput.y);
      await sleep(200);
      await cdp(tabId, 'Input.insertText', { text: term });
      await sleep(900);
      picker = await evalFn(tabId, sfaPicker).catch(() => picker) || picker;
      elog(item.id + ": picker e search dilam: '" + term + "' — " + (picker.options || []).length + ' option');
      if ((picker.options || []).length === 0 && preSearchCount > 0 && picker.searchInput) {
        // The search filtered everything out (the asset may carry a
        // different display name) — clear it and use the unfiltered
        // list rather than failing the item.
        elog(item.id + ': search e 0 option — search muchhe unfiltered list e khujchi');
        await realClick(tabId, picker.searchInput.x, picker.searchInput.y);
        await sleep(150);
        await clearFocusedInput(tabId);
        await sleep(700);
        picker = await evalFn(tabId, sfaPicker).catch(() => picker) || picker;
        elog(item.id + ': search muchhar por ' + (picker.options || []).length + ' option dekha jacche');
      }
    }
    let opt = sfaMatchOption(picker.options, S.refMediaId, S.refAssetName, S.refFileName);
    let scrolls = 0;
    while (!opt && scrolls < 2) {
      const scrolled = await evalFn(tabId, sfaPickerScroll).catch(() => false);
      if (!scrolled) break;
      scrolls++;
      await sleep(600);
      picker = await evalFn(tabId, sfaPicker).catch(() => picker) || picker;
      opt = sfaMatchOption(picker.options, S.refMediaId, S.refAssetName, S.refFileName);
      elog(item.id + ': picker scroll ' + scrolls + ' — option ' + (opt ? 'paichi' : 'ekhono pai ni') + ' (mot ' + (picker.options || []).length + ' option dekha jacche)');
    }
    if (!opt) {
      // v2.1: name what WAS seen, so a future miss is self-diagnosing.
      const seen = (picker.options || []).slice(0, 5).map((o) => "[name='" + (o.name || '') + "' mediaId=" + (o.mediaId || 'null') + ']').join(', ');
      elog(item.id + ': picker options chilo: ' + (seen || '(kono option dekha jay ni)'));
      await pressEscape(tabId).catch(() => {});
      // v2.6.1: zero matching assets usually means the reference is
      // GONE from the project (the V2.6 bin incident), not merely
      // unmatched — close the picker, restore it via the re-upload
      // path ONCE, and let the next attach try use the restored
      // asset instead of failing the item.
      // v3.0.1: gated — the re-upload fires only on listing-proven
      // absence (recoverReferenceIfProvenAbsent); a bare picker miss
      // under a flood is not proof and must not re-upload.
      if (!recoveredOnce) {
        recoveredOnce = true;
        const ok = await recoverReferenceIfProvenAbsent(tabId).catch(() => false);
        if (ok) continue;
      }
      throw fail('picker e reference khuje pai ni');
    }
    if (opt.via === 'single') {
      elog(item.id + ": picker e ekmatro option tai select holo (name='" + (opt.name || '') + "')");
    } else if (opt.via === 'filename') {
      elog(item.id + ": filename-pattern diye option select holo (name='" + (opt.name || '') + "')");
    } else {
      elog(item.id + ': asset select holo — "' + (opt.name || '') + '"' + (opt.mediaId ? ' (mediaId=' + opt.mediaId + ')' : ''));
    }
    await realClick(tabId, opt.x, opt.y);
    await sleep(600);
    const pk2 = await evalFn(tabId, sfaPicker).catch(() => null);
    if (pk2 && pk2.addBtn) {
      await realClick(tabId, pk2.addBtn.x, pk2.addBtn.y);
      elog(item.id + ': "Add to prompt" click holo');
      await sleep(600);
    } else {
      elog(item.id + ': "Add to prompt" button nai — option click ei attach dhora holo');
    }
    const after = await getIngredients(tabId);
    const grew = (before.ingredients >= 0 && after.ingredients > before.ingredients) ||
      (before.ingredients < 0 && after.ingredients >= 1);
    if (grew) {
      elog(item.id + ': reference add hoyeche — chip ache ekhon ' + after.ingredients);
      return;
    }
    elog(item.id + ': reference add verify fail (ingredients ' + before.ingredients + ' -> ' + after.ingredients + ') — attach try ' + attachTry + '/2');
    await pressEscape(tabId).catch(() => {});
    await sleep(400);
  }
  throw fail('reference add hoy ni');
}

/* ---------------- download ---------------- */
/* v2.2 quality route: for 2K/4K the download goes through Flow's own
 * tile menu (the direct URL is only the original size). Flow's menu
 * offers "1K Original size" / "2K Upscaled" — for 4K we pick the
 * highest option the menu actually shows. A menu download lands with
 * Flow's own file name (the downloads API cannot rename a download
 * the page started), so the item records dlName and the match report
 * lists it under Flow names. Any menu failure falls back to the 1K
 * direct download below. */
async function downloadViaMenu(tabId, item, tile, quality) {
  const before = new Set();
  const existing = await chrome.downloads.search({});
  (existing || []).forEach((d) => before.add(d.id));
  const tu = tile && tile.mediaId ? await evalFn(tabId, sfaTileUrl, tile.mediaId).catch(() => null) : null;
  if (!tu) throw new Error('tile paoa jay ni');
  elog(item.id + ': ' + quality + ' menu download — tile e click hocche (viewer khulbe)');
  await realClick(tabId, tu.x, tu.y);
  await sleep(1500);
  const btn = await evalFn(tabId, sfaFindDownloadBtn);
  if (!btn) throw new Error('Viewer e Download button paoa jay ni');
  elog(item.id + ': menu download — Download button e click hocche');
  await realClick(tabId, btn.x, btn.y);
  await sleep(900);
  const want = quality === '4K' ? ['4K', '2K', 'Upscaled', 'Original size'] : ['2K', 'Upscaled', 'Original size'];
  let picked = null;
  for (const t of want) {
    picked = await evalFn(tabId, sfaFindTextBtn, { text: t }).catch(() => null);
    if (picked) break;
  }
  let pickedLabel = 'Download';
  if (picked) {
    pickedLabel = picked.label || pickedLabel;
    if (quality === '4K' && !/4\s*k/i.test(pickedLabel)) {
      elog(item.id + ': 4K nai — highest available nilam ("' + pickedLabel + '")');
    } else {
      elog(item.id + ': menu theke "' + pickedLabel + '" select holo');
    }
    await realClick(tabId, picked.x, picked.y);
  } else {
    elog(item.id + ': size submenu paoa jay ni — Download click ei ja ashe tai hobe');
  }
  const t0 = Date.now();
  while (Date.now() - t0 < 30000) {
    const news = await chrome.downloads.search({ startedAfter: new Date(t0 - 5000).toISOString() });
    const fresh = (news || []).find((d) => !before.has(d.id));
    if (fresh) {
      const done = await waitDownloadComplete(fresh.id, 60000);
      if (!done) throw new Error('Menu download interrupted');
      const base = String(done.filename || '').replace(/\\/g, '/').split('/').pop();
      elog(item.id + ': menu download done — file: ' + base + ' (' + (done.fileSize || done.totalBytes || 0) + ' bytes)');
      return { flowName: base, label: pickedLabel };
    }
    await sleep(1000);
  }
  throw new Error('Menu download shuru hoyni');
}

/* v2.0: primary path is the completed tile's own URL (sfaTileUrl —
 * the signed flow.google.com/asb/... thumbnail URL), saved under our
 * exact filename and byte-verified as before. Blob URLs and missing
 * URLs fall back to the viewer route. v2.2: 2K/4K try Flow's own
 * download menu first (see downloadViaMenu). */
/* v2.6 — video tile download (best effort): the <video> element's own
 * source under the item's exact .mp4 name; a blob: source cannot be
 * fetched from the service worker, so the viewer route runs instead
 * (Flow's own Download saves the file with Flow's name). If neither
 * works the item fails with an honest reason — the run continues. */
async function downloadVideoTile(tabId, item, tile) {
  item.mediaKind = 'video';
  const tm = tile && tile.mediaId ? await evalFn(tabId, sfaTileMedia, tile.mediaId).catch(() => null) : null;
  const vurl = (tm && tm.kind === 'video' && tm.url) ? tm.url : (tile && tile.videoSrc) || '';
  const fname = targetPathFor(S.project, item.id, 'video');
  if (vurl && vurl.indexOf('blob:') !== 0) {
    try {
      elog(item.id + ': video download shuru — ' + fname);
      const size = await downloadAndVerify(vurl, fname);
      elog(item.id + ': video download done (' + size + ' bytes)');
      item.stage = 'done';
      return '';
    } catch (e) {
      elog(item.id + ': video direct download fail (' + e.message + ') — viewer fallback hocche');
    }
  } else if (vurl) {
    elog(item.id + ': video blob URL — viewer fallback hocche');
  }
  try {
    const note = await fallbackDownload(tabId, tile);
    elog(item.id + ': video fallback download done (Flow er nijer name e save hoyeche)');
    item.stage = 'done';
    return note;
  } catch (fbErr) {
    const err = new Error('video download capture hoy ni');
    err.finalReason = 'video download capture hoy ni — Flow theke manually download koro';
    throw err;
  }
}

async function downloadFromTile(tabId, item, tile) {
  if (tile && tile.kind === 'video') return downloadVideoTile(tabId, item, tile);
  const q = (S.settings && S.settings.quality) || '1K';
  if ((q === '2K' || q === '4K') && tile && tile.mediaId) {
    try {
      const r = await downloadViaMenu(tabId, item, tile, q);
      item.dlName = r.flowName || '';
      item.stage = 'done';
      return 'via menu — ' + r.label + ' (flow name: ' + r.flowName + ')';
    } catch (e) {
      elog(item.id + ': ' + q + ' menu fail (' + e.message + ') — 1K direct download holo');
      item.dlName = '';
    }
  }
  const fname = targetPath(S.project, item.id);
  const tu = tile && tile.mediaId ? await evalFn(tabId, sfaTileUrl, tile.mediaId).catch(() => null) : null;
  // Prefer the URL captured when the tile was resolved (at
  // attribution time it is guaranteed in the render window); a
  // fresh lookup can come back empty if the grid has since churned
  // (new uploads push finished tiles out of the virtualized window).
  const url = (tu && tu.url) ? tu.url : ((tile && tile.url) || '');
  if (url && url.indexOf('blob:') !== 0) {
    elog(item.id + ': download shuru — ' + fname + ' (tile mediaId=' + tile.mediaId + ')');
    const size = await downloadAndVerify(upgradeUrl(url), fname);
    elog(item.id + ': download done (' + size + ' bytes)');
    item.stage = 'done';
    return '';
  }
  if (url) elog(item.id + ': blob URL — tile click fallback hocche');
  else elog(item.id + ': tile URL paoa jay ni — tile click fallback hocche');
  try {
    const note = await fallbackDownload(tabId, tile);
    elog(item.id + ': fallback download done');
    item.stage = 'done';
    return note;
  } catch (fbErr) {
    const err = new Error('download hoy ni — report pathao');
    err.finalReason = 'download hoy ni — report pathao';
    throw err;
  }
}

/* Viewer fallback: click the finished tile (realClick moves the mouse
 * first — hover toolbars need real pointer movement), press the
 * viewer's Download button, then "1K Original size" when the download
 * opens a size submenu. The file lands with Flow's own name, so a
 * successful fallback returns the 'fallback-name' note. */
async function fallbackDownload(tabId, tileHint) {
  const before = new Set();
  const existing = await chrome.downloads.search({});
  (existing || []).forEach((d) => before.add(d.id));
  let cx = null;
  let cy = null;
  if (tileHint && tileHint.mediaId) {
    const tu = await evalFn(tabId, sfaTileUrl, tileHint.mediaId).catch(() => null);
    if (tu) { cx = tu.x; cy = tu.y; }
  }
  if (cx === null && !(tileHint && tileHint.mediaId)) {
    // No specific tile was requested: the legacy any-tile guess is
    // the only option. With a tileHint, guessing ANOTHER tile would
    // download unverified content under this item's number - the
    // exact failure v3 exists to eliminate - so it fails honestly.
    const tiles = await evalFn(tabId, sfaTiles).catch(() => null);
    const cand = (tiles || []).find((t) => t.kind === 'image' && t.mediaId);
    if (cand) {
      const tu2 = await evalFn(tabId, sfaTileUrl, cand.mediaId).catch(() => null);
      if (tu2) { cx = tu2.x; cy = tu2.y; }
    }
  }
  if (cx === null && !(tileHint && tileHint.mediaId)) {
    const img = await evalFn(tabId, sfaLastImg).catch(() => null);
    if (img) { cx = img.x; cy = img.y; }
  }
  if (cx === null) throw new Error('Result image tile paoa jay ni');
  elog('Fallback: tile e click hocche (' + cx + ',' + cy + ') — viewer khulbe');
  await realClick(tabId, cx, cy);
  await sleep(1500);
  const btn = await evalFn(tabId, sfaFindDownloadBtn);
  if (!btn) throw new Error('Viewer e Download button paoa jay ni');
  elog('Fallback: Download button e click hocche');
  await realClick(tabId, btn.x, btn.y);
  await sleep(900);
  const sizeBtn = await evalFn(tabId, sfaFindTextBtn, { text: 'Original size' }).catch(() => null);
  if (sizeBtn) {
    elog('Fallback: size menu te "' + sizeBtn.label + '" pelam — click hocche');
    await realClick(tabId, sizeBtn.x, sizeBtn.y);
  }
  const t0 = Date.now();
  while (Date.now() - t0 < 30000) {
    const news = await chrome.downloads.search({ startedAfter: new Date(t0 - 5000).toISOString() });
    const fresh = (news || []).find((d) => !before.has(d.id));
    if (fresh) {
      const done = await waitDownloadComplete(fresh.id, 60000);
      if (done) return 'fallback-name';
      throw new Error('Fallback download interrupted');
    }
    await sleep(1000);
  }
  throw new Error('Fallback download shuru hoyni');
}

/* v2.6.2 — read the prompt Flow shows for a finished tile: open the
 * tile in the viewer (realClick, like the fallback download does),
 * harvest the prompt text via sfaTilePrompt's viewer stage, then
 * close with Escape (the viewer's own close button if Escape did not
 * take). Returns { ok:true, text } or { ok:false } — a tile that is
 * gone, a viewer that does not open, or a prompt region that cannot
 * be found are all a soft "unreadable"; callers count rounds and fall
 * back to order-based assignment after 3. */
/* v3.0.1 — read a tile's viewer prompt TWICE, as two independent
 * locate+click cycles, and accept the text only if both reads agree.
 * The single read has a structural race (proven by the sim battery:
 * paced-fast-noprompt and paced-prompt-notime both produced an
 * off-by-one WRONG-CONTENT download): the probe locates the tile by
 * media id and returns its centre, the engine clicks the point — and
 * if a new generation lands in between, the grid shifts and the click
 * opens the NEIGHBOUR tile's viewer, whose prompt then "exactly
 * matches" a different outstanding item. Two reads suffering the
 * same shift onto the same neighbour is negligible; disagreement
 * marks the read worthless (retry later) instead of pinning a wrong
 * tile to an item. Used by every PACED viewer claim; serial mode is
 * single-flight (a shifted read there can only read as foreign —
 * it cannot cross-attribute) and is deliberately untouched. */
async function readTilePromptTwice(tabId, mediaId) {
  // NEVER throws: this sits on fallback paths, and a fallback that
  // can throw can kill the whole run (the v3.0.1 sim caught exactly
  // that — a bad identifier reference here crashed every paced run
  // that reached a viewer claim).
  try {
    const rd1 = await readTilePromptText(tabId, mediaId).catch(() => ({ ok: false }));
    const rd2 = await readTilePromptText(tabId, mediaId).catch(() => ({ ok: false }));
    if (rd1 && rd1.ok && rd2 && rd2.ok) {
      if (promptNormText(rd1.text) !== promptNormText(rd2.text)) return { ok: false, shifted: true };
      return { ok: true, text: rd1.text };
    }
    // Neither read produced prompt text, and at least one open
    // found a viewer with NO prompt in it: the tile carries no
    // prompt (an upload, or a tile whose viewer is prompt-less).
    // Returned as a verdict, not a failure, so callers park it at
    // once instead of burning viewer rounds on it (a mid-run upload
    // flood otherwise costs six viewer opens per tile and starves
    // real downloads — sim-proven at the reference-sink flood, item
    // 015). sawNoPrompt is reported even when the verdict is not
    // decisive, so callers can bar the tile from exclusivity: a
    // prompt-less tile must NEVER be exclusivity-claimed (sim-proven
    // wrong download: the last item claimed a flood upload).
    const anyOk = (rd1 && rd1.ok) || (rd2 && rd2.ok);
    const sawNP = (rd1 && rd1.noPrompt) || (rd2 && rd2.noPrompt);
    if (!anyOk && sawNP) return { ok: false, noPrompt: true, sawNoPrompt: true };
    if (sawNP) return { ok: false, sawNoPrompt: true };
    return { ok: false };
  } catch (e) { return { ok: false }; }
}

async function readTilePromptText(tabId, mediaId) {
  try {
    const pt = await evalFn(tabId, sfaTilePrompt, mediaId).catch(() => null);
    if (!pt || !pt.found) return { ok: false, text: '' };
    await realClick(tabId, pt.x, pt.y);
    await sleep(1200);
    const vp = await evalFn(tabId, sfaTilePrompt, null).catch(() => null);
    let text = '';
    let closePt = null;
    if (vp && vp.found && vp.text) { text = String(vp.text); closePt = vp.close || null; }
    await pressEscape(tabId).catch(() => {});
    await sleep(300);
    if (text && closePt) {
      const still = await evalFn(tabId, sfaTilePrompt, null).catch(() => null);
      if (still && still.found) {
        await realClick(tabId, closePt.x, closePt.y).catch(() => {});
        await sleep(300);
      }
    }
    // noPrompt: a viewer WAS open (overlayOpen) but showed no prompt
    // text at all — decisive for uploads / prompt-less tiles, and
    // kept distinct from "the viewer never opened" (a retryable
    // failure). (The probe's found:true always carries text, so the
    // overlayOpen marker is the only honest prompt-less signal.)
    if (!text) return { ok: false, text: '', noPrompt: !!(vp && (vp.found || vp.overlayOpen)) };
    return { ok: true, text };
  } catch (e) {
    await pressEscape(tabId).catch(() => {});
    return { ok: false, text: '' };
  }
}

/* v2.2 — one completed generation, two outcomes. Records the tile
 * identity + URL on the item and kicks off its thumbnail, then:
 * - Download Later mode (settings.autoDownload === false): returns
 *   { generatedOnly: true } — the caller marks the item "generated"
 *   and NO download happens now.
 * - Auto mode: downloads immediately (tile route, direct URL, or the
 *   viewer fallback) and returns { note }.
 * With neither a tile nor a usable URL there is nothing to defer, so
 * the viewer fallback runs at once even in Download Later mode. */
async function completeItem(tabId, item, tile, knownUrl) {
  // v3: the reference can NEVER be downloaded under an item number -
  // exclusion by identity (the full UUID set), asserted inside the one
  // funnel every completion passes through, not at each call site.
  if (tile && tile.mediaId && Array.isArray(S.refMediaIds) && S.refMediaIds.includes(tile.mediaId)) {
    throw new Error('reference tile download theke rokkha peyechi (mediaId=' + tile.mediaId + ')');
  }
  let url = knownUrl || '';
  if (tile && tile.mediaId) {
    item.tileMediaId = tile.mediaId;
    if (tile.kind === 'video') item.mediaKind = 'video'; // v2.6: .mp4 naming + verify
    if (!url) {
      if (tile.kind === 'video') {
        // The tile's poster <img> URL is NOT the video file — only the
        // <video> element's own source counts (fresh read at download).
        if (tile.videoSrc) url = tile.videoSrc;
      } else {
        const tu = await evalFn(tabId, sfaTileUrl, tile.mediaId).catch(() => null);
        if (tu && tu.url) url = tu.url;
      }
    }
  }
  if (url) item.tileUrl = url;
  if (tile || url) item.completedAt = Date.now();
  // v3: ETA samples recorded HERE, in the single completion funnel, so
  // every path (serial/paced, prompt/fast, catalog/DOM) feeds the
  // estimate - the V2.6.2 prompt-check run showed ETA '-' after 7
  // completions because one path never recorded a sample.
  if (tile || url) noteItemCycle(item);
  if (url && url.indexOf('blob:') !== 0 && !(tile && tile.kind === 'video')) captureThumbnail(item.id, upgradeUrl(url));
  if (S.settings && S.settings.autoDownload === false && (tile || (url && url.indexOf('blob:') !== 0))) {
    elog(item.id + ': generated — download pore hobe (Download Later mode, tile mone rakha holo)');
    item.stage = 'generated';
    save();
    return { generatedOnly: true };
  }
  if (tile) {
    const note = await downloadFromTile(tabId, item, tile);
    return { note: note || '' };
  }
  if (url && url.indexOf('blob:') !== 0) {
    const fname = targetPath(S.project, item.id);
    elog(item.id + ': download shuru — ' + fname);
    const size = await downloadAndVerify(upgradeUrl(url), fname);
    elog(item.id + ': download done (' + size + ' bytes)');
    item.stage = 'done';
    return { note: '' };
  }
  const note = await fallbackDownload(tabId, tile || null);
  elog(item.id + ': fallback download done');
  item.stage = 'done';
  return { note: note || '' };
}

/* Decide where the fallback send-click goes. First choice: the coords
 * captured BEFORE typing (empty-composer layout, known-good) — but only if
 * the element at that point still verifies via sfaVerifyPoint as a
 * non-blacklisted button. If verification fails, re-run the (now
 * blacklist-aware) composer finder and verify its pick the same way. */
async function resolveClickTarget(tabId, item, storedSend) {
  if (storedSend) {
    const v = await evalFn(tabId, sfaVerifyPoint, { x: storedSend.x, y: storedSend.y }).catch(() => null);
    if (v && v.ok) return { x: storedSend.x, y: storedSend.y, label: v.label || storedSend.label || '', strategy: 'age-dhora coords (verified)' };
    elog(item.id + ': click fallback — age-dhora coords verify fail (' + (v ? (v.reason || '?') + (v.label ? ', label="' + v.label + '"' : '') : 'probe fail') + '), notun kore button khujchi');
  }
  const fresh = await evalFn(tabId, sfaFindComposer).catch(() => null);
  if (fresh && fresh.send) {
    const v2 = await evalFn(tabId, sfaVerifyPoint, { x: fresh.send.x, y: fresh.send.y }).catch(() => null);
    if (v2 && v2.ok) return { x: fresh.send.x, y: fresh.send.y, label: v2.label || fresh.send.label || '', strategy: fresh.send.strategy + ' (notun, verified)' };
    elog(item.id + ': click fallback — notun button er point-verify fail (' + (v2 ? (v2.reason || '?') : 'probe fail') + '), finder er pick tai use hocche');
    return { x: fresh.send.x, y: fresh.send.y, label: fresh.send.label || '', strategy: fresh.send.strategy + ' (notun)' };
  }
  return null;
}

/* v3 - serial completion wait, CATALOG-FIRST. The listing carries
 * each generation's own prompt, so the tile that completes this item
 * is PROVEN to be its (prompt attribution), never guessed from grid
 * order or from "the newest tile". Error tiles are watched on the DOM
 * side (a failed generation produces no catalog row) and classified:
 * unusual-activity becomes a cooldown signal, a daily limit stops the
 * run, a generic failure gets a bounded guarded Retry. Prompt-less
 * rows fall down the ladder: viewer verify -> exclusivity -> park.
 * If the listing is unavailable, the proven DOM wait takes over. */
async function waitForCompletion(tabId, snap, item, opts) {
  opts = opts || {};
  const cat0 = await fetchCatalog(tabId).catch(() => null);
  if (!cat0) return waitForCompletionDom(tabId, snap, item, opts);
  const epoch = abortEpoch;
  const quota = Math.max(1, opts.count || 1);
  const wantKind = opts.wantKind || 'image';
  const promptMode = (S.settings && S.settings.matchMode) === 'prompt';
  const t0 = Date.now();
  let retries = 0;
  let catMisses = 0;
  // Error tiles are counted against the PRE-SEND snapshot count -
  // the DOM wait's proven baseline. Error tiles persist in the grid
  // after a failed send; any per-tile identity scheme re-reads the
  // stale tile as a fresh failure on the next attempt (found by the
  // sim: a resend after cooldown was killed by its own stale tile).
  let errBase = (snap && snap.errorCount) || 0;
  const unverifiedRounds = new Map(); // uuid -> viewer attempts
  const mine = []; // v3: this item's attributed rows so far (Count quota)
  while (Date.now() - t0 < 240000) {
    if (stopRequested) throw ABORT;
    if (epoch !== abortEpoch) throw ABORT;
    beat();
    item.stage = 'waiting ' + Math.round((Date.now() - t0) / 1000) + 's';
    // --- error tiles (DOM side) ---
    const tiles = await evalFn(tabId, sfaTiles).catch(() => null);
    if (tiles) {
      const errTiles = tiles.filter((t) => t.kind === 'error');
      if (errTiles.length > errBase) {
        const et = errTiles[0];
        const cls = classifyErrorText(et.text || et.label || '');
        if (cls === 'unusual') {
          const err = new Error('Flow unusual activity boleche - ektu thamte hobe');
          err.cooldown = true;
          throw err;
        }
        if (cls === 'limit') {
          const err = new Error('Flow daily limit sesh - aj ar generation hobe na');
          err.stopRun = true;
          throw err;
        }
        if (retries < 2 && et.retryBtn) {
          retries++;
          elog(item.id + ': error tile - Retry click (' + retries + '/2)');
          await realClick(tabId, et.retryBtn.x, et.retryBtn.y);
          errBase = errTiles.length - 1; // the retried tile should leave error state
        } else {
          // Retries exhausted or no Retry on offer: this send is
          // dead. Fail the attempt now (the caller resends) instead
          // of burning the whole 240s wait.
          throw new Error('Flow error: ' + (et.text || et.label || 'generation failed'));
        }
      }
    }
    // --- attribution (listing side) ---
    const cat = await fetchCatalog(tabId, true).catch(() => null);
    if (!cat) {
      catMisses++;
      if (catMisses >= 3) return waitForCompletionDom(tabId, snap, item, opts);
    } else {
      catMisses = 0;
      const mineUuids = new Set(mine.map((a) => a.uuid));
      const rows = candidateRowsWithParked(cat).filter((r) => (r.kind === wantKind || !wantKind) && !mineUuids.has(r.uuid));
      // Count quota: accumulate this item's attributed rows across
      // polls - the first is the download, the rest are extras, and
      // the wait only completes when the quota fills (or time runs
      // out with a partial set, which still downloads its primary).
      const res = pickAttributions(rows, [{ id: item.id, prompt: item.sentPrompt || item.prompt, got: mine.length, quota: quota }]);
      for (const a of res.assign) {
        unparkUuid(a.uuid);
        if (!mine.find((mm) => mm.uuid === a.uuid)) mine.push(a);
      }
      if (mine.length >= quota) {
        const primary = mine.find((a) => !a.extra) || mine[0];
        const extras = mine.filter((a) => a !== primary).map((a) => ({ mediaId: a.uuid, kind: a.kind }));
        const tile = await resolveCatalogTile(tabId, primary.uuid, primary.kind);
        return { tile: tile, extras: extras };
      }
      // --- prompt-less rows: the fallback ladder ---
      for (const row of res.unverified) {
        if (!row.prompt) {
          const done = await serialUnverifiedRow(tabId, item, row, promptMode, unverifiedRounds);
          if (done) return done;
        }
      }
    }
    await sleepOrStop(2500, epoch);
    save();
  }
  if (mine.length) {
    const primary = mine.find((a) => !a.extra) || mine[0];
    const extras = mine.filter((a) => a !== primary).map((a) => ({ mediaId: a.uuid, kind: a.kind }));
    const tile = await resolveCatalogTile(tabId, primary.uuid, primary.kind);
    return { tile: tile, extras: extras };
  }
  throw new Error('Timeout 240s — generation sesh hoyni');
}

/* Resolve a catalog UUID to a DOM tile object completeItem can use:
 * scroll it into the virtualized window, then read its live tile. */
async function resolveCatalogTile(tabId, uuid, kind) {
  for (let i = 0; i < 8; i++) {
    const tm = await evalFn(tabId, sfaTileMedia, uuid).catch(() => null);
    if (tm && tm.found) return tm;
    await evalFn(tabId, sfaRevealTile, uuid).catch(() => null);
    await sleep(600);
  }
  return { mediaId: uuid, kind: kind || 'image' };
}

/* One prompt-less catalog row in the serial wait. Returns a completion
 * object if the row completes the current item, else null (row parked,
 * consumed as foreign, or revived for its true owner). */
async function serialUnverifiedRow(tabId, item, row, promptMode, rounds) {
  if (!Array.isArray(S.unclaimedUuids)) S.unclaimedUuids = [];
  if (!Array.isArray(S.consumedTiles)) S.consumedTiles = [];
  const park = () => {
    if (!S.consumedTiles.includes(row.uuid)) S.consumedTiles.push(row.uuid);
    if (!S.unclaimedUuids.includes(row.uuid)) S.unclaimedUuids.push(row.uuid);
    save();
    return null;
  };
  if (promptMode) {
    const n = (rounds.get(row.uuid) || 0) + 1;
    rounds.set(row.uuid, n);
    if (n <= 3) {
      await resolveCatalogTile(tabId, row.uuid, row.kind);
      const rd = await readTilePromptText(tabId, row.uuid).catch(() => ({ ok: false }));
      if (rd && rd.ok) {
        const sentItems = S.items.filter((it) => (it.sentAt || 0) > 0 || it === item);
        const hit = matchPromptToItems(rd.text, sentItems.map((it) => ({ id: it.id, prompt: it.sentPrompt || it.prompt })));
        if (hit && hit.itemId === item.id) {
          elog(item.id + ': Prompt check (viewer) ✓ - tile er prompt mileche (' + hit.how + ')');
          const tile = await resolveCatalogTile(tabId, row.uuid, row.kind);
          return { tile: tile, extras: [] };
        }
        if (hit && hit.itemId) {
          const other = S.items.find((it) => it.id === hit.itemId);
          if (other && !other.tileMediaId && other.status !== 'done' && other.status !== 'generated') {
            if (!S.consumedTiles.includes(row.uuid)) S.consumedTiles.push(row.uuid);
            try {
              const outcome = await completeItem(tabId, other, await resolveCatalogTile(tabId, row.uuid, row.kind), '');
              const term = terminalStatusFor(outcome);
              other.status = term; other.stage = term; other.failReason = '';
              elog(other.id + ': late tile eshe poucheche - download hoye gelo (' + term + ')');
            } catch (e) { elog(other.id + ': late tile download e badha'); }
            save();
          }
          return null;
        }
        elog(item.id + ': Prompt check - tile ta pathano kono prompt er na, bad deowa holo');
        return park();
      }
      return null; // unreadable this round - retried, then exclusivity
    }
  }
  // exclusivity: serial runs have exactly ONE outstanding send; a
  // prompt-less row created at/after this send can only be its result.
  if (row.createdAt && item.sentAt && row.createdAt >= item.sentAt - 5000) {
    elog(item.id + ': prompt-less tile - ekmatro outstanding send dhore neowa holo');
    const tile = await resolveCatalogTile(tabId, row.uuid, row.kind);
    return { tile: tile, extras: [] };
  }
  return park();
}

/* ---------------- one item ---------------- */
/* v2.5 — ONE send attempt, factored out of processItem so the paced
 * loop can reuse the exact same machinery (snapshot -> clear -> picker
 * attach -> type+verify -> gap -> Enter -> start-signal wait with the
 * hardened click fallback). ctx carries the cross-attempt type-fail
 * counter ({ typeFails }); opts.enforceGap === false skips the send
 * gap (paced mode paces sends itself) but still stamps lastSendAt.
 * Resolves { snap, busySeen, sentAt } once generation has verifiably
 * started; throws (with finalReason where the serial rules make it
 * final) otherwise. */
async function sendPromptOnce(tabId, item, ctx, opts) {
  ctx = ctx || { typeFails: 0 };
  opts = opts || {};
  const wantRef = itemNeedsRef(item);
  // Pre-send snapshot: completion + error detection are relative to
  // this. snap.ids = mediaIds already in the grid; snap.errorCount =
  // error tiles already there (old error tiles persist forever).
  const snapTiles = await evalFn(tabId, sfaTiles).catch(() => []);
  const snap = {
    ids: (snapTiles || []).map((t) => t.mediaId).filter(Boolean),
    count: (snapTiles || []).length,
    errorCount: (snapTiles || []).filter((t) => t.kind === 'error').length
  };
  let composer = await evalFn(tabId, sfaFindComposer);
  if (!composer || !composer.input) throw new Error('Prompt input paoa jay ni');
  // Send-button coords are captured NOW, in the empty-composer layout
  // where the arrow's position is known-good. In v1.2 the button was
  // re-located AFTER typing — and once text is present a clear/close (x)
  // control sits near the composer, which the finder mistook for the
  // send button: the click erased the prompt and nothing generated.
  const storedSend = composer.send || null;
  if (storedSend) {
    elog(item.id + ': send button age theke dhora ache (' + storedSend.x + ',' + storedSend.y + '), strategy=' + storedSend.strategy + ', label="' + (storedSend.label || '') + '"');
  } else {
    elog(item.id + ': SABDHAN: khali box e send button paoa jay ni — click fallback thakbe na, sudhu Enter diye try hobe');
  }

  // Focus + clear the box first (clearing after an attach could
  // remove the ingredient, so the order is: clear -> attach -> type).
  item.stage = 'typing';
  await realClick(tabId, composer.input.x, composer.input.y);
  await sleep(150);
  await clearFocusedInput(tabId);

  if (wantRef) {
    item.stage = 'ref bosano hocche';
    save();
    await attachRefFromProject(tabId, item);
    // Attaching re-renders/shifts the composer, so re-find it and
    // type with the fresh layout (v1.4 typed into nowhere exactly
    // because pre-attach coordinates went stale).
    const freshComposer = await evalFn(tabId, sfaFindComposer).catch(() => null);
    if (freshComposer && freshComposer.input) {
      composer = freshComposer;
      elog(item.id + ': reference add er por composer notun kore khuje neowa holo');
    } else {
      elog(item.id + ': reference add er por composer notun kore paoa jay ni — ager coords diyei type hobe');
    }
  }

  // Type, with ONE in-attempt retry: a failed verify re-finds the
  // composer, refocuses, waits 600ms and types again before the
  // attempt is allowed to fail on typing.
  let vt = null;
  for (let t = 1; t <= 2; t++) {
    await realClick(tabId, composer.input.x, composer.input.y);
    await sleep(t === 1 ? 150 : 600);
    await cdp(tabId, 'Input.insertText', { text: item.prompt });
    await sleep(500);
    vt = await verifyTyped(tabId, item.prompt);
    if (vt.ok) break;
    if (t === 1) {
      elog(item.id + ': TYPE FAIL (in-attempt 1/2, box length ' + vt.len + ') — composer notun kore khuje abar type hocche');
      const reComposer = await evalFn(tabId, sfaFindComposer).catch(() => null);
      if (reComposer && reComposer.input) composer = reComposer;
    }
  }
  if (!vt.ok) {
    ctx.typeFails++;
    elog(item.id + ': TYPE FAIL: box e lekha nai (fail ' + ctx.typeFails + '/2, box length ' + vt.len + ')');
    if (ctx.typeFails >= 2) {
      const err = new Error('prompt type hoy ni');
      err.finalReason = 'prompt type hoy ni';
      throw err;
    }
    throw new Error('prompt type hoy ni — abar try hobe');
  }
  item.stage = 'typed';
  elog(item.id + ': typed OK, ' + vt.len + ' chars box e ache');
  save();

  // Pacing rule: generation starts are spaced by the configured
  // interval (settings.intervalSec; v2.0's fixed 10s is the default).
  if (opts.enforceGap === false) { S.lastSendAt = Date.now(); save(); }
    else await enforceSendGap(item);

  // ---- SEND: Enter FIRST. Flow's composer is a chat-style input
  // where Enter = send, and a trusted CDP Enter can never land on
  // a wrong (clear/close) control the way a blind click could.
  item.stage = 'send: Enter';
  elog(item.id + ': Enter diye send er chesta');
  save();
  let sentAt = Date.now();
  await pressEnter(tabId);

  // Fail fast if generation never actually starts: 15s signal wait
  // after Enter, then ONE hardened click fallback + another 15s.
  item.stage = 'gen shuru check';
  save();
  let signal = await waitForStartSignal(tabId, snap, vt.len);
  if (!signal) {
    elog(item.id + ': Enter e start signal pai ni (15s) — click fallback hocche');
    const target = await resolveClickTarget(tabId, item, storedSend);
    if (target) {
      item.stage = 'send: click';
      elog(item.id + ': click fallback — button "' + (target.label || '') + '" (' + target.x + ',' + target.y + '), strategy=' + target.strategy);
      save();
      await realClick(tabId, target.x, target.y);
      S.lastSendAt = Date.now();
      save();
      sentAt = Date.now();
      signal = await waitForStartSignal(tabId, snap, vt.len);
    } else {
      elog(item.id + ': click fallback er jonno nirbhorjoggo button paoa jay ni');
    }
  }
  if (!signal) {
    const err = new Error('send hoy ni — Enter o click duitai miss (button khuje pete somossa)');
    err.finalReason = err.message;
    throw err;
  }
  elog(item.id + ': generation shuru hoyeche — signal: ' + signal.name);
  item.stage = 'waiting';
  save();

  // v3: the send ledger - attribution matches catalog rows against
  // what was ACTUALLY sent; the ETA and watchdog read the same record.
  item.sentPrompt = item.prompt;
  item.sendCount = (item.sendCount || 0) + 1;
  return { snap: snap, busySeen: signal.busySeen, sentAt: sentAt };
}

async function processItem(tabId, item, gen) {
  let lastError = null;
  const sendCtx = { typeFails: 0 };
  const verifyRounds = new Map(); // v2.6.2: mediaId -> failed prompt-check rounds (this item's process run)
  for (let attempt = 1; attempt <= 3; attempt++) {
    if (stopRequested) throw ABORT;
    if (gen !== undefined && gen !== runGen) throw ABORT; // v2.3: superseded by a newer run
    item.attempts = (item.attempts || 0) + 1;
    elog(item.id + ': attempt ' + attempt + ' shuru');
    save();
    try {
      await ensureAttached(tabId); // never start an attempt on a dead session
      const sent = await sendPromptOnce(tabId, item, sendCtx);
      item.sentAt = sent.sentAt || Date.now(); // v2.6: ETA cycle input
      save();
      // Tile-based completion wait (240s cap; error tiles handled via
      // their Retry button inside the wait).
      const wopts = {
        busySeen: sent.busySeen, sentAt: sent.sentAt,
        count: clampGenCount(S.settings && S.settings.genCount),
        wantKind: (S.settings && S.settings.genType) === 'video' ? 'video' : 'image'
      };
      // v2.6.2 Prompt-check (serial): the finished tile must prove it
      // belongs to this item — its viewer prompt is read and matched
      // against everything sent so far. A late leftover from an
      // earlier item is downloaded under THAT item instead; a tile
      // matching nothing sent is consumed as foreign; an unreadable
      // tile is re-checked and accepted on order after 3 rounds.
      if ((S.settings && S.settings.matchMode) === 'prompt') {
        wopts.verifyTile = async (tile) => {
          const rd = await readTilePromptText(tabId, tile.mediaId);
          if (!rd.ok) {
            const n = (verifyRounds.get(tile.mediaId) || 0) + 1;
            verifyRounds.set(tile.mediaId, n);
            if (n >= 3) {
              elog(item.id + ': ! Prompt check: tile er prompt pora jay ni — order dhorei neowa holo');
              return { action: 'accept' };
            }
            return { action: 'exclude' }; // not consumed — re-checked next poll
          }
          const others = S.items.filter((it) => it.id !== item.id && !it.tileMediaId && ((it.sentAt || 0) > 0 || (it.attempts || 0) > 0) && it.status !== 'pending');
          const v = serialTileVerdict(rd.text, item, others);
          if (v.kind === 'current') {
            elog(item.id + ': Prompt check ✓ — tile er prompt mileche (' + v.how + ')');
            return { action: 'accept' };
          }
          if (v.kind === 'other') {
            const other = S.items.find((it) => it.id === v.itemId);
            elog(item.id + ': Prompt check — tile ta ' + v.itemId + ' er (late leftover), or name ei jabe');
            return { action: 'reassign', item: other };
          }
          if (!Array.isArray(S.consumedTiles)) S.consumedTiles = [];
          if (tile.mediaId && !S.consumedTiles.includes(tile.mediaId)) S.consumedTiles.push(tile.mediaId);
          elog(item.id + ': Prompt check — tile ta pathano kono prompt er na, bad deowa holo');
          save();
          return { action: 'exclude' };
        };
        wopts.onReassign = async (tile, other) => {
          if (!Array.isArray(S.consumedTiles)) S.consumedTiles = [];
          if (tile.mediaId && !S.consumedTiles.includes(tile.mediaId)) S.consumedTiles.push(tile.mediaId);
          if (other && !other.tileMediaId && other.status !== 'done' && other.status !== 'generated') {
            try {
              const outcome = await completeItem(tabId, other, tile, '');
              const term = terminalStatusFor(outcome);
              other.status = term;
              other.stage = term;
              other.failReason = '';
              noteItemCycle(other);
              elog(other.id + ': late tile eshe poucheche — download hoye gelo (' + term + ')');
            } catch (e) {
              elog(other.id + ': late tile download e badha (' + (e && e.message ? e.message : String(e)) + ')');
            }
          }
          save();
        };
      }
      const comp = await waitForCompletion(tabId, sent.snap, item, wopts);
      item.stage = 'downloading';
      save();
      if (comp.tile) {
        // v2.6: record every consumed tile (result + count extras) so
        // no later item can ever match them.
        if (!Array.isArray(S.consumedTiles)) S.consumedTiles = [];
        if (comp.tile.mediaId && !S.consumedTiles.includes(comp.tile.mediaId)) S.consumedTiles.push(comp.tile.mediaId);
        if (comp.extras && comp.extras.length) {
          for (const ex of comp.extras) if (ex.mediaId && !S.consumedTiles.includes(ex.mediaId)) S.consumedTiles.push(ex.mediaId);
          if (S.consumedTiles.length > 600) S.consumedTiles = S.consumedTiles.slice(-600);
          if (!item.extraNoted) {
            item.extraNoted = true;
            elog(item.id + ': extra ' + comp.extras.length + ' ta image skip kora holo (Count x' + clampGenCount(S.settings && S.settings.genCount) + ' — prothom tai download hobe)');
          }
        }
        save();
        return await completeItem(tabId, item, comp.tile, '');
      }
      // v3: NO busy-cycle rescue. The old fallback downloaded "the
      // newest tile" or a scan URL on suspicion - exactly the class of
      // guess that misnumbers downloads. No proven tile = honest fail;
      // the item retries and a late row can still revive it by prompt.
      const err = new Error('image khuje pai ni — report pathao');
      err.finalReason = 'image khuje pai ni — report pathao';
      throw err;
    } catch (e) {
      if (e === ABORT) throw e;
      // v3: an unusual-activity cooldown is a SESSION signal, not an
      // item failure - the attempt is refunded and the run waits out
      // an escalating cooldown (60s, doubling, cap 300s).
      if (e && e.cooldown) {
        item.attempts = Math.max(0, (item.attempts || 1) - 1);
        attempt--;
        item.cooldowns = (item.cooldowns || 0) + 1;
        if (item.cooldowns <= 3) {
          S.cooldownLevel = Math.min(4, (S.cooldownLevel || 0) + 1);
          const waitMs = Math.min(300000, 60000 * Math.pow(2, S.cooldownLevel - 1));
          S.cooldownUntil = Date.now() + waitMs;
          elog(item.id + ': Flow unusual activity - ' + Math.round(waitMs / 1000) + 's cooldown, attempt khoroch holo na');
          save();
          const until = S.cooldownUntil;
          while (Date.now() < until) { if (stopRequested) throw ABORT; await sleepOrStop(Math.min(5000, until - Date.now())); }
          continue;
        }
        elog(item.id + ': bar bar unusual activity - ei attempt ta normal fail hishebe gelo');
      }
      // v3: a daily-limit signal stops the whole run cleanly.
      if (e && e.stopRun) {
        stopRequested = true;
        e.finalReason = e.message;
        throw e;
      }
      lastError = e;
      elog(item.id + ': attempt ' + attempt + ' fail — ' + e.message);
      if (e.finalReason) {
        // v2.1: picker attach failures are usually transient (picker
        // timing/render) — they may consume up to 2 attempts with the
        // standard backoff before the item is marked FAILED. They used
        // to die at attempts=1 because attach marks them final.
        const PICKER_FAIL_PREFIXES = ['picker e reference khuje pai ni', 'picker khule ni', 'picker khola jay ni', 'reference add hoy ni'];
        const isPickerFail = PICKER_FAIL_PREFIXES.some((p) => e.finalReason.indexOf(p) === 0);
        if (!isPickerFail || attempt >= 2) throw e; // fail fast: reason is final for this item
        elog(item.id + ': picker attach fail — 2 attempt porjonto try hobe (ekhon ' + attempt + '/2), 15s por abar try hobe');
      }
      if (attempt < 3) {
        elog(item.id + ': 15s por abar try hobe');
        await sleepOrStop(15000); // v2.3: Stop cuts the backoff short instantly
      }
    }
  }
  throw lastError || new Error('Unknown failure');
}

/* ---------------- report ---------------- */
function buildReport() {
  const c = counts();
  const lines = [];
  lines.push('SHEIKH Flow Auto — Run Report');
  lines.push('Project: ' + (S.project || '(unnamed)'));
  lines.push('Date: ' + new Date().toLocaleString());
  lines.push('Started: ' + (S.runStartedAt ? new Date(S.runStartedAt).toLocaleString() : '-'));
  lines.push('Finished: ' + (S.runFinishedAt ? new Date(S.runFinishedAt).toLocaleString() : '-'));
  lines.push('Total: ' + c.total + ' | Done: ' + c.done + ' | Failed: ' + c.failed + ' | Pending: ' + c.pending + (c.generated ? ' | Generated (not downloaded): ' + c.generated : ''));
  lines.push('Download settings: quality ' + ((S.settings && S.settings.quality) || '1K') + ', auto-download ' + (S.settings && S.settings.autoDownload === false ? 'OFF (Download Later)' : 'ON') + ', folder ' + runFolderName() + ', run mode ' + ((S.settings && S.settings.runMode) || 'serial') + ', gen ' + ((S.settings && S.settings.genType) || 'image') + '/' + ((S.settings && S.settings.genModel) || '') + '/' + ((S.settings && S.settings.genRatio) || '') + '/x' + clampGenCount(S.settings && S.settings.genCount) + ', match ' + ((S.settings && S.settings.matchMode) || 'prompt'));
  const failedIds = S.items.filter((i) => i.status === 'failed').map((i) => i.id);
  lines.push('Failed IDs: ' + (failedIds.length ? failedIds.join(', ') : 'none'));
  lines.push('');
  const failedItems = S.items.filter((i) => i.status === 'failed');
  if (failedItems.length) {
    lines.push('Failed items (reason shoho):');
    for (const it of failedItems) lines.push(it.id + ' — ' + (it.failReason || it.note || 'reason jana nai'));
    lines.push('');
  }
  lines.push('Per-item status:');
  for (const it of S.items) {
    lines.push(it.id + '  ' + it.status + (it.attempts ? '  attempts=' + it.attempts : '') + (it.stage ? '  stage=' + it.stage : '') + (it.failReason ? '  failReason=' + it.failReason : '') + (it.note ? '  note=' + it.note : ''));
  }
  lines.push('');
  lines.push('--- Engine log (last 40) — diagnosis er jonno Bby ke pathiye dilei hobe ---');
  const engineLines = S.log.filter((l) => l.indexOf('[engine]') === 0);
  const tail = (engineLines.length ? engineLines : S.log).slice(-40);
  for (const l of tail) lines.push(l);
  return lines.join('\n');
}
async function downloadReportFile() {
  try {
    const url = 'data:text/plain;charset=utf-8,' + encodeURIComponent(S.lastReport || buildReport());
    await downloadsDownload({ url, filename: 'SHEIKH Flow Auto/' + runFolderName() + '/run-report.txt', saveAs: false });
  } catch (e) { /* panel button is the reliable path */ }
}

/* ---------------- run loop ---------------- */
async function parkWhilePaused(tabId) {
  if (!pauseRequested) return false; // returns true if we parked
  S.paused = true;
  elog('Engine: pause dhora hoyeche — debugger detach kore opekkha korchi');
  await dbgDetach(tabId);
  saveNow();
  while (pauseRequested && !stopRequested) {
    beat();
    try { await sleepOrStop(500); } catch (e) { if (e !== ABORT) throw e; break; }
  }
  S.paused = false;
  save();
  if (stopRequested) return true;
  await dbgAttach(tabId);
  elog('Engine: resume — debugger abar attach OK');
  return true;
}

/* v2.3 — force-reset a wedged run (start/resume handlers call this
 * when the loop flag is on but the heartbeat is >20s stale). The old
 * loop is invalidated by generation and woken by the epoch bump, so
 * its waits throw ABORT and its finally skips cleanup; every page
 * call it might be parked inside now carries the 8s CDP timeout, so
 * it unwinds fast and never touches the new run's items. */
function forceResetRun() {
  runGen++;
  bumpAbortEpoch();
  loopActive = false;
  pauseRequested = false;
  stopRequested = false;
  S.running = false;
  S.paused = false;
  for (const it of S.items) if (it.status === 'active') { it.status = 'pending'; it.stage = ''; }
}

/* ---------------- v3 paced loop ----------------
 * Sends go out one by one at the configured interval (minimum gap
 * between SENDS) WITHOUT waiting for each generation to finish. The
 * watcher attributes finished generations by their CATALOG PROMPT
 * (pickAttributions over the project listing) - content-true and
 * order-independent, so failures and retries interleaving with later
 * sends can never shift a number. Error tiles are classified, never
 * charged by position: unusual-activity triggers an escalating send
 * cooldown, a daily limit stops the run, and a generic failure is
 * resolved by elimination (the send that produced no catalog row
 * fails on its own 240s timeout and is re-sent first). Prompt-less
 * rows fall down the ladder: viewer verify (prompt mode) ->
 * exclusivity (fast mode) -> park (re-examined every pass). */

/* v3 - parked rows stay re-examinable: a row parked as unclaimed is
 * excluded from normal candidates (it sits in consumedTiles) but is
 * offered again here every pass - when its true owner is (re)sent, a
 * prompt match can still claim it. Identity exclusions always apply. */
function candidateRowsWithParked(cat) {
  const base = attributionCandidates(cat);
  const parked = new Set(S.unclaimedUuids || []);
  if (!parked.size || !cat || !Array.isArray(cat.media)) return base;
  const have = new Set(base.map((r) => r.uuid));
  const refs = new Set(S.refMediaIds || []);
  if (S.refMediaId) refs.add(S.refMediaId);
  const extra = cat.media.filter((r) => r && r.origin === 'generated' && parked.has(r.uuid) && !have.has(r.uuid) && !refs.has(r.uuid));
  return base.concat(extra);
}
function parkUuid(uuid) {
  if (!uuid) return;
  if (!Array.isArray(S.consumedTiles)) S.consumedTiles = [];
  if (!S.consumedTiles.includes(uuid)) S.consumedTiles.push(uuid);
  if (!Array.isArray(S.unclaimedUuids)) S.unclaimedUuids = [];
  if (!S.unclaimedUuids.includes(uuid)) S.unclaimedUuids.push(uuid);
}
function unparkUuid(uuid) {
  if (!uuid || !Array.isArray(S.unclaimedUuids)) return;
  const ix = S.unclaimedUuids.indexOf(uuid);
  if (ix >= 0) S.unclaimedUuids.splice(ix, 1);
}
/* v3 - late-leftover revival (paced): rows whose catalog prompt
 * belongs to an already-FAILED item complete THAT item under its own
 * number. Returns the rows that remain for the pending sends. */
async function reviveFailedFromRows(tabId, rows) {
  if (!rows || !rows.length) return rows || [];
  const failed = (S.items || []).filter((it) => it.status === 'failed' && !it.tileMediaId && (it.sentPrompt || it.prompt));
  if (!failed.length) return rows;
  const res = pickAttributions(rows, failed.map((f) => ({ id: f.id, prompt: f.sentPrompt || f.prompt, got: 0, quota: 1 })));
  if (!res.assign.length) return rows;
  const used = new Set();
  for (const a of res.assign) {
    if (a.extra) continue;
    const item = failed.find((f) => f.id === a.itemId);
    if (!item) continue;
    try {
      const tile = await resolveCatalogTile(tabId, a.uuid, a.kind);
      const outcome = await completeItem(tabId, item, tile, '');
      const term = terminalStatusFor(outcome);
      item.status = term;
      item.stage = term;
      item.failReason = '';
      if (!Array.isArray(S.consumedTiles)) S.consumedTiles = [];
      if (!S.consumedTiles.includes(a.uuid)) S.consumedTiles.push(a.uuid);
      unparkUuid(a.uuid);
      used.add(a.uuid);
      elog(item.id + ': late tile eshe poucheche - download hoye gelo (' + term + ')');
    } catch (e) {
      elog(item.id + ': late tile download e badha (' + (e && e.message ? e.message : String(e)) + ')');
    }
  }
  if (used.size) save();
  return rows.filter((r) => !used.has(r.uuid));
}
const pacedViewerRounds = new Map(); // uuid -> failed viewer reads (paced backlog)
/* v3 - ONE prompt-less row per paced pass (the viewer backlog never
 * blocks sends). Returns true when the pass's backlog slot was used. */
async function pacedUnverifiedRow(tabId, row, pending, promptMode, gotById, genCount) {
  const attributeTo = (item, how) => {
    unparkUuid(row.uuid);
    if (item.quotaUuid) {
      if (!Array.isArray(S.consumedTiles)) S.consumedTiles = [];
      if (!S.consumedTiles.includes(row.uuid)) S.consumedTiles.push(row.uuid);
      if (!item.extraNoted) { item.extraNoted = true; elog(item.id + ': extra image skip kora holo (Count x' + genCount + ')'); }
    } else {
      item.quotaUuid = row.uuid;
      item.tileGot = (item.tileGot || 0) + 1;
      gotById[item.id] = item.tileGot;
    }
    elog(item.id + ': tile neowa holo (' + how + ')');
    return true;
  };
  if (promptMode) {
    const n = (pacedViewerRounds.get(row.uuid) || 0) + 1;
    pacedViewerRounds.set(row.uuid, n);
    if (n > 3) { parkUuid(row.uuid); return true; }
    await resolveCatalogTile(tabId, row.uuid, row.kind);
    // v3.0.1: twice-read (locate->click grid-shift guard) — a single
    // read can return the neighbour tile's prompt and pin this row
    // to the wrong item (sim-proven wrong-content download).
    const rd = await readTilePromptTwice(tabId, row.uuid);
    if (!rd || !rd.ok) return true; // backlog slot spent; retried next passes
    const hit = matchPromptToItems(rd.text, pending.map((p) => ({ id: p.id, prompt: p.sentPrompt || p.prompt })));
    if (hit && hit.itemId) {
      const item = pending.find((p) => p.id === hit.itemId);
      if (item) { elog(item.id + ': Prompt check (viewer) ✓ - prompt mileche (' + hit.how + ')'); return attributeTo(item, 'viewer prompt'); }
    }
    const failedHit = matchPromptToItems(rd.text, (S.items || []).filter((it) => it.status === 'failed' && !it.tileMediaId).map((it) => ({ id: it.id, prompt: it.sentPrompt || it.prompt })));
    if (failedHit && failedHit.itemId) {
      await reviveFailedFromRows(tabId, [Object.assign({}, row, { prompt: rd.text })]);
      return true;
    }
    elog('Paced: ekta tile pathano kono prompt er na - park kora holo');
    parkUuid(row.uuid);
    return true;
  }
  // fast mode: exclusivity only - exactly one outstanding send and the
  // row was created at/after it. Otherwise the row waits (pending may
  // drain to one) or is parked once it predates every live send.
  if (pending.length === 1 && row.createdAt && pending[0].sentAt && row.createdAt >= pending[0].sentAt - 5000) {
    return attributeTo(pending[0], 'ekmatro outstanding send');
  }
  if (pending.length && row.createdAt && pending.every((p) => p.sentAt && row.createdAt < p.sentAt - 5000)) {
    parkUuid(row.uuid);
    return true;
  }
  return false;
}

/* v3.0.1 — the DOM ladder (paced): the safety net under the truth
 * layer. The V3 watcher attributed ONLY through the project listing;
 * when the listing is dead, prompt-less, or its rows never become
 * candidates (baseline missed at run start + unparseable createTime
 * => createdAt 0 => filtered out), NO paced path could assign a
 * finished tile: sends ran, generations finished, zero downloads,
 * zero log lines (Amin's run-report-4; reproduced in
 * tests/repro-catalog.js for all three states). This ladder works
 * off the DOM tiles the watcher already scans every pass: a finished
 * tile that stays unassigned for 3 watcher polls escalates — viewer
 * verify against the outstanding sends (the existing prompt
 * matching), then exclusivity (exactly one outstanding send predates
 * the tile), then park WITH a log line (never silence). It runs
 * whatever the catalog state, after the catalog step, and claims
 * through the same quotaUuid funnel the completion sweep drains.
 * Escalation is one tile per pass while the catalog is assigning
 * (the backlog discipline); when the catalog assigned nothing, the
 * ladder is the only drain and may escalate two. Every viewer claim
 * goes through readTilePromptTwice (the locate->click grid-shift
 * guard). */
const domTileWatch = new Map(); // mediaId -> { polls, firstSeen }
const domViewerRounds = new Map(); // mediaId -> viewer attempts
const domClaimedUuids = new Set(); // uuids claimed via the DOM ladder (kept out of the catalog path)
const domPromptlessUuids = new Set(); // v3.0.1: tiles whose viewer ever opened prompt-less — barred from exclusivity
const domGenSeenUuids = new Set(); // v3.0.1: tiles seen GENERATING (hasPct) during this run — the only tiles exclusivity may claim
let ladderBacklog = 0; // v3.0.1: unassigned finished tiles the ladder has not processed yet (last pass)
async function pacedDomLadder(tabId, tiles, pending, genCount, wantKind, catalogAssigned) {
  if (!tiles || !tiles.length || !pending.length) return;
  // v3.0.1: remember every tile ever seen generating this run. An
  // upload appears in the grid already finished and is never seen
  // with a progress %, so this set is the structural line between
  // "a generation result" and "an asset that was always there" —
  // the prompt-less bar alone cannot draw it (a prompt-less viewer
  // and a never-opened viewer look alike until the overlay marker).
  for (const t of tiles) if (t && t.mediaId && t.hasPct) domGenSeenUuids.add(t.mediaId);
  const baseIds = new Set((S.pacedBase && S.pacedBase.ids) || []);
  const refIds = new Set(S.refMediaIds || []);
  if (S.refMediaId) refIds.add(S.refMediaId);
  const consumed = new Set(S.consumedTiles || []);
  const claimed = new Set();
  for (const p of pending) if (p.quotaUuid) claimed.add(p.quotaUuid);
  for (const it of S.items || []) if (it.tileMediaId) claimed.add(it.tileMediaId);
  const cands = [];
  for (const t of tiles) {
    if (!t || !t.mediaId || t.kind !== wantKind || t.hasPct || !t.hasThumb) continue;
    const id = t.mediaId;
    if (baseIds.has(id) || refIds.has(id) || consumed.has(id) || claimed.has(id) || domClaimedUuids.has(id)) continue;
    let w = domTileWatch.get(id);
    if (!w) { w = { polls: 0, firstSeen: Date.now() }; domTileWatch.set(id, w); }
    w.polls++;
    // with a live catalog the tile waits 3 polls (the listing gets
    // first chance — it is the truth layer); with NO catalog there
    // is nothing to wait for, so 2 polls of stability suffice.
    if (w.polls >= (S.catalogOk ? 3 : 2)) cands.push({ tile: t, w: w });
  }
  if (domTileWatch.size > 400) {
    const alive = new Set(tiles.map((t) => t && t.mediaId).filter(Boolean));
    for (const k of Array.from(domTileWatch.keys())) if (!alive.has(k)) domTileWatch.delete(k);
  }
  ladderBacklog = domTileWatch.size; // watched, not yet claimed/parked
  if (!cands.length) return;
  cands.sort((a, b) => a.w.firstSeen - b.w.firstSeen);
  // Throughput: when the catalog step assigned nothing this pass
  // (dead / prompt-less / candidate-less listing), the ladder is the
  // only drain — it may escalate a second tile, and a third when a
  // real backlog is waiting (an upload flood must not starve the
  // items whose tiles sit behind it). When the catalog is working,
  // one escalation per pass stays the discipline.
  const maxEsc = catalogAssigned ? 1 : (cands.length >= 6 ? 3 : 2);
  let escUsed = 0;
  for (const cand of cands) {
    if (escUsed >= maxEsc) break;
    escUsed++;
    await escalateDomTile(tabId, cand.tile, pending, genCount, wantKind, escUsed === 1);
  }
}
async function escalateDomTile(tabId, tile, pending, genCount, wantKind, allowExclusivity) {
  const mediaId = tile.mediaId;
  const attributeDom = (item, how) => {
    domClaimedUuids.add(mediaId);
    domTileWatch.delete(mediaId);
    if (item.quotaUuid) {
      if (!Array.isArray(S.consumedTiles)) S.consumedTiles = [];
      if (!S.consumedTiles.includes(mediaId)) S.consumedTiles.push(mediaId);
      if (!item.extraNoted) { item.extraNoted = true; elog(item.id + ': extra image skip kora holo (Count x' + genCount + ')'); }
    } else {
      item.quotaUuid = mediaId;
      item.tileGot = (item.tileGot || 0) + 1;
    }
    elog(item.id + ': tile neowa holo (' + how + ', DOM ladder)');
    save();
  };
  // 1) viewer verify — the tile's own prompt against the sends,
  // read TWICE (locate->click grid-shift guard).
  const rounds = domViewerRounds.get(mediaId) || 0;
  if (rounds < 3) {
    domViewerRounds.set(mediaId, rounds + 1);
    const rd = await readTilePromptTwice(tabId, mediaId);
    if (rd && rd.sawNoPrompt) domPromptlessUuids.add(mediaId);
    if (rd && rd.noPrompt) {
      elog('Paced: DOM ladder - ekta tile e kono prompt nai (upload hote pare), park kora holo');
      parkUuid(mediaId);
      domTileWatch.delete(mediaId);
      return;
    }
    if (rd && rd.ok) {
      const hit = matchPromptToItems(rd.text, pending.map((p) => ({ id: p.id, prompt: p.sentPrompt || p.prompt })));
      if (hit && hit.itemId) {
        const item = pending.find((p) => p.id === hit.itemId);
        if (item) { elog(item.id + ': Prompt check (viewer, DOM ladder) ✓ - prompt mileche (' + hit.how + ')'); attributeDom(item, 'viewer prompt'); return; }
      }
      const failedHit = matchPromptToItems(rd.text, (S.items || []).filter((it) => it.status === 'failed' && !it.tileMediaId).map((it) => ({ id: it.id, prompt: it.sentPrompt || it.prompt })));
      if (failedHit && failedHit.itemId) {
        await reviveFailedFromRows(tabId, [{ uuid: mediaId, prompt: rd.text, kind: wantKind, createdAt: 0 }]);
        domClaimedUuids.add(mediaId);
        domTileWatch.delete(mediaId);
        return;
      }
      elog('Paced: DOM ladder - ekta tile pathano kono prompt er na, park kora holo');
      parkUuid(mediaId);
      domTileWatch.delete(mediaId);
      return;
    }
    return; // unreadable / shift-suspect this pass — retried until the rounds run out
  }
  // 2) exclusivity — exactly one outstanding send predates the tile
  // (first escalation of the pass only: it is a guess, never
  // stacked, and NEVER for a tile that ever opened prompt-less —
  // that tile is an upload, not a generation — and NEVER for a tile
  // that was never seen generating this run: a flood upload that
  // appears mid-run already finished must not be claimed just
  // because one send happens to be outstanding; sim-proven wrong
  // download before this guard).
  const w = domTileWatch.get(mediaId);
  if (allowExclusivity && domGenSeenUuids.has(mediaId) && !domPromptlessUuids.has(mediaId) && pending.length === 1 && pending[0].sentAt && w && w.firstSeen >= pending[0].sentAt - 5000) {
    attributeDom(pending[0], 'ekmatro outstanding send');
    return;
  }
  // 3) park — with a log line, never in silence. The uuid stays
  // re-examinable through the catalog path (unclaimedUuids).
  elog('Paced: DOM ladder - tile ta kono send er sathe milano gelo na, park kora holo (mediaId=' + mediaId + ')');
  parkUuid(mediaId);
  domTileWatch.delete(mediaId);
}

async function runPacedLoop(tabId, gen) {
  const epoch = abortEpoch;
  const TIMEOUT_MS = 240000;
  const baseTiles = await evalFn(tabId, sfaTiles).catch(() => null) || [];
  if (!(S.pacedBase && S.pacedBase.at === S.runStartedAt && Array.isArray(S.pacedBase.ids))) {
    S.pacedBase = { at: S.runStartedAt, ids: baseTiles.map((t) => t.mediaId).filter(Boolean) };
    save();
  }
  // v3: error tiles are tracked by tile key - a NEW error tile is a
  // classification event, never an order-based charge (see WATCH).
  const errSeenKeys = new Set(baseTiles.filter((t) => t.kind === 'error').map((t) => t.key));
  const sendQueue = S.items.filter((i) => i.status === 'pending');
  const retryQueue = [];
  const pending = S.items.filter((i) => i.status === 'active' && !i.tileMediaId);
  let inFlight = null; // item inside sendPromptOnce right now (in no queue)
  for (const p of pending) if (!p.sentAt) p.sentAt = Date.now();
  elog('Paced mode shuru — interval ' + clampIntervalSec(S.settings && S.settings.intervalSec) + 's, pathano baki ' + sendQueue.length + ', age theke opekkha ' + pending.length);

  const markFailed = async (item, reason) => {
    item.status = 'failed';
    item.stage = 'failed';
    item.note = reason;
    item.failReason = reason;
    elog(item.id + ': FAILED — ' + reason);
    await screenshotError(tabId, sanitizeProject(S.project), item.id).catch(() => {});
    saveNow();
  };
  const failAttempt = async (item, reason) => {
    const ix = pending.indexOf(item);
    if (ix >= 0) pending.splice(ix, 1);
    if ((item.attempts || 0) < 3) {
      item.tileMediaId = null;
      item.tileUrl = '';
      item.quotaTile = null; // v2.6: partial count quota restarts with the resend
      item.quotaUuid = null; // v3: catalog primary pointer
      item.tileGot = 0;
      item.sentAt = 0;
      item.status = 'active';
      item.stage = 'resend hobe';
      retryQueue.unshift(item);
      elog(item.id + ': attempt fail (' + reason + ') — resend queue r age jabe (send ' + (item.attempts || 0) + '/3)');
      saveNow();
    } else {
      await markFailed(item, reason);
    }
  };

  // v3 match modes: 'prompt' (default) adds the viewer step of the
  // fallback ladder for prompt-less rows; 'fast' skips it. BOTH modes
  // attribute by catalog prompt - FIFO pairing and the freeze-drain-
  // repair machine are deleted (order is not evidence).
  const matchMode = (S.settings && S.settings.matchMode) === 'fast' ? 'fast' : 'prompt';
  elog('Paced match mode: ' + (matchMode === 'fast' ? 'Fast order (catalog prompt, viewer chara)' : 'Prompt check (catalog prompt + viewer)'));

  try {
    while (true) {
      if (stopRequested || S.watchdogUnwind || gen !== runGen || epoch !== abortEpoch) break;
      if (await parkWhilePaused(tabId)) {
        if (stopRequested) break;
        await ensureAttached(tabId).catch(() => {});
      }
      if (stopRequested || gen !== runGen || epoch !== abortEpoch) break;
      beat();

      // ---- SEND: next item once the send gap has elapsed ----
      const nextItem = (S.cooldownUntil && Date.now() < S.cooldownUntil) ? null : (retryQueue[0] || sendQueue[0]);
      if (nextItem) {
        const gapMs = clampIntervalSec(S.settings && S.settings.intervalSec) * 1000;
        const last = S.lastSendAt || 0;
        if (!last || Date.now() - last >= gapMs) {
          const item = retryQueue.length ? retryQueue.shift() : sendQueue.shift();
          item.status = 'active';
          item.stage = 'shuru hocche';
          item.failReason = '';
          item.attempts = (item.attempts || 0) + 1;
          saveNow();
          elog(item.id + ': paced send hocche (send ' + item.attempts + '/3)');
          inFlight = item;
          try {
            await ensureAttached(tabId);
            const sent = await sendPromptOnce(tabId, item, { typeFails: 0 }, { enforceGap: false });
            item.sentAt = sent.sentAt || Date.now();
            item.stage = 'waiting';
            pending.push(item);
            saveNow();
          } catch (e) {
            if (e === ABORT) throw e;
            await failAttempt(item, (e && (e.finalReason || e.message)) || String(e));
          } finally {
            inFlight = null;
          }
        }
      }

      // ---- WATCH (v3): attribution by the LISTING, errors by the DOM ----
      // Finished generations are matched to sends by their catalog
      // prompt (pickAttributions) - never by finish order, so a failed
      // send and its retry interleaving with later sends cannot shift
      // a single number. Error tiles (which produce no catalog row)
      // are only CLASSIFIED: unusual-activity starts a cooldown that
      // charges nobody, a daily limit stops the run, a generic error
      // is resolved by elimination (the send that produced no row
      // fails on its own 240s timeout).
      // v3.0.1: under the listing sits the DOM ladder (pacedDomLadder)
      // — if the listing is dead, prompt-less, or candidate-less, DOM
      // tiles escalate viewer -> exclusivity -> park, so a finished
      // generation can never again sit unassigned in total silence.
      {
        const wantKindP = (S.settings && S.settings.genType) === 'video' ? 'video' : 'image';
        const genCountP = clampGenCount(S.settings && S.settings.genCount);
        let tilesP = null;
        try { tilesP = await evalFn(tabId, sfaTiles); } catch (e) { tilesP = null; }
        if (tilesP) {
          for (const et of tilesP) {
            if (et.kind !== 'error' || errSeenKeys.has(et.key)) continue;
            errSeenKeys.add(et.key);
            const cls = classifyErrorText(et.text || et.label || '');
            if (cls === 'unusual') {
              S.cooldownLevel = Math.min(4, (S.cooldownLevel || 0) + 1);
              const waitMs = Math.min(300000, 60000 * Math.pow(2, S.cooldownLevel - 1));
              S.cooldownUntil = Date.now() + waitMs;
              elog('Paced: Flow unusual activity - ' + Math.round(waitMs / 1000) + 's cooldown (karo attempt khoroch holo na)');
              save();
            } else if (cls === 'limit') {
              elog('Paced: Flow daily limit - run thamano hocche');
              stopRequested = true;
            } else {
              elog('Paced: notun error tile - kon item er ta elimination diye bujhbo (order diye kokhono na)');
            }
          }
        }
        const catP = await fetchCatalog(tabId).catch(() => null);
        let catAssigned = 0;
        if (catP) {
          // v3.0.1: rows the DOM ladder already claimed (or that are
          // an item's recorded primary) stay out of the catalog path —
          // one tile can never complete two items.
          const rowsAll = candidateRowsWithParked(catP).filter((r) => r.kind === wantKindP && !domClaimedUuids.has(r.uuid) && !(r.uuid && pending.some((p) => p.quotaUuid === r.uuid)));
          // late leftovers first: a row whose prompt belongs to a
          // FAILED item revives that item under its own number.
          const rowsLeft = await reviveFailedFromRows(tabId, rowsAll);
          if (pending.length) {
            const sends = pending.map((p) => ({ id: p.id, prompt: p.sentPrompt || p.prompt, got: p.tileGot || 0, quota: genCountP }));
            const res = pickAttributions(rowsLeft, sends);
            const gotById = {};
            for (const s of res.sends) gotById[s.id] = s.got;
            const primaryById = {};
            for (const a of res.assign) {
              unparkUuid(a.uuid);
              if (a.extra) {
                if (!Array.isArray(S.consumedTiles)) S.consumedTiles = [];
                if (!S.consumedTiles.includes(a.uuid)) S.consumedTiles.push(a.uuid);
                const owner = pending.find((p) => p.id === a.itemId);
                if (owner && !owner.extraNoted) {
                  owner.extraNoted = true;
                  elog(owner.id + ': extra image skip kora holo (Count x' + genCountP + ' - prothom tai download hobe)');
                }
              } else if (!primaryById[a.itemId]) {
                primaryById[a.itemId] = a;
              }
            }
            for (const p of pending) {
              if (gotById[p.id] !== undefined) p.tileGot = gotById[p.id];
              if (primaryById[p.id] && !p.quotaUuid) p.quotaUuid = primaryById[p.id].uuid;
            }
            // prompt-less rows: viewer backlog (prompt mode) or
            // exclusivity (fast mode), at most one tile per pass.
            for (const row of res.unverified) {
              if (row.prompt) continue;
              const doneRow = await pacedUnverifiedRow(tabId, row, pending, matchMode === 'prompt', gotById, genCountP);
              if (doneRow) break;
            }
            for (const p of pending) if (gotById[p.id] !== undefined) p.tileGot = gotById[p.id];
            catAssigned = res.assign.length;
            if (res.assign.length) save();
          }
        }
        // completions FIRST: quota filled and a primary tile
        // recorded — v3.0.1: hoisted out of the catalog block, and
        // deliberately BEFORE the DOM ladder: a claimed tile's
        // download must never wait behind ladder viewer reads (the
        // sim's reference-sink flood starved exactly one download
        // that way — the grid churns finished tiles out of the
        // virtualized window while the ladder is busy).
        for (const item of pending.slice()) {
          if (!item.quotaUuid || (item.tileGot || 0) < genCountP) continue;
          pending.splice(pending.indexOf(item), 1);
          const uuid = item.quotaUuid;
          item.quotaUuid = null;
          item.tileGot = 0;
          item.stage = 'downloading';
          save();
          try {
            const tile = await resolveCatalogTile(tabId, uuid, wantKindP);
            const outcome = await completeItem(tabId, item, tile, '');
            const term = terminalStatusFor(outcome);
            item.status = term;
            item.stage = term;
            item.failReason = '';
            if (term === 'generated') {
              elog(item.id + ': generated - image ready, download baki (Download Later)');
            } else {
              item.note = (outcome && outcome.note) || '';
              elog(item.id + ': done' + (item.note ? ' (' + item.note + ')' : ''));
            }
          } catch (e) {
            await failAttempt(item, (e && (e.finalReason || e.message)) || String(e));
          }
          saveNow();
        }
        // v3.0.1: the DOM ladder runs WHATEVER the catalog state —
        // with a dead / prompt-less / candidate-less listing it is
        // the only attribution path paced mode has. It runs AFTER
        // the completion sweep (claims download on the next pass).
        // It is a fallback: an error inside it must NEVER kill the
        // run (throttled log).
        try {
          await pacedDomLadder(tabId, tilesP, pending, genCountP, wantKindP, catAssigned);
        } catch (e) {
          const nowE = Date.now();
          if (!runPacedLoop._ladderErrAt || nowE - runPacedLoop._ladderErrAt > 60000) {
            runPacedLoop._ladderErrAt = nowE;
            elog('Paced: DOM ladder e somossha — ' + ((e && e.message) || e) + ' (run cholche, catalog path ache)');
          }
        }
        const nowMs = Date.now();
        for (const item of pending.slice()) {
          // fully claimed and only awaiting its download pass — the
          // elimination timeout must not kill it mid-claim.
          if (item.quotaUuid && (item.tileGot || 0) >= genCountP) continue;
          // v3.0.1: elimination is only sound once the watcher has
          // actually LOOKED at every finished tile. While the DOM
          // ladder still has unprocessed tiles queued (an upload
          // flood can bury real tiles behind dozens of prompt-less
          // ones), a timed-out item gets patience extensions —
          // capped, so a genuinely failed generation still fails.
          if (pacedIsTimedOut(item.sentAt, nowMs, TIMEOUT_MS) && nowMs > (item.timeoutBoostUntil || 0) && ladderBacklog > 0 && (item.ladderExtensions || 0) < 4) {
            item.ladderExtensions = (item.ladderExtensions || 0) + 1;
            item.timeoutBoostUntil = nowMs + 60000;
            if (!item.ladderExtLogged) { item.ladderExtLogged = true; elog(item.id + ': timeout barano holo — DOM ladder ekhono ' + ladderBacklog + ' ta tile process korche'); }
            continue;
          }
          if (pacedIsTimedOut(item.sentAt, nowMs, TIMEOUT_MS) && nowMs > (item.timeoutBoostUntil || 0)) {
            elog(item.id + ': paced timeout - 240s e kono tile ashe ni');
            await failAttempt(item, 'Timeout 240s — generation sesh hoyni');
          }
        }
      }

      if (!sendQueue.length && !retryQueue.length && !pending.length) break;
      await sleepOrStop(1500, epoch);
    }
  } catch (e) {
    if (e !== ABORT) throw e;
  }
  if (stopRequested || S.watchdogUnwind) {
    let back = 0;
    if (inFlight && inFlight.status === 'active') { inFlight.status = 'pending'; inFlight.stage = ''; inFlight.sentAt = 0; inFlight.quotaTile = null; inFlight.quotaUuid = null; inFlight.tileGot = 0; back++; }
    for (const item of pending) { item.status = 'pending'; item.stage = ''; item.sentAt = 0; item.quotaTile = null; item.quotaUuid = null; item.tileGot = 0; back++; }
    for (const item of retryQueue) { item.status = 'pending'; item.stage = ''; item.sentAt = 0; item.quotaTile = null; item.quotaUuid = null; item.tileGot = 0; back++; }
    if (back) elog('Paced: stop — ' + back + ' ta item pending e ferot gelo (Resume e abar jabe)');
    saveNow();
  }
}

/* v2.6 — apply the panel's generation options to Flow's composer at
 * run start (both run modes, after the reference gate, before the
 * first send). Drives the composer's own settings menu with the same
 * probe + real-click machinery as everything else: open the chip
 * menu, click Type / Model / Ratio / Count by visible text, close,
 * then READ BACK the composer chip text and verify. One short log
 * line per setting. NEVER throws and NEVER blocks the run — a setting
 * that cannot be applied just leaves Flow's current value in place. */
async function applyGenerationSettings(tabId) {
  const st = S.settings || {};
  const type = st.genType === 'video' ? 'video' : 'image';
  const model = st.genModel || genDefaultModel(type);
  const ratio = st.genRatio || '16:9';
  const count = clampGenCount(st.genCount);
  const steps = [
    { key: 'type', group: 'type', want: type === 'video' ? 'Video' : 'Image', label: 'Type: ' + (type === 'video' ? 'Video' : 'Image') },
    { key: 'model', group: 'model', want: model, label: 'Model: ' + model },
    { key: 'ratio', group: 'ratio', want: ratio, label: 'Ratio: ' + ratio },
    { key: 'count', group: 'count', want: 'x' + count, label: 'Count: x' + count }
  ];
  const results = {};
  try {
    let chip = await evalFn(tabId, sfaGenChip).catch(() => null);
    if (!chip || !chip.open) {
      elog('! Settings: composer chip paoa jay ni — Flow er current setting ei cholbe');
      return;
    }
    const readMenu = async () => (await evalFn(tabId, sfaGenMenu).catch(() => null));
    let menu = null;
    const ensureMenu = async () => {
      menu = await readMenu();
      if (menu && menu.open) return true;
      const c2 = await evalFn(tabId, sfaGenChip).catch(() => null);
      if (!c2 || !c2.open) return false;
      // v2.6.1: every settings click is containment-guarded (the
      // chip must prove it is in the composer / an open overlay, and
      // never in the media grid).
      const okClick = await guardedClick(tabId, c2.open.x, c2.open.y, 'composerOrOverlay');
      if (!okClick) return false;
      await sleep(700);
      menu = await readMenu();
      return !!(menu && menu.open);
    };
    const chipClicked = await guardedClick(tabId, chip.open.x, chip.open.y, 'composerOrOverlay');
    if (!chipClicked) {
      elog('! Settings: chip click rokhha holo — Flow er current setting ei cholbe');
      return;
    }
    await sleep(800);
    menu = await readMenu();
    if (!menu || !menu.open) {
      elog('! Settings: menu khule ni — Flow er current setting ei cholbe');
      return;
    }
    for (const step of steps) {
      let applied = false;
      try {
        if (!menu || !menu.open) { if (!(await ensureMenu())) { results[step.key] = false; continue; } }
        const opts = (menu.options || []).filter((o) => o.group === step.group);
        const opt = pickGenOption(opts, step.want);
        if (opt) {
          if (opt.selected) applied = true;
          else {
            // v2.6.1: menu-option coordinates come from the broad
            // sfaGenMenu harvest — the click only happens if the
            // point provably sits in the composer / open overlay and
            // outside the media grid (see the audit notes).
            const optClicked = await guardedClick(tabId, opt.x, opt.y, 'composerOrOverlay');
            if (!optClicked) { results[step.key] = false; continue; }
            await sleep(600);
            applied = true;
            // Confirm via a fresh menu read when the menu survives.
            const m2 = await readMenu();
            if (m2 && m2.open) {
              menu = m2;
              const o2 = pickGenOption((m2.options || []).filter((o) => o.group === step.group), step.want);
              if (o2 && o2.selected === false) applied = false;
            } else {
              menu = m2;
            }
          }
        }
      } catch (e) { applied = false; }
      results[step.key] = applied;
    }
    await pressEscape(tabId).catch(() => {});
    await sleep(300);
    // v2.6.1: verify the settings menu actually CLOSED — a leftover
    // popover would intercept the reference paste / first-send clicks
    // that follow. One more Escape if it is still open.
    const leftover = await readMenu().catch(() => null);
    if (leftover && leftover.open) {
      await pressEscape(tabId).catch(() => {});
      await sleep(250);
    }
    // Read-back: the composer chip names the model and the count.
    chip = await evalFn(tabId, sfaGenChip).catch(() => null);
    if (chip && chip.text) {
      if (chipHasText(chip.text, model)) results.model = true;
      const cc = chipCountOf(chip.text);
      if (cc !== null) results.count = (cc === count);
    }
    for (const step of steps) {
      if (results[step.key]) elog('✓ Setting applied — ' + step.label);
      else elog('! Setting holo na — ' + step.label + ' (Flow er current tai cholbe)');
    }
  } catch (e) {
    elog('! Settings apply e badha (' + (e && e.message ? e.message : String(e)) + ') — run cholbe');
  }
}

async function runLoop() {
  if (loopActive) return;
  await loadState();
  loopActive = true;
  const myGen = ++runGen;
  stopRequested = false;
  S.running = true;
  S.paused = false;
  if (!S.runStartedAt) S.runStartedAt = Date.now();
  if (!S.runFolder) S.runFolder = sanitizeProject(S.project);
  startHeartbeat();
  startWatchdog();
  saveNow();

  let tab = null;
  try {
    tab = S.tabId ? await chrome.tabs.get(S.tabId).catch(() => null) : null;
    if (!tab || !tab.url || !FLOW_URL_RE.test(tab.url)) tab = await findFlowTab();
    if (!tab) { elog('ERROR: Flow tab paoa jay ni — run bondho'); return; }
    S.tabId = tab.id;
    // v3: pin the tab against Chrome Memory Saver - a discarded Flow
    // tab kills the debugger session and every wait with it.
    try { chrome.tabs.update(tab.id, { autoDiscardable: false }); } catch (e) { /* best effort */ }
    elog('Run shuru — project: ' + S.project + ', mot ' + S.items.length + ' item, tab ' + tab.id + ' (' + (tab.url || '') + ')');
    if (S.settings && S.settings.refMode && S.settings.refMode !== 'none' && !S.settings.refReady) {
      elog('SABDHAN: reference mode "' + S.settings.refMode + '" select chilo kintu clipboard e image jay ni — run REF CHARA cholbe');
    }
    try {
      await dbgAttach(tab.id);
      elog('Debugger attach OK (tab ' + tab.id + ')');
    } catch (e) {
      elog('ERROR: Debugger attach FAIL (' + e.message + ') — Flow tab e DevTools khola thakle bondho kore abar try koro.');
      return;
    }

    // v2.6.1 ORDER (Amin's explicit fix): generation settings FIRST,
    // reference upload SECOND. In V2.6 the settings menu was driven
    // AFTER the reference sheet had been uploaded — and that run lost
    // the sheet (Flow: "1 item moved to bin") before the first attach.
    // With settings first, no settings-menu clicking ever happens
    // while the reference exists in the project. This point is shared
    // by both run modes: the serial loop and runPacedLoop both start
    // below this sequence. Settings-apply is fail-soft as before.
    await applyGenerationSettings(tab.id);

    // v2.0: reference lifecycle BEFORE any generation — upload first
    // and once, gated on full upload completion (user rules 1-2). A
    // failed gate aborts the run start; nothing is generated.
    try {
      const refOk = await ensureReference(tab.id);
      if (!refOk) { elog('Run bondho — reference ready korte parini (uporer karon dekho)'); return; }
      // v2.6.1: survival verify right after the gate — if the asset
      // provably vanished again moments after uploading, restore it
      // ONCE via the re-upload path before any item depends on it.
      if (S.refMediaId) {
        const present = await refPresentInProject(tab.id).catch(() => true);
        if (!present) {
          const ok = await recoverReference(tab.id).catch(() => false);
          if (!ok) { elog('Run bondho — reference gate er poreo asset paoa gelo na'); return; }
        }
      }
    } catch (e) {
      if (e === ABORT) { elog('Run bondho — reference dhap e stop chaowa hoyeche'); return; }
      throw e;
    }

    // v3: attribution baseline - every UUID the project already holds
    // BEFORE this run generates anything. Captured once per run (a
    // resume keeps the original baseline).
    if (!Array.isArray(S.baselineUuids)) {
      const catB = await fetchCatalog(tab.id, true).catch(() => null);
      if (catB) { S.baselineUuids = catB.media.map((r) => r.uuid); save(); }
    }

    if (S.settings && S.settings.runMode === 'paced') {
      await runPacedLoop(tab.id, myGen);
    } else for (let idx = 0; idx < S.items.length; idx++) {
      const item = S.items[idx];
      if (stopRequested) break;
      if (item.status === 'done') continue;
      if (item.status === 'failed') continue;
      if (item.status === 'generated') continue; // v2.2: image ready, awaiting the Download-Later pass
      if (await parkWhilePaused(tab.id)) { if (stopRequested) break; }
      if (myGen !== runGen) return; // v2.3: a newer run superseded this loop
      if (item.status !== 'pending' && item.status !== 'active') item.status = 'pending';
      item.status = 'active';
      item.stage = 'shuru hocche';
      item.failReason = '';
      saveNow();
      elog(item.id + ': kaj cholche (' + (idx + 1) + '/' + S.items.length + ')');
      try {
        await ensureAttached(tab.id); // v1.4: a fresh item never begins on a dead debugger session
        const outcome = await processItem(tab.id, item, myGen);
        if (myGen !== runGen) return; // v2.3: superseded while the item ran
        // v2.3: ONE advance point. Whichever terminal status the item
        // produced — "done" (downloaded now) or "generated" (Download
        // Later: the image exists in Flow and its file comes down in
        // the Download-generated pass) — it is applied right here and
        // the loop moves on to the next item. No outcome branch can
        // stall the advance.
        const term = terminalStatusFor(outcome);
        item.status = term;
        item.stage = term;
        item.failReason = '';
        noteItemCycle(item); // v2.6: real pace sample for the ETA
        if (term === 'generated') {
          elog(item.id + ': generated — image ready, download baki (Download Later)');
        } else {
          const note = (outcome && outcome.note) || '';
          item.note = note;
          elog(item.id + ': done' + (note ? ' (' + note + ')' : ''));
        }
      } catch (e) {
        if (myGen !== runGen) return; // v2.3: superseded — the new run owns the items now
        if (e === ABORT && S.watchdogFiredFor === item.id) {
          // v3: the watchdog fired on THIS item's stage - that is a
          // failed attempt with a reason, not a user stop. The run
          // continues with the next item.
          const wStage = S.watchdogFiredStage || item.stage || '';
          S.watchdogFiredFor = '';
          S.watchdogFiredStage = '';
          S.watchdogUnwind = false; // serial consumed the unwind
          item.status = 'failed';
          item.stage = 'failed';
          item.note = 'stage timeout: ' + wStage;
          item.failReason = 'stage timeout: ' + wStage;
          elog(item.id + ': FAILED — stage timeout (' + wStage + ') — watchdog unwind koreche, run cholche');
          saveNow();
          continue;
        }
        if (e === ABORT) {
          item.status = 'pending';
          item.stage = '';
          elog(item.id + ': stop er jonno item pending rakha holo');
          break;
        }
        item.status = 'failed';
        item.stage = 'failed';
        item.note = e.message || String(e);
        item.failReason = e.finalReason || e.message || String(e);
        elog(item.id + ': FAILED — ' + item.failReason);
        elog(item.id + ': ERROR screenshot neowa hocche');
        await screenshotError(tab.id, sanitizeProject(S.project), item.id);
      }
      saveNow();
      // No separate between-item pacing — the interval gap is
      // enforced at every send inside processItem (enforceSendGap).
    }
  } catch (e) {
    elog('ERROR: run theme gelo — ' + (e && e.message ? e.message : String(e)));
  } finally {
    const stoppedByUser = stopRequested;
    // v2.3: clear the run flags FIRST. In v2.2 this block awaited the
    // debugger detach before clearing loopActive — a cleanup call
    // that never settled left the flag on forever and silently
    // swallowed every later Start. A superseded loop (myGen stale)
    // skips cleanup entirely: the newer run owns the state now.
    if (myGen === runGen) {
      S.running = false;
      S.paused = false;
      pauseRequested = false;
      loopActive = false;
    }
    if (tab && myGen === runGen) await dbgDetach(tab.id);
    if (myGen === runGen) {
      const c = counts();
      const drained = c.pending === 0 && c.active === 0;
      // v2.2 retry-at-end: the queue drained with failures left → reset
      // them and run another round (max 3), unless the user stopped.
      const wantRound = drained && c.failed > 0 && !stopRequested &&
        !!(S.settings && S.settings.retryAtEnd) && (S.retryRoundsUsed || 0) < 3;
      // v2.3: a Download-Later run that drains naturally downloads its
      // generated items right away — in v2.2 they sat at "generated"
      // forever because the pass only ran from the panel button.
      const autoPass = drained && c.generated > 0 && !stopRequested && !wantRound;
      if (wantRound) {
        S.retryRoundsUsed = (S.retryRoundsUsed || 0) + 1;
        for (const it of S.items) {
          if (it.status === 'failed') { it.status = 'pending'; it.note = ''; it.failReason = ''; it.stage = ''; }
        }
        elog('seshe failed gula abar cholche (round ' + S.retryRoundsUsed + '/3) — ' + c.failed + ' item');
      } else if (drained) {
        S.runFinishedAt = Date.now();
        S.lastReport = buildReport();
        elog('Run sesh — Done ' + c.done + ' / ' + c.total + ', Failed ' + c.failed + (c.generated ? ', Generated (download baki) ' + c.generated : '') + '.');
        if (c.generated > 0 && !autoPass) {
          elog('Download Later: ' + c.generated + ' ta image generated ache — panel er "Download generated" button chap dile sob ekbare download hobe');
        }
        // v2.2: one finish notification per natural run finish.
        if (!stopRequested) {
          try {
            await chrome.notifications.create('sfa-finish-' + Date.now(), {
              type: 'basic',
              iconUrl: chrome.runtime.getURL('icons/icon128.png'),
              title: 'SHEIKH Flow Auto',
              message: 'Run finished — Done ' + c.done + ', Failed ' + c.failed
            });
          } catch (e) { /* notifications are best-effort */ }
        }
        await downloadReportFile();
      } else {
        elog('Run theme ache — Done ' + c.done + ', Pending ' + (c.pending + c.active) + ', Failed ' + c.failed + '. Resume kore baki kaj hobe.');
      }
      stopHeartbeat();
      stopWatchdog();
      // v3: a watchdog unwind is neither a user stop nor a drain -
      // the run re-enters and picks the items up from pending.
      const watchdogRestart = !!S.watchdogUnwind && !stopRequested;
      if (S.watchdogUnwind) S.watchdogUnwind = false;
      await saveNow();
      if (stoppedByUser && !wantRound) elog('Engine stopped — notun Start er jonno ready');
      if (wantRound) runLoop();
      else if (watchdogRestart) { elog('Watchdog: run abar shuru hocche — atke thaka kaj pending theke cholbe'); runLoop(); }
      else if (autoPass) {
        elog('run sesh — generated gula ekhon download hocche');
        await downloadGeneratedPass().catch((e) => elog('Download generated auto-pass e badha: ' + (e && e.message ? e.message : String(e))));
      }
    }
  }
}

/* ---------------- v2.2 verify + match report ----------------
 * For every item, is its file actually on disk? Done items downloaded
 * directly are "<ID>.png"; menu downloads (2K/4K) carry dlName. */
async function verifyDownloads() {
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const map = {};
  for (const it of S.items) {
    let found = false;
    let filename = '';
    if (it.dlName) {
      const res = await chrome.downloads.search({ filenameRegex: esc(it.dlName) + '$' });
      const hit = (res || []).find((d) => d.state === 'complete' && (d.fileSize || d.totalBytes || 0) > 10000 && d.filename.replace(/\\/g, '/').endsWith('/' + it.dlName));
      if (hit) { found = true; filename = it.dlName; }
    }
    if (!found) {
      const ext = fileExtFor(it); // v2.6: video items verify against .mp4
      const res = await chrome.downloads.search({ filenameRegex: esc(it.id) + '\\' + ext + '$' });
      const hit = (res || []).find((d) => d.state === 'complete' && (d.fileSize || d.totalBytes || 0) > 10000 && d.filename.replace(/\\/g, '/').endsWith('/' + it.id + ext));
      if (hit) { found = true; filename = it.id + ext; }
    }
    map[it.id] = { found, filename };
  }
  return map;
}

/* ---------------- v2.2 Download-Later pass ----------------
 * Walks the "generated" items IN ORDER and downloads each through the
 * quality route (menu for 2K/4K via the tile, direct URL otherwise),
 * marking them done (or failed with the reason). Runs outside the
 * generation loop; S.dlPass mirrors activity into the saved state so
 * the panel can disable its button while a pass is going. */
let laterPassActive = false;
async function downloadGeneratedPass() {
  await loadState();
  if (laterPassActive || loopActive || retryOneActive) return { ok: false, error: 'Run ba download pass cholche — opekkha koro' };
  const gens = S.items.filter((i) => i.status === 'generated');
  if (!gens.length) return { ok: true, count: 0 };
  laterPassActive = true;
  S.dlPass = true;
  await saveNow();
  let tab = null;
  let doneN = 0;
  try {
    tab = S.tabId ? await chrome.tabs.get(S.tabId).catch(() => null) : null;
    if (!tab || !tab.url || !FLOW_URL_RE.test(tab.url)) tab = await findFlowTab();
    if (tab) {
      S.tabId = tab.id;
      await dbgAttach(tab.id).catch(() => {});
    }
    elog('Download generated shuru — ' + gens.length + ' ta image por por download hobe');
    for (const item of gens) {
      if (item.status !== 'generated') continue;
      try {
        let note = '';
        if (tab && item.tileMediaId) {
          note = await downloadFromTile(tab.id, item, { mediaId: item.tileMediaId, kind: item.mediaKind || 'image' });
        } else if (item.tileUrl && item.tileUrl.indexOf('blob:') !== 0) {
          const fname = targetPathFor(S.project, item.id, item.mediaKind);
          const size = await downloadAndVerify(upgradeUrl(item.tileUrl), fname);
          elog(item.id + ': download done (' + size + ' bytes)');
        } else if (tab) {
          note = await fallbackDownload(tab.id, item.tileMediaId ? { mediaId: item.tileMediaId } : null);
        } else {
          throw new Error('Flow tab o nai, tile URL o nai — download er upay nai');
        }
        item.status = 'done';
        item.stage = 'done';
        item.failReason = '';
        item.note = note || '';
        doneN++;
        elog(item.id + ': done (Download-Later pass)');
      } catch (e) {
        item.status = 'failed';
        item.stage = 'failed';
        item.note = e.message || String(e);
        item.failReason = e.finalReason || e.message || String(e);
        elog(item.id + ': Download-Later FAILED — ' + item.failReason);
      }
      await saveNow();
    }
    elog('Download generated sesh — ' + doneN + '/' + gens.length + ' done');
  } finally {
    if (tab) await dbgDetach(tab.id).catch(() => {});
    laterPassActive = false;
    S.dlPass = false;
    await saveNow();
  }
  return { ok: true, count: doneN };
}

/* ---------------- v2.4 single-item retry ----------------
 * Panel message {type:'retryOne', itemId} — regenerates ONE failed
 * item and nothing else. NUMBERING INTEGRITY (user's explicit spec):
 * the item keeps its own ID end to end; processItem/completeItem
 * download under targetPath(project, item.id) exactly like the run
 * loop, and no other item is read for writing, renumbered or
 * re-downloaded. Refused while the run loop (or a download pass, or
 * another single retry) is active. Download semantics follow the
 * CURRENT settings: autoDownload off → the item becomes "generated"
 * and its file comes down in the Download-Later pass. */
let retryOneActive = false;
async function retryOneItem(itemId) {
  await loadState();
  if (loopActive || laterPassActive || retryOneActive) {
    elog('Retry ' + itemId + ': neya holo na — run cholche, ses hole retry koro');
    return { ok: false, error: 'busy' };
  }
  const item = S.items.find((i) => i.id === itemId);
  if (!item) return { ok: false, error: 'Item paoa jay ni: ' + itemId };
  if (item.status !== 'failed') return { ok: false, error: 'Item failed obosthay nei: ' + itemId };
  retryOneActive = true;
  stopRequested = false;
  let tab = null;
  const prevReason = item.failReason;
  const prevNote = item.note;
  try {
    elog('Retry ' + item.id + ': shuru — sudhu ei item tai abar hobe, or number ei download hobe');
    tab = S.tabId ? await chrome.tabs.get(S.tabId).catch(() => null) : null;
    if (!tab || !tab.url || !FLOW_URL_RE.test(tab.url)) tab = await findFlowTab();
    if (!tab) {
      elog('Retry ' + item.id + ': FAILED — Flow tab paoa jay ni');
      return { ok: false, error: 'Flow tab paoa jay ni' };
    }
    S.tabId = tab.id;
    await dbgAttach(tab.id);
    // If this item needs the reference, make sure it is in the project
    // (same one-time lifecycle as a normal run start).
    const refOk = await ensureReference(tab.id);
    if (!refOk) {
      elog('Retry ' + item.id + ': FAILED — reference ready korte parini');
      return { ok: false, error: 'Reference ready na' };
    }
    // Fresh attempt for THIS item only; stale tile/dlName from the
    // failed attempt are cleared so the new download is recorded
    // under this item's own ID name.
    item.status = 'active';
    item.stage = 'retry hocche';
    item.failReason = '';
    item.tileMediaId = null;
    item.tileUrl = '';
    item.dlName = '';
    await saveNow();
    const outcome = await processItem(tab.id, item, runGen);
    const term = terminalStatusFor(outcome);
    item.status = term;
    item.stage = term;
    item.failReason = '';
    item.note = term === 'generated' ? '' : ((outcome && outcome.note) || '');
    noteItemCycle(item); // v2.6: real pace sample for the ETA
    elog('Retry ' + item.id + ': ' + (term === 'generated'
      ? 'generated — download pore hobe (Download Later)'
      : 'done — ' + item.id + ' name ei download hoyeche'));
    await saveNow();
    return { ok: true, status: term };
  } catch (e) {
    if (e === ABORT) {
      // Stopped/reset mid-retry: the item goes back to failed with
      // its original reason — nothing about it was half-changed.
      item.status = 'failed';
      item.stage = 'failed';
      item.failReason = prevReason;
      item.note = prevNote;
      elog('Retry ' + item.id + ': theme gelo (abort) — item failed ei roilo');
      await saveNow().catch(() => {});
      return { ok: false, error: 'Retry theme geche' };
    }
    item.status = 'failed';
    item.stage = 'failed';
    item.note = e.message || String(e);
    item.failReason = e.finalReason || e.message || String(e);
    elog('Retry ' + item.id + ': FAILED — ' + item.failReason);
    if (tab) await screenshotError(tab.id, sanitizeProject(S.project), item.id).catch(() => {});
    await saveNow().catch(() => {});
    return { ok: false, error: item.failReason };
  } finally {
    retryOneActive = false;
    if (tab) await dbgDetach(tab.id).catch(() => {});
    await saveNow().catch(() => {});
  }
}

/* ---------------- gap fill ---------------- */
async function skipDownloaded(items, project) {
  await loadState();
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  let marked = 0;
  const list = items && items.length ? items : S.items;
  for (const it of list) {
    if (it.status === 'done') continue;
    const ext = fileExtFor(it); // v2.6: video items skip against .mp4
    const res = await chrome.downloads.search({ filenameRegex: esc(it.id) + '\\' + ext + '$' });
    const hit = (res || []).find((d) => d.state === 'complete' && (d.fileSize || d.totalBytes || 0) > 10000 && d.filename.replace(/\\/g, '/').endsWith('/' + it.id + ext));
    if (hit) { it.status = 'done'; it.note = 'existing'; marked++; }
  }
  if (items && items.length) { S.items = items; if (project) S.project = project; }
  elog('Skip-downloaded check: ' + marked + ' item age thekei download ache bole done mark holo');
  saveNow();
  return marked;
}

/* ---------------- messages ---------------- */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    await loadState();
    try {
      switch (msg && msg.type) {
        case 'preflight': {
          const r = await runPreflight();
          sendResponse({ ok: true, result: r });
          break;
        }
        case 'start': {
          const licBlockStart = await licenseGate();
          if (licBlockStart) { elog('License nei — run shuru holo na (' + licBlockStart.reason + ')'); sendResponse({ ok: false, error: 'License active nei — age Activation theke key boshao' }); break; }
          if (retryOneActive) {
            elog('Start neya holo na: ekta single-item retry cholche');
            sendResponse({ ok: false, error: 'Single retry cholche — ektu opekkha koro' });
            break;
          }
          if (loopActive && !shouldForceResetLoop(loopActive, S.engineHeartbeat, Date.now())) {
            // v2.3: a refusal is LOGGED, never silent — in v2.2 this
            // branch swallowed three Start presses without a trace in
            // the engine log.
            elog('Start neya holo na: run ekhono cholche (engine busy)');
            sendResponse({ ok: false, error: 'Run already cholche' });
            break;
          }
          if (loopActive) {
            elog('Start: ager run atke chilo — reset kore notun run shuru');
            forceResetRun();
          }
          elog('Run shuru hocche — start request neya holo');
          // v3: Start = Resume. The panel's Start always sends the
          // full list, so the handler decides: SAME signature as the
          // saved run + real progress => keep EVERYTHING (items,
          // runStartedAt, folder, ETA samples, baseline, ref identity)
          // and merely continue. A different list is a fresh run.
          let resumeRun = false;
          if (msg.items && msg.items.length) {
            const projForSig = msg.project !== undefined ? sanitizeProject(msg.project) : S.project;
            const refForSig = (msg.settings && msg.settings.refFileName) || S.refFileName || '';
            const newSig = runSignatureFor(projForSig, msg.items, refForSig);
            resumeRun = shouldResumeRun(S.runSignature, S.items, newSig);
            if (resumeRun) {
              elog('Start: eki run er list - saved state thekei RESUME hocche (progress, folder, ETA sob thaklo)');
              for (const it of S.items) if (it.status === 'active') { it.status = 'pending'; it.stage = ''; }
            } else {
              S.runSignature = newSig;
              S.items = msg.items.map((i) => ({ id: i.id, prompt: i.prompt, needsRef: !!i.needsRef, status: 'pending', attempts: 0, note: '', failReason: '', stage: '', tileMediaId: null, tileUrl: '', completedAt: 0, dlName: '', sentAt: 0, tileGot: 0, quotaTile: null, quotaUuid: null, extraNoted: false, mediaKind: '', sentPrompt: '', sendCount: 0, cooldowns: 0, cycleNotedFor: 0 }));
            }
          }
          if (msg.project !== undefined) S.project = sanitizeProject(msg.project);
          if (msg.settings) {
            const rm = msg.settings.refMode;
            const prevDl = S.settings || {};
            S.settings = Object.assign(DEFAULT_SETTINGS(), {
              autoDownload: prevDl.autoDownload, quality: prevDl.quality,
              datedFolder: prevDl.datedFolder, retryAtEnd: prevDl.retryAtEnd,
              intervalSec: prevDl.intervalSec, runMode: prevDl.runMode, matchMode: prevDl.matchMode,
              genType: prevDl.genType, genModel: prevDl.genModel,
              genRatio: prevDl.genRatio, genCount: prevDl.genCount,
              refMode: (rm === 'marked' || rm === 'all' || rm === 'none') ? rm : 'marked',
              refReady: !!msg.settings.refReady
            });
            // v2.2: the panel also sends the Download-section values
            // with Start; they win over the stored ones.
            applyDownloadSettings(msg.settings);
            // Fresh start (items were sent): record the reference file
            // name and reset the v2 lifecycle — ensureReference will
            // re-discover the asset in this project or upload it once.
            // v2.2: also fix this run's download folder + retry rounds.
            if (msg.items && msg.items.length && !resumeRun) {
              S.refFileName = msg.settings.refFileName || '';
              S.refMediaId = null;
              S.refAssetName = '';
              S.refPickerName = '';
              S.refStatus = '';
              S.pacedBase = null;
              S.cycleSamples = []; // v2.6: ETA measures THIS run's pace
              S.consumedTiles = [];
              S.etaMs = null;
              S.endsAt = null;
              S.retryRoundsUsed = 0;
              // v3 fresh-run resets: identity set, baseline, recovery
              // budget, cooldown and parked rows all belong to a run.
              S.refMediaIds = [];
              S.baselineUuids = null;
              S.refRecovered = false;
              S.unclaimedUuids = [];
              S.cooldownUntil = 0;
              S.cooldownLevel = 0;
              S.watchdogUnwind = false;
              S.watchdogFiredFor = '';
              S.watchdogFiredStage = '';
              S.runFolder = S.settings.datedFolder
                ? datedFolderName(S.project, Date.now())
                : sanitizeProject(S.project);
            }
          }
          if (msg.tabId) S.tabId = msg.tabId;
          if (!resumeRun) S.runStartedAt = Date.now();
          S.runFinishedAt = null;
          pauseRequested = false; stopRequested = false;
          await saveNow();
          runLoop();
          sendResponse({ ok: true });
          break;
        }
        case 'pause': {
          pauseRequested = true;
          elog('Engine: pause request pelam — cholti item sesh hole thamba');
          sendResponse({ ok: true });
          break;
        }
        case 'resume': {
          const licBlockResume = await licenseGate();
          if (licBlockResume) { sendResponse({ ok: false, error: 'License active nei — age Activation theke key boshao' }); break; }
          if (retryOneActive) { sendResponse({ ok: false, error: 'Single retry cholche — ektu opekkha koro' }); break; }
          if (loopActive && !shouldForceResetLoop(loopActive, S.engineHeartbeat, Date.now())) { pauseRequested = false; sendResponse({ ok: true }); break; }
          if (loopActive) {
            elog('Resume: ager run atke chilo — reset kore resume hocche');
            forceResetRun();
          }
          // loop not active (e.g. service worker restarted): restart from saved items
          elog('Engine: resume request pelam — saved state theke loop abar shuru hocche');
          pauseRequested = false; stopRequested = false;
          for (const it of S.items) if (it.status === 'active') { it.status = 'pending'; it.stage = ''; }
          await saveNow();
          runLoop();
          sendResponse({ ok: true });
          break;
        }
        case 'stop': {
          stopRequested = true;
          pauseRequested = false;
          bumpAbortEpoch(); // v2.3: wake every wait loop NOW, not at its next poll
          elog('Engine: stop request pelam');
          sendResponse({ ok: true });
          break;
        }
        case 'retryFailed': {
          const licBlockRetry = await licenseGate();
          if (licBlockRetry) { sendResponse({ ok: false, error: 'License active nei — age Activation theke key boshao' }); break; }
          if (loopActive || retryOneActive) { sendResponse({ ok: false, error: 'Run cholche — age stop koro' }); break; }
          let n = 0;
          for (const it of S.items) if (it.status === 'failed') { it.status = 'pending'; it.note = ''; it.failReason = ''; it.stage = ''; n++; }
          await saveNow();
          elog('Retry failed: ' + n + ' item abar pending kora holo');
          if (n > 0) { stopRequested = false; pauseRequested = false; runLoop(); }
          sendResponse({ ok: true, count: n });
          break;
        }
        case 'skipDownloaded': {
          const marked = await skipDownloaded(msg.items || null, msg.project);
          sendResponse({ ok: true, marked });
          break;
        }
        case 'getState': {
          sendResponse({ ok: true, state: S, loopActive });
          break;
        }
        case 'clearState': {
          if (loopActive) { sendResponse({ ok: false, error: 'Run cholche' }); break; }
          S = DEFAULT_STATE();
          await saveNow();
          sendResponse({ ok: true });
          break;
        }
        case 'buildReport': {
          S.lastReport = buildReport();
          await saveNow();
          sendResponse({ ok: true, report: S.lastReport });
          break;
        }
        case 'settings': {
          // v2.2: live Download-section settings from the panel.
          const before = JSON.stringify([S.settings.autoDownload, S.settings.quality, S.settings.datedFolder, S.settings.retryAtEnd, S.settings.intervalSec, S.settings.runMode, S.settings.genType, S.settings.genModel, S.settings.genRatio, S.settings.genCount, S.settings.matchMode]);
          applyDownloadSettings(msg.settings || {});
          await saveNow();
          const after = JSON.stringify([S.settings.autoDownload, S.settings.quality, S.settings.datedFolder, S.settings.retryAtEnd, S.settings.intervalSec, S.settings.runMode, S.settings.genType, S.settings.genModel, S.settings.genRatio, S.settings.genCount, S.settings.matchMode]);
          if (before !== after) {
            elog('Settings bodleche — auto-download ' + (S.settings.autoDownload ? 'ON' : 'OFF (Download Later)') + ', quality ' + S.settings.quality + ', interval ' + S.settings.intervalSec + 's, dated folder ' + (S.settings.datedFolder ? 'ON' : 'OFF') + ', retry-at-end ' + (S.settings.retryAtEnd ? 'ON' : 'OFF') + ', run mode ' + S.settings.runMode + ', match ' + S.settings.matchMode + ', gen ' + S.settings.genType + '/' + S.settings.genModel + '/' + S.settings.genRatio + '/x' + S.settings.genCount);
          }
          sendResponse({ ok: true, settings: S.settings });
          break;
        }
        case 'thumbs': {
          // v2.2: session thumbnails for done/generated item rows.
          const out = {};
          for (const id of msg.ids || []) {
            if (thumbCache.has(id)) out[id] = thumbCache.get(id);
          }
          sendResponse({ ok: true, thumbs: out });
          break;
        }
        case 'verify': {
          const map = await verifyDownloads();
          sendResponse({ ok: true, verify: map });
          break;
        }
        case 'matchReport': {
          const map = await verifyDownloads();
          sendResponse({ ok: true, report: buildMatchReport(S.items, map) });
          break;
        }
        case 'downloadGenerated': {
          const r = await downloadGeneratedPass();
          sendResponse(r);
          break;
        }
        case 'retryOne': {
          const licBlockOne = await licenseGate();
          if (licBlockOne) { sendResponse({ ok: false, error: 'License active nei — age Activation theke key boshao' }); break; }
          // v2.4: single-item retry (panel Items tab). All the logic
          // (busy refusal, numbering integrity) lives in retryOneItem.
          const r = await retryOneItem(String((msg && msg.itemId) || ''));
          sendResponse(r);
          break;
        }
        default:
          sendResponse({ ok: false, error: 'Unknown message type' });
      }
    } catch (e) {
      sendResponse({ ok: false, error: e && e.message ? e.message : String(e) });
    }
  })();
  return true; // async response
});

chrome.runtime.onStartup.addListener(() => { loadState(); });
loadState();
