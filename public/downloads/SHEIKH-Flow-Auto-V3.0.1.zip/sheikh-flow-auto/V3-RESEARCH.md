# SHEIKH Flow Auto — V3 Research

Phase 1 of the V3.0 rebuild (Amin's order, 2026-11-02): deep research first,
derive the system, build ONE version. This document separates **FACT**
(sourced from live-recon write-ups or provable in our code) from
**INFERENCE** (our best reading; flagged wherever the design leans on it).

Primary external source: **gflow-cli** (github.com/ffroliva/gflow-cli), a
mature open-source Flow automation CLI whose docs are reverse-engineered
from live recon (Aug–Oct 2026, with issue-level evidence). Secondary:
FlowKit / flow-bridge error taxonomies, the facebook-reels-all extension's
engineering notes, and competitor extension READMEs (Auto-Flow by
duckmartians, FlowBatch, VEO Automation).

---

## 1. How Flow actually works (web research)

### 1.1 The project media library is a data model, not just a grid — FACT

Each Flow **project** owns a media library (no cross-project reachability).
The page loads it via a tRPC call:

```
GET https://labs.google/fx/api/trpc/flow.projectInitialData
    ?input={"json":{"projectId":"<id>","toolName":"PINHOLE"}}
```

- Fires on plain project load, regardless of UI cohort.
- **Complete, not paginated** at observed scales (a 267-asset project
  returned every asset in one ~650 KB payload).
- **Directly callable from an authenticated browser context** (cookies
  only, no navigation/rendering), measured 458–610 ms per project.
  (gflow MEDIA_LIBRARY.md, #543.)
- Payload (`projectContents`):
  - `media[]` — every project asset. Kind is the discriminating sub-key:
    `image` carries **`generatedImage` or `userUploadedImage`**; `video`
    carries `generatedVideo` + `operation`. Uploads and generations are
    therefore distinguishable **by type, server-side**.
  - `workflows[]` — one per generation batch/upload, with
    `metadata.displayName` (caption), `metadata.primaryMediaId` (→ media
    UUID), `batchId`, create/update times.
  - Per-asset metadata includes `mediaMetadata.createTime` and **the full
    `requestData`, including the original prompt, for generated media**.

### 1.2 Identity: the media UUID is the only stable identifier — FACT

- `media[].name` (the UUID) is the only stable identity. Everything else
  is display sugar.
- `displayName` is an **AI-generated caption of the result, not the
  prompt**: across 136 prompt-bearing assets only 2 captions were
  substrings of their prompt; hard cap ≈ 35 chars; computed
  **asynchronously** (a fresh generation may have no caption yet).
- **Uploads keep their original filename verbatim** as displayName.
- Names are **mutable** (Agent rename) and **not unique**. gflow's rule,
  adopted verbatim for V3: *"Cached name = optimization. Listing = truth.
  UUID = identity."* Search by name, verify by UUID.
- The one DOM-visible identity anchor: **thumbnail URLs carry the UUID**
  (`media.getMediaUrlRedirect?name=<uuid>`), which gflow's picker code
  uses to assert the exact tile before attaching.

### 1.3 The grid is virtualized — DOM scans cannot enumerate the library — FACT

- On a 267-asset project, only **19–27 `[role='option']` tiles exist in
  the DOM at any instant**, recycled as the scroll window moves.
- "A DOM scan can never enumerate the library, and scroll-and-scan loops
  are both slow and WAF-noisy." gflow **removed** scroll-scan tiers in
  v0.58.0 in favour of search-first + the listing endpoint.
- Corollary for us: any logic of the form "the asset is not in my tile
  scan, therefore it is gone" is unsound. Our `sfaTiles` probe caps at 60
  tiles and additionally requires layout visibility — the real DOM window
  is smaller than our cap, so the cap never even binds; the window does.

### 1.4 The picker — FACT

- Tabs (en): All / Images / Videos / Voices / Characters / Uploads; the
  picker has **its own active project** (Recents dropdown), not
  necessarily the editor's project — "asset missing though it exists" is
  a known failure shape when they diverge.
- **Search indexes the caption (displayName), not the prompt.** For
  uploads the caption is the filename, so filename search works for the
  reference; prompt-text search never matches anything.
- The picker exposes no usable accessible tree; tiles are matched by
  anchored text, tolerating a localized media-type badge glued to the
  tile text.
- Since the 2026-08 redesign, **clicking a result tile attaches it
  directly and closes the dialog** (an include/"Add to prompt" button
  exists only in the hover-preview pane on some cohorts) — both shapes
  must be handled (our current code already treats "button absent" as
  attached).

### 1.5 Generation transport and the "unusual activity" error — FACT

- `PUBLIC_ERROR_UNUSUAL_ACTIVITY` = **reCAPTCHA/risk evaluation
  failure**, not a content failure and not a per-item failure. Triggers:
  rapid submit bursts, automation-shaped request contexts, VPN/shared
  IPs. FlowKit's confirmed transport lesson (2026-09-23): direct-minted
  generation calls get their reCAPTCHA action rewritten to
  `extension_hijack_detected`, while **a real Generate UI gesture mints
  the proper action** — which is why serious tools submit through Flow's
  real UI with trusted input and use direct calls only for
  upload/poll/media. Our CDP-Enter send design is the right transport;
  keep it.
- Handling doctrine, two independent tools agreeing:
  - FlowKit: **never auto-retry** an unusual-activity failure; pause
    submits; the block is a session trust signal that recovers with
    time/cadence, not with retries.
  - facebook-reels-all: treat it as **transient with its own budget** —
    separate rate-limit counter (never the item-fail budget), 60 s
    backoff, retry the same scene, budget resets on any success.
- The error tile's text is user-visible ("We noticed some unusual
  activity. Note that browser extensions that modify the page may cause
  issues… You have not been charged for this generation."), so the tile
  text is classifiable at the DOM level.
- Hidden daily per-model caps exist ("Failed — daily limit reached"):
  another error class that must not burn item attempts blindly — it is a
  stop-and-tell-the-user condition.

### 1.6 Tabs die quietly — FACT (from facebook-reels-all's bug table)

- Chrome Memory Saver freezes/discards inactive background tabs; a
  discarded Flow tab makes automation stall. Their fix:
  `chrome.tabs.update(id, {autoDiscardable: false})` after creating the
  tab. A discarded tab also masquerades as a reCAPTCHA refusal.

### 1.7 How other tools attribute results — FACT/INFERENCE

- **API tools (gflow, FlowKit):** attribution by construction — the
  generation response returns the media IDs; polling/media via API.
- **Serial UI tools (FlowBatch et al.):** one prompt at a time; the only
  new result must be theirs. Attribution by exclusivity.
- **Concurrent UI tools (Auto-Flow, VEO Automation):** their public docs
  do not describe any content-true attribution mechanism. INFERENCE:
  they pair by appearance/completion order and accept the risk — the
  exact defect Amin rejects, because his QuickVid pipeline maps image N
  to narration line N and a swap is silent corruption.
- **No public tool we found uses a stronger UI-side signal than
  (a) the listing's `requestData` prompt, or (b) the viewer's prompt
  text.** The listing signal is strictly stronger: it is complete (not
  windowed), typed (upload vs generated), and carries the original
  prompt — no viewer round-trip, no focus theft.

### 1.8 The viewer and the prompt — INFERENCE (bounded)

- Our own V2.6.2 live runs prove the viewer *can* expose prompt text
  (the prompt-check mode worked often enough to be useful) but the
  extraction is heuristic: labelled-region search, else
  longest-sentence fallback; storyboard prompts share a long style
  suffix, so overlap scoring needs a margin rule; a truncated view shows
  only the head. Treat viewer text as a **fallback verification**, never
  the primary signal.
- `data-media-id` on grid tiles == the media UUID: INFERENCE, strongly
  supported (our downloads have worked across versions keyed by it;
  gflow confirms thumbnail URLs embed the same UUID). V3 keeps
  UUID-keyed logic but never lets a DOM absence override the listing.

---

## 2. Audit of our code (V2.6.2) — failure → mechanism

### (a) Settings-menu click binned the reference (V2.6 incident)

- `applyGenerationSettings` (new in V2.6) harvested click coordinates
  from `sfaGenMenu`'s document-wide scan (any `[class*=menu i]`,
  `[class*=dropdown i]`, low-page buttons) whose only grid exclusion was
  `closest('.flow-grid-tile-container')` — a class Flow's current UI is
  not guaranteed to put on upload/asset tiles (`sfaTiles` itself carries
  a fallback for exactly that absence). Coordinates were clicked after
  sleeps with **no point verification** — the protection the send click
  had since v1.3 (`sfaVerifyPoint`) was not applied to this new code.
  A tile's overflow menu is itself `[role=menu]`, and "Move to bin"
  lives in tile menus: a harvested/stale coordinate could reach it.
- V2.6.1 mitigations (kept in V3): settings applied **before** the
  reference upload; `guardedClick` (`sfaPointCheck` + `genClickVerdict`)
  refuses grid points and destructive labels at click time.
- Residual risk in V2.6.2: the harvest is still heuristic; other
  unguarded `realClick` paths remain — the error-tile **Retry** click
  inside `waitForCompletion` uses coordinates from the tile scan with no
  point check at click time.

### (b) Survival-check misfire → re-uploads → sheet downloaded (V2.6.1)

- **False absence:** `refPresentInProject` judged presence from
  `sfaTiles` (≤60, visibility-filtered) plus `sfaFindAsset` over the
  same window. Per §1.3 the real window is ~19–27 tiles and the
  reference is the **oldest** asset — every generation pushes it out of
  the window. `refPresenceVerdict`'s "scan not capped ⇒ absence proven"
  premise is false under virtualization: the scan is *always*
  effectively capped. Name fallback also fails when the new UI shows the
  upload under a generic label.
- **Identity as a scalar:** the engine tracked ONE `S.refMediaId`.
  `recoverReference` nulls it and re-pastes; the re-upload is a **new**
  UUID. Between paste and gate completion the new tile is an unknown
  non-reference tile; the old UUID is forgotten (if Flow kept both
  copies, the old one is unexcluded too).
- **Download:** the paced watcher / serial candidate picker excluded
  only the *current* `S.refMediaId`. The fresh sheet tile at grid top —
  new, finished-looking, thumbnail present — matched the order-based
  picker and was downloaded under an item number.
- Root pattern: **identity assumed from position and a single mutable
  scalar, instead of verified against a complete, typed listing.**

### (c) FIFO attribution breaks on failure + retry interleave

- `pacedAssign` / `pacedQuotaAssign` pair the k-th finished tile with
  the k-th sent-but-unmatched item. The invariant "among successes,
  finish order == send order" breaks the moment any send fails
  server-side and is re-sent: its tile finishes after later sends'
  tiles, yet the first finisher still takes the failed item's slot.
- Error tiles carry **no item identity**; the watcher consumes a count
  delta against `pending[0]` (oldest pending) by assumption
  (`pacedErrorDelta`). With unusual-activity errors common under
  automation cadence (§1.5), interleaves are the common case.
- Even freeze-drain-repair (fast mode) only helps if the error is
  detected and charged to the right item — both are assumptions.
- Prompt-check mode mitigates via viewer text but falls back to FIFO
  after 3 unreadable rounds, silently reintroducing the defect exactly
  when verification is hardest; and its viewer round-trips steal
  focus/DOM state mid-run (see d).

### (d) Stuck 'gen shuru check' stage; ETA '—' in prompt mode

Provable hang/staleness mechanisms in the code (the exact live locus was
not captured in a run report; these are the candidates, ranked):

1. **Fossil state after service-worker death (most consistent with the
   evidence).** `loopActive`, `runGen`, `abortEpoch` are module-scope;
   persisted `S.running=true` + last `item.stage` survive in storage.
   Nothing reconciles a dead run when the worker restarts —
   `chrome.runtime.onStartup` only loads state. The panel then displays
   a frozen stage ('gen shuru check') with no live loop behind it
   indefinitely, until the user happens to press something that consults
   the heartbeat. The same fossil explains the ETA half: `refreshEta`
   nulls `etaMs` whenever `S.running` is false or samples are empty,
   and the panel only renders ETA while `running` — a stopped/dead run
   shows '—' even with 7 completions recorded.
2. **Serialized paced loop.** Sends and watching share one
   `while(true)`: a slow `sendPromptOnce` (the picker attach flow chains
   dozens of evals, each individually capped at 8 s ×2 by `cdp()` —
   worst case minutes for one attach) starves the watcher; conversely
   `pacedPromptAssign`'s per-tile viewer round-trips (click + 1.2 s +
   evals + Escape + …) serialize behind one awaited call. The displayed
   stage is whatever was last saved — it can sit at a send stage for
   minutes while the engine is technically alive.
3. **`scriptFn` has no timeout** (chrome.scripting.executeScript,
   preflight path) — a wedged renderer hangs its caller forever.
4. **ETA sample fragility (code fact):** cycle samples are recorded only
   by `noteItemCycle` at five scattered call sites, each dependent on
   `item.sentAt` surviving (it is zeroed by fail/stop paths and by the
   start handler's item rebuild), and `S.cycleSamples` is wiped by every
   fresh Start. One missed site = no samples = ETA '—' despite
   completions.

Waits that ARE properly bounded (verified): `waitForCompletion` 240 s,
`waitForStartSignal` 15 s ×2, `waitRefUploadGate` 90 s,
`waitDownloadComplete` 90 s, all CDP calls 8 s + one heal-retry.

### (e) Pause/Stop → Start restarts from item 1

- The panel's Start button **always** sends the full parsed list
  (`type:'start', items: displayItems…`). The background 'start' handler
  **unconditionally replaces** `S.items` with a fresh all-pending list
  when items are present, resets `runStartedAt = Date.now()`, recomputes
  `runFolder` (a dated folder changes mid-run!), wipes `cycleSamples`,
  `consumedTiles`, `pacedBase`, and the reference identity.
- A separate Resume path exists and works from saved state, but the
  natural user action after Stop is Start — and Start is defined as
  "new run". Resume integrity therefore depends on the user picking the
  right button: a UX-level trap, engineered into the message contract.

### Identity assumed rather than verified — full list

| Place | Assumption | Reality |
|---|---|---|
| `sfaTiles` window | scan ≈ project contents | ~19–27 of N tiles (virtualized) |
| `refPresenceVerdict` | absence in scan = absence in project | scan is always partial |
| `S.refMediaId` (scalar) | one reference identity, stable | re-upload mints a new UUID; copies can coexist |
| `pacedAssign`/`pacedQuotaAssign` | finish order = send order | broken by any failure+retry interleave |
| `pacedErrorDelta` → `pending[0]` | newest error belongs to oldest pending | error tiles carry no identity |
| tile `label` | caption ≈ prompt | caption is an AI summary, ≤35 chars, async |
| busy-cycle fallback + `lastUrl` download | "the newest thing is probably ours" | can download an unverified/foreign tile |
| `waitForStartSignal` media-growth | any new tile = our generation started | a late leftover also satisfies it |
| panel Start contract | Start = new run | user means "continue" after Stop |

---

## 3. Research conclusions that change the design

1. **Adopt the listing (`flow.projectInitialData`) as the truth layer**
   for identity, presence, and attribution. It is complete, typed
   (upload vs generated), UUID-keyed, and carries the original prompt.
   This one adoption structurally removes (b) and (c) and most of (a)'s
   blast radius.
2. **Downloads require a prompt-verified, generated-origin UUID.**
   Nothing downloads on order, position, or "newest thing" heuristics.
   The busy-cycle/lastUrl fallbacks are deleted, not patched.
3. **Error tiles are signals, not verdicts.** Classify by text:
   unusual-activity → global cooldown, no attempt charged (FlowKit +
   facebook-reels-all doctrine); daily-limit → stop and tell the user;
   generic → the affected send is identified by elimination (it is the
   outstanding send that produces no media row), never by oldest-first
   assumption.
4. **Presence is proven only by the listing.** Grid absence proves
   nothing, ever. Re-upload requires listing-proven absence AND an
   actual attach failure, at most once per run.
5. **Hang-proofing is a system property, not per-wait care**: every
   primitive gets a timeout (including `scriptFn`), every stage gets a
   budget enforced by a watchdog that unwinds to a failed attempt, and a
   dead worker's fossil run is reconciled at startup.
6. **Start = resume.** The saved run (signature-matched) is the single
   source of truth; Start replaces it only when the list actually
   changed. Removes (e) without depending on which button the user
   presses.
7. **Keep UI sends** (reCAPTCHA mints correctly only for real UI
   gestures — §1.5) and keep V2.6.1's containment-guarded clicks,
   extended to the Retry click.
8. **Pin the Flow tab** (`autoDiscardable:false`) so Memory Saver can't
   freeze the run's tab mid-batch.
