# SHEIKH Flow Auto — V3.0 System Design

Derived from V3-RESEARCH.md. One principle runs through everything:
**the listing is truth, UUID is identity, and nothing is downloaded,
attached, or declared lost on the basis of position, order, or a
windowed DOM scan.** Where V2.x got clever (FIFO pairing, grid-scan
survival checks, scalar reference identity), V3 substitutes a dumber,
verifiable mechanism.

## 0. What stays

- CDP trusted-input sends (Enter-first, verified click fallback) — the
  reCAPTCHA-correct transport (Research §1.5).
- Settings applied **before** the reference upload; every menu/picker
  click containment-guarded (V2.6.1), now including the Retry click.
- The panel as-is (emerald theme, text diet, i18n ×8, dated folders,
  Download Later, QuickVid match report, single-item retry, toasts,
  badge, interval stepper, GENERATION card). Only the version tag and
  the match-mode semantics change (see §3.4).
- Upload-once reference lifecycle, picker attach, 1K direct / 2K-4K menu
  download routes, thumbnails, reports, notifications.

## 1. The truth layer: project catalog

New self-contained probe `sfaProjectData()` runs in the Flow tab:

1. Parse `projectId` from `location.pathname` (segment after `project`).
2. `fetch('/fx/api/trpc/flow.projectInitialData?input=' +
   encodeURIComponent(JSON.stringify({json:{projectId, toolName:'PINHOLE'}})),
   {credentials:'include'})` against the page origin (labs.google; the
   same path is attempted on flow.google.com).
3. Defensively walk the tRPC envelope (`result.data.json…`) to
   `projectContents`; normalize to:
   `{ ok, projectId, media: [{uuid, kind, origin, prompt, displayName,
   createdAt}], workflows: [{id, primaryMediaId, createdAt}] }`
   where `origin` is `'upload'` iff the row carries
   `userUploadedImage`/`userUploadedVideo`, else `'generated'`, and
   `prompt` is dug out of `requestData` by trying the known key paths
   (`requestData.prompt`, `…textPrompt`, `…structuredPrompt`…, plus a
   bounded recursive search for a long string field named like
   `prompt`). Any failure → `{ok:false}` — never throws.

Engine side: `fetchCatalog(tabId)` wraps the probe in a 20 s timeout,
caches the last good catalog for 3 s, and returns `null` on failure.
**A null catalog never blocks a run and never proves absence** — it
only disables the catalog-dependent fast paths (§3.3 ladder).

At run start the engine records `S.baselineUuids` = all catalog UUIDs
(persisted, keyed by the run signature, §5). Everything attributable
must be a generated-origin UUID outside the baseline.

## 2. Reference lifecycle

- **Identity is a set**: `S.refMediaIds` — every UUID ever confirmed as
  the reference in this project. It only ever grows within a run.
- **Exclusion by identity AND type, in every path**: a UUID is
  downloadable only if (a) it is not in `refMediaIds`, (b) it is not in
  `consumedTiles`, (c) when a catalog is available, its row's origin is
  `'generated'`. `completeItem` asserts (a)+(b) itself, so no caller —
  present or future — can download the sheet. Upload-origin rows are
  ineligible by construction, so even a re-uploaded sheet (new UUID,
  origin `upload`) can never become an item's download (kills failure
  b's download half structurally, not by vigilance).
- **Presence is proven only by the listing**: present iff some catalog
  row's UUID ∈ `refMediaIds`, or an upload-origin row's `displayName`
  equals `S.refFileName` (then that UUID is adopted into the set).
  Catalog unavailable ⇒ *unknown* ⇒ treated as present.
- **Upload** (only when listing proves absence, or no listing exists and
  the V2 grid check also fails): the existing paste path; the gate now
  polls the **catalog** for a new upload-origin row named like the file
  (fallback: the old tile gate when the catalog is unavailable). The
  confirmed UUID joins `refMediaIds`. Gate bounded at 90 s; failure
  aborts run start as before.
- **Recovery**: at most once per run (`S.refRecovered`), and only when
  the catalog proves absence **and** a picker attach has actually
  failed for that reason. Grid absence never triggers anything.
- **Attach**: picker flow as today, with two upgrades — the chosen
  option is verified against the reference identity where the DOM
  allows (thumbnail URL carries the UUID, Research §1.2); ingredient
  count growth remains the success signal.

## 3. Attribution — content-true by construction

### 3.1 The send ledger

Every send records on the item: `sentPrompt` (the exact text typed),
`sentAt`, and increments `sendCount`. Outstanding = sent, not yet
terminal, no attributed UUID yet.

### 3.2 The attribution rule

A generated-origin catalog row R (UUID ∉ baseline, ∉ refMediaIds,
∉ consumed) is attributed to item I **iff** R's prompt verifies against
I's `sentPrompt` with the existing scorer (`exact` / prefix /
token-overlap ≥ 0.85 with a > 0.03 margin over the runner-up — the
boilerplate-tie protection from V2.6.2). Attribution is independent of
finish order, send order, retries, and interleaves — failure (c) has no
mechanism left:

- Out-of-order finishes: each row carries its own prompt. Order is
  irrelevant.
- Failure + retry: the failed send produces **no** generated row; its
  re-send produces a row with the same prompt, which fills the item
  then. A later send's row can never take the failed item's slot,
  because slots don't exist — only prompt equality does.
- Count > 1: up to `genCount` rows share the item's prompt; the first
  attributed row is the download, the rest are consumed as extras
  (existing quota bookkeeping, now keyed by verified rows).
- Late leftover: a row whose prompt matches an earlier, already-failed
  item revives and completes that item (the V2.6.2 reassign behaviour,
  now driven by the listing instead of a viewer round-trip).

### 3.3 Fallback ladder (when a row's prompt is missing, or no catalog)

Prompts in the listing can lag (captions/metadata are async). For a new
generated row with no prompt yet, in descending preference:

1. **Wait**: re-poll the catalog for up to 45 s; prompts normally land.
2. **Viewer verify** (matchMode `prompt` only): read the tile's prompt
   in Flow's viewer (existing `sfaTilePrompt` path, with the tile first
   scrolled into view via a new `sfaRevealTile(uuid)` probe) and score
   it the same way. Viewer work happens in a backlog, never blocking
   sends.
3. **Exclusivity**: if exactly ONE send is outstanding, attribute to it
   — sound by construction (this is the serial tools' guarantee).
4. **Park**: otherwise the row stays in `S.unclaimedUuids` and is
   re-examined on every later poll. It is **never** paired by order.
   If the owning item times out, it fails and retries; a parked row can
   still claim-match that item's re-send by prompt equality — and only
   by prompt equality.

### 3.4 Match modes (panel options kept, semantics repaired)

- **Prompt check** (default): ladder §3.3 in full (catalog → wait →
  viewer → exclusivity → park).
- **Fast order**: catalog → wait → exclusivity → park (skips the viewer
  step). It is *not* the old FIFO: V3 removes order-based pairing
  entirely, because that pairing is proven defect (c). The two modes
  now differ in verification depth and speed, never in safety. (This
  redefinition is called out in the delivery report.)

### 3.5 Errors are signals, not verdicts

DOM error tiles are still counted (delta vs baseline), but an error
delta no longer "consumes" an item:

- Classify the new error tile's text:
  - **Unusual activity** → global cooldown: sends pause for 60 s,
    doubling per consecutive hit (max 300 s), reset on the next
    success. **No item is charged an attempt.** (Research §1.5
    doctrine.) The run logs one line and the panel shows the cooldown
    in the live stage.
  - **Daily limit** → the run stops cleanly with a plain-language log
    line (nothing is broken; come back tomorrow or switch model).
  - **Generic** → if exactly one send is outstanding, it owns the
    error: click the tile's Retry (containment-verified, §6) up to 2×
    inside its wait, else charge that send's attempt. If several are
    outstanding (paced), charge nobody yet: each outstanding send is
    resolved by the catalog (row ⇒ fine) or by its own 240 s timeout
    (⇒ that send failed; retry it). Certainty over speed.
- The serial wait keeps its shape but its completion condition is now
  §3.2/§3.3, and its error handling follows the classification above.

## 4. Pacing modes

- **Serial (One by one)**: as today, one outstanding send; completion
  via the catalog-first wait (§3.5). Exclusivity makes attribution
  trivially sound even with the catalog down.
- **Paced**: sends at the configured interval as today; the watcher is
  the catalog poll (§3). Freeze-drain-repair is **deleted** — it existed
  to protect FIFO pairing, which no longer exists. A failed send is
  simply re-queued at the head after its timeout/elimination, exactly
  like the existing retry queue.

## 5. Resume integrity — saved state is the only truth

- `runSignature` = djb2 hash over `project`, the ordered
  `id + prompt` list, and `refFileName`, stored on the run at build
  time.
- The `start` handler: if incoming items' signature **equals** the
  saved signature and a saved run exists → **resume**: items, progress,
  `runStartedAt`, `runFolder`, `cycleSamples`, `baselineUuids`,
  `refMediaIds`, `consumedTiles` are all kept; only settings are
  refreshed. If the signature differs (or state was cleared) → build a
  fresh run exactly as today.
- The serial loop, paced loop, retry-failed, and single-retry paths
  already work from saved state; with the start contract fixed, Stop →
  Start, Pause → Start, panel reload → Start, and worker restart →
  Start all continue the same run. (Failure e) has no path left: the
  engine, not the button choice, decides.

## 6. Hang-proofing — budgets everywhere, watchdog above all

- **Every primitive bounded**: `cdp()` already races 8 s; `scriptFn`
  gains the same treatment (20 s). `fetchCatalog` 20 s. Downloads 90 s.
  All poll loops keep their deadlines.
- **Stage budgets**: a single `setStage(item, stage)` helper stamps
  `item.stage` + `item.stageSince`. A supervisor interval (5 s, alive
  while `S.running`) checks the currently-active item (and the paced
  sender) against a budget table (typing 60 s, ref-attach 150 s,
  start-check 45 s, waiting 300 s, downloading 180 s, cooldown exempt,
  default 300 s). Over-budget ⇒ log + `bumpAbortEpoch()` — the running
  wait throws ABORT and the item flow converts it to a failed attempt
  with reason `stage timeout`. Even an unknown-unknown hang now
  degrades to a retry, never a frozen run.
- **Fossil reconciliation**: when the worker loads state and finds
  `S.running === true` with no live loop in this worker instance (i.e.,
  always, at worker start), it reconciles immediately: `running=false`,
  active items → `pending` (stage cleared), one log line ("Engine
  restart hoyeche — Resume/Start diye baki kaj hobe"). The panel's
  existing stale-engine banner then tells the truth.
- **Tab pinning**: at run start, `chrome.tabs.update(tabId,
  {autoDiscardable:false})` (best-effort) so Memory Saver cannot freeze
  the Flow tab mid-run.
- The paced loop's watcher and sender stay sequential (simpler), but
  every step inside them is now individually budgeted, and the watchdog
  bounds the whole.

## 7. ETA — one funnel, persistent pace

- `completeItem` — the single funnel every completion passes through
  (serial, paced, repair, reassign, Download-Later generation) — records
  the cycle sample itself (`noteItemCycle`, now idempotent per
  item+send via `item.cycleNotedAt === item.sentAt` guard). The five
  scattered call sites become redundant-but-harmless.
- Samples persist across stop/resume of the same run (only a new
  signature resets them — §5).
- `refreshEta` keeps the last computed ETA when the run is merely
  paused/stopped with items remaining (panel shows it as the estimate
  of record instead of '—'); ETA is null only before the first
  completion of a run.

## 8. Settings apply

Unchanged from V2.6.1 (settings before reference; fail-soft; read-back
verify) plus: all clicks in the flow go through `guardedClick`, and the
error-tile Retry click gets its own verdict zone (`retry`: the point
must sit inside an error tile on a retry-labelled control, proven by
`sfaPointCheck` at click time).

## 9. What is deleted (simpler beats clever)

- `pacedAssign` (FIFO pairing) and the order logic of
  `pacedQuotaAssign` — replaced by §3 attribution (quota *counting*
  stays, driven by verified rows).
- Freeze-drain-repair (`fdrTransition` and the paced repair phase).
- `refPresenceVerdict` + grid-scan survival checks — replaced by §2
  listing presence.
- The busy-cycle completion fallback and the `lastUrl` download path —
  both could download an unverified tile.
- `waitForStartSignal`'s "any new tile" success signal narrows to
  busy-indicator or a new tile/error **in the DOM delta** — it only
  proves *a* generation started; attribution never relied on it, and
  the catalog wait confirms ours. (Kept as a start check, demoted from
  evidence.)

## 10. Proof plan (Phase 3)

- All existing node suites pass; assertions that encoded FIFO pairing,
  grid-survival, or the FDR machine are replaced by assertions of the
  V3 mechanisms (each replacement justified in the delivery report).
- New pure-layer tests: catalog normalization, attribution (out-of-order,
  retry interleave, boilerplate twins, Count quota, parked rows),
  listing presence, run signature/resume decision, stage budgets,
  error classification, ETA funnel.
- A **simulated Flow harness** (`tests/sim-harness.js`): the real
  background.js runs in a VM against a scripted fake Flow (fake DOM for
  the probes + a scripted catalog + a generation scheduler). Full
  40+-item batches for run mode × match strategy (4 runs), scripted
  with: out-of-order finishes, error tiles (incl. one unusual-activity),
  a late leftover, the reference sinking out of the DOM window, a
  re-upload tile appearing mid-run, and a mid-run Stop → Start.
  Pass bar: zero misnumbered downloads, zero reference downloads, zero
  hangs (wall-clock bound), resume continues at the correct item.

## As-built notes (implementation deltas, 2026-11-02)

- `sfaTiles` exports tile `text` capped at 240 chars (design said ~200) — the error classifier needs the full "Unusual activity" sentence.
- The ladder's "wait up to 45 s for the prompt to land" is realized as ladder rounds inside the existing bounded waits (serial: viewer rounds across 2.5 s polls; paced: one backlog tile per pass) rather than a separate timer — the 240 s wait bound governs.
- The guarded Retry click reuses the tile probe's pre-existing `retryBtn` export; no new point-verification zone was needed (persistence of the same error tile across 2 polls + a per-wait budget of 2 is the guard).
- `pacedCompletedNew` was also deleted: once the watcher went catalog-first it had no callers left (the Download-Later pass works from recorded media-ids).
- `pickAttributions` gained an identical-prompt rule found by test-v3: byte-identical prompts on multiple open sends are interchangeable by content, so their rows are dealt deterministically (oldest row → first such send) instead of dying on the exact-tie ambiguity rule that protects *different* prompts sharing a prefix.
- The serial DOM fallback (`waitForCompletionDom`) keeps its v2.6.2 verifyTile hook — it is the catalog-down path, and there the viewer prompt is the best available signal.

## Simulation-found defects (fixed during Phase 3 proof)

The simulated Flow harness caught four REAL engine defects that the
pure test suites could not - each is now covered by a regression
assertion in tests/test-v3.js:

1. **Bare `typeFails` ReferenceError** in sendPromptOnce's type-fail
   log line (the counter lives on `ctx`). It fired only when the
   first type attempt left the composer empty - i.e. exactly when
   the retry path was needed - and masked the real error.
2. **Dead error-tile filter**: the catalog wait and the paced
   watcher matched error tiles by `t.error`, but `sfaTiles` rows
   carry `kind: 'error'`. Error classification (cooldown / daily
   limit / guarded Retry) silently never ran in catalog mode; a
   failed send burned the full 240 s wait per attempt.
3. **`snap.ids.has` TypeError**: the snapshot's id list is an Array
   (the DOM wait uses indexOf/concat); the catalog wait used the
   Set API and crashed the attempt the first time an error tile
   existed.
4. **Stale error tiles**: error tiles persist in the grid after a
   failed send. The catalog wait's per-tile identity scheme
   re-read the stale tile as a fresh failure on the resend,
   re-triggering cooldown forever. Fixed by adopting the DOM
   wait's proven mechanism: a pre-send error COUNT baseline
   (snap.errorCount); only tiles above the baseline are new.

## Simulation-found defects, round 2 (fixed during the full-battery proof)

5. **Dead error classification (again, deeper)**: not only was the
   catalog wait's tile filter wrong - the paced watcher's seen-set
   used the same `t.error` field. Both now match on `kind==='error'`.
6. **Stale error tiles (count baseline)**: per-tile identity for
   error tiles was replaced by the DOM wait's pre-send error COUNT
   baseline (snap.errorCount) in the catalog wait - see defect 4 in
   round 1; the resend-after-cooldown case is covered by the sim's
   scene-9 script.
7. **Captured-URL downloads**: the download path now prefers the
   media URL captured when the tile was resolved at attribution
   time; a fresh lookup can come back empty after grid churn
   (uploads pushing finished tiles out of the virtualized window).
8. **No-guess viewer fallback**: `fallbackDownload` previously fell
   back to the FIRST image tile in the grid when its target tile
   was unresolvable - unverified content under an item's number.
   With a specific tile identity requested, it now fails honestly;
   the any-tile guess survives only for identity-less legacy calls.
9. Harness fidelity fixes (not engine defects): the downloads mock
   must invoke the callback form the engine uses; elementFromPoint
   must respect overlay layering (viewer > picker > composer bar >
   grid) or tiles laid out over the composer steal its clicks; the
   30-upload flood is staggered over ~20 s (a real multi-file
   upload is not instantaneous); the audit's ground truth is the
   prompt an asset was generated from (viewerPrompt), not the
   listing-exposed prompt, which is null for prompt-less rows.
