'use strict';
/* SHEIKH Flow Auto v3.0.1 unit tests — the catalog-failure fix.
 * The paced watcher attributed ONLY through the project listing; a
 * dead / prompt-less / candidate-less listing stalled a run in total
 * silence (run-report-4; reproduced by tests/repro-catalog.js).
 * v3.0.1 adds (1) the DOM ladder under the listing, (2) catalog
 * instrumentation + a preflight catalog line. These tests pin the
 * wiring; behaviour is proven by the sim battery (tests/sim-harness.js
 * with the -nocat / -notime / -noprompt combos). */
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');
let pass = 0, fail = 0;
function ok(c, m) { if (c) { pass++; } else { fail++; console.error('FAIL: ' + m); } }
function eq(a, b, m) { ok(a === b, m + ' (got ' + JSON.stringify(a) + ', want ' + JSON.stringify(b) + ')'); }
function has(src, s, m) { ok(src.indexOf(s) >= 0, m + ' — missing: ' + s.slice(0, 80)); }
function count(src, s) { return src.split(s).length - 1; }

const bg = fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8');
const panel = fs.readFileSync(path.join(ROOT, 'panel.js'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'panel.html'), 'utf8');
const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.json'), 'utf8'));

// ==== version ====
eq(manifest.version, '3.0.1', 'manifest version 3.0.1');
ok(html.includes('class="vtag">v3.0.1'), 'panel shows v3.0.1');

// ==== catalog instrumentation ====
has(bg, 'function noteCatalogHealth(res)', 'catalog health logger exists');
eq(count(bg, 'noteCatalogHealth('), 3, 'noteCatalogHealth: definition + success path + failure path');
has(bg, 'S.catalogStats', 'catalog stats kept on state');
has(bg, 'Catalog: listing paoa geche', 'catalog ok log line (rows + prompt count)');
has(bg, 'Catalog: listing paoa jacche na', 'catalog dead log line (DOM fallback named)');
has(bg, "sig = 'dead'", 'dead is a distinct health signature');
// the preflight probes the listing and reports it
has(bg, 'result.catalog = cat', 'preflight probes the catalog');
has(bg, 'catalog: null', 'preflight result carries a catalog field');

// ==== the DOM ladder ====
has(bg, 'async function pacedDomLadder(tabId, tiles, pending, genCount, wantKind, catalogAssigned)', 'DOM ladder exists');
has(bg, 'const domTileWatch = new Map()', 'per-tile poll tracking');
has(bg, 'const domClaimedUuids = new Set()', 'DOM-claim registry');
has(bg, 'S.catalogOk ? 3 : 2', 'escalation polls: 3 with a live catalog, 2 without');
has(bg, 'async function escalateDomTile(tabId, tile, pending, genCount, wantKind, allowExclusivity)', 'ladder escalation step exists');
has(bg, 'const maxEsc = catalogAssigned ? 1 : (cands.length >= 6 ? 3 : 2)', 'escalations only when the catalog assigned nothing');
has(bg, 'async function readTilePromptTwice(tabId, mediaId)', 'twice-read grid-shift guard exists');
has(bg, 'promptNormText(rd1.text) !== promptNormText(rd2.text)', 'twice-read requires agreement');
has(bg, 'const rd = await readTilePromptTwice(tabId, mediaId);', 'ladder step 1: viewer verify (twice-read)');
has(bg, 'const rd = await readTilePromptTwice(tabId, row.uuid);', 'catalog backlog viewer verify (twice-read)');
has(bg, 'matchPromptToItems(rd.text, pending.map', 'ladder matches the viewer text to outstanding sends');
has(bg, "pending.length === 1 && pending[0].sentAt", 'ladder step 2: exclusivity on one outstanding send');
has(bg, 'park kora holo (mediaId=', 'ladder step 3: park WITH a log line (never silence)');
has(bg, 'item.tileGot = (item.tileGot || 0) + 1', 'ladder claims through the quotaUuid funnel');
// reference + pre-existing tiles are untouchable
has(bg, 'refIds.has(id)', 'ladder never touches reference tiles');
has(bg, 'baseIds.has(id)', 'ladder never touches pre-run tiles');
has(bg, 'consumed.has(id)', 'ladder never touches consumed tiles');
// the watcher calls it outside the catalog block, and the catalog
// path can never re-claim a DOM-claimed row into a second item
has(bg, 'await pacedDomLadder(tabId, tilesP, pending, genCountP, wantKindP, catAssigned);', 'watcher runs the ladder every pass');
has(bg, '!domClaimedUuids.has(r.uuid)', 'catalog path excludes DOM-claimed rows');
eq(count(bg, 'resolveCatalogTile(tabId, uuid, wantKindP)'), 1, 'exactly one completion sweep (hoisted, shared)');
// the ladder revives failed items through the same row funnel
has(bg, 'await reviveFailedFromRows(tabId, [{ uuid: mediaId, prompt: rd.text', 'ladder revives failed items by viewer prompt');
// prompt-less tiles are a verdict, not a retry loop (upload floods
// must not burn viewer rounds or starve downloads)
has(bg, 'noPrompt: !!(vp && (vp.found || vp.overlayOpen))', 'viewer-open-but-textless is signalled via the overlay marker');
has(bg, 'overlayOpen: true', 'probe marks an open-but-prompt-less viewer (distinct from no viewer)');
// exclusivity may only claim a tile this run actually saw
// generating — a mid-run upload appears already finished, so it can
// never be exclusivity-claimed (the flood-upload wrong download)
has(bg, 'const domGenSeenUuids = new Set();', 'seen-generating registry exists');
has(bg, 'if (t && t.mediaId && t.hasPct) domGenSeenUuids.add(t.mediaId);', 'ladder records generating sightings from the full scan');
has(bg, 'allowExclusivity && domGenSeenUuids.has(mediaId) && !domPromptlessUuids.has(mediaId)', 'exclusivity requires a seen-generating, never-prompt-less tile');
has(bg, 'const sawNP = (rd1 && rd1.noPrompt) || (rd2 && rd2.noPrompt);', 'twice-read tracks any prompt-less open');
has(bg, 'const domPromptlessUuids = new Set();', 'prompt-less tile registry exists');
has(bg, '!domPromptlessUuids.has(mediaId) && pending.length === 1', 'exclusivity never claims a prompt-less tile');
has(bg, 'if (rd && rd.noPrompt)', 'ladder parks prompt-less tiles at once');
// downloads drain BEFORE the ladder runs (a claimed tile must never
// wait behind ladder viewer reads while the grid churns)
ok(bg.indexOf('resolveCatalogTile(tabId, uuid, wantKindP)') < bg.indexOf('await pacedDomLadder('), 'completion sweep runs before the DOM ladder');
has(bg, 'if (item.quotaUuid && (item.tileGot || 0) >= genCountP) continue;', 'timeout sweep skips fully-claimed items');
// elimination timeout is patient while the ladder has unprocessed
// tiles (capped extensions) — a flood must not fail live items
has(bg, 'let ladderBacklog = 0;', 'ladder backlog is tracked');
has(bg, 'ladderBacklog > 0 && (item.ladderExtensions || 0) < 4', 'timeout extensions are capped at 4');
has(bg, 'item.timeoutBoostUntil = nowMs + 60000', 'extension is +60s of patience');
has(bg, "cands.length >= 6 ? 3 : 2", 'escalations scale with the backlog');

// ==== recovery gate: a picker miss is not proof of loss ====
// (the flood buries the sheet in the virtualized picker; the old
// code re-uploaded a sheet that was never lost)
has(bg, 'async function recoverReferenceIfProvenAbsent(tabId)', 'proven-absence recovery gate exists');
has(bg, "if (pres.status !== 'absent')", 'recovery fires only on listing-proven absence');
has(bg, 'const ok = await recoverReferenceIfProvenAbsent(tabId).catch(() => false);', 'picker-failure path goes through the gate');
eq(count(bg, 'recoverReference(tabId)'), 2, 'recoverReference is defined once and called once — inside the gate');
eq(count(bg, 'recoverReference(tab.id)'), 1, 'the run-start survival verify keeps its direct call (already listing-gated via refPresentInProject)');
has(bg, 'Reference recovery hobe na — listing nai', 'gate logs its refusal when the listing is dead (never silence)');
// resume must not re-upload a sheet whose upload this run already
// recorded — grid rediscovery cannot prove a recorded asset gone
has(bg, 'if (!cat0 && S.refMediaId)', 'no-listing + recorded id: ensureReference trusts the record');
has(bg, 'Listing nai — record kora reference id diyei cholche', 'trust-the-record path is logged (never silence)');
ok(bg.indexOf('if (!cat0 && S.refMediaId)') > bg.indexOf('const cat0 = await fetchCatalog(tabId)'), 'trust check sits after the catalog verdict (proven absence still uploads)');

// ==== panel: the catalog preflight line ====
has(panel, "if (r.catalog)", 'panel renders the catalog line when probed');
has(panel, "t('pfCatalogBad')", 'panel: catalog unreachable line');
has(panel, "t('pfCatalogNoPrompts', { n: r.catalog.rows })", 'panel: catalog prompt-less line');
has(panel, "t('pfCatalogOk', { n: r.catalog.rows, m: r.catalog.prompts })", 'panel: catalog healthy line');
ok(!/pfCatalog[\s\S]{0,120}cls: 'bad'/.test(panel), 'catalog lines are never bad-level (a dead catalog must not block Start)');
const langs = ['en', 'bn', 'hi', 'tr', 'fr', 'de', 'it', 'es'];
for (const L of langs) {
  const block = panel.split(new RegExp('^' + L + ': \\{', 'm'))[1] || '';
  for (const k of ['pfCatalogOk', 'pfCatalogNoPrompts', 'pfCatalogBad', 'checkShortCatalog']) {
    ok(block.indexOf(k + ':') >= 0, L + ' dict has ' + k);
  }
}

// ==== serial mode untouched by the ladder ====
const serialRegion = bg.slice(bg.indexOf('async function runSerialLoop'), bg.indexOf('async function pacedUnverifiedRow'));
ok(serialRegion.indexOf('pacedDomLadder') < 0, 'serial loop never calls the DOM ladder');
const waitRegion = bg.slice(bg.indexOf('async function waitForCompletion('), bg.indexOf('async function runSerialLoop'));
ok(waitRegion.indexOf('return waitForCompletionDom(tabId, snap, item, opts)') >= 0, 'serial DOM fallback intact');

console.log('\ntest-v301: ' + pass + ' passed, ' + fail + ' failed');
if (fail) { console.error('SOME TESTS FAILED'); process.exit(1); }
console.log('ALL TESTS PASSED');
