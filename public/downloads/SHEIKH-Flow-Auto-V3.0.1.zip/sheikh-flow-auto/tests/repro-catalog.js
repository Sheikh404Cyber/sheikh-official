'use strict';
/* v3.0.1 — REPRODUCTION driver for the paced catalog-failure dead
 * states (Phase 1 evidence, run against the PRE-FIX engine).
 *
 * Boots the real engine against the fake Flow with a broken listing
 * (combo suffix: -nocat / -noprompt / -notime) and watches one simple
 * fact: the fake page finishes generating every image, yet the engine
 * completes/downloads NOTHING.
 *
 * Verdict REPRODUCED = all N fake generations exist, >=45s of watcher
 * time passed since the last one appeared, engine done == 0 and
 * downloads == 0. Run one case per process:
 *   SIM_ITEMS=8 node tests/repro-catalog.js paced-prompt-nocat
 */
process.env.SIM_EXPORT = '1';
const { FakeFlow, makeScenario, bootEngine, ITEMS } = require('./sim-harness.js');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function runCase(combo) {
  const scenario = makeScenario(combo);
  const flow = new FakeFlow(scenario);
  const engine = bootEngine(flow);
  const settings = {
    refMode: 'all', refReady: true, refFileName: 'ref-sheet.png',
    autoDownload: true, quality: '1K', datedFolder: false, retryAtEnd: false,
    intervalSec: 1,
    runMode: combo.indexOf('paced') === 0 ? 'paced' : 'serial',
    matchMode: combo.indexOf('-fast') >= 0 ? 'fast' : 'prompt',
    genType: 'image', genModel: 'Nano Banana 2.1', genRatio: '16:9', genCount: 1
  };
  await engine.send({ type: 'start', items: ITEMS.map((i) => ({ ...i })), project: 'ReproProject', settings, tabId: 1 });
  const N = ITEMS.length;
  const t0 = Date.now();
  let lastGenAt = 0;
  let lastGenCount = 0;
  let verdict = null;
  while (Date.now() - t0 < 420000) {
    const genDone = Array.from(flow.assets.values()).filter((a) => a.origin === 'generated' && a.state === 'done').length;
    if (genDone !== lastGenCount) { lastGenCount = genDone; lastGenAt = Date.now(); }
    const gs = await engine.send({ type: 'getState' });
    const st = gs.state;
    const done = st.items.filter((i) => i.status === 'done').length;
    const failed = st.items.filter((i) => i.status === 'failed').length;
    const dls = Array.from(engine.downloads.records.values()).filter((r) => r.state === 'complete').length;
    if (genDone >= N && lastGenAt && Date.now() - lastGenAt >= 45000) {
      verdict = { reproduced: done === 0 && dls === 0, genDone, done, failed, dls, waitedAfterLastGenSec: Math.round((Date.now() - lastGenAt) / 1000), logTail: st.log.slice(-15) };
      break;
    }
    if (done > 0 || dls > 0) {
      verdict = { reproduced: false, genDone, done, failed, dls, note: 'engine completed/downloaded something — dead state NOT present', logTail: st.log.slice(-15) };
      break;
    }
    await sleep(2000);
  }
  if (!verdict) verdict = { reproduced: false, note: 'observation window ended without a verdict', genDone: lastGenCount };
  await engine.send({ type: 'stop' }).catch(() => {});
  console.log(JSON.stringify({ combo, catalogMode: scenario.catalogMode, items: N, ...verdict }, null, 1));
  process.exit(verdict.reproduced ? 0 : 1);
}

runCase(process.argv[2] || 'paced-prompt-nocat').catch((e) => { console.error('REPRO ERROR: ' + (e && e.stack || e)); process.exit(2); });
