# SHEIKH Flow Auto V3.0.1 - simulation results (catalog-failure fix)

Final battery, 2026-11-02 (tests/sim-harness.js; jsdom fake Flow;
same ground-truth audit bar as V3.0). The four standard combos ran
at the full 42 items; the catalog-failure combos (-nocat = listing
unreachable, -notime = listing rows without usable timestamps) ran
at 12 items, the size the failure modes need to manifest.

| combo                | items | result | wall  |
|----------------------|-------|--------|-------|
| serial-prompt        | 42    | PASS   | 630 s |
| serial-fast          | 42    | PASS   | 543 s |
| paced-prompt         | 42    | PASS   | 573 s |
| paced-fast           | 42    | PASS   | 548 s |
| paced-prompt-nocat   | 12    | PASS   | 657 s |
| paced-fast-nocat     | 12    | PASS   | 657 s |
| serial-prompt-nocat  | 12    | PASS   | 142 s |
| paced-prompt-notime  | 12    | 11/12  | 226 s |

paced-prompt-notime's single failure (item 011) is a compound
harness-window edge, not an attribution error: the item's claimed
tile could not be downloaded (it sat outside the fake grid's
render window through every reveal retry), its resend then hit the
fake picker's 40-option window, which no longer contained the
reference — and the recovery gate correctly refused a re-upload
because the listing proved the reference present. No wrong-content
download, no upload-origin download, reference uploaded exactly
once; the item failed honestly with the picker reason.

What V3.0.1 fixes (each sim-proven; raw results in
~/workspace/v301-sim/final/):
1. The DOM ladder under the listing (paced): in V3.0 a dead /
   prompt-less / candidate-less listing left paced mode with NO
   assignment path — sends ran, generations finished, zero
   downloads, zero log lines (Amin's live run-report-4;
   pre-fix state reproduced by tests/repro-catalog.js).
2. Exclusivity could claim a mid-run UPLOAD tile (wrong download,
   paced-fast-nocat): a prompt-less viewer and a never-opened
   viewer were indistinguishable, so the prompt-less bar never
   fired. Fixed structurally — the viewer probe now marks an
   open-but-prompt-less viewer (overlayOpen), and exclusivity may
   only claim a tile the run actually saw generating (hasPct).
3. Viewer reads are taken twice and must agree (grid-shift race
   produced off-by-one wrong-content downloads in noprompt /
   notime states).
4. The picker-failure reference recovery re-uploaded a sheet that
   was never lost (the flood buries it in the virtualized picker).
   Recovery now fires only on listing-proven absence.
5. A Stop -> Start resume in a dead-catalog project re-uploaded
   the reference: ensureReference's grid rediscovery cannot prove
   a recorded asset gone, so a recorded id is now trusted when no
   listing can prove absence.
6. Catalog instrumentation: one log line on every health change
   (reachable / rows / prompts), and a Catalog verdict line in the
   Flow Tab Check — a dead catalog is visible before a run starts,
   never discovered from a silent run report.

# SHEIKH Flow Auto V3.0 - simulation results

Final battery, 2026-11-02 (tests/sim-harness.js; jsdom fake Flow;
42 items per combo; scripted adversities: out-of-order finishes,
generic error tile + guarded Retry (scene 7), unusual-activity
error + 60s cooldown with attempt refund (scene 9, prompt modes),
late duplicate tile at +25s (scene 11), prompt-less catalog row
(scene 21), 30-upload flood at the 15th tile sinking the reference
out of the 27-tile window, duplicate reference upload at the 18th
tile, mid-run Stop at 20 done -> Start with the same list).

| combo          | result | wall  |
|----------------|--------|-------|
| serial-prompt  | PASS   | 616 s |
| serial-fast    | PASS   | 527 s |
| paced-prompt   | PASS   | 504 s |
| paced-fast     | PASS   | 486 s |

PASS bar (audited from ground truth, not engine claims): all 42
items done; exactly one download per item; every downloaded
asset's true generating prompt equals that item's prompt; zero
upload-origin downloads; reference uploaded exactly once;
runStartedAt unchanged across the Stop -> Start (resume, not
restart).

Real engine defects the harness caught and that are now fixed
(each with a regression assertion in tests/test-v3.js):
1. bare `typeFails` ReferenceError in the type-retry log line;
2. error tiles matched by `t.error` instead of `kind==='error'`
   (dead classification in the catalog wait AND the paced watcher);
3. `snap.ids.has` on an Array snapshot;
4. stale error tiles re-failing resends (fixed with the DOM wait's
   pre-send error-count baseline);
5. downloads re-looked-up after grid churn instead of using the
   URL captured at resolution time;
6. viewer fallback guessing the first grid tile when its target
   was unresolvable (now fails honestly with a tile identity).
