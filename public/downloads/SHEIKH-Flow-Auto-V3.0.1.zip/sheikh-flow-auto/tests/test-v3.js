'use strict';
/* SHEIKH Flow Auto v3.0.1 unit tests — the V3 mechanisms at the pure
 * layer:
 *   - sfaProjectData: the listing probe — envelope walking, media
 *     kind/origin discrimination (generatedImage vs userUploadedImage),
 *     prompt recovery from requestData, displayName via workflows,
 *     and total failure => {ok:false} (never throws).
 *   - pickAttributions: content-true attribution — out-of-order
 *     finishes, failure+retry interleave (THE V2.6.1 defect case),
 *     boilerplate twins, identical prompts, Count quota with carried
 *     got, prompt-less rows returned unverified (never paired).
 *   - classifyErrorText / catalogRefPresence / runSignatureFor /
 *     shouldResumeRun / stage budgets / noteItemCycle dedupe.
 * Run: node tests/test-v3.js */
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');

let pass = 0, fail = 0;
function ok(cond, label) {
  if (cond) { pass++; }
  else { fail++; console.log('FAIL: ' + label); }
}
function eq(a, b, label) { ok(JSON.stringify(a) === JSON.stringify(b), label + ` — got ${JSON.stringify(a)}, want ${JSON.stringify(b)}`); }

const bg = fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8');

function extractFn(srcText, name) {
  const start = srcText.indexOf('function ' + name + '(');
  if (start === -1) throw new Error('function not found: ' + name);
  let i = srcText.indexOf('{', start);
  let depth = 0;
  for (; i < srcText.length; i++) {
    if (srcText[i] === '{') depth++;
    else if (srcText[i] === '}') { depth--; if (depth === 0) break; }
  }
  return srcText.slice(start, i + 1);
}
function revive(srcText, name, prelude) {
  return new Function('"use strict";\n' + (prelude || '') + extractFn(srcText, name) + '\nreturn ' + name + ';')();
}
const AsyncFunction = Object.getPrototypeOf(async function () {}).constructor;
function reviveAsync(srcText, name, prelude) {
  return new AsyncFunction('"use strict";\n' + (prelude || '') + 'async ' + extractFn(srcText, name) + '\nreturn ' + name + ';')();
}
const promptDeps = extractFn(bg, 'promptNormText') + '\n' + extractFn(bg, 'promptTokenSet') + '\n' +
  extractFn(bg, 'promptExactMatch') + '\n' + extractFn(bg, 'promptOverlapScore') + '\n' + extractFn(bg, 'matchPromptToItems');
const pickAttributions = revive(bg, 'pickAttributions', promptDeps);
const classifyErrorText = revive(bg, 'classifyErrorText');
const catalogRefPresence = revive(bg, 'catalogRefPresence');
const hashStrV3 = revive(bg, 'hashStrV3');
const runSignatureFor = revive(bg, 'runSignatureFor', extractFn(bg, 'hashStrV3'));
const shouldResumeRun = revive(bg, 'shouldResumeRun');
function extractConst(srcText, name) {
  const start = srcText.indexOf('const ' + name + ' = {');
  if (start === -1) throw new Error('const not found: ' + name);
  const end = srcText.indexOf('};', start);
  return srcText.slice(start, end + 2).replace('const ' + name, 'var ' + name);
}
const stageBudgetFor = revive(bg, 'stageBudgetFor', extractConst(bg, 'STAGE_BUDGETS_V3'));
const stageOverBudget = revive(bg, 'stageOverBudget', extractConst(bg, 'STAGE_BUDGETS_V3') + '\n' + extractFn(bg, 'stageBudgetFor'));

/* ---------- sfaProjectData: the listing probe ---------- */
{
  const payload = {
    result: { data: { json: {
      media: [
        { name: 'gen-1', image: { generatedImage: { seed: 1 } }, mediaMetadata: { createTime: '2026-11-02T00:00:01.000Z' },
          requestData: { imagesRequest: { promptText: 'A baker puts a tray of bread into a brick oven at sunrise, wide shot' } } },
        { name: 'upl-1', image: { userUploadedImage: {} }, mediaMetadata: { createTime: '2026-11-01T00:00:01.000Z' } },
        { name: 'vid-1', video: { generatedVideo: {} }, mediaMetadata: { createTime: '2026-11-02T00:00:02.000Z' },
          requestData: { prompt: 'Waves crash over a harbour wall during a storm at dusk, slow motion' } },
        { name: 'gen-noprompt', image: { generatedImage: {} }, mediaMetadata: { createTime: '2026-11-02T00:00:03.000Z' } }
      ],
      workflows: [
        { name: 'wf-1', metadata: { primaryMediaId: 'gen-1', displayName: 'A baker puts a tray of bread', createTime: '2026-11-02T00:00:01.000Z' } },
        { name: 'wf-2', metadata: { primaryMediaId: 'upl-1', displayName: 'ref-sheet.png', createTime: '2026-11-01T00:00:01.000Z' } }
      ]
    } } }
  };
  const prelude =
    'var location = { pathname: "/fx/tools/flow/project/abc123def4567890", origin: "https://labs.google" };\n' +
    'var __payload = ' + JSON.stringify(payload) + ';\n' +
    'var fetch = async function () { return { ok: true, json: async function () { return __payload; } }; };\n';
  (async () => {
    const sfaProjectData = await reviveAsync(bg, 'sfaProjectData', prelude);
    const res = await sfaProjectData();
    eq(res.ok, true, 'listing probe: envelope payload parses');
    eq(res.projectId, 'abc123def4567890', 'listing probe: project id from URL');
    eq(res.media.length, 4, 'listing probe: all media rows normalized');
    const g1 = res.media.find((r) => r.uuid === 'gen-1');
    eq(g1.kind, 'image', 'listing probe: image kind');
    eq(g1.origin, 'generated', 'listing probe: generatedImage -> generated origin');
    ok(g1.prompt.indexOf('baker puts a tray') !== -1, 'listing probe: prompt recovered from nested requestData');
    eq(g1.displayName, 'A baker puts a tray of bread', 'listing probe: displayName joined from workflows');
    ok(g1.createdAt > 0, 'listing probe: createdAt parsed');
    const u1 = res.media.find((r) => r.uuid === 'upl-1');
    eq(u1.origin, 'upload', 'listing probe: userUploadedImage -> upload origin');
    eq(u1.prompt, '', 'listing probe: uploads carry no prompt');
    eq(u1.displayName, 'ref-sheet.png', 'listing probe: upload keeps its filename');
    const v1 = res.media.find((r) => r.uuid === 'vid-1');
    eq(v1.kind, 'video', 'listing probe: video kind');
    ok(v1.prompt.indexOf('Waves crash') !== -1, 'listing probe: direct requestData.prompt recovered');
    const np = res.media.find((r) => r.uuid === 'gen-noprompt');
    eq(np.prompt, '', 'listing probe: a generated row without requestData yields an empty prompt (ladder case)');

    // failure shapes never throw
    const badFetch = await reviveAsync(bg, 'sfaProjectData',
      'var location = { pathname: "/fx/tools/flow/project/abc123def4567890", origin: "https://labs.google" };\n' +
      'var fetch = async function () { throw new Error("net down"); };\n');
    eq((await badFetch()).ok, false, 'listing probe: fetch failure -> ok:false');
    const badShape = await reviveAsync(bg, 'sfaProjectData',
      'var location = { pathname: "/fx/tools/flow/project/abc123def4567890", origin: "https://labs.google" };\n' +
      'var fetch = async function () { return { ok: true, json: async function () { return { something: "else" }; } }; };\n');
    eq((await badShape()).ok, false, 'listing probe: unrecognized shape -> ok:false');
    const noProj = await reviveAsync(bg, 'sfaProjectData',
      'var location = { pathname: "/fx/tools/flow", origin: "https://labs.google" };\n' +
      'var fetch = async function () { return { ok: true, json: async function () { return {}; } }; };\n');
    eq((await noProj()).ok, false, 'listing probe: no project id -> ok:false');
    runSyncTests();
  })().catch((e) => { console.log('FAIL: listing probe suite threw — ' + (e && e.stack || e)); process.exit(1); });
}

function runSyncTests() {
  /* ---------- classifyErrorText ---------- */
  {
    eq(classifyErrorText('Failed to generate. Unusual activity detected.'), 'unusual', 'error class: unusual activity');
    eq(classifyErrorText('unusual activity'), 'unusual', 'error class: bare unusual');
    eq(classifyErrorText('Daily limit reached for this model'), 'limit', 'error class: daily limit');
    eq(classifyErrorText('You have reached your quota'), 'limit', 'error class: quota');
    eq(classifyErrorText('Failed to generate. Something went wrong.'), 'generic', 'error class: generic failure');
    eq(classifyErrorText(''), 'generic', 'error class: empty text is generic');
    eq(classifyErrorText(null), 'generic', 'error class: null text is generic');
  }

  /* ---------- pickAttributions ---------- */
  const BOILER = ' Editorial Economic Storybook illustration, ivory paper background, navy and charcoal ink, flat 2D hand-drawn style, no text in image.';
  const PA = 'A woman baker in a cream apron puts a tray of bread into a brick oven at sunrise.' + BOILER;
  const PB = 'A fisherman mends a torn net beside a wooden boat on a quiet harbour wall.' + BOILER;
  const PC = 'A clerk stamps a tall stack of claim tickets at a wooden counter in a post office.' + BOILER;
  const row = (uuid, prompt, createdAt) => ({ uuid, prompt, kind: 'image', createdAt: createdAt || 0 });
  {
    // out-of-order: B finished first, both rows in one pass
    const r = pickAttributions([row('tB', PB, 2000), row('tA', PA, 1000)],
      [{ id: 'A', prompt: PA, got: 0, quota: 1 }, { id: 'B', prompt: PB, got: 0, quota: 1 }]);
    eq(r.assign.map((a) => [a.itemId, a.uuid]).sort(), [['A', 'tA'], ['B', 'tB']], 'attr: out-of-order rows land on their prompt owners');
    // THE V2.6.1 DEFECT: A's send failed and was re-sent AFTER B was
    // sent; A's retry row and B's row arrive together — FIFO gave B's
    // row to A. Prompt attribution cannot.
    const r2 = pickAttributions([row('tB', PB, 3000), row('tA2', PA, 4000)],
      [{ id: 'A', prompt: PA, got: 0, quota: 1 }, { id: 'B', prompt: PB, got: 0, quota: 1 }]);
    eq(r2.assign.map((a) => [a.itemId, a.uuid]).sort(), [['A', 'tA2'], ['B', 'tB']], 'attr: failure+retry interleave cannot shift numbers');
    // boilerplate twins: identical suffix, distinct heads
    const r3 = pickAttributions([row('tX', PB, 1000)], [{ id: 'A', prompt: PA, got: 0, quota: 1 }, { id: 'B', prompt: PB, got: 0, quota: 1 }]);
    eq(r3.assign.map((a) => a.itemId), ['B'], 'attr: boilerplate twin resolves to the true head, not the shared suffix');
    // identical prompts on two items: deterministic oldest-row -> first-listed send
    const r4 = pickAttributions([row('t1', PA, 1000), row('t2', PA, 2000)],
      [{ id: 'A', prompt: PA, got: 0, quota: 1 }, { id: 'B', prompt: PA, got: 0, quota: 1 }]);
    eq(r4.assign.map((a) => [a.itemId, a.uuid]), [['A', 't1'], ['B', 't2']], 'attr: identical prompts dealt oldest-row first');
    // quota with carried got: A already has 1 of 2; one more row completes it as an extra-slot primary rule
    const r5 = pickAttributions([row('tA2', PA, 2000)], [{ id: 'A', prompt: PA, got: 1, quota: 2 }]);
    eq(r5.assign.length, 1, 'attr: carried-got quota accepts the filling row');
    eq(r5.sends[0].got, 2, 'attr: got advances to quota');
    // quota full: further same-prompt rows are NOT attributed
    const r6 = pickAttributions([row('tZ', PA, 2000)], [{ id: 'A', prompt: PA, got: 1, quota: 1 }]);
    eq(r6.assign, [], 'attr: quota-full item takes nothing more');
    eq(r6.unverified.map((x) => x.uuid), ['tZ'], 'attr: surplus row stays unverified (consumed by caller as foreign/parked)');
    // Count=2 from zero: first row primary, second extra
    const r7 = pickAttributions([row('t1', PA, 1000), row('t2', PA, 2000)], [{ id: 'A', prompt: PA, got: 0, quota: 2 }]);
    eq(r7.assign.map((a) => [a.uuid, a.extra]), [['t1', false], ['t2', true]], 'attr: count quota — first row downloads, second is an extra');
    // prompt-less + foreign-prompt rows are never paired
    const r8 = pickAttributions([row('tN', '', 1000), row('tF', 'A pirate ship sails into a neon sunset over a chrome ocean.' + BOILER, 2000)],
      [{ id: 'A', prompt: PA, got: 0, quota: 1 }]);
    eq(r8.assign, [], 'attr: prompt-less and foreign rows are assigned to NOBODY');
    eq(r8.unverified.map((x) => x.uuid), ['tN', 'tF'], 'attr: both come back unverified for the ladder');
    // a row matching a LATER send while an earlier is outstanding: fine (content decides)
    const r9 = pickAttributions([row('tC', PC, 1000)],
      [{ id: 'A', prompt: PA, got: 0, quota: 1 }, { id: 'B', prompt: PB, got: 0, quota: 1 }, { id: 'C', prompt: PC, got: 0, quota: 1 }]);
    eq(r9.assign.map((a) => a.itemId), ['C'], 'attr: only the matching send is completed');
  }

  /* ---------- catalogRefPresence with an identity SET ---------- */
  {
    const R = (uuid, origin, displayName) => ({ uuid, origin: origin || 'generated', displayName: displayName || '', kind: 'image', prompt: '', createdAt: 0 });
    const cat = { media: [R('newgen', 'generated'), R('upl-2', 'upload', 'ref-sheet.png')] };
    eq(catalogRefPresence(cat, ['upl-1', 'upl-2'], 'ref-sheet.png').id, 'upl-2', 'presence: ANY uuid of the identity set counts');
    eq(catalogRefPresence(cat, ['upl-1'], 'other.png').status, 'absent', 'presence: set miss + name miss on a complete listing -> absent');
    eq(catalogRefPresence(cat, ['upl-1'], 'ref-sheet.png').adopt, true, 'presence: re-upload under the same filename is adoptable');
  }

  /* ---------- run signature + resume decision ---------- */
  {
    const items = [{ id: '001', prompt: 'alpha prompt one' }, { id: '002', prompt: 'beta prompt two' }];
    const sig = runSignatureFor('Proj', items, 'ref.png');
    eq(runSignatureFor('Proj', items.map((i) => ({ ...i })), 'ref.png'), sig, 'signature: stable for the same run');
    ok(runSignatureFor('Proj', [items[1], items[0]], 'ref.png') !== sig, 'signature: order-sensitive');
    ok(runSignatureFor('Proj', items, 'other.png') !== sig, 'signature: reference-sensitive');
    ok(runSignatureFor('Other', items, 'ref.png') !== sig, 'signature: project-sensitive');
    ok(runSignatureFor('Proj', [{ id: '001', prompt: 'alpha prompt CHANGED' }, items[1]], 'ref.png') !== sig, 'signature: prompt-sensitive');
    const saved = [{ id: '001', status: 'done' }, { id: '002', status: 'pending' }];
    eq(shouldResumeRun(sig, saved, sig), true, 'resume: same signature + progress -> resume');
    eq(shouldResumeRun(sig, [{ id: '001', status: 'pending' }, { id: '002', status: 'pending' }], sig), false, 'resume: same signature but NO progress -> fresh is fine');
    eq(shouldResumeRun(sig, saved, 'different'), false, 'resume: different signature -> fresh');
    eq(shouldResumeRun('', saved, sig), false, 'resume: no saved signature -> fresh');
    eq(shouldResumeRun(sig, [{ id: '001', status: 'pending', attempts: 2 }], sig), true, 'resume: attempts count as progress');
    eq(shouldResumeRun(sig, [{ id: '001', status: 'pending', tileMediaId: 'x' }], sig), true, 'resume: a recorded tile counts as progress');
  }

  /* ---------- stage budgets ---------- */
  {
    eq(stageBudgetFor('gen shuru check'), 45000, 'budget: start-check stage is tight (45s)');
    eq(stageBudgetFor('waiting 24s'), 300000, 'budget: counter suffix is stripped before lookup');
    eq(stageBudgetFor('waiting'), 300000, 'budget: waiting matches the 240s wait + margin');
    eq(stageBudgetFor('ref bosano hocche'), 150000, 'budget: ref attach gets the picker-chain budget');
    eq(stageBudgetFor('some brand new stage'), 300000, 'budget: unknown stages get the default');
    eq(stageOverBudget('gen shuru check', 1000, 1000 + 45001), true, 'budget: over budget fires');
    eq(stageOverBudget('gen shuru check', 1000, 1000 + 44999), false, 'budget: under budget is quiet');
    eq(stageOverBudget('waiting 130s', 0, 99999999), false, 'budget: no start stamp -> never fires');
  }

  /* ---------- noteItemCycle: one sample per send (ETA funnel) ---------- */
  {
    const S = { cycleSamples: [] };
    const prelude = 'var S = ' + JSON.stringify(S) + ';\n';
    const noteItemCycle = revive(bg, 'noteItemCycle', prelude);
    // revive closes over its own S; reach it back via a fresh global trick:
    const item = { sentAt: 1000, completedAt: 1600 };
    noteItemCycle(item); noteItemCycle(item); noteItemCycle(item);
    eq(item.cycleNotedFor, 1000, 'eta funnel: the send is marked noted');
    item.sentAt = 5000; item.completedAt = 5900;
    noteItemCycle(item);
    eq(item.cycleNotedFor, 5000, 'eta funnel: a NEW send earns a NEW sample');
  }

  /* ---------- wiring: v3 architecture present, v2 mechanisms absent ---------- */
  {
    ok(bg.includes('async function sfaProjectData('), 'v3: listing probe exists');
    ok(bg.includes('async function fetchCatalog('), 'v3: catalog layer exists');
    ok(bg.includes('function attributionCandidates('), 'v3: candidate filter exists');
    ok(bg.includes('function candidateRowsWithParked('), 'v3: parked rows are re-examined');
    ok(bg.includes('async function reviveFailedFromRows('), 'v3: late-leftover revival exists');
    ok(bg.includes('function watchdogTick('), 'v3: stage watchdog exists');
    ok(bg.includes('S.watchdogUnwind'), 'v3: watchdog unwind flag wired');
    ok(bg.includes('runSignatureFor(') && bg.includes('shouldResumeRun('), 'v3: start=resume decision wired');
    ok(bg.includes('autoDiscardable: false'), 'v3: Flow tab pinned against Memory Saver');
    ok(bg.includes('refMediaIds'), 'v3: reference identity is a set');
    ok(!bg.includes('function pacedAssign('), 'v3: FIFO pacedAssign deleted');
    ok(!bg.includes('function pacedQuotaAssign('), 'v3: order-quota assigner deleted');
    ok(!bg.includes('function pacedPromptAssign('), 'v3: viewer assigner (FIFO fallback) deleted');
    ok(!bg.includes('function fdrTransition('), 'v3: freeze-drain-repair deleted');
    ok(!bg.includes('function refPresenceVerdict('), 'v3: grid-scan survival verdict deleted');
    ok(!bg.includes('viaBusy'), 'v3: busy-cycle download rescue deleted');
    ok(bg.includes("(fail ' + ctx.typeFails"), 'v3: type-fail log uses ctx.typeFails (bare-name ReferenceError found by the sim)');
    ok(!bg.includes('(t) => t.error') && !bg.includes('!et.error'), 'v3: error tiles matched by kind==="error" everywhere (t.error was a dead filter, found by the sim)');
    ok(bg.includes('let errBase = (snap && snap.errorCount) || 0'), 'v3: catalog wait baselines error tiles on the pre-send count (stale tiles cannot re-fail a resend)');
    ok(bg.includes('Retries exhausted or no Retry on offer'), 'v3: catalog wait fails a dead send fast instead of burning 240s');
    ok(!bg.includes('snap.ids.has'), 'v3: snap.ids is an Array - no Set API on it (found by the sim)');
    ok(bg.includes("((tile && tile.url) || '')"), 'v3: download prefers the URL captured at resolution time (grid churn cannot strand a verified tile)');
    ok(bg.includes('guessing ANOTHER tile would'), 'v3: viewer fallback never guesses an unrelated tile when a specific tile was requested');
    const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.json'), 'utf8'));
    eq(manifest.version, '3.0.1', 'manifest version 3.0.1');
  }

  console.log(`\ntest-v3: ${pass} passed, ${fail} failed`);
  if (fail) process.exit(1);
  console.log('ALL TESTS PASSED');
}
