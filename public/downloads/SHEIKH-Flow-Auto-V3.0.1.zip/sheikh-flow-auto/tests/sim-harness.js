'use strict';
/* SHEIKH Flow Auto v3 — SIMULATED FLOW HARNESS.
 *
 * Runs the REAL background.js end-to-end against a scripted fake
 * Google Flow page (jsdom): the engine's own probes execute in the
 * page context via the mocked chrome.debugger Runtime.evaluate, its
 * clicks/keys arrive through the mocked CDP Input channel and land on
 * fake DOM elements by coordinates, and the project listing the V3
 * truth layer reads is served by a stubbed page fetch in the exact
 * tRPC envelope shape the probe normalizes.
 *
 * Ground truth: every generated asset's catalog prompt is known to
 * the harness. A run PASSES only if every download's filename id owns
 * the downloaded asset's prompt (content-true attribution), the
 * reference is never downloaded, exactly one reference upload ever
 * happens, and the batch finishes inside its wall-clock bound.
 *
 * Adversities scripted per run: out-of-order finishes, a generic
 * error tile + Retry (serial), an unusual-activity error tile +
 * cooldown (serial prompt run), a prompt-less catalog row (ladder:
 * viewer in prompt mode, exclusivity in fast mode), a late duplicate
 * row for an already-done item, the reference sinking out of the
 * 27-tile grid window mid-run, a duplicate re-upload asset appearing
 * mid-run, and a mid-run Stop -> Start with the same list (resume).
 *
 * Needs jsdom:  npm --prefix tests/.simdeps i jsdom
 * Run:          node tests/sim-harness.js [combo ...]
 * Combos: serial-prompt serial-fast paced-prompt paced-fast
 */
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.join(__dirname, '..');
let JSDOM;
try {
  JSDOM = require(path.join(__dirname, '.simdeps', 'node_modules', 'jsdom')).JSDOM;
} catch (e) {
  console.log('sim-harness: jsdom missing — run: npm --prefix tests/.simdeps i jsdom');
  process.exit(2);
}

const PROJECT_ID = 'simproj-1234567890abcdef';
const PROJECT_URL = 'https://labs.google/fx/tools/flow/project/' + PROJECT_ID;
const REF_NAME = 'ref-sheet.png';
const N_ITEMS = parseInt(process.env.SIM_ITEMS || '42', 10);
const BOILER = ' Editorial Economic Storybook illustration, ivory paper background, navy and charcoal ink, rust orange accents, flat 2D hand-drawn style, no text in image.';
const SCENES = [
  'a baker slides a tray of round loaves into a brick oven while flour dust hangs in the morning light',
  'a fisherman knots a torn net on a harbour wall as gulls circle over moored wooden boats',
  'a clerk stamps claim tickets at a post office counter under a slow ceiling fan',
  'children fly a red kite over flooded rice terraces after the monsoon rain',
  'an old lighthouse keeper trims a lamp wick while waves break on black rocks below',
  'a tea seller pours steaming cha into clay cups at a crowded railway platform stall',
  'a potter shapes a wet clay bowl on a spinning wheel in a courtyard workshop',
  'a ferryman poles a bamboo raft across a wide brown river at first light',
  'a grandmother threads marigold garlands on the steps of a small village temple',
  'a blacksmith hammers a glowing ploughshare as sparks scatter across the forge floor',
  'a rickshaw puller waits under a banyan tree during a sudden afternoon downpour',
  'a spice merchant weighs dried chillies on a brass balance in a narrow bazaar lane',
  'a schoolteacher writes fractions on a chalkboard in a tin-roofed classroom',
  'a boatman sings while hauling a net heavy with silver hilsa fish at dawn',
  'a tailor stitches a bright sari border by the light of a shop window',
  'a farmer guides two oxen along the edge of a mustard field in winter fog',
  'a station master waves a green flag as a mail train pulls away in the dusk',
  'a honey collector lowers a rope ladder down a cliff face above the sea',
  'a puppeteer paints a wooden tiger mask behind a travelling theatre cart',
  'a midwife carries a lantern across a courtyard during a night-time power cut',
  'a carpenter planes a teak door frame while shavings curl onto the floor',
  'a mango seller arranges ripe fruit in pyramids at a roadside stall',
  'a weaver works a handloom with indigo thread in a quiet veranda room',
  'a night watchman taps his staff on cobblestones outside a sleeping market',
  'a young monk sweeps fallen leaves from the steps of a hill monastery',
  'a snake charmer lifts the lid of a woven basket in a village fair crowd',
  'a glassblower turns a bubble of molten glass into a small green bottle',
  'a cartographer inks a river delta map by candlelight in a map room',
  'a shepherd leads goats down a stony path toward a watering pond at noon',
  'a lacquer artist paints tiny boats on a wooden tray in a riverside studio',
  'an auctioneer calls bids over baskets of tea at a warehouse podium',
  'a diver surfaces with an oyster shell beside a pearl boat at sunrise',
  'a miller opens the sluice gate as the water wheel begins to turn',
  'a calligrapher grinds an ink stick before writing a wedding invitation',
  'a basket weaver soaks cane strips in a pond behind her stilt house',
  'a salt worker rakes white crystals into rows under a hard midday sun',
  'a puppeteer’s shadow dragon dances on a lit screen during a night show',
  'a herbalist bundles dried roots and leaves at a forest edge stall',
  'a train porter balances three suitcases on his head along the platform',
  'a fish dry-yard worker turns rows of fish on bamboo racks by the shore',
  'a bell founder pours molten bronze into a clay mould in a foundry yard',
  'a scribe copies an old manuscript page onto palm leaf in a library cell'
];
const itemPrompt = (n) => 'Scene ' + n + ': ' + SCENES[(parseInt(n, 10) - 1) % SCENES.length] + '.' + BOILER;
const ITEMS = [];
for (let i = 1; i <= N_ITEMS; i++) {
  const id = String(i).padStart(3, '0');
  ITEMS.push({ id, prompt: itemPrompt(id), needsRef: true });
}

/* ================= Fake Flow page ================= */
class FakeFlow {
  constructor(scenario) {
    this.scenario = scenario;
    // v3.0.1: catalog failure variants — 'ok' (default), 'dead'
    // (listing fetch fails outright), 'noprompts' (listing answers
    // but generated rows carry no requestData prompt), 'notime'
    // (listing dead for the first 40s — so the run-start baseline
    // capture misses it — then answers WITHOUT createTime on rows,
    // so the probe normalizes createdAt to 0).
    this.catalogMode = (scenario && scenario.catalogMode) || 'ok';
    this.bornAt = Date.now();
    this.assets = new Map();   // uuid -> asset (insertion order = creation)
    this.errors = [];          // {id, text, prompt, at, retried}
    this.seq = 0;
    this.uploadCount = 0;
    this.sends = [];           // {prompt, refAttached, at}
    this.pendingGens = 0;
    this.viewerUuid = null;
    this.dom = new JSDOM(`<!DOCTYPE html><html><head><title>Flow</title></head><body>
      <div id="grid"></div>
      <div id="busy" role="progressbar" style="display:none">Generating</div>
      <div id="picker" style="display:none">
        <div class="picker-head"><input id="pickerSearch" type="text" placeholder="Search assets"></div>
        <div class="picker-tabs"><button data-tab="All">All</button><button data-tab="Uploads">Uploads</button></div>
        <div id="pickerOptions"></div>
        <button id="pickerAdd">Add to prompt</button>
      </div>
      <div id="viewer" style="display:none">
        <div id="viewerPrompt"></div>
        <button id="viewerDownload">Download</button>
        <button id="viewerClose">Close</button>
      </div>
      <div id="composerBar">
        <div id="chips"></div>
        <button id="plusBtn" aria-label="Add ingredients">+</button>
        <div id="promptBox" contenteditable="true" role="textbox" aria-label="Enter a prompt"></div>
        <button id="clearBtn">Clear prompt</button>
        <button id="sendBtn" aria-label="Send">Send</button>
        <button id="chipBtn">Nano Banana 2.1 · 16:9 · x1</button>
        <div id="genMenu" style="display:none"></div>
      </div>
    </body></html>`, { url: PROJECT_URL, runScripts: 'outside-only', pretendToBeVisual: true });
    this.win = this.dom.window;
    this.doc = this.win.document;
    this.uuidCounter = 0;
    // fake images always finish loading at a real size (probes read
    // naturalWidth to tell thumbnails from placeholders)
    const imgProto = this.win.HTMLImageElement.prototype;
    Object.defineProperty(imgProto, 'naturalWidth', { get() { return this.getAttribute('src') ? 100 : 0; } });
    Object.defineProperty(imgProto, 'naturalHeight', { get() { return this.getAttribute('src') ? 100 : 0; } });
    Object.defineProperty(imgProto, 'complete', { get() { return true; } });
    this.setupRects();
    // jsdom has no layout engine: elementFromPoint must come from the
    // harness's rect registry (the engine's sfaPointCheck depends on it)
    this.doc.elementFromPoint = (x, y) => this.elementFromPoint(x, y);
    this.doc.elementsFromPoint = (x, y) => { const el = this.elementFromPoint(x, y); return el ? [el] : []; };
    this.setupFetch();
    this.setupBehavior();
    this.renderAll();
  }
  nextUuid(kind) { return kind + '-' + (++this.uuidCounter) + '-uuid'; }
  /* ---- layout: deterministic rects, zero for hidden ---- */
  setupRects() {
    const win = this.win;
    const proto = win.Element.prototype;
    const self = this;
    proto.getBoundingClientRect = function () {
      if (self.isHidden(this)) return { x: 0, y: 0, left: 0, top: 0, right: 0, bottom: 0, width: 0, height: 0 };
      return this.__rect || { x: 0, y: 0, left: 0, top: 0, right: 0, bottom: 0, width: 0, height: 0 };
    };
  }
  isHidden(el) {
    let n = el;
    while (n && n !== this.doc.body) {
      if (n.style && n.style.display === 'none') return true;
      n = n.parentElement;
    }
    return false;
  }
  setRect(el, x, y, w, h) { el.__rect = { x, y, left: x, top: y, right: x + w, bottom: y + h, width: w, height: h }; }
  layout() {
    const d = this.doc;
    // grid tiles: 4 columns of 170px
    const tiles = d.querySelectorAll('.flow-grid-tile-container');
    tiles.forEach((t, i) => this.setRect(t, 10 + (i % 4) * 170, 10 + Math.floor(i / 4) * 170, 160, 160));
    this.setRect(d.getElementById('busy'), 10, 5, 200, 20);
    this.setRect(d.getElementById('promptBox'), 120, 900, 560, 60);
    this.setRect(d.getElementById('plusBtn'), 60, 900, 44, 44);
    this.setRect(d.getElementById('clearBtn'), 690, 900, 110, 40);
    this.setRect(d.getElementById('sendBtn'), 810, 900, 80, 44);
    this.setRect(d.getElementById('chipBtn'), 120, 845, 260, 36);
    this.setRect(d.getElementById('chips'), 120, 800, 400, 30);
    d.querySelectorAll('#chips .chip').forEach((c, i) => { this.setRect(c, 120 + i * 90, 800, 80, 26); const im = c.querySelector('img'); if (im) this.setRect(im, 120 + i * 90, 800, 26, 26); });
    this.setRect(d.getElementById('picker'), 200, 150, 640, 520);
    this.setRect(d.getElementById('pickerSearch'), 220, 170, 400, 36);
    d.querySelectorAll('.picker-tabs button').forEach((b, i) => this.setRect(b, 220 + i * 90, 215, 80, 30));
    d.querySelectorAll('#pickerOptions .opt').forEach((o, i) => this.setRect(o, 220, 255 + i * 44, 500, 40));
    this.setRect(d.getElementById('pickerAdd'), 220, 620, 160, 40);
    this.setRect(d.getElementById('viewer'), 150, 120, 760, 560);
    this.setRect(d.getElementById('viewerPrompt'), 180, 180, 600, 200);
    this.setRect(d.getElementById('viewerDownload'), 620, 140, 130, 36);
    this.setRect(d.getElementById('viewerClose'), 180, 140, 90, 36);
    d.querySelectorAll('#genMenu button').forEach((b, i) => this.setRect(b, 130, 500 + i * 34, 220, 30));
    this.setRect(d.getElementById('genMenu'), 120, 490, 240, 420);
  }
  /* ---- catalog (the listing the v3 truth layer reads) ---- */
  catalogPayload() {
    const media = [];
    const workflows = [];
    for (const a of this.assets.values()) {
      if (a.state !== 'done') continue;
      const row = { name: a.uuid, mediaMetadata: this.catalogMode === 'notime' ? {} : { createTime: new Date(a.createdAt).toISOString() } };
      if (a.kind === 'video') row.video = a.origin === 'upload' ? { userUploadedVideo: {} } : { generatedVideo: {} };
      else row.image = a.origin === 'upload' ? { userUploadedImage: {} } : { generatedImage: {} };
      if (a.origin === 'generated' && a.prompt != null && this.catalogMode !== 'noprompts') row.requestData = { promptText: a.prompt };
      media.push(row);
      workflows.push({ name: 'wf-' + a.uuid, metadata: { primaryMediaId: a.uuid, displayName: a.displayName, createTime: new Date(a.createdAt).toISOString() } });
    }
    return { result: { data: { json: { media, workflows } } } };
  }
  setupFetch() {
    const self = this;
    this.win.fetch = async (url) => {
      if (String(url).includes('projectInitialData')) {
        if (self.catalogMode === 'dead') return { ok: false, status: 500, json: async () => ({}) };
        if (self.catalogMode === 'notime' && Date.now() - self.bornAt < 40000) return { ok: false, status: 500, json: async () => ({}) };
        return { ok: true, json: async () => self.catalogPayload() };
      }
      return { ok: false, status: 404, json: async () => ({}) };
    };
  }
  /* ---- rendering ---- */
  visibleAssets() {
    // newest-first, virtualized window of 27 tiles (errors interleave by time)
    const entries = [];
    for (const a of this.assets.values()) if (a.state === 'done') entries.push({ t: a.createdAt, asset: a });
    for (const e of this.errors) entries.push({ t: e.at, error: e });
    entries.sort((x, y) => y.t - x.t);
    return entries.slice(0, 27);
  }
  renderAll() {
    const grid = this.doc.getElementById('grid');
    grid.innerHTML = '';
    for (const entry of this.visibleAssets()) {
      const c = this.doc.createElement('div');
      c.className = 'flow-grid-tile-container';
      if (entry.asset) {
        const a = entry.asset;
        const inner = this.doc.createElement('div');
        inner.className = a.kind === 'video' ? 'flow-video-tile' : 'flow-image-tile';
        inner.setAttribute('data-media-id', a.uuid);
        const img = this.doc.createElement('img');
        img.setAttribute('data-media-id', a.uuid);
        img.setAttribute('src', 'https://fake.local/media/' + a.uuid + '.png');
        img.setAttribute('alt', a.displayName);
        inner.appendChild(img);
        c.appendChild(inner);
      } else {
        const e = entry.error;
        const inner = this.doc.createElement('div');
        inner.className = 'flow-error-tile';
        inner.textContent = e.text;
        const btn = this.doc.createElement('button');
        btn.textContent = 'Retry';
        btn.setAttribute('data-retry-for', e.id);
        inner.appendChild(btn);
        c.appendChild(inner);
        c.__errorId = e.id;
      }
      grid.appendChild(c);
    }
    this.doc.getElementById('busy').style.display = this.pendingGens > 0 ? '' : 'none';
    this.layout();
    // error retry buttons need rects (inside their tile)
    this.doc.querySelectorAll('.flow-error-tile button').forEach((b) => {
      const host = b.closest('.flow-grid-tile-container');
      const r = host && host.__rect;
      if (r) this.setRect(b, r.left + 40, r.top + 100, 80, 32);
    });
    this.doc.querySelectorAll('.flow-grid-tile-container img').forEach((im) => {
      const host = im.closest('.flow-grid-tile-container');
      if (host && host.__rect) this.setRect(im, host.__rect.left, host.__rect.top, 160, 160);
    });
    this.doc.querySelectorAll('[data-media-id]').forEach((el) => {
      const host = el.closest('.flow-grid-tile-container');
      if (host && host.__rect && el !== host) this.setRect(el, host.__rect.left, host.__rect.top, 160, 160);
    });
  }
  renderPicker() {
    const wrap = this.doc.getElementById('pickerOptions');
    const term = (this.doc.getElementById('pickerSearch').value || '').toLowerCase();
    wrap.innerHTML = '';
    const list = [];
    for (const a of this.assets.values()) if (a.state === 'done') list.push(a);
    list.sort((x, y) => y.createdAt - x.createdAt);
    for (const a of list) {
      if (term && !a.displayName.toLowerCase().includes(term)) continue;
      const o = this.doc.createElement('div');
      o.className = 'opt';
      o.setAttribute('data-media-id', a.uuid);
      const im = this.doc.createElement('img');
      im.setAttribute('src', 'https://fake.local/media/' + a.uuid + '.png');
      o.appendChild(im);
      const sp = this.doc.createElement('span');
      sp.textContent = a.displayName;
      o.appendChild(sp);
      wrap.appendChild(o);
    }
    this.layout();
  }
  renderChips() {
    const chips = this.doc.getElementById('chips');
    chips.innerHTML = '';
    if (this.attachedRefUuid) {
      const c = this.doc.createElement('span');
      c.className = 'chip';
      const im = this.doc.createElement('img');
      im.setAttribute('src', 'https://fake.local/media/' + this.attachedRefUuid + '.png');
      c.appendChild(im);
      chips.appendChild(c);
    }
    this.layout();
  }
  /* ---- behavior ---- */
  setupBehavior() {
    const d = this.doc;
    d.addEventListener('click', (ev) => this.onClick(ev), true);
    d.getElementById('pickerSearch').addEventListener('input', () => this.renderPicker());
    // settings menu options
    const menu = d.getElementById('genMenu');
    const labels = ['Image', 'Video', 'Nano Banana 2.1', 'Nano Banana Pro', 'Imagen 4', 'Veo 3.1 Fast', 'Veo 3.1 Quality', '16:9', '9:16', '1:1', '4:3', '3:4', 'x1', 'x2', 'x3', 'x4'];
    for (const lab of labels) {
      const b = d.createElement('button');
      b.textContent = lab;
      b.setAttribute('data-gen-opt', lab);
      menu.appendChild(b);
    }
    this.layout();
  }
  onClick(ev) {
    const d = this.doc;
    const t = ev.target;
    const tileHost = t.closest ? t.closest('.flow-grid-tile-container') : null;
    if (t.id === 'plusBtn') { d.getElementById('picker').style.display = ''; this.renderPicker(); this.layout(); return; }
    if (t.id === 'chipBtn') { const m = d.getElementById('genMenu'); m.style.display = m.style.display === 'none' ? '' : 'none'; this.layout(); return; }
    if (t.getAttribute && t.getAttribute('data-gen-opt')) {
      const lab = t.getAttribute('data-gen-opt');
      const chip = d.getElementById('chipBtn');
      const parts = chip.textContent.split('·').map((s) => s.trim());
      if (/banana|imagen|veo/i.test(lab)) parts[0] = lab;
      else if (/:/.test(lab)) parts[1] = lab;
      else if (/^x\d$/.test(lab)) parts[2] = lab;
      chip.textContent = parts.join(' · ');
      d.getElementById('genMenu').style.display = 'none';
      this.layout();
      return;
    }
    if (t.classList && t.classList.contains('opt')) {
      const uuid = t.getAttribute('data-media-id');
      this.attachedRefUuid = uuid;
      this.renderChips();
      d.getElementById('picker').style.display = 'none';
      this.layout();
      return;
    }
    if (t.id === 'sendBtn') { this.submit(); return; }
    if (t.getAttribute && t.getAttribute('data-retry-for')) {
      const e = this.errors.find((x) => x.id === t.getAttribute('data-retry-for'));
      if (e && !e.retried) { e.retried = true; this.errors = this.errors.filter((x) => x !== e); this.scheduleGeneration(e.prompt, this.scenario.retryPlan(e)); this.renderAll(); }
      return;
    }
    if (t.id === 'viewerClose') { d.getElementById('viewer').style.display = 'none'; this.viewerUuid = null; this.layout(); return; }
    if (tileHost) {
      const mid = tileHost.querySelector('[data-media-id]');
      if (mid) { this.openViewer(mid.getAttribute('data-media-id')); }
    }
  }
  openViewer(uuid) {
    const a = this.assets.get(uuid);
    if (!a) return;
    this.viewerUuid = uuid;
    this.doc.getElementById('viewerPrompt').textContent = a.viewerPrompt != null ? a.viewerPrompt : (a.prompt || '');
    this.doc.getElementById('viewer').style.display = '';
    this.layout();
  }
  composerText() { return this.doc.getElementById('promptBox').textContent || ''; }
  submit() {
    const prompt = this.composerText().replace(/\s+/g, ' ').trim();
    if (!prompt) return;
    const refAttached = !!this.attachedRefUuid;
    this.sends.push({ prompt, refAttached, at: Date.now() });
    // Flow clears the composer after a send
    this.doc.getElementById('promptBox').textContent = '';
    this.attachedRefUuid = null;
    this.renderChips();
    const plan = this.scenario.onSend(this, prompt, this.sends.length);
    for (const step of plan || []) this.scheduleGeneration(prompt, step);
    this.renderAll();
  }
  scheduleGeneration(prompt, step) {
    this.pendingGens++;
    this.renderAll();
    setTimeout(() => {
      this.pendingGens--;
      if (step.type === 'tile') {
        const uuid = this.nextUuid('gen');
        this.assets.set(uuid, {
          uuid, kind: 'image', origin: 'generated',
          prompt: step.catalogPrompt === undefined ? prompt : step.catalogPrompt,
          viewerPrompt: prompt,
          displayName: (prompt || '').slice(0, 35),
          createdAt: Date.now(), state: 'done'
        });
        if (step.extraDelayDuplicate) {
          setTimeout(() => {
            const dup = this.nextUuid('gen');
            this.assets.set(dup, {
              uuid: dup, kind: 'image', origin: 'generated',
              prompt: step.catalogPrompt === undefined ? prompt : step.catalogPrompt,
              displayName: (prompt || '').slice(0, 35),
              createdAt: Date.now(), state: 'done'
            });
            this.renderAll();
          }, step.extraDelayDuplicate);
        }
      } else if (step.type === 'error') {
        this.errors.push({ id: 'err-' + (++this.seq), text: step.errorText || 'Failed to generate. Something went wrong.', prompt, at: Date.now(), retried: false });
      }
      this.renderAll();
      if (this.scenario.onStepDone) this.scenario.onStepDone(this, step);
    }, step.delay || 400);
  }
  pasteReference() {
    // Ctrl+V with the sheet on the clipboard: Flow uploads it once.
    setTimeout(() => {
      this.uploadCount++;
      const uuid = this.nextUuid('upl');
      this.assets.set(uuid, {
        uuid, kind: 'image', origin: 'upload', prompt: null,
        displayName: REF_NAME, createdAt: Date.now(), state: 'done'
      });
      this.renderAll();
    }, 500);
  }
  addUpload(displayName) {
    const uuid = this.nextUuid('upl');
    this.assets.set(uuid, {
      uuid, kind: 'image', origin: 'upload', prompt: null,
      displayName, createdAt: Date.now(), state: 'done'
    });
    this.renderAll();
    return uuid;
  }
  elementFromPoint(x, y) {
    const matches = [];
    const all = this.doc.querySelectorAll('*');
    for (const el of all) {
      if (this.isHidden(el)) continue;
      const r = el.__rect;
      if (!r || !r.width) continue;
      if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) matches.push(el);
    }
    if (!matches.length) return null;
    // Layering, as in real Flow: modal overlays and the fixed
    // composer bar sit ABOVE the scrolling grid. Without this, a
    // grid tile laid out over the composer's coordinates wins the
    // smallest-area contest and steals every composer click once
    // the library grows tall (found by the 42-item sim: typing
    // died for every item after the upload flood).
    const within = (sel) => {
      const root = this.doc.querySelector(sel);
      if (!root || this.isHidden(root)) return null;
      const p = matches.filter((el) => el === root || (el.closest && el.closest(sel)));
      return p.length ? p : null;
    };
    const pool = within('#viewer') || within('#picker') || within('#composerBar') || matches;
    let best = null; let bestArea = Infinity;
    for (const el of pool) {
      const r = el.__rect;
      const area = r.width * r.height;
      if (area <= bestArea) { best = el; bestArea = area; }
    }
    return best;
  }
}

/* ================= chrome mock + engine boot ================= */
function bootEngine(flow) {
  const pageCtx = flow.dom.getInternalVMContext();
  const downloads = { records: new Map(), nextId: 1, listeners: [] };
  const storage = new Map();
  let engineListener = null;

  const runtimeEvaluate = async (params) => {
    try {
      let v = vm.runInContext(params.expression, pageCtx, { timeout: 15000 });
      if (v && typeof v.then === 'function') v = await v;
      return { result: { value: v === undefined ? null : v } };
    } catch (e) {
      return { exceptionDetails: { text: String((e && e.message) || e) } };
    }
  };
  const mouseEvent = (params) => {
    if (params.type === 'mousePressed') {
      const el = flow.elementFromPoint(params.x, params.y);
      if (el) {
        flow.lastClicked = el;
        if (el.id === 'promptBox' || el.closest && el.closest('#pickerSearch')) { try { el.focus(); } catch (e) {} }
        el.dispatchEvent(new flow.win.MouseEvent('mousedown', { bubbles: true }));
        el.dispatchEvent(new flow.win.MouseEvent('mouseup', { bubbles: true }));
        el.dispatchEvent(new flow.win.MouseEvent('click', { bubbles: true }));
      }
    }
    return {};
  };
  const keyEvent = (params) => {
    if (params.type !== 'keyDown' && params.type !== 'rawKeyDown') return {};
    if (params.key === 'Enter') {
      const ae = flow.doc.activeElement;
      if (ae && (ae.id === 'promptBox' || ae.id === 'sendBtn')) flow.submit();
    } else if (params.key === 'Escape') {
      flow.doc.getElementById('picker').style.display = 'none';
      flow.doc.getElementById('viewer').style.display = 'none';
      flow.doc.getElementById('genMenu').style.display = 'none';
      flow.layout();
    } else if ((params.key === 'v' || params.key === 'V') && params.modifiers === 2) {
      flow.pasteReference();
    } else if (params.key === 'a' && params.modifiers === 2) {
      const ae = flow.doc.activeElement;
      if (ae && ae.id === 'promptBox') flow.doc.getElementById('promptBox').textContent = '';
      if (ae && ae.tagName === 'INPUT') { ae.value = ''; ae.dispatchEvent(new flow.win.Event('input', { bubbles: true })); }
    } else if (params.key === 'Backspace') {
      const ae = flow.doc.activeElement;
      if (ae && ae.tagName === 'INPUT' && ae.value) { ae.value = ''; ae.dispatchEvent(new flow.win.Event('input', { bubbles: true })); }
    }
    return {};
  };
  const insertText = (params) => {
    const ae = flow.doc.activeElement || flow.lastClicked;
    if (!ae) return {};
    if (ae.id === 'promptBox') ae.textContent = (ae.textContent || '') + params.text;
    else if (ae.tagName === 'INPUT' || ae.tagName === 'TEXTAREA') {
      ae.value = (ae.value || '') + params.text;
      ae.dispatchEvent(new flow.win.Event('input', { bubbles: true }));
    }
    return {};
  };
  const sendCommand = (target, method, params) => {
    params = params || {};
    switch (method) {
      case 'Runtime.evaluate': return runtimeEvaluate(params);
      case 'Input.dispatchMouseEvent': return Promise.resolve(mouseEvent(params));
      case 'Input.dispatchKeyEvent': return Promise.resolve(keyEvent(params));
      case 'Input.insertText': return Promise.resolve(insertText(params));
      case 'Page.captureScreenshot': return Promise.resolve({ data: '' });
      default: return Promise.resolve({});
    }
  };
  const chromeMock = {
    runtime: {
      id: 'sim-extension',
      getURL: (p) => 'chrome-extension://sim/' + p,
      onMessage: { addListener: (fn) => { engineListener = fn; } },
      onStartup: { addListener: () => {} },
      getManifest: () => ({ version: '3.0.0' })
    },
    storage: {
      local: {
        get: async (key) => {
          if (key == null) return Object.fromEntries(storage);
          if (typeof key === 'string') return storage.has(key) ? { [key]: storage.get(key) } : {};
          return {};
        },
        set: async (obj) => { for (const k of Object.keys(obj)) storage.set(k, obj[k]); },
        remove: async (key) => { storage.delete(key); }
      }
    },
    tabs: {
      query: async () => [{ id: 1, url: PROJECT_URL, active: true, title: 'Flow' }],
      get: async (id) => ({ id, url: PROJECT_URL, active: true, title: 'Flow' }),
      update: async () => ({}),
      create: async () => ({ id: 2, url: PROJECT_URL }),
      captureVisibleTab: async () => 'data:image/png;base64,'
    },
    debugger: {
      attach: async () => ({}),
      detach: async () => ({}),
      sendCommand,
      onDetach: { addListener: () => {} },
      onEvent: { addListener: () => {} }
    },
    scripting: {
      executeScript: async (inj) => {
        globalThis.document = flow.doc;
        globalThis.window = flow.win;
        globalThis.location = flow.win.location;
        globalThis.fetch = flow.win.fetch;
        globalThis.getComputedStyle = flow.win.getComputedStyle.bind(flow.win);
        const r = inj.func.apply(null, inj.args || []);
        const v = (r && typeof r.then === 'function') ? await r : r;
        return [{ result: v }];
      }
    },
    downloads: {
      // the engine uses the CALLBACK form (with runtime.lastError),
      // so the mock must invoke it - a promise-only mock deadlocks
      // the engine's download waiter (found by this harness).
      download: (opts, cb) => {
        const id = downloads.nextId++;
        const rec = { id, url: opts.url, filename: opts.filename, state: 'in_progress', fileSize: 50000 };
        downloads.records.set(id, rec);
        setTimeout(() => {
          rec.state = flow.scenario.downloadFails && flow.scenario.downloadFails(opts.url) ? 'interrupted' : 'complete';
          for (const fn of downloads.listeners) fn({ id, state: { current: rec.state } });
        }, 60);
        if (typeof cb === 'function') { chromeMock.runtime.lastError = undefined; cb(id); return undefined; }
        return Promise.resolve(id);
      },
      search: async (q) => {
        let out = Array.from(downloads.records.values());
        if (q && q.id !== undefined) out = out.filter((r) => r.id === q.id);
        if (q && q.filenameRegex) {
          const re = new RegExp(q.filenameRegex);
          out = out.filter((r) => re.test(r.filename.replace(/\\/g, '/')));
        }
        if (q && q.urlRegex) { const re = new RegExp(q.urlRegex); out = out.filter((r) => re.test(r.url)); }
        return out.map((r) => ({ id: r.id, url: r.url, filename: r.filename, state: r.state, fileSize: r.fileSize, totalBytes: r.fileSize }));
      },
      onChanged: { addListener: (fn) => downloads.listeners.push(fn) },
      show: async () => {}
    },
    notifications: { create: async () => ({}), clear: async () => ({}) },
    action: { setBadgeText: async () => ({}), setBadgeBackgroundColor: async () => ({}) },
    sidePanel: { setOptions: async () => ({}), open: async () => ({}) },
    alarms: { create: () => {}, onAlarm: { addListener: () => {} }, getAll: async () => [] },
    permissions: { contains: async () => true }
  };
  globalThis.chrome = chromeMock;
  globalThis.location = flow.win.location;
  globalThis.fetch = flow.win.fetch;
  const code = fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8');
  vm.runInThisContext(code, { filename: 'background.js' });
  if (!engineListener) throw new Error('engine did not register a message listener');
  const send = (msg) => new Promise((resolve, reject) => {
    const to = setTimeout(() => reject(new Error('engine message timeout: ' + msg.type)), 15000);
    try {
      engineListener(msg, { tab: { id: 1 } }, (resp) => { clearTimeout(to); resolve(resp); });
    } catch (e) { clearTimeout(to); reject(e); }
  });
  return { send, downloads, storage };
}

/* ================= scenarios ================= */
function makeScenario(combo) {
  const serial = combo.indexOf('serial') === 0;
  const promptMode = combo.indexOf('-prompt') >= 0;
  // v3.0.1: catalog failure suffixes — -nocat (listing dead),
  // -noprompt (listing prompt-less), -notime (listing late + no
  // createTime on rows).
  const catalogMode = /-nocat$/.test(combo) ? 'dead' : (/-noprompt$/.test(combo) ? 'noprompts' : (/-notime$/.test(combo) ? 'notime' : 'ok'));
  const sendCountByPrompt = new Map();
  let tilesDone = 0;
  let sinkDone = false;
  let dupUploadDone = false;
  return {
    catalogMode,
    onSend(flow, prompt, sendIndex) {
      const m = /Scene (\d+):/.exec(prompt);
      const scene = m ? parseInt(m[1], 10) : 0;
      const n = (sendCountByPrompt.get(prompt) || 0) + 1;
      sendCountByPrompt.set(prompt, n);
      if (process.env.SIM_DEBUG) console.error('[fake] send scene=' + scene + ' n=' + n + ' promptHead=' + JSON.stringify(prompt.slice(0, 12)) + ' len=' + prompt.length);
      const jitter = 250 + ((scene * 37) % 400);
      if (scene === 7 && n === 1) {
        // generic generation failure (serial: Retry path; paced in
        // sim scope: merely slow - a paced generic failure resolves
        // by the 240s elimination timeout, outside the sim budget)
        if (serial) return [{ type: 'error', errorText: 'Failed to generate. Something went wrong, please try again.', delay: 500 }];
        return [{ type: 'tile', delay: 1800 }];
      }
      if (scene === 9 && n === 1 && serial && promptMode) {
        // unusual activity: cooldown signal, attempt refunded, resend works
        return [{ type: 'error', errorText: 'Failed to generate. Unusual activity detected.', delay: 500 }];
      }
      if (scene === 11 && n === 1) return [{ type: 'tile', delay: jitter, extraDelayDuplicate: 25000 }];
      if (scene === 21 && n === 1) return [{ type: 'tile', delay: jitter, catalogPrompt: null }]; // prompt-less row
      const delay = serial ? jitter : 200 + ((N_ITEMS - scene) % 6) * 260 + (scene % 3) * 90;
      return [{ type: 'tile', delay }];
    },
    retryPlan() { return { type: 'tile', delay: 500 }; },
    onStepDone(flow, step) {
      if (step.type !== 'tile') return;
      tilesDone++;
      if (tilesDone === 15 && !sinkDone) {
        sinkDone = true;
        // 30 newer uploads flood the grid: the reference (uploaded at
        // run start) sinks out of the 27-tile window for good. A real
        // 30-file upload is not instantaneous - stagger it over ~20s
        // so a just-finished tile gets its normal first-poll window
        // (an instantaneous dump tested teleportation, not Flow).
        for (let i = 0; i < 30; i++) {
          setTimeout(() => flow.addUpload('asset-' + String(i).padStart(3, '0') + '.png'), i * 700);
        }
      }
      if (tilesDone === 18 && !dupUploadDone) {
        dupUploadDone = true;
        flow.addUpload(REF_NAME); // a stray duplicate of the sheet
      }
    },
    downloadFails() { return false; }
  };
}

/* ================= one simulated run ================= */
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function runCombo(combo) {
  const t0 = Date.now();
  const scenario = makeScenario(combo);
  const flow = new FakeFlow(scenario);
  const engine = bootEngine(flow);
  const settings = {
    refMode: 'all', refReady: true, refFileName: REF_NAME,
    autoDownload: true, quality: '1K', datedFolder: false, retryAtEnd: false,
    intervalSec: 1,
    runMode: combo.indexOf('paced') === 0 ? 'paced' : 'serial',
    matchMode: combo.indexOf('-fast') >= 0 ? 'fast' : 'prompt',
    genType: 'image', genModel: 'Nano Banana 2.1', genRatio: '16:9', genCount: 1
  };
  const startMsg = { type: 'start', items: ITEMS.map((i) => ({ ...i })), project: 'SimProject', settings, tabId: 1 };
  const problems = [];
  await engine.send(startMsg);
  let stopped = false;
  let savedStartedAt = null;
  let resumedStartedAt = null;
  const deadline = t0 + (combo.mode === 'serial' ? 22 : 14) * 60 * 1000; // anti-hang bound; a healthy 42-item serial run needs ~15 min of fake time
  let finalState = null;
  while (Date.now() < deadline) {
    const gs = await engine.send({ type: 'getState' });
    const st = gs.state;
    finalState = st;
    const doneCount = st.items.filter((i) => i.status === 'done').length;
    if (!st.running && st.items.every((i) => i.status === 'done' || i.status === 'failed')) break; // finished (or died) without needing the stop phase
    if (!stopped && doneCount >= Math.min(20, Math.floor(N_ITEMS / 2))) {
      savedStartedAt = st.runStartedAt;
      await engine.send({ type: 'stop' });
      for (let k = 0; k < 80; k++) {
        const g2 = await engine.send({ type: 'getState' });
        if (!g2.state.running) break;
        await sleep(500);
      }
      await engine.send(startMsg); // SAME list: must RESUME, not restart
      resumedStartedAt = (await engine.send({ type: 'getState' })).state.runStartedAt;
      stopped = true;
      continue;
    }
    if (stopped && !st.running && st.items.every((i) => i.status === 'done' || i.status === 'failed')) break;
    if (process.env.SIM_DEBUG) {
      const c = st.items.reduce((a, i) => { a[i.status] = (a[i.status] || 0) + 1; return a; }, {});
      console.log('  [dbg] running=' + st.running + ' ' + JSON.stringify(c) + ' uploads=' + flow.uploadCount);
      const lines = st.log || [];
      for (let li = (runCombo.__logSeen || 0); li < lines.length; li++) console.log('  [log] ' + lines[li]);
      runCombo.__logSeen = lines.length;
    }
    await sleep(1000);
  }
  const wall = Date.now() - t0;
  if (!finalState) problems.push('no state captured');
  if (stopped) {
    if (resumedStartedAt !== savedStartedAt) problems.push('RESUME: runStartedAt changed (' + savedStartedAt + ' -> ' + resumedStartedAt + ') - the run restarted instead of resuming');
  } else if (N_ITEMS >= 10) problems.push('mid-run stop point never reached');
  // ground-truth download audit
  const dl = Array.from(engine.downloads.records.values()).filter((r) => r.state === 'complete' && /^\d{3}[A-Z]?\.png$/.test(String(r.filename).replace(/\\/g, '/').split('/').pop()));
  const perItem = {};
  for (const r of dl) {
    const base = String(r.filename).replace(/\\/g, '/').split('/').pop();
    const id = base.replace(/\.(png|mp4)$/, '');
    const um = /media\/([^/]+)\.png/.exec(r.url || '');
    const uuid = um ? um[1] : null;
    (perItem[id] = perItem[id] || []).push(uuid);
    const asset = uuid ? flow.assets.get(uuid) : null;
    if (!asset) { problems.push(id + ': downloaded unknown asset ' + uuid); continue; }
    if (asset.origin !== 'generated') problems.push(id + ': downloaded a ' + asset.origin.toUpperCase() + ' asset (' + uuid + ')');
    const want = ITEMS.find((i) => i.id === id);
    // ground truth = the prompt the asset was actually generated
    // from (viewerPrompt); asset.prompt is only what the LISTING
    // exposes, which is null for prompt-less rows by design.
    const truthPrompt = asset.viewerPrompt != null ? asset.viewerPrompt : asset.prompt;
    if (want && truthPrompt !== want.prompt) { problems.push(id + ': WRONG CONTENT - downloaded ' + uuid + ' whose prompt starts ' + JSON.stringify(String(truthPrompt || '').slice(0, 30))); if (process.env.SIM_DEBUG) console.error('[audit] want len=' + want.prompt.length + ' got len=' + String(truthPrompt || '').length + '\n  want tail=' + JSON.stringify(want.prompt.slice(-60)) + '\n  got  tail=' + JSON.stringify(String(truthPrompt || '').slice(-60))); }
  }
  for (const it of ITEMS) {
    const st = finalState && finalState.items.find((i) => i.id === it.id);
    if (!st || st.status !== 'done') problems.push(it.id + ': final status = ' + (st && st.status) + (st && st.failReason ? ' (' + st.failReason + ')' : ''));
    const n = (perItem[it.id] || []).length;
    if (n !== 1) problems.push(it.id + ': download count = ' + n + ' (want exactly 1)');
  }
  if (flow.uploadCount !== 1) problems.push('reference uploads = ' + flow.uploadCount + ' (want exactly 1 - no mid-run re-upload)');
  return { combo, wallMs: wall, problems, logTail: finalState ? finalState.log.slice(-30) : [] };
}

/* ================= main (one child process per combo) ================= */
if (process.env.SIM_EXPORT) { module.exports = { FakeFlow, makeScenario, bootEngine, ITEMS }; }
else (async () => {
  const args = process.argv.slice(2);
  if (args[0] === '--one') {
    const r = await runCombo(args[1]);
    console.log(JSON.stringify(r));
    process.exit(r.problems.length ? 1 : 0);
  }
  const combos = args.length ? args : ['serial-prompt', 'serial-fast', 'paced-prompt', 'paced-fast'];
  const { spawn } = require('child_process');
  let allOk = true;
  for (const combo of combos) {
    console.log('=== SIM ' + combo + ' ===');
    const child = spawn(process.execPath, [__filename, '--one', combo], { stdio: ['ignore', 'pipe', 'inherit'] });
    let out = '';
    child.stdout.on('data', (d) => { out += d; });
    const code = await new Promise((res) => child.on('close', res));
    let r = null;
    try { r = JSON.parse(out.trim().split('\n').pop()); } catch (e) { /* fallthrough */ }
    if (!r) { console.log('  HARNESS ERROR (no result, exit ' + code + ')'); allOk = false; continue; }
    console.log('  wall: ' + Math.round(r.wallMs / 1000) + 's');
    if (r.problems.length) {
      allOk = false;
      for (const p of r.problems) console.log('  FAIL: ' + p);
      console.log('  --- engine log tail ---');
      for (const line of r.logTail) console.log('   ' + line);
    } else {
      console.log('  PASS: 42/42 done, every download content-true, reference uploaded once and never downloaded, resume preserved the run');
    }
  }
  console.log(allOk ? '\nSIM: ALL COMBOS PASSED' : '\nSIM: FAILURES PRESENT');
  process.exit(allOk ? 0 : 1);
})().catch((e) => { console.log('SIM HARNESS ERROR: ' + (e && e.stack || e)); process.exit(2); });
