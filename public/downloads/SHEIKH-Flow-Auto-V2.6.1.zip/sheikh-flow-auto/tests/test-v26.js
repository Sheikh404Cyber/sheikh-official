'use strict';
/* SHEIKH Flow Auto v2.6 unit tests.
   - computeEtaMs (engine-side ETA from measured cycle samples):
     serial avg x remaining; paced max(sends x interval, completions
     x avg); null before the first completion.
   - Generation-option helpers: clampGenCount, genNormText,
     pickGenOption, chipHasText / chipCountOf read-back checks.
   - pacedQuotaAssign: Count=2 with interleaved arrivals across two
     polls (first tile downloads, extras noted, completion only when
     the quota fills), Count=1 equivalence, partial quota.
   - sfaResultTiles kind filtering for the serial quota collection.
   - New page probes (sfaGenChip, sfaGenMenu, sfaTileMedia) survive
     extraction standalone (evalFn contract).
   - Wiring: settings-apply runs before the reference gate (v2.6.1); video
     download path; ETA state exposure; panel GENERATION card, ref
     chip + thumbnail; text diet (deleted keys, en strings short);
     neutral CSS palette + animation system; manifest 2.6.1.
   Run: node tests/test-v26.js */
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');

let pass = 0, fail = 0;
function ok(cond, label) {
  if (cond) { pass++; }
  else { fail++; console.log('FAIL: ' + label); }
}
function eq(a, b, label) { ok(JSON.stringify(a) === JSON.stringify(b), label + ` — got ${JSON.stringify(a)}, want ${JSON.stringify(b)}`); }

const bg = fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8');
const panel = fs.readFileSync(path.join(ROOT, 'panel.js'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'panel.html'), 'utf8');
const css = fs.readFileSync(path.join(ROOT, 'panel.css'), 'utf8');

function extractFn(srcText, name) {
  const start = srcText.indexOf('function ' + name + '(');
  if (start === -1) throw new Error('function not found: ' + name);
  let i = srcText.indexOf('{', start);
  let depth = 0;
  for (; i < srcText.length; i++) {
    if (srcText[i] === '{') depth++;
    else if (srcText[i] === '}') { depth--; if (depth === 0) break; }
  }
  return srcText.slice(start, i + 1);
}
function revive(srcText, name, prelude) {
  return new Function('"use strict";\n' + (prelude || '') + extractFn(srcText, name) + '\nreturn ' + name + ';')();
}
const clampIntervalSec = revive(bg, 'clampIntervalSec');
const computeEtaMs = revive(bg, 'computeEtaMs', extractFn(bg, 'clampIntervalSec'));
const clampGenCount = revive(bg, 'clampGenCount');
const genNormText = revive(bg, 'genNormText');
const pickGenOption = revive(bg, 'pickGenOption', extractFn(bg, 'genNormText'));
const chipHasText = revive(bg, 'chipHasText', extractFn(bg, 'genNormText'));
const chipCountOf = revive(bg, 'chipCountOf');
const pacedQuotaAssign = revive(bg, 'pacedQuotaAssign');
const sfaResultTiles = revive(bg, 'sfaResultTiles');

/* ---------- computeEtaMs ---------- */
{
  eq(computeEtaMs({ samples: [], mode: 'serial', remainingItems: 5 }), null, 'ETA: no samples -> null (dash)');
  eq(computeEtaMs({ samples: [0, -3], mode: 'serial', remainingItems: 5 }), null, 'ETA: non-positive samples filtered -> null');
  eq(computeEtaMs({ samples: [60000, 120000], mode: 'serial', remainingItems: 4 }), 360000, 'ETA serial: avg 90s x 4 remaining');
  eq(computeEtaMs({ samples: [45000], mode: 'serial', remainingItems: 1 }), 45000, 'ETA serial: single sample');
  eq(computeEtaMs({ samples: [45000], mode: 'serial', remainingItems: 0 }), 0, 'ETA serial: nothing remaining -> 0');
  eq(computeEtaMs({ samples: [30000], mode: 'paced', remainingItems: 2, unsentItems: 10, intervalSec: 10 }), 100000,
    'ETA paced: sends dominate (10 unsent x 10s > 2 x 30s)');
  eq(computeEtaMs({ samples: [60000], mode: 'paced', remainingItems: 5, unsentItems: 2, intervalSec: 10 }), 300000,
    'ETA paced: completions dominate (5 x 60s > 2 x 10s)');
  eq(computeEtaMs({ samples: [10000], mode: 'paced', remainingItems: 1, unsentItems: 1, intervalSec: 999 }), 120000,
    'ETA paced: interval clamped to 120s');
  eq(computeEtaMs({ samples: [8000, 12000], mode: 'paced', remainingItems: 3, unsentItems: 0, intervalSec: 10 }), 30000,
    'ETA paced: nothing unsent -> completions only');
  eq(computeEtaMs({ samples: [20000], remainingItems: 3 }), 60000, 'ETA: mode omitted -> serial');
}

/* ---------- generation option helpers ---------- */
{
  eq(clampGenCount(0), 1, 'count 0 -> 1');
  eq(clampGenCount(5), 4, 'count 5 -> 4');
  eq(clampGenCount('3'), 3, 'count "3" -> 3');
  eq(clampGenCount(undefined), 1, 'count undefined -> 1');
  eq(clampGenCount(2.9), 2, 'count 2.9 -> 2');
  eq(genNormText('Veo 3.1 - Fast'), 'veo31fast', 'norm strips punctuation/spaces');
  eq(genNormText('🍌 Nano Banana 2.1'), 'nanobanana21', 'norm strips emoji');
  const models = [{ text: 'Nano Banana 2.1' }, { text: 'Nano Banana Pro' }, { text: 'Imagen 4' }];
  eq(pickGenOption(models, 'Nano Banana Pro').text, 'Nano Banana Pro', 'pick: exact model');
  eq(pickGenOption(models, 'imagen 4').text, 'Imagen 4', 'pick: normalized exact');
  eq(pickGenOption([{ text: 'Veo 3.1 - Fast' }], 'Veo 3.1 Fast').text, 'Veo 3.1 - Fast', 'pick: dash variant matches');
  eq(pickGenOption(models, 'Nano Banana').text, 'Nano Banana 2.1', 'pick: containment fallback');
  eq(pickGenOption(models, 'DALL-E'), null, 'pick: unknown -> null');
  eq(pickGenOption([], 'x2'), null, 'pick: empty options -> null');
  eq(pickGenOption([{ text: 'x2' }], 'x2').text, 'x2', 'pick: count option');
  eq(chipHasText('🍌 Nano Banana 2.1 | x2', 'Nano Banana 2.1'), true, 'chip read-back: model present');
  eq(chipHasText('🍌 Nano Banana 2.1 | x2', 'Imagen 4'), false, 'chip read-back: other model absent');
  eq(chipCountOf('Nano Banana 2.1 x2'), 2, 'chip read-back: count 2');
  eq(chipCountOf('🍌 Nano Banana Pro × 4'), 4, 'chip read-back: count with multiplication sign');
  eq(chipCountOf('x12'), null, 'chip read-back: x12 is not a count');
  eq(chipCountOf('Nano Banana 2.1'), null, 'chip read-back: no count shown');
}

/* ---------- pacedQuotaAssign ---------- */
const T = (mediaId) => ({ mediaId, kind: 'image', hasThumb: true, hasPct: false });
{
  // Count=2, interleaved arrivals. Grid order is newest-first.
  // Ownership is unknowable from the grid, so the convention is the
  // send-order lock (same as v2.5): finished tiles are dealt
  // oldest-finish-first to the OLDEST pending item until its quota
  // fills, then to the next. Poll 1 grid: [b2, b1, a1] -> the finish
  // order a1, b1, b2 deals A its quota (a1 download + b1 extra) and
  // B its first tile (b2).
  const q1 = pacedQuotaAssign(
    [{ id: 'A', got: 0 }, { id: 'B', got: 0 }, { id: 'C', got: 0 }],
    [T('b2'), T('b1'), T('a1')], 2);
  eq(q1.assignments.map((a) => [a.itemId, a.tile.mediaId]), [['A', 'a1'], ['B', 'b2']],
    'quota p1: first tiles dealt in send order (oldest finish first)');
  eq(q1.extras.map((a) => [a.itemId, a.tile.mediaId]), [['A', 'b1']], 'quota p1: second tile inside A quota is an extra');
  eq(q1.completed, ['A'], 'quota p1: A completes when its quota fills');
  eq(q1.got, [{ id: 'A', got: 2 }, { id: 'B', got: 1 }, { id: 'C', got: 0 }], 'quota p1: got counts');

  // Poll 2: two more tiles finish: grid [c1, a2] -> finish order
  // a2, c1: a2 fills B's quota (extra slot), c1 is C's first tile.
  const q2 = pacedQuotaAssign(
    [{ id: 'B', got: 1 }, { id: 'C', got: 0 }],
    [T('c1'), T('a2')], 2);
  eq(q2.assignments.map((a) => [a.itemId, a.tile.mediaId]), [['C', 'c1']], 'quota p2: C gets its first tile');
  eq(q2.extras.map((a) => [a.itemId, a.tile.mediaId]), [['B', 'a2']], 'quota p2: B quota filled by an extra slot');
  eq(q2.completed, ['B'], 'quota p2: B completes when its quota fills');
  eq(q2.got, [{ id: 'B', got: 2 }, { id: 'C', got: 1 }], 'quota p2: got counts');

  // Count=1 behaves exactly like the old FIFO pairing.
  const q3 = pacedQuotaAssign([{ id: 'A', got: 0 }, { id: 'B', got: 0 }], [T('t2'), T('t1')], 1);
  eq(q3.assignments.map((a) => [a.itemId, a.tile.mediaId]), [['A', 't1'], ['B', 't2']], 'quota count=1: FIFO pairing');
  eq(q3.extras, [], 'quota count=1: no extras');
  eq(q3.completed, ['A', 'B'], 'quota count=1: both complete');

  // Partial quota: fewer tiles than the count.
  const q4 = pacedQuotaAssign([{ id: 'A', got: 0 }], [T('x1')], 3);
  eq(q4.assignments.length, 1, 'quota partial: one assignment');
  eq(q4.completed, [], 'quota partial: not complete yet');
  eq(q4.got, [{ id: 'A', got: 1 }], 'quota partial: got 1 of 3');
  eq(pacedQuotaAssign([{ id: 'A', got: 0 }], [], 2).assignments, [], 'quota: no tiles -> nothing');
  eq(pacedQuotaAssign([], [T('x1')], 2).completed, [], 'quota: no pending -> nothing completes');
}

/* ---------- sfaResultTiles ---------- */
{
  const tiles = [
    { mediaId: 'n1', kind: 'image', hasThumb: true, hasPct: false },
    { mediaId: 'p1', kind: 'image', hasThumb: true, hasPct: true },
    { mediaId: 'old', kind: 'image', hasThumb: true, hasPct: false },
    { mediaId: 'v1', kind: 'video', hasThumb: false, hasPct: false, videoSrc: 'https://x/v.mp4' },
    { mediaId: 'v2', kind: 'video', hasThumb: false, hasPct: true, videoSrc: 'https://x/v2.mp4' },
    { mediaId: 'r1', kind: 'image', hasThumb: true, hasPct: false }
  ];
  eq(sfaResultTiles(tiles, ['old'], 'r1', 'image').map((t) => t.mediaId), ['n1'], 'resultTiles image: fresh finished only (snap/ref/pct excluded)');
  eq(sfaResultTiles(tiles, ['old'], 'r1', 'video').map((t) => t.mediaId), ['v1'], 'resultTiles video: settled video with a source');
  eq(sfaResultTiles(tiles, ['old'], 'r1').map((t) => t.mediaId), ['n1'], 'resultTiles: kind defaults to image');
  eq(sfaResultTiles(null, [], null, 'image'), [], 'resultTiles: null tiles -> empty');
}

/* ---------- new probes are self-contained (evalFn contract) ---------- */
{
  const forbidden = ['evalFn', 'scriptFn', 'cdp(', 'elog(', 'realClick', 'save(', 'beat(', 'sleep(', 'chrome.', 'targetPath', 'upgradeUrl', 'attachedTabId', 'stopRequested', 'ABORT'];
  for (const name of ['sfaGenChip', 'sfaGenMenu', 'sfaTileMedia']) {
    const code = extractFn(bg, name);
    const bad = forbidden.filter((f) => code.includes(f));
    ok(bad.length === 0 && !/\bS\./.test(code), name + ' is self-contained' + (bad.length ? ' (refs: ' + bad.join(',') + ')' : ''));
    let fn = null;
    try { fn = new Function('return (' + code + ')')(); } catch (e) { /* asserted below */ }
    ok(typeof fn === 'function', name + ' revives standalone');
  }
}

/* ---------- engine wiring ---------- */
ok(bg.includes('async function applyGenerationSettings('), 'applyGenerationSettings exists');
ok(bg.indexOf('await applyGenerationSettings(tab.id)') < bg.indexOf('await ensureReference(tab.id)'),
  'settings are applied BEFORE the reference gate (v2.6.1 reorder)');
ok(bg.includes('await applyGenerationSettings(tab.id)'), 'runLoop calls settings-apply before the loops');
ok(bg.includes("genType: 'image'") && bg.includes("genModel: 'Nano Banana 2.1'") && bg.includes("genRatio: '16:9'") && bg.includes('genCount: 1'),
  'DEFAULT_SETTINGS carries the generation defaults');
ok(bg.includes('GEN_MODELS') && bg.includes("'Veo 3.1 Fast'") && bg.includes("'Veo 3.1 Quality'") && bg.includes("'Imagen 4'"),
  'model vocabulary matches the Flow menu labels');
ok(bg.includes('extras: extras'), 'serial completion wait returns count extras');
ok(bg.includes('item.extraNoted'), 'extras are noted once per item');
ok((bg.match(/pacedQuotaAssign\(/g) || []).length >= 2, 'paced loop uses the quota assignment');
ok(bg.includes('async function downloadVideoTile('), 'video download path exists');
ok(bg.includes("item.mediaKind = 'video'"), 'video tiles mark the item kind (.mp4 naming)');
ok(bg.includes('targetPathFor(') && bg.includes("'.mp4'"), 'targetPathFor produces .mp4 for video');
ok(bg.includes('function computeEtaMs(') && bg.includes('function refreshEta(') && bg.includes('function noteItemCycle('),
  'ETA machinery exists (compute / refresh / sample)');
ok(bg.includes('S.etaMs = eta') && bg.includes('S.endsAt'), 'etaMs / endsAt are exposed in the polled state');
ok(bg.includes('noteItemCycle(item); // v2.6: real pace sample for the ETA'), 'both run loops record cycle samples');
ok(bg.includes('S.cycleSamples = []; // v2.6: ETA measures THIS run'), 'fresh start resets the ETA samples');

/* ---------- panel: generation card, ref chip + thumbnail, ETA ---------- */
ok(html.includes('id="genSec"'), 'GENERATION card exists');
ok(html.includes('id="genTypePills"') && html.includes('data-gt="image"') && html.includes('data-gt="video"'), 'type pills (Image | Video)');
ok(html.includes('id="genModelPills"'), 'model pills container (built per type)');
for (const r of ['16:9', '9:16', '1:1', '4:3', '3:4']) ok(html.includes('data-gr="' + r + '"'), 'ratio pill ' + r);
for (const c of ['1', '2', '3', '4']) ok(html.includes('data-gc="' + c + '"'), 'count pill x' + c);
ok(html.includes('data-i18n="generation"') && html.includes('data-i18n="genModelLabel"') && html.includes('data-i18n="genRatioLabel"') && html.includes('data-i18n="genCountLabel"'),
  'generation labels are i18n keys');
ok(panel.includes('genType: genTypeSel') && panel.includes('genModel: genModelSel') && panel.includes('genRatio: genRatioSel') && panel.includes('genCount: genCountSel'),
  'panel sends the generation options with the settings');
ok(panel.includes('GEN_MODELS_PANEL') && panel.includes('function syncGenPills('), 'model pills rebuild per type');
ok(html.includes('id="refThumb"'), 'reference thumbnail element exists');
ok(panel.includes('new FileReader()') && panel.includes('refThumb'), 'thumbnail preview reads the picked file (session-only)');
ok(html.includes('id="refChip"') && html.includes('id="refChipText"'), 'single reference status chip exists');
ok(!html.includes('refTxtHint') && !html.includes('id="refImgInfo"') && !html.includes('id="refStatus"'), 'the three old reference text lines are gone from the HTML');
ok(!panel.includes("t('refReadyInfo'") && !panel.includes("t('refNoneInfo'") && !panel.includes("t('refStatusPrefix'"), 'panel code no longer renders the long reference lines');
ok(panel.includes('bgState.etaMs') && panel.includes('bgState.endsAt'), 'panel renders the engine ETA / Ends');
ok(!panel.includes('(Date.now() - bgState.runStartedAt) / finished'), 'panel no longer guesses the ETA from wall-clock average');

/* ---------- i18n: diet + new keys ---------- */
const dictStart = panel.indexOf('const STRINGS = ');
const litStart = panel.indexOf('{', dictStart);
let depth = 0, litEnd = -1;
for (let i = litStart; i < panel.length; i++) {
  if (panel[i] === '{') depth++;
  else if (panel[i] === '}') { depth--; if (depth === 0) { litEnd = i; break; } }
}
const STRINGS = new Function('"use strict"; return (' + panel.slice(litStart, litEnd + 1) + ');')();
for (const code of Object.keys(STRINGS)) {
  for (const gone of ['refTxtHint', 'refStatusPrefix', 'refNoneInfo', 'refReadyInfo']) {
    ok(!(gone in STRINGS[code]), code + ': long-line key ' + gone + ' deleted');
  }
  for (const k of ['generation', 'genTypeLabel', 'genTypeImage', 'genTypeVideo', 'genModelLabel', 'genRatioLabel', 'genCountLabel', 'pfVideoOk', 'pfImageBad']) {
    ok(typeof STRINGS[code][k] === 'string' && STRINGS[code][k].length > 0, code + ' has v2.6 key ' + k);
  }
}
{
  const tooLong = Object.entries(STRINGS.en).filter(([, v]) => v.length > 80);
  eq(tooLong.map(([k]) => k), [], 'text diet: no English UI string exceeds one short line (80 chars)');
}

/* ---------- CSS: neutral palette + smooth motion ---------- */
ok(css.includes('--bg: #0a0a0f'), 'neutral near-black background');
ok(css.includes('--card: #131318'), 'neutral card surface');
ok(css.includes('--ease: cubic-bezier(.22,.8,.28,1)'), 'single smooth easing curve');
ok(!css.includes('radial-gradient(130%') && /body \{[^}]*background: var\(--bg\);/.test(css), 'no background tint wash (body is flat neutral)');
for (const hex of ['#17102b', '#2a1850', '#1c1236', '#130b26', '#120b24', '#372763', '#3d2b6e']) {
  ok(!css.includes(hex), 'violet wash hex gone: ' + hex);
}
ok(css.includes('.refthumb') && css.includes('width: 46px'), 'reference thumbnail style (46px)');
ok(css.includes('.refchip'), 'reference chip style');
ok(css.includes('.pills.genwrap'), 'model pills wrap style');
ok(css.includes('details[open ] .secbody'), 'smooth accordion body animation');
ok(css.includes('@keyframes livepulse'), 'gentle live-card pulse');
ok((css.match(/var\(--ease\)/g) || []).length >= 10, 'easing applied across the motion system');

/* ---------- manifest ---------- */
const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.json'), 'utf8'));
eq(manifest.version, '2.6.1', 'manifest version 2.6.1');
ok(html.includes('class="vtag">v2.6.1'), 'panel shows v2.6.1');

console.log(`\ntest-v26: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
