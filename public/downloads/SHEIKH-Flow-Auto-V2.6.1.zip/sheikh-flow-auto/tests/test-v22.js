'use strict';
/* SHEIKH Flow Auto v2.2 unit tests.
   - Pure engine helpers extracted from background.js: clampIntervalSec,
     formatEta, datedFolderName, buildMatchReport.
   - i18n dictionary completeness in panel.js (ALL languages define the
     exact English key set; 'help' present everywhere).
   - Manifest checks: version 2.6.1 + notifications permission.
   Run: node tests/test-v22.js */
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');

let pass = 0, fail = 0;
function ok(cond, label) {
  if (cond) { pass++; }
  else { fail++; console.log('FAIL: ' + label); }
}
function eq(a, b, label) { ok(JSON.stringify(a) === JSON.stringify(b), label + ` — got ${JSON.stringify(a)}, want ${JSON.stringify(b)}`); }

/* ---------- extract helpers from background.js ---------- */
const bg = fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8');
function extractFn(name) {
  const start = bg.indexOf('function ' + name + '(');
  if (start === -1) throw new Error('function not found: ' + name);
  let i = bg.indexOf('{', start);
  let depth = 0;
  const from = i;
  for (; i < bg.length; i++) {
    if (bg[i] === '{') depth++;
    else if (bg[i] === '}') { depth--; if (depth === 0) break; }
  }
  return bg.slice(start, i + 1);
}
// sanitizeProject lives in lib/parse.js normally; background.js uses a
// same-named local scope function — find its shuffle-free definition used
// by datedFolderName: it calls sanitizeProject(project). Provide the real
// one from lib/parse.js for the sandbox.
const parse = require(path.join(ROOT, 'lib', 'parse.js'));
const sandbox = { sanitizeProject: parse.sanitizeProject, S: null };
for (const name of ['clampIntervalSec', 'formatEta', 'datedFolderName', 'buildMatchReport']) {
  const src = extractFn(name);
  sandbox[name] = new Function('sanitizeProject', '"use strict";\n' + src + '\nreturn ' + name + ';')(parse.sanitizeProject);
}
const { clampIntervalSec, formatEta, datedFolderName, buildMatchReport } = sandbox;

/* ---------- clampIntervalSec ---------- */
eq(clampIntervalSec(10), 10, 'clamp 10');
eq(clampIntervalSec(3), 3, 'clamp 3 (min)');
eq(clampIntervalSec(2), 3, 'clamp 2 -> 3');
eq(clampIntervalSec(120), 120, 'clamp 120 (max)');
eq(clampIntervalSec(999), 120, 'clamp 999 -> 120');
eq(clampIntervalSec('abc'), 10, 'clamp NaN -> 10');
eq(clampIntervalSec(undefined), 10, 'clamp undefined -> 10');
eq(clampIntervalSec('25'), 25, 'clamp "25" -> 25');
eq(clampIntervalSec(7.9), 7, 'clamp 7.9 -> 7 (floor)');

/* ---------- formatEta ---------- */
eq(formatEta(null), '—', 'eta null');
eq(formatEta(undefined), '—', 'eta undefined');
eq(formatEta(-5), '—', 'eta negative');
eq(formatEta(0), '0s', 'eta 0');
eq(formatEta(45), '45s', 'eta 45s');
eq(formatEta(90), '1m 30s', 'eta 90');
eq(formatEta(600), '10m 0s', 'eta 600');
eq(formatEta(3723), '1h 2m', 'eta 3723');

/* ---------- datedFolderName ---------- */
const ts = new Date(2026, 10, 1, 14, 5).getTime(); // 2026-11-01 14:05 local
// sanitizeProject keeps spaces (legal in download paths — same contract as
// the v2.1 folder names) but strips path-illegal characters.
eq(datedFolderName('Banks Video', ts), 'Banks Video-20261101-1405', 'dated folder banks');
const weird = datedFolderName('  Weird: Project/1? ', ts);
ok(weird.endsWith('-20261101-1405') && !/[\\/:*?"<>|]/.test(weird), 'dated folder sanitizes project: ' + weird);

/* ---------- buildMatchReport ---------- */
const fakeItems = [
  { id: '001A', status: 'done' },
  { id: '002A', status: 'done', dlName: 'flow-image-xyz.png' },
  { id: '003A', status: 'done' },
  { id: '004A', status: 'failed' },
  { id: '005A', status: 'generated' },
  { id: '006A', status: 'pending' }
];
const verifyMap = {
  '001A': { found: true, filename: 'SHEIKH Flow Auto/P/001A.png' },
  '002A': { found: true, filename: 'SHEIKH Flow Auto/P/flow-image-xyz.png' },
  '003A': { found: false, filename: '' }
};
const rep = buildMatchReport(fakeItems, verifyMap);
eq(rep.total, 6, 'report total');
eq(rep.verified, ['001A', '002A'], 'report verified');
eq(rep.missing, ['003A'], 'report missing (done but not found)');
eq(rep.failed, ['004A'], 'report failed');
eq(rep.generated, ['005A'], 'report generated');
eq(rep.pending, ['006A'], 'report pending');
eq(rep.flowNamed, [{ id: '002A', name: 'flow-image-xyz.png' }], 'report flowNamed');
const repEmpty = buildMatchReport([], {});
eq(repEmpty.total, 0, 'report empty total');
eq(repEmpty.missing, [], 'report empty missing');

/* ---------- i18n completeness (panel.js STRINGS) ---------- */
const panel = fs.readFileSync(path.join(ROOT, 'panel.js'), 'utf8');
const dictStart = panel.indexOf('const STRINGS = ');
ok(dictStart !== -1, 'panel.js has STRINGS dictionary');
const litStart = panel.indexOf('{', dictStart);
let depth = 0, litEnd = -1;
for (let i = litStart; i < panel.length; i++) {
  if (panel[i] === '{') depth++;
  else if (panel[i] === '}') { depth--; if (depth === 0) { litEnd = i; break; } }
}
ok(litEnd !== -1, 'STRINGS literal closed');
const STRINGS = new Function('"use strict"; return (' + panel.slice(litStart, litEnd + 1) + ');')();
const langCodes = Object.keys(STRINGS);
eq(langCodes.sort(), ['bn', 'de', 'en', 'es', 'fr', 'hi', 'it', 'tr'].sort(), 'dictionary has exactly the 8 languages');
const enKeys = Object.keys(STRINGS.en).sort();
ok(enKeys.length > 80, 'english key count sane (' + enKeys.length + ')');
for (const code of langCodes) {
  const keys = Object.keys(STRINGS[code]).sort();
  eq(keys, enKeys, 'language "' + code + '" defines exactly the English key set');
  ok(typeof STRINGS[code].help === 'string' && STRINGS[code].help.length > 0, 'language "' + code + '" has help label');
  for (const k of enKeys) {
    ok(typeof STRINGS[code][k] === 'string' && STRINGS[code][k].length > 0, code + '.' + k + ' is a non-empty string');
  }
}
// No empty-value + no leftover untranslated "Help" except en/it? it uses "Aiuto", es "Ayuda".

/* ---------- manifest ---------- */
const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.json'), 'utf8'));
eq(manifest.version, '2.6.1', 'manifest version 2.6.1');
ok(manifest.permissions.includes('notifications'), 'manifest has notifications permission');
ok(manifest.permissions.includes('downloads'), 'manifest keeps downloads permission');
ok(manifest.permissions.includes('debugger'), 'manifest keeps debugger permission');
ok(manifest.permissions.includes('sidePanel'), 'manifest keeps sidePanel permission');

console.log(`\ntest-v22: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
