'use strict';
/* SHEIKH Flow Auto v2.3 unit tests.
   - Pure engine helpers extracted from background.js:
     shouldForceResetLoop (stale-loop reset decision for the
     start/resume handlers) and terminalStatusFor (the run loop's
     single advance decision: done vs generated).
   - Source-level guards for the v2.3 mechanisms that cannot be
     unit-run outside Chrome: the CDP timeout race, the abort-epoch
     wiring, the auto Download-Later pass on natural drain, and the
     Start-handler logging.
   - Manifest version 2.6.1.
   Run: node tests/test-v23.js */
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');

let pass = 0, fail = 0;
function ok(cond, label) {
  if (cond) { pass++; }
  else { fail++; console.log('FAIL: ' + label); }
}
function eq(a, b, label) { ok(JSON.stringify(a) === JSON.stringify(b), label + ` — got ${JSON.stringify(a)}, want ${JSON.stringify(b)}`); }

const bg = fs.readFileSync(path.join(ROOT, 'background.js'), 'utf8');
function extractFn(name) {
  const start = bg.indexOf('function ' + name + '(');
  if (start === -1) throw new Error('function not found: ' + name);
  let i = bg.indexOf('{', start);
  let depth = 0;
  for (; i < bg.length; i++) {
    if (bg[i] === '{') depth++;
    else if (bg[i] === '}') { depth--; if (depth === 0) break; }
  }
  return bg.slice(start, i + 1);
}
const shouldForceResetLoop = new Function('"use strict";\n' + extractFn('shouldForceResetLoop') + '\nreturn shouldForceResetLoop;')();
const terminalStatusFor = new Function('"use strict";\n' + extractFn('terminalStatusFor') + '\nreturn terminalStatusFor;')();

/* ---------- shouldForceResetLoop ---------- */
const NOW = 1000000;
eq(shouldForceResetLoop(false, 0, NOW), false, 'no loop -> never reset');
eq(shouldForceResetLoop(false, NOW - 999999, NOW), false, 'no loop, ancient heartbeat -> still no reset');
eq(shouldForceResetLoop(true, NOW - 1000, NOW), false, 'fresh heartbeat (1s) -> no reset');
eq(shouldForceResetLoop(true, NOW - 19999, NOW), false, 'heartbeat 19.999s old -> no reset');
eq(shouldForceResetLoop(true, NOW - 20000, NOW), false, 'heartbeat exactly 20s old -> no reset (needs >20s)');
eq(shouldForceResetLoop(true, NOW - 20001, NOW), true, 'heartbeat 20.001s old -> reset');
eq(shouldForceResetLoop(true, NOW - 60000, NOW), true, 'heartbeat 60s old -> reset');
eq(shouldForceResetLoop(true, 0, NOW), true, 'loop on, heartbeat never set -> reset');
eq(shouldForceResetLoop(true, undefined, NOW), true, 'loop on, heartbeat undefined -> reset');
eq(shouldForceResetLoop(true, null, NOW), true, 'loop on, heartbeat null -> reset');

/* ---------- terminalStatusFor ---------- */
eq(terminalStatusFor({ generatedOnly: true }), 'generated', 'generatedOnly outcome -> generated');
eq(terminalStatusFor({ generatedOnly: true, note: 'x' }), 'generated', 'generatedOnly wins over note');
eq(terminalStatusFor({ note: '' }), 'done', 'note outcome -> done');
eq(terminalStatusFor({ note: 'fallback-name' }), 'done', 'fallback note -> done');
eq(terminalStatusFor({}), 'done', 'empty outcome -> done');
eq(terminalStatusFor(null), 'done', 'null outcome -> done');
eq(terminalStatusFor(undefined), 'done', 'undefined outcome -> done');

/* ---------- source guards: Bug A mechanisms ---------- */
ok(/function withTimeout\(/.test(bg), 'withTimeout exists');
ok((bg.match(/withTimeout\(chrome\.debugger\.sendCommand/g) || []).length === 2, 'both cdp sendCommand calls are timeout-wrapped (try + retry)');
ok(/withTimeout\(chrome\.debugger\.attach/.test(bg), 'debugger.attach is timeout-wrapped');
ok(/withTimeout\(chrome\.debugger\.detach/.test(bg), 'debugger.detach is timeout-wrapped');
ok(/e\.cdpTimeout/.test(bg), 'cdp treats timeout as detach-class failure');
ok(/async function sleepOrStop\(/.test(bg), 'sleepOrStop exists');
ok((bg.match(/sleepOrStop\(/g) || []).length >= 8, 'sleepOrStop wired into the long waits (found ' + (bg.match(/sleepOrStop\(/g) || []).length + ' uses)');
ok(/function bumpAbortEpoch\(/.test(bg), 'bumpAbortEpoch exists');
const stopCase = bg.slice(bg.indexOf("case 'stop':"), bg.indexOf("case 'stop':") + 400);
ok(/bumpAbortEpoch\(\)/.test(stopCase), 'stop handler bumps the abort epoch');
ok(/function forceResetRun\(/.test(bg), 'forceResetRun exists');
ok(/Start neya holo na: run ekhono cholche/.test(bg), 'start refusal is logged, never silent');
ok(/ager run atke chilo — reset kore notun run shuru/.test(bg), 'start force-reset is logged');
ok(/Engine stopped — notun Start er jonno ready/.test(bg), 'cleanup ready line is logged after stop');
ok(/shouldForceResetLoop\(loopActive, S\.engineHeartbeat, Date\.now\(\)\)/.test(bg), 'handlers use the stale-heartbeat decision');

/* ---------- source guards: Bug B mechanisms ---------- */
ok(/const term = terminalStatusFor\(outcome\);/.test(bg), 'run loop applies the single advance decision');
ok(/generated — download pore hobe/.test(bg), 'generated branch logs "download pore hobe"');
ok(/run sesh — generated gula ekhon download hocche/.test(bg), 'natural drain logs the auto download pass');
const finallyIdx = bg.indexOf('const autoPass = drained && c.generated > 0 && !stopRequested && !wantRound;');
ok(finallyIdx !== -1, 'autoPass is computed on natural drain (not stopped, no retry round)');
ok(/downloadGeneratedPass\(\)\.catch/.test(bg), 'auto pass is invoked from the run finally with error logging');

/* ---------- manifest ---------- */
const manifest = JSON.parse(fs.readFileSync(path.join(ROOT, 'manifest.json'), 'utf8'));
eq(manifest.version, '2.6.1', 'manifest version 2.6.1');

console.log(`\ntest-v23: ${pass} passed, ${fail} failed`);
process.exit(fail ? 1 : 0);
